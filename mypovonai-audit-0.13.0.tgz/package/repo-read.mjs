/**
 * Everything the fleet needs to know about a repository, learned by READING FILES -- never by
 * running git.
 *
 * The audited repo is untrusted. Its `.git/config` (and includes, submodule config, `core.worktree`,
 * attribute filters, hooks) can make git execute commands or touch paths outside the repo, and
 * blocklisting config keys is a losing game. So the package never spawns git against the target.
 * This module answers the same questions by plain reads:
 *
 *   commitOf       .git/HEAD -> ref -> loose ref or packed-refs. Anything odd -> null.
 *   remoteUrlOf    a tiny INI read of [remote "origin"] url. Includes are IGNORED, never followed.
 *   listRepoFiles  a walk of the files ON DISK (minus dependency/VCS/build dirs and .gitignore'd
 *                  paths), symlinks never followed. It is "files on disk", not "tracked files".
 *   snapshots      byte-for-byte copies of the tree, so `fix` can revert and emit a patch without git.
 */
import { createHash } from "node:crypto";
import { lstatSync, readdirSync, readFileSync, realpathSync, statSync } from "node:fs";
import { dirname, isAbsolute, join, resolve } from "node:path";

import { isBuildOutputPath, readContained, rmdirContained, unlinkContained, writeContained } from "./paths.mjs";

const MAX_FILES = 200_000;
const readText = (p) => {
  try {
    return readFileSync(p, "utf8");
  } catch {
    return null;
  }
};
const isDir = (p) => {
  try {
    return statSync(p).isDirectory();
  } catch {
    return false;
  }
};

/**
 * The directory holding HEAD and refs. `.git` as a directory, or as a FILE (`gitdir: <path>`: a
 * worktree or submodule). The target must be an existing plain directory; it is only ever READ.
 * Returns { gitDir, commonDir } or null.
 */
export function resolveGitDir(repoPath) {
  const dotgit = join(repoPath, ".git");
  let st;
  try {
    st = lstatSync(dotgit);
  } catch {
    return null;
  }
  let gitDir = null;
  if (st.isDirectory()) gitDir = dotgit;
  else if (st.isFile()) {
    const m = (readText(dotgit) ?? "").match(/^gitdir:\s*(.+?)\s*$/m);
    if (!m || m[1].includes("\0")) return null;
    gitDir = isAbsolute(m[1]) ? m[1] : resolve(repoPath, m[1]);
  }
  if (!gitDir || !isDir(gitDir)) return null;
  // A worktree's gitdir names its shared dir in `commondir` (a path, read, never executed).
  let commonDir = gitDir;
  const c = readText(join(gitDir, "commondir"))?.trim();
  if (c && !c.includes("\0")) {
    const cd = isAbsolute(c) ? c : resolve(gitDir, c);
    if (isDir(cd)) commonDir = cd;
  }
  return { gitDir, commonDir };
}

const SHA = /^[0-9a-f]{40}([0-9a-f]{24})?$/;
const REF = /^refs\/[A-Za-z0-9._\/+-]+$/;

function lookupRef(dirs, ref) {
  if (!REF.test(ref) || ref.includes("..") || ref.includes("//")) return null;
  for (const d of dirs) {
    const loose = readText(join(d, ref))?.trim();
    if (loose && SHA.test(loose)) return loose;
  }
  for (const d of dirs) {
    const packed = readText(join(d, "packed-refs"));
    if (!packed) continue;
    for (const line of packed.split("\n")) {
      const m = line.match(/^([0-9a-f]{40}(?:[0-9a-f]{24})?) (\S+)$/);
      if (m && m[2] === ref) return m[1];
    }
  }
  return null;
}

/** HEAD's commit sha, or null when it cannot be read plainly (never throws, never executes). */
export function commitOf(repoPath) {
  const g = resolveGitDir(repoPath);
  if (!g) return null;
  const head = readText(join(g.gitDir, "HEAD"))?.trim();
  if (!head) return null;
  if (SHA.test(head)) return head;
  const m = head.match(/^ref:\s*(\S+)$/);
  return m ? lookupRef([...new Set([g.gitDir, g.commonDir])], m[1]) : null;
}

/** `url` of [remote "origin"] from the repo config, includes ignored; null if absent. */
export function remoteUrlOf(repoPath) {
  const g = resolveGitDir(repoPath);
  if (!g) return null;
  for (const d of [...new Set([g.commonDir, g.gitDir])]) {
    const text = readText(join(d, "config"));
    if (!text) continue;
    let inOrigin = false;
    for (const raw of text.split("\n")) {
      const line = raw.trim();
      const sec = line.match(/^\[\s*([A-Za-z0-9.-]+)(?:\s+"((?:[^"\\]|\\.)*)")?\s*\]/);
      if (sec) {
        inOrigin = sec[1].toLowerCase() === "remote" && sec[2] === "origin";
        continue;
      }
      const kv = inOrigin && line.match(/^url\s*=\s*(.+)$/i);
      if (kv) return kv[1].replace(/^"(.*)"$/, "$1").trim() || null;
    }
  }
  return null;
}

// ---- .gitignore (a subset: comments, negation, anchoring, dir-only, * ? **) --------------------

function globToRegex(pat) {
  let re = "";
  for (let i = 0; i < pat.length; i += 1) {
    const ch = pat[i];
    if (ch === "*") {
      if (pat[i + 1] === "*") {
        i += 1;
        if (pat[i + 1] === "/") {
          i += 1;
          re += "(?:.*/)?";
        } else re += ".*";
      } else re += "[^/]*";
    } else if (ch === "?") re += "[^/]";
    else re += ch.replace(/[.+^${}()|[\]\\]/g, "\\$&");
  }
  return re;
}

/** Parses one .gitignore into rules relative to its own directory. */
function parseIgnore(text, base) {
  const rules = [];
  for (let line of text.split("\n")) {
    line = line.replace(/\r$/, "");
    if (!line.trim() || line.startsWith("#")) continue;
    let neg = false;
    if (line.startsWith("!")) {
      neg = true;
      line = line.slice(1);
    }
    line = line.replace(/(?<!\\)\s+$/, "");
    const dirOnly = line.endsWith("/");
    if (dirOnly) line = line.slice(0, -1);
    const anchored = line.includes("/");
    line = line.replace(/^\//, "");
    if (!line) continue;
    rules.push({ neg, dirOnly, base, re: new RegExp(`^${anchored ? "" : "(?:.*/)?"}${globToRegex(line)}$`) });
  }
  return rules;
}

function ignored(rules, rel, isDirectory) {
  let result = false;
  for (const r of rules) {
    if (r.dirOnly && !isDirectory) continue;
    const sub = r.base ? (rel.startsWith(`${r.base}/`) ? rel.slice(r.base.length + 1) : null) : rel;
    if (sub === null) continue;
    if (r.re.test(sub)) result = !r.neg;
  }
  return result;
}

const isSkippedDir = (name) => name === "node_modules" || name === ".git";

/**
 * Every regular file under the repo root, relative, sorted. Never follows a symlink, never descends
 * into node_modules/.git/build output, honours .gitignore files met on the way down.
 */
export function listRepoFiles(repoPath, { respectGitignore = true, includeIgnoredBuild = false } = {}) {
  const out = [];
  const walk = (rel, inherited) => {
    if (out.length >= MAX_FILES) return;
    let entries;
    try {
      entries = readdirSync(join(repoPath, rel), { withFileTypes: true });
    } catch {
      return;
    }
    let rules = inherited;
    if (respectGitignore) {
      const gi = entries.find((e) => e.name === ".gitignore" && e.isFile());
      if (gi) {
        const t = readText(join(repoPath, rel, ".gitignore"));
        if (t) rules = [...inherited, ...parseIgnore(t, rel)];
      }
    }
    for (const e of entries) {
      const r = rel ? `${rel}/${e.name}` : e.name;
      if (e.isSymbolicLink()) continue;
      if (e.isDirectory()) {
        if (isSkippedDir(e.name)) continue;
        if (!includeIgnoredBuild && isBuildOutputPath(`${r}/x`)) continue;
        if (respectGitignore && ignored(rules, r, true)) continue;
        walk(r, rules);
      } else if (e.isFile()) {
        if (respectGitignore && ignored(rules, r, false)) continue;
        out.push(r);
      }
    }
  };
  walk("", []);
  return out.sort();
}

/** Files whose CONTENT must never reach a model prompt even if present on disk. */
export const SECRET_FILE = /(^|\/)(\.env(\.(?!example$|sample$|template$|dist$)[^/]*)?|\.npmrc|\.netrc|\.pypirc|id_(rsa|dsa|ecdsa|ed25519)[^/]*|[^/]*\.(pem|key|p12|pfx|keystore|jks)|credentials(\.json)?|\.dev\.vars[^/]*)$/i;

// ---- snapshots: revert + patch without git ------------------------------------------------------

const MAX_SNAP_FILE = 4 * 1024 * 1024;

/**
 * Byte-exact copy of every file under the root (build output and dependency dirs excluded; ignored
 * files INCLUDED so a revert never deletes the operator's ignored files). `prev` makes it cheap:
 * a file whose size+mtime is unchanged is reused, not re-read.
 */
export function takeSnapshot(repoPath, prev = null) {
  const snap = new Map();
  for (const rel of listRepoFiles(repoPath, { respectGitignore: false })) {
    let st;
    try {
      st = lstatSync(join(repoPath, rel));
    } catch {
      continue;
    }
    if (!st.isFile()) continue;
    const old = prev?.get(rel);
    if (old && old.size === st.size && old.mtimeMs === st.mtimeMs) {
      snap.set(rel, old);
      continue;
    }
    // Contained read: a symlink (or a swapped-in one) is skipped, never followed.
    let content;
    try {
      content = readContained(repoPath, rel);
    } catch {
      continue;
    }
    const big = content.length > MAX_SNAP_FILE;
    snap.set(rel, {
      size: st.size,
      mtimeMs: st.mtimeMs,
      mode: st.mode & 0o777,
      buf: big ? null : content,
      hash: big ? createHash("sha256").update(content).digest("hex") : null,
    });
  }
  return snap;
}

function sameAsEntry(repoPath, rel, e) {
  let cur;
  try {
    cur = readContained(repoPath, rel);
  } catch {
    return false;
  }
  return e.buf ? e.buf.equals(cur) : createHash("sha256").update(cur).digest("hex") === e.hash;
}

/** Paths that differ from `snap`: { modified, created, deleted }. */
export function diffSnapshot(repoPath, snap) {
  const now = takeSnapshot(repoPath, snap);
  const modified = [];
  const created = [];
  const deleted = [];
  for (const [rel, e] of now) {
    const o = snap.get(rel);
    if (!o) created.push(rel);
    else if (o !== e && !sameAsEntry(repoPath, rel, o)) modified.push(rel);
  }
  for (const rel of snap.keys()) if (!now.has(rel)) deleted.push(rel);
  return { modified, created, deleted };
}

/**
 * Puts the tree back to `snap`: rewrites modified files, removes files created since, restores deleted
 * ones. EVERY filesystem effect goes through the contained helpers in paths.mjs (O_NOFOLLOW on the final
 * component, each parent a real directory, same-inode check, no symlinks or hardlinks), so a symlink
 * planted at -- or above -- a path can never redirect a write or a delete outside the repository.
 * A path that fails containment is left alone and reported in the returned `refused` list.
 */
export function restoreSnapshot(repoPath, snap) {
  const d = diffSnapshot(repoPath, snap);
  const refused = [];
  for (const rel of d.created) {
    try {
      unlinkContained(repoPath, rel);
      pruneEmptyDirs(repoPath, rel);
    } catch (error) {
      refused.push({ rel, why: String(error?.message ?? error) });
    }
  }
  for (const rel of [...d.modified, ...d.deleted]) {
    const e = snap.get(rel);
    if (!e.buf) {
      refused.push({ rel, why: "too large to snapshot" });
      continue;
    }
    try {
      writeContainedRestore(repoPath, rel, e);
    } catch (error) {
      refused.push({ rel, why: String(error?.message ?? error) });
    }
  }
  return { refused };
}

function writeContainedRestore(repoPath, rel, e) {
  let exists = true;
  try {
    lstatSync(join(repoPath, rel));
  } catch {
    exists = false;
  }
  // A path that exists is vetted against the same real path; a missing one is created under verified parents.
  const expected = exists ? { abs: join(realpathSync(repoPath), rel) } : undefined;
  writeContained(repoPath, rel, e.buf, expected, e.mode);
}

function pruneEmptyDirs(repoPath, rel) {
  let d = dirname(rel);
  while (d && d !== ".") {
    try {
      rmdirContained(repoPath, d);
    } catch {
      return;
    }
    d = dirname(d);
  }
}

// ---- a git-style unified patch, computed in JS --------------------------------------------------

function lineDiff(a, b) {
  let s = 0;
  while (s < a.length && s < b.length && a[s] === b[s]) s += 1;
  let e = 0;
  while (e < a.length - s && e < b.length - s && a[a.length - 1 - e] === b[b.length - 1 - e]) e += 1;
  const A = a.slice(s, a.length - e);
  const B = b.slice(s, b.length - e);
  const ops = [];
  for (let i = 0; i < s; i += 1) ops.push([" ", a[i]]);
  if (A.length * B.length > 4_000_000) {
    for (const l of A) ops.push(["-", l]);
    for (const l of B) ops.push(["+", l]);
  } else {
    const n = A.length;
    const m = B.length;
    const L = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1));
    for (let i = n - 1; i >= 0; i -= 1) for (let j = m - 1; j >= 0; j -= 1) L[i][j] = A[i] === B[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
    let i = 0;
    let j = 0;
    while (i < n && j < m) {
      if (A[i] === B[j]) {
        ops.push([" ", A[i]]);
        i += 1;
        j += 1;
      } else if (L[i + 1][j] >= L[i][j + 1]) ops.push(["-", A[i++]]);
      else ops.push(["+", B[j++]]);
    }
    while (i < n) ops.push(["-", A[i++]]);
    while (j < m) ops.push(["+", B[j++]]);
  }
  for (let k = a.length - e; k < a.length; k += 1) ops.push([" ", a[k]]);
  return ops;
}

function splitLines(buf) {
  if (buf.length === 0) return { lines: [], noEol: false };
  const t = buf.toString("utf8");
  const noEol = !t.endsWith("\n");
  const lines = t.split("\n");
  if (!noEol) lines.pop();
  return { lines, noEol };
}

function hunksFor(oldBuf, newBuf, ctx = 3) {
  const o = splitLines(oldBuf);
  const n = splitLines(newBuf);
  const ops = lineDiff(o.lines, n.lines);
  const changed = ops.map(([t], i) => (t === " " ? -1 : i)).filter((i) => i >= 0);
  if (changed.length === 0 && o.noEol === n.noEol) return "";
  const groups = [];
  for (const i of changed) {
    const last = groups[groups.length - 1];
    if (last && i - last[1] <= ctx * 2) last[1] = i;
    else groups.push([i, i]);
  }
  let oldNo = 0;
  let newNo = 0;
  const pos = ops.map(([t]) => {
    const p = [oldNo, newNo];
    if (t !== "+") oldNo += 1;
    if (t !== "-") newNo += 1;
    return p;
  });
  let out = "";
  for (const [gs, ge] of groups) {
    const from = Math.max(0, gs - ctx);
    const to = Math.min(ops.length - 1, ge + ctx);
    let oc = 0;
    let nc = 0;
    let body = "";
    for (let i = from; i <= to; i += 1) {
      const [t, line] = ops[i];
      if (t !== "+") oc += 1;
      if (t !== "-") nc += 1;
      const lastOld = t !== "+" && pos[i][0] === o.lines.length - 1;
      const lastNew = t !== "-" && pos[i][1] === n.lines.length - 1;
      body += `${t}${line}\n`;
      if ((t === " " && lastOld && lastNew && (o.noEol || n.noEol)) || (t === "-" && lastOld && o.noEol) || (t === "+" && lastNew && n.noEol)) {
        body += "\\ No newline at end of file\n";
      }
    }
    const os = oc === 0 ? pos[from][0] : pos[from][0] + 1;
    const ns = nc === 0 ? pos[from][1] : pos[from][1] + 1;
    out += `@@ -${os}${oc === 1 ? "" : `,${oc}`} +${ns}${nc === 1 ? "" : `,${nc}`} @@\n${body}`;
  }
  return out;
}

const isBinary = (buf) => buf.includes(0);
const readSafe = (repoPath, rel) => {
  try {
    return readContained(repoPath, rel);
  } catch {
    return null;
  }
};

/** A `git apply`-able patch of everything that changed since `snap` (text files; binaries are skipped). */
export function patchSince(repoPath, snap) {
  const d = diffSnapshot(repoPath, snap);
  let patch = "";
  const modeOf = (rel) => (lstatSync(join(repoPath, rel)).mode & 0o111 ? "100755" : "100644");
  for (const rel of [...d.modified].sort()) {
    const o = snap.get(rel);
    const nb = readSafe(repoPath, rel);
    if (!nb || !o.buf || isBinary(o.buf) || isBinary(nb)) continue;
    const h = hunksFor(o.buf, nb);
    if (h) patch += `diff --git a/${rel} b/${rel}\n--- a/${rel}\n+++ b/${rel}\n${h}`;
  }
  for (const rel of [...d.created].sort()) {
    const nb = readSafe(repoPath, rel);
    if (!nb || isBinary(nb)) continue;
    const h = hunksFor(Buffer.alloc(0), nb);
    patch += `diff --git a/${rel} b/${rel}\nnew file mode ${modeOf(rel)}\n--- /dev/null\n+++ b/${rel}\n${h}`;
  }
  for (const rel of [...d.deleted].sort()) {
    const o = snap.get(rel);
    if (!o.buf || isBinary(o.buf)) continue;
    patch += `diff --git a/${rel} b/${rel}\ndeleted file mode 100644\n--- a/${rel}\n+++ /dev/null\n${hunksFor(o.buf, Buffer.alloc(0))}`;
  }
  return patch;
}
