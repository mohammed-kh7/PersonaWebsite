#!/usr/bin/env bash
# agent-setup N/A gate — the seven agent-setup lenses must (1) answer `skipped`, with zero
# findings, on a product repo, and (2) stay fast on a ~/.claude-shaped dir full of transcripts.
# The list is EXPLICIT: agent-security and agent-containment are product lenses and also
# match probes/agent-*.sh, so a glob would grade them as agent-setup lenses.
set -uo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"; fail=0
AGENT_SETUP_LENSES="agent-hook-registration agent-secrets-in-config agent-skill-duplicates agent-context-budget agent-dead-mcp agent-silent-checklist agent-prose-only-rule"
for l in $AGENT_SETUP_LENSES; do
  p="$DIR/probes/$l.sh"
  [ -f "$p" ] || { echo "N/A FAIL: probes/$l.sh does not exist"; fail=1; continue; }
  out="$(bash "$p" "$DIR/fixtures/security" 2>/dev/null)"
  [ "$(printf '%s' "$out" | grep -c '"type":"finding"')" -eq 0 ] || { echo "N/A FAIL: $l found on a product repo"; fail=1; }
  [ "$(printf '%s' "$out" | grep -c '"type":"skipped"')" -eq 1 ] || { echo "N/A FAIL: $l did not report exactly one skipped"; fail=1; }
done
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT; mkdir -p "$T/projects/x"; echo '# x' > "$T/CLAUDE.md"
for i in $(seq 1 2000); do echo '{}' > "$T/projects/x/$i.jsonl"; done
s=$(date +%s)
for l in $AGENT_SETUP_LENSES; do bash "$DIR/probes/$l.sh" "$T" >/dev/null 2>&1; done
e=$(( $(date +%s) - s ))
[ "$e" -le 5 ] || { echo "SLOW: agent probes took ${e}s over a transcript-heavy dir"; fail=1; }
# agent-secrets-in-config must NEVER print the secret it found: not in the finding, not
# in the evidence command's own output.
FX="$DIR/fixtures/agent-secrets-in-config"
sec="$(bash "$DIR/probes/agent-secrets-in-config.sh" "$FX" 2>/dev/null)"
[ "$(printf '%s' "$sec" | grep -c 'AAFAKE')" -eq 0 ] || { echo "LEAK: probe output contains the fake token body"; fail=1; }
[ "$(printf '%s' "$sec" | grep -c '"type":"finding"')" -ge 1 ] || { echo "agent-secrets-in-config did not fire on its fixture"; fail=1; }
ev="$(printf '%s' "$sec" | grep '"type":"evidence"' | while IFS= read -r l; do
  cmd="$(printf '%s' "$l" | node -e 'let d="";process.stdin.on("data",c=>d+=c).on("end",()=>process.stdout.write(JSON.parse(d).cmd))')"
  (cd "$FX" && bash -c "$cmd" 2>&1)
done)"
[ "$(printf '%s' "$ev" | grep -c 'AAFAKE')" -eq 0 ] || { echo "LEAK: evidence output contains the fake token body"; fail=1; }

# A real ~/.claude holds tens of thousands of vendored plugin files. The probes must PRUNE
# them (plugins/ registers its own hooks via hooks.json), finish quickly, and not report a
# vendored hook or a helper module as an unregistered hook of THIS setup.
P="$(mktemp -d)"; trap 'rm -rf "$T" "$P"' EXIT
echo '# x' > "$P/CLAUDE.md"; echo '{"hooks":{}}' > "$P/settings.json"
mkdir -p "$P/plugins/cache/a" "$P/plugins/marketplaces/m/hooks" "$P/removed-old/hooks" "$P/hooks"
for i in $(seq 1 5000); do printf '# note %s\n' "$i" > "$P/plugins/cache/a/f$i.md"; done
printf '#!/usr/bin/env bash\n# claude-hook: PreToolUse\n' > "$P/plugins/marketplaces/m/hooks/vendored.sh"
printf '#!/usr/bin/env bash\n# claude-hook: PreToolUse\n' > "$P/removed-old/hooks/old.sh"
printf 'def helper(): pass\n' > "$P/hooks/_base.py"
printf '# see "# claude-hook: <Event>" in the docs\n' > "$P/hooks/mentions.sh"
s=$(date +%s)
pout="$(for l in $AGENT_SETUP_LENSES; do bash "$DIR/probes/$l.sh" "$P" 2>/dev/null; done)"
e=$(( $(date +%s) - s ))
[ "$e" -le 10 ] || { echo "SLOW: 7 agent probes took ${e}s over a plugins/cache of 5,000 files (budget 10s)"; fail=1; }
[ "$(printf '%s' "$pout" | grep -c '"type":"finding"')" -eq 0 ] || { echo "FP: vendored/helper/mention files reported:"; printf '%s\n' "$pout" | grep '"type":"finding"' | cut -c1-200; fail=1; }

exit $fail
