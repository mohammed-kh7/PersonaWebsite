import { execFileSync, spawnSync } from "node:child_process";
import { mkdtempSync, symlinkSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { expect, test } from "vitest";

import { isMain } from "../is-main.mjs";

/**
 * The way a CUSTOMER invokes the CLI, which is the one way it was never tested.
 *
 * npm links a bin as a symlink, so `process.argv[1]` is the link while
 * `import.meta.url` is the resolved file. The old guard compared those two
 * strings and silently never ran `main()` — `npx mypovonai-audit run` exited 0
 * having printed nothing, in every published version from 0.1.0 to 0.6.0.
 *
 * Every other test in this repo executes these files by their real path, which
 * is why a whole suite stayed green over a CLI that did not work for anyone.
 */
const FLEET = dirname(fileURLToPath(new URL("../cli.mjs", import.meta.url)));

test("the entry guard matches when invoked through a symlink", () => {
  const dir = mkdtempSync(join(tmpdir(), "entrypoint-"));
  const real = join(dir, "real.mjs");
  const link = join(dir, "bin-shim");
  // Extensionless, exactly like `/usr/local/bin/mypovonai-audit`.
  writeFileSync(
    real,
    `import { isMain } from ${JSON.stringify(join(FLEET, "is-main.mjs"))};
     console.log(isMain(import.meta.url) ? "RAN" : "SILENT");`,
  );
  symlinkSync(real, link);

  const viaLink = execFileSync(process.execPath, [link], { encoding: "utf8" }).trim();
  const viaReal = execFileSync(process.execPath, [real], { encoding: "utf8" }).trim();

  expect(viaReal).toBe("RAN");
  // The regression. This said SILENT for every installed copy.
  expect(viaLink).toBe("RAN");
});

test("the entry guard survives a path containing a space and a hash", () => {
  // `file://${path}` produced a malformed URL for these, so the guard failed
  // the same silent way for anyone whose project lived in "My Repo".
  const dir = mkdtempSync(join(tmpdir(), "entry point #1-"));
  const real = join(dir, "real.mjs");
  writeFileSync(
    real,
    `import { isMain } from ${JSON.stringify(join(FLEET, "is-main.mjs"))};
     console.log(isMain(import.meta.url) ? "RAN" : "SILENT");`,
  );
  expect(execFileSync(process.execPath, [real], { encoding: "utf8" }).trim()).toBe("RAN");
});

test("a module that is NOT the entry point still reports false", () => {
  // The guard has to keep saying no when these files are imported as libraries,
  // or `run.mjs` would execute itself every time `cli.mjs` imports it.
  expect(isMain("file:///somewhere/else/not-the-entry.mjs")).toBe(false);
});

test("the real CLI prints usage when invoked through a symlink", () => {
  // End to end against the shipped entry point, not a stand-in.
  const dir = mkdtempSync(join(tmpdir(), "cli-shim-"));
  const link = join(dir, "mypovonai-audit");
  symlinkSync(join(FLEET, "cli.mjs"), link);

  // `spawnSync`, not `execFileSync`: this command writes its usage to STDERR
  // and exits 0. `execFileSync` returns stdout and only exposes stderr when it
  // THROWS, so the first version of this test read an empty string and failed
  // against a CLI that was working. Capture both streams unconditionally.
  const result = spawnSync(process.execPath, [link, "--help"], { encoding: "utf8", env: { ...process.env, MYPOVONAI_KEY: "", MYPOVONAI_ENDPOINT: "http://127.0.0.1:1" } });
  expect(result.stderr).toContain("mypovonai-audit");
  expect(result.stderr).toContain("login <key>");
});
