#!/usr/bin/env bash
# Every probe MUST fire on its known-bad fixture. A probe that stays silent on
# a fixture designed to break it is a dead gate — it would score a broken repo
# as clean. This test is the guard against that.
# (Born from [[feedback-guard-passes-without-testing-anything]]: FWB + CRM
# secretlint hooks were declared-but-uninstalled and failed OPEN for weeks.)
set -uo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"

# Run the fixtures from a COPY outside the install path.
#
# Twenty-two probes exclude `-not -path '*/node_modules/*'`, which matches
# anywhere in the ABSOLUTE path — not just inside the tree being scanned. Once
# this package is installed as a dependency its fixtures live under
# `node_modules/mypovonai-audit/fixtures`, so every source-scanning probe
# excluded its own known-bad input: measured on a real `npm install` of the
# tarball, 17 of 29 gates went dead and the CLI refused to run at all.
#
# Copying is the fix that does not touch twenty-two calibrated probes, and it
# makes this check independent of where the package happens to sit — which is
# what a gate about the probes should be.
FIXTURE_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/fleet-fixtures-XXXXXX")"
trap 'rm -rf "$FIXTURE_ROOT"' EXIT
cp -R "$DIR/fixtures/." "$FIXTURE_ROOT/" 2>/dev/null || {
  echo "could not stage fixtures"; exit 1;
}

fail=0
found_any=0
for probe in "$DIR"/probes/*.sh; do
  [ -e "$probe" ] || continue
  id="$(basename "$probe" .sh)"
  [ "$id" = "_lib" ] && continue
  found_any=1
  fx="$FIXTURE_ROOT/$id"
  if [ ! -d "$fx" ]; then
    echo "NO FIXTURE for probe $id — cannot prove it fires"
    fail=1
    continue
  fi
  out=$(bash "$probe" "$fx" 2>/dev/null)
  n=$(printf '%s' "$out" | grep -c '"severity"')
  if [ "$n" -eq 0 ]; then
    echo "DEAD GATE: $id produced 0 findings on its known-bad fixture"
    fail=1
    continue
  fi
  # A fixture may pin the SPECIFIC finding it exists to trigger via
  # expected.grep. Without this, a probe can pass by firing on an unrelated
  # criterion while the one the fixture targets is silently dead — which is
  # exactly what happened to the rls writer-coverage check on first write.
  if [ -f "$fx/expected.grep" ]; then
    miss=0
    while IFS= read -r pat; do
      [ -z "$pat" ] && continue
      # A here-string, NOT `printf | grep -q`: under `set -o pipefail` grep -q exits
      # at the first match, printf then dies of SIGPIPE (141) while still writing,
      # and the pipeline reports "no match" for a finding that IS there. Intermittent,
      # load-dependent, and a different gate each run -- it falsely killed 1-3 of 64
      # gates in CI whenever the machine was busy (see also probes/money.sh).
      grep -q "$pat" <<<"$out" || { echo "DEAD GATE: $id missing expected finding: $pat"; miss=1; }
    done < "$fx/expected.grep"
    [ "$miss" -eq 1 ] && { fail=1; continue; }
  fi
  echo "ok: $id fired $n finding(s) on fixture"
done
if [ "$found_any" -eq 0 ]; then
  echo "NO PROBES FOUND — nothing to test"
  fail=1
fi
exit $fail
