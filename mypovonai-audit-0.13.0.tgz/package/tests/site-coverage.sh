#!/usr/bin/env bash
# Second-order coverage: does each probe's fixture reach every finding site the
# probe DECLARES?
#
# probe-fires.sh proves a probe is alive. It does NOT prove every CRITERION in
# that probe is alive. A probe with five checks whose fixture trips one reports
# "ok: fired 1 finding(s)" and the other four have never been observed to fire
# in their lives -- they will report clean on any repo, forever, and nothing in
# the system says so. Measured 2026-09-11: 13 of 29 probes were fully covered.
#
# Exit 0 = every declared finding site is exercised by its fixture.
set -uo pipefail
cd "$(dirname "$0")/.." || exit 1

# Same staging as probe-fires.sh, for the same reason: the probes' node_modules
# exclusion matches the absolute path, so fixtures sitting under an installed
# package are invisible to the very probes they exist to prove.
FIXTURE_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/fleet-sites-XXXXXX")"
trap 'rm -rf "$FIXTURE_ROOT"' EXIT
cp -R fixtures/. "$FIXTURE_ROOT/" 2>/dev/null || { echo "could not stage fixtures"; exit 1; }

fail=0
total_sites=0; total_hit=0
for probe in probes/*.sh; do
  lens="$(basename "$probe" .sh)"
  [ "$lens" = "_lib" ] && continue
  [ -d "$FIXTURE_ROOT/$lens" ] || { echo "NO FIXTURE: $lens"; fail=1; continue; }

  # Declared: every line that calls `finding`. `grep -n` gives the line number,
  # which is exactly what _lib.sh stamps into each finding's `site`.
  declared="$(grep -n '^[[:space:]]*finding ' "$probe" | cut -d: -f1 | sort -u)"
  # Union over the primary fixture AND any variants. Some finding sites are
  # alternatives of one if/else -- `cicd` line 9 fires only when there is NO
  # .github/workflows, which the primary fixture must have to reach every check
  # below it. One fixture can never reach both, so a lens may carry
  # `fixtures/<lens>.b`, `.c`, ... each a different known-bad shape.
  hit="$(for fx in "$FIXTURE_ROOT/$lens" "$FIXTURE_ROOT/$lens".*; do
           [ -d "$fx" ] || continue
           bash "$probe" "$fx" 2>/dev/null
         done | sed -n 's/.*"site":"[^:]*:\([0-9]*\)".*/\1/p' | sort -u)"

  n_dec=$(printf '%s\n' "$declared" | grep -c . || true)
  n_hit=$(comm -12 <(printf '%s\n' "$declared") <(printf '%s\n' "$hit") | grep -c . || true)
  total_sites=$((total_sites + n_dec)); total_hit=$((total_hit + n_hit))

  missing="$(comm -23 <(printf '%s\n' "$declared") <(printf '%s\n' "$hit") | tr '\n' ' ')"
  if [ -n "${missing// /}" ]; then
    echo "UNPROVEN GATE: $lens — fixture never reaches $probe line(s): $missing"
    fail=1
  else
    echo "ok: $lens $n_hit/$n_dec finding sites exercised"
  fi
done

echo "---"
echo "finding sites: $total_hit/$total_sites exercised by a fixture"
[ "$fail" = "0" ] || { echo "FAIL: a declared gate with no negative control reports clean forever."; exit 1; }
