#!/usr/bin/env bash
# no-leak gate — a probe must never print the credential it found.
#
# Source excerpts are withheld from uploads. Probe output and local judge context
# must still mask credentials, so a secrets probe that quotes
# the secret turns an audit into a leak. Each fixture declares its own forbidden
# literals in `secrets.txt`; this runs the lens over the fixture and fails if
# any of them appears in the output.
#
# It ALSO fails when a declared literal is missing from the fixture source. A
# gate whose subject has been renamed away passes forever while checking
# nothing -- that is the failure mode, not a false alarm.
set -uo pipefail
cd "$(dirname "$0")/.."
fail=0; checked=0; fixtures=0
for list in fixtures/*/secrets.txt; do
  [ -f "$list" ] || continue
  fx="$(dirname "$list")"; name="$(basename "$fx")"; lens="${name%.clean}"
  fx="$(cd "$fx" && pwd)"
  probe="probes/${lens}.sh"
  if [ ! -f "$probe" ]; then
    printf 'no-leak: %s declares secrets but probes/%s.sh does not exist\n' "$name" "$lens" >&2
    fail=1; continue
  fi
  fixtures=$((fixtures + 1))
  out="$(bash "$probe" "$fx" 2>&1)"
  # Execute the actual recorded evidence path through the production collector.
  # Checking only JSON leaves raw sed/grep source leaks invisible.
  evidence_out="$(printf '%s\n' "$out" | node --input-type=module -e '
    import { collectEvidence } from "./run.mjs";
    let raw = "";
    for await (const chunk of process.stdin) raw += chunk;
    for (const line of raw.split("\n")) {
      if (!line.trim()) continue;
      const row = JSON.parse(line);
      if (row.type === "evidence") console.log(collectEvidence(row.cmd, process.argv[1]));
    }
  ' "$fx")" || { printf 'no-leak: evidence collector failed for %s\n' "$name" >&2; fail=1; }
  out="$out
$evidence_out"
  src="$(find "$fx" -type f ! -name 'secrets.txt' ! -name 'expected.grep' 2>/dev/null)"
  [ -n "$src" ] || { printf 'no-leak: %s has no source files besides its own lists\n' "$name" >&2; fail=1; continue; }
  while IFS= read -r lit; do
    case "$lit" in ''|'#'*) continue ;; esac
    checked=$((checked + 1))
    # positive control: the literal must still be IN the fixture
    # The file list is built HERE, not with grep's --include/--exclude: those
    # sit after `--`, which ends option parsing, so grep took them as FILENAMES
    # and every filter was silently inert. secrets.txt must be excluded because
    # it lives inside the fixture -- grepping the whole directory made every
    # declared literal vouch for itself, and a literal present in no source file
    # passed the control on its own echo.
    if ! printf '%s\n' "$src" | tr '\n' '\0' | xargs -0 grep -qF "$lit" 2>/dev/null; then
      printf 'no-leak: %s lists a literal absent from the fixture source (%.6s…) — the check has nothing to catch\n' "$name" "$lit" >&2
      fail=1; continue
    fi
    if grep -qF -- "$lit" <<<"$out"; then
      printf 'LEAK  %s: probe printed a declared secret (%.6s…, %d chars)\n' "$lens" "$lit" "${#lit}" >&2
      fail=1
    fi
  done < "$list"
done
if [ "$fixtures" -eq 0 ]; then
  printf 'no-leak: no fixture declares secrets.txt — nothing proven\n' >&2
  exit 1
fi
if [ "$fail" -eq 0 ]; then
  printf 'no-leak: %d literals across %d fixtures, none printed\n' "$checked" "$fixtures"
else
  printf 'no-leak: FAILED\n' >&2
fi
exit "$fail"
