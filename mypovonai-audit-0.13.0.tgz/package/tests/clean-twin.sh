#!/usr/bin/env bash
# clean-twin gate — every fixtures/<lens>.clean/ must produce ZERO findings.
#
# The failure this pack exists to avoid is not silence, it is NOISE: an earlier
# attempt at route authorization emitted 110 findings on one Laravel repo, none
# of them real, which is the same as emitting none. A known-bad fixture proves a
# lens can fire; only its clean twin proves it can stay quiet.
#
# A twin with no probe, or a lens whose known-bad fixture is missing, fails
# here too — a twin alone would let a permanently-silent probe look correct.
set -uo pipefail
cd "$(dirname "$0")/.."
fail=0; twins=0
for fx in fixtures/*.clean/; do
  name="$(basename "${fx%/}")"; lens="${name%.clean}"
  probe="probes/${lens}.sh"
  if [ ! -f "$probe" ]; then
    printf 'clean-twin: %s has no probes/%s.sh\n' "$name" "$lens" >&2; fail=1; continue
  fi
  if [ ! -d "fixtures/${lens}" ]; then
    printf 'clean-twin: %s has no known-bad twin at fixtures/%s\n' "$name" "$lens" >&2; fail=1; continue
  fi
  twins=$((twins + 1))
  out="$(bash "$probe" "$fx" 2>&1)"
  n="$(grep -c '"type":"finding"' <<<"$out")"
  if [ "$n" -ne 0 ]; then
    printf 'clean-twin: %s emitted %d finding(s) on clean input:\n' "$lens" "$n" >&2
    grep '"type":"finding"' <<<"$out" | sed 's/^/    /' >&2
    fail=1
  else
    # A probe that SKIPS the clean twin proves nothing: it must have run.
    if grep -q "\"type\":\"skipped\"" <<<"$out"; then
      printf 'clean-twin: %s SKIPPED its own clean twin (%s) — silence here is not a pass\n' \
        "$lens" "$(grep '"type":"skipped"' <<<"$out" | head -1)" >&2
      fail=1
    fi
  fi
done
[ "$twins" -gt 0 ] || { printf 'clean-twin: no clean twins found\n' >&2; exit 1; }
[ "$fail" -eq 0 ] && printf 'clean-twin: %d twins, zero findings\n' "$twins" || printf 'clean-twin: FAILED\n' >&2
exit "$fail"
