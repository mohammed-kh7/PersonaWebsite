#!/usr/bin/env python3
# Trusted probe mutations only; fixture application code is never executed.
from pathlib import Path
import subprocess, tempfile, shutil, json, re, os, time, sys, hashlib
base=Path(__file__).resolve().parents[1]
out=Path(sys.argv[1]) if len(sys.argv)>1 else Path(tempfile.mkdtemp(prefix='legacy-proof-results-'))
out.mkdir(parents=True,exist_ok=True)
ids=sorted(p.stem for p in (base/'probes').glob('*.sh') if not p.name.startswith('_') and '_software-layer.mjs' not in p.read_text())
# Copy trusted audit sources only. Scanned fixtures remain inert files.
def run(args,cwd):
 r=subprocess.run(args,cwd=cwd,text=True,capture_output=True,timeout=20)
 return r.returncode,r.stdout+r.stderr
fixes={
'agent-context-budget':('agent-context-budget.sh','"$total" -gt 40000','"$total" -gt 4000000'),
'agent-dead-mcp':('agent-dead-mcp.sh','grep -qxF -- "$var"','grep -qE "^"'),
'agent-hook-registration':('agent-hook-registration.sh','grep -qF -- "$name"','grep -qE "^"'),
'agent-secrets-in-config':('agent-secrets-in-config.sh','telegram|[0-9]{8,10}:AA[A-Za-z0-9_-]{30,}','telegram|__MUTATED_IMPOSSIBLE_SECRET__'),
'agent-silent-checklist':('_lib.sh','(run|go) through .{0,40}silently|silently .{0,30}(check|rule|gate)','__MUTATED_IMPOSSIBLE_CHECKLIST__'),
'agent-skill-duplicates':('agent-skill-duplicates.sh','c[n] > 1','c[n] > 1000'),
'docs-parity':('docs-parity.sh','if [ -n "$missing" ]; then','if [ -z "$missing" ]; then'),
'state-transition-integrity':('state-transition-integrity.sh',r'\.update(Many)?\(',r'__MUTATED_IMPOSSIBLE_UPDATE__'),
'testing':('testing.sh','-type d -name integration','-type d -name __MUTATED_IMPOSSIBLE_INTEGRATION__')}
results=[]
for id in ids:
 with tempfile.TemporaryDirectory(prefix='legacy-mutation-') as td:
  root=Path(td)/'fleet';root.mkdir();(root/'probes').mkdir();(root/'tests').mkdir();(root/'fixtures').mkdir()
  for f in base.glob('*.mjs'): shutil.copy2(f,root/f.name)
  for f in (base/'probes').glob('*.mjs'): shutil.copy2(f,root/'probes'/f.name)
  shutil.copy2(base/'probes/_lib.sh',root/'probes/_lib.sh')
  probe=root/'probes'/f'{id}.sh';original=(base/'probes'/f'{id}.sh').read_text();probe.write_text(original)
  for name in ['probe-fires.sh','clean-twin.sh']:shutil.copy2(base/'tests'/name,root/'tests'/name)
  for fx in (base/'fixtures').glob(id+'*'):
   if fx.is_dir() and (fx.name==id or fx.name.startswith(id+'.')):shutil.copytree(fx,root/'fixtures'/fx.name,symlinks=True)
  rc,text=run(['bash',str(probe),str(root/'fixtures'/id)],root)
  msgs=[]
  for line in text.splitlines():
   try:
    item=json.loads(line)
    if item.get('type')=='finding':msgs.append(item['message'])
   except (json.JSONDecodeError,KeyError):pass
  # Pin every observed primary-fixture finding so deleting one predicate cannot
  # pass merely because an unrelated criterion still emits a finding.
  expected=root/'fixtures'/id/'expected.grep'
  pre=expected.read_text() if expected.exists() else ''
  expected.write_text(pre+'\n'+'\n'.join(re.sub(r'([.\[\\*^$])',r'\\\1',json.dumps(m,ensure_ascii=False)[1:-1]) for m in msgs)+'\n')
  rc,baseline=run(['bash','tests/probe-fires.sh'],root)
  result={'id':id,'baseline_rc':rc,'baseline_findings':len(msgs),'mutation':None,'clean_mutation':None}
  if rc==0:
   candidates=[]
   # Replace a literal core search predicate, not filenames, emitters or shell syntax.
   # Parse complete shell-quoted grep patterns (including embedded quote of the other kind).
   pattern=re.compile(r"\bgrep\s+(?:-[\w]+\s+)+(?:--\s+)?(['\"])")
   starts=[(m.end(),m.group(1)) for m in pattern.finditer(original)]
   assignments=re.compile(r"(?m)^[ \t]*(?:P_[A-Z_]+|AI_SDK|LIMITER|FFFD|GENLOG_NAME|GENLOG_FIELDS)=(['\"])")
   starts += [(m.end(),m.group(1)) for m in assignments.finditer(original)]
   for start,quote in starts:
    end=start
    while end<len(original):
     if quote=='"' and original[end]=='\\':end+=2;continue
     if original[end]==quote:break
     end+=1
    literal=original[start:end]
    if not literal or literal.startswith('$') or '\n' in literal:continue
    candidates.append((start,end,literal))
   found=False
   for start,end,literal in candidates:
    for replacement in ['__MUTATED_IMPOSSIBLE_SOURCE_MATCH_9470__','.']:
     probe.write_text(original[:start]+replacement+original[end:])
     syntax=subprocess.run(['bash','-n',str(probe)],capture_output=True)
     if syntax.returncode:continue
     rc,failed=run(['bash','tests/probe-fires.sh'],root)
     if rc==1 and 'DEAD GATE: '+id in failed:
      result['mutation']={'line':original[:start].count('\n')+1,'original_pattern':literal,'replacement':replacement,'gate_rc':rc,'gate_message':next(l for l in failed.splitlines() if 'DEAD GATE:' in l)};found=True;break
    if found:break
   probe.write_text(original)
   if not result['mutation'] and id in fixes:
    filename,old,new=fixes[id]
    file=root/'probes'/filename
    saved=file.read_text()
    if old not in saved: raise RuntimeError('mutation target changed: '+id)
    file.write_text(saved.replace(old,new,1))
    rc,failed=run(['bash','tests/probe-fires.sh'],root)
    if rc==1 and 'DEAD GATE: '+id in failed:
     result['mutation']={'source':'fleet/probes/'+filename,'line':saved[:saved.index(old)].count('\n')+1,'original_pattern':old,'replacement':new,'gate_rc':rc,'gate_message':next(l for l in failed.splitlines() if 'DEAD GATE:' in l)}
    file.write_text(saved)
   probe.write_text(original)
   rc,restored=run(['bash','tests/probe-fires.sh'],root);result['restored_rc']=rc
   clean=root/'fixtures'/(id+'.clean')
   if clean.exists():
    rc,cleanbase=run(['bash','tests/clean-twin.sh'],root);result['clean_baseline_rc']=rc
    if rc==0:
     shutil.rmtree(clean);shutil.copytree(root/'fixtures'/id,clean,symlinks=True)
     rc,broken=run(['bash','tests/clean-twin.sh'],root)
     result['clean_mutation']={'gate_rc':rc,'message':next((l for l in broken.splitlines() if 'emitted' in l),broken[-200:])}
   else:result['clean_status']='MISSING_CLEAN_TWIN'
  else:result['baseline_error']=baseline[-600:]
  if result.get('mutation'):
   result['mutation'].setdefault('source','fleet/probes/'+id+'.sh')
   source_name=Path(result['mutation']['source']).name
   result['original_source_sha256']=hashlib.sha256((base/'probes'/source_name).read_bytes()).hexdigest()
   result['restored_source_sha256']=hashlib.sha256((root/'probes'/source_name).read_bytes()).hexdigest()
   assert result['original_source_sha256']==result['restored_source_sha256'], id+' not restored'
  results.append(result)
  (out/'legacy-mutations.json').write_text(json.dumps(results,indent=2)+'\n')
  print(id, 'matcher='+str(bool(result['mutation'])),'clean='+str(result.get('clean_mutation',{})),flush=True)
print('complete',len(results),'matcher proofs',sum(bool(r['mutation']) for r in results),'clean proofs',sum(bool(r['clean_mutation']) and r['clean_mutation']['gate_rc']==1 for r in results),flush=True)

assert len(results)==64, 'legacy lens count changed; review mutation coverage intentionally'
assert all(r.get('baseline_rc')==0 and r.get('mutation') and r.get('restored_rc')==0 and r.get('clean_baseline_rc')==0 and r.get('clean_mutation',{}).get('gate_rc')==1 for r in results), 'not every legacy mutation/clean gate proved'
print('Proof artifact:',out/'legacy-mutations.json')
