/**
 * Where the judging model comes from.
 *
 * There are two, and they are not interchangeable:
 *
 *  - `anthropicTransport(apiKey)` — a metered API key. This is what a SERVER
 *    uses, because a server has no human and no subscription.
 *  - `claudeCodeTransport()` — shells out to the locally installed `claude`
 *    CLI, which is already signed in. Nothing is billed per token; the operator
 *    is using the seat they already pay for, on their own machine, for their
 *    own work. That is what makes a consultant-run audit cost nothing per run.
 *
 * The split exists because the fleet runs in two very different places. The
 * container has a key and no human; a laptop has a human and no key. Passing a
 * transport rather than a key lets the same `runFleet` serve both without
 * either one pretending to be the other.
 */
import { execFileSync, spawnSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const API = "https://api.anthropic.com/v1/messages";
const DEFAULT_MODEL = process.env.FLEET_MODEL ?? "claude-sonnet-5";

/** The metered path. Returns `{ text, usage }`. */
export function anthropicTransport(apiKey, { model = DEFAULT_MODEL } = {}) {
  if (!apiKey) return null;
  return {
    name: "anthropic-api",
    metered: true,
    async ask(prompt) {
      const response = await fetch(API, {
        method: "POST",
        headers: { "content-type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model, max_tokens: 6000, messages: [{ role: "user", content: prompt }] }),
      });
      if (!response.ok) {
        throw new Error(`anthropic ${response.status}: ${(await response.text()).slice(0, 200)}`);
      }
      const body = await response.json();
      return { text: (body.content ?? []).map((c) => c.text ?? "").join(""), usage: body.usage ?? {} };
    },
  };
}

/**
 * Environment the `claude` child may see. An ALLOWLIST: the process env of a
 * developer machine carries cloud and registry tokens (AWS_*, GH_TOKEN, NPM_TOKEN,
 * CLOUDFLARE_*), and the child reads repo text an attacker may have written.
 * Auth still works through the keychain / config dir, which need only HOME, USER
 * and TMPDIR (measured: `env -i` without USER/TMPDIR answers "Not logged in").
 *
 * `ANTHROPIC_*` is deliberately absent: a stray key would move the run onto
 * metered billing, the opposite of the point of this seat. `CLAUDE_CODE_*`
 * session vars are absent too (a nested-session marker makes `--print` ignore
 * stdin); only the config dir and an explicit OAuth token pass.
 */
const ENV_ALLOW = new Set([
  "PATH", "HOME", "USER", "LOGNAME", "SHELL", "TMPDIR", "TERM", "LANG", "TZ",
  "XDG_CONFIG_HOME", "XDG_DATA_HOME", "XDG_CACHE_HOME", "XDG_STATE_HOME",
  "CLAUDE_CONFIG_DIR", "CLAUDE_CODE_OAUTH_TOKEN",
  "HTTPS_PROXY", "HTTP_PROXY", "NO_PROXY", "https_proxy", "http_proxy", "no_proxy",
  "SSL_CERT_FILE", "NODE_EXTRA_CA_CERTS",
]);

/** The child's environment, built from the allowlist only. */
export function allowlistedEnv(source = process.env) {
  const env = {};
  for (const [k, v] of Object.entries(source)) {
    if (v !== undefined && (ENV_ALLOW.has(k) || k.startsWith("LC_"))) env[k] = v;
  }
  return env;
}

/**
 * The flags that make `claude --print` a pure text-in/text-out judge. Both the
 * judge and the fix agent need NO tools: the fix agent is handed the file and
 * returns the new body as JSON, and OUR code does the (contained) write.
 *
 *  --tools ""            no built-in tools at all (no Bash/Read/Write/WebFetch)
 *  --strict-mcp-config   with no --mcp-config: no MCP servers
 *  --setting-sources ""  no user/project/local settings, so no hooks, no
 *                        project CLAUDE.md or MCP from the audited repo
 *  --permission-mode dontAsk   anything that would prompt is denied
 *  --no-session-persistence    nothing written to the session store
 *
 * `--tools` and `--strict-mcp-config` are REQUIRED: if the installed CLI lacks
 * either the seat is refused (fail closed), never run with tools on. The other
 * flags are applied when the CLI advertises them.
 */
const REQUIRED_FLAGS = ["--tools", "--strict-mcp-config"];

const helpCache = new Map();
function cliHelp(bin) {
  if (!helpCache.has(bin)) {
    let text = "";
    try {
      text = execFileSync(bin, ["--help"], { encoding: "utf8", timeout: 20_000, stdio: ["ignore", "pipe", "pipe"], env: allowlistedEnv() });
    } catch {
      text = "";
    }
    helpCache.set(bin, text);
  }
  return helpCache.get(bin);
}

/**
 * Prepended to every prompt sent to the contained CLI.
 *
 * MEASURED root cause of the 0.12.3 regression: with `--tools ""` the model still
 * believes it has tools (the CLI's default agent persona is an engineer in a repo)
 * and on prompts that say "what you can see of the repository" it answers with a
 * tool call as plain text (`<invoke name="Bash">ls ...`). The CLI then replies
 * "The previous response failed to produce a valid tool call. Please retry" and
 * the model tries again - sometimes recovering after one round, sometimes looping
 * until the 300s timeout. Telling it, in the message itself, that there is no
 * tool and the whole input is already in front of it removes the loop without
 * giving it any capability back. In the message rather than a flag so it works on
 * every CLI version that passes the containment check.
 */
export const NO_TOOLS_PREAMBLE =
  "You are running in a sandbox with NO tools: no shell, no file reading, no search, no web. " +
  "Everything you can ever see is in this message. Do not write tool calls or tool-call markup " +
  "of any kind; a single plain-text reply is the only thing that is read. If the message does not " +
  "contain enough to decide, say so inside the JSON format requested - do not ask to look further.\n\n";

/** argv for the contained judge, or null when this CLI cannot be contained. */
export function containedArgs(bin) {
  const help = cliHelp(bin);
  if (!REQUIRED_FLAGS.every((f) => help.includes(f))) return null;
  const args = ["--print", "--tools", "", "--strict-mcp-config"];
  if (help.includes("--setting-sources")) args.push("--setting-sources", "");
  if (help.includes("--permission-mode")) args.push("--permission-mode", "dontAsk");
  if (help.includes("--no-session-persistence")) args.push("--no-session-persistence");
  return args;
}

/**
 * The subscription path: the `claude` CLI on this machine, already signed in.
 *
 * `--print` makes it answer once and exit. The prompt goes on STDIN rather than
 * argv: a judge prompt carries a rubric and code excerpts, which blow past the
 * argv size limit and would also land in the process table for every other user
 * on the box.
 *
 * The prompt contains text from the audited repo, i.e. attacker-writable text.
 * So the child runs with no tools, no MCP, no settings, an allowlisted env and
 * an EMPTY temporary cwd: a prompt-injected "run this" or "write that file" has
 * nothing to act with and nowhere to act.
 *
 * Usage comes back as zeros and that is honest — this path is not metered per
 * token, so reporting an invented number would make the cost line a fiction.
 */
export function claudeCodeTransport({ bin = process.env.FLEET_CLAUDE_BIN ?? "claude", timeoutMs = 300_000 } = {}) {
  return {
    name: "claude-code",
    metered: false,
    async ask(prompt) {
      const args = containedArgs(bin);
      if (!args) {
        throw new Error(
          `the installed \`claude\` CLI does not support ${REQUIRED_FLAGS.join(" and ")}; refusing to run a judge with tools enabled. Update Claude Code or use ANTHROPIC_API_KEY.`,
        );
      }
      const cwd = mkdtempSync(join(tmpdir(), "mypovonai-judge-"));
      try {
        const run = spawnSync(bin, args, {
          input: NO_TOOLS_PREAMBLE + prompt,
          encoding: "utf8",
          timeout: timeoutMs,
          maxBuffer: 32 * 1024 * 1024,
          cwd,
          env: allowlistedEnv(),
        });
        if (run.error || run.status !== 0) throw new Error(describeFailure(run, timeoutMs));
        const text = run.stdout;
        return { text, usage: { input_tokens: 0, output_tokens: 0 } };
      } finally {
        rmSync(cwd, { recursive: true, force: true });
      }
    },
  };
}

/**
 * A failure message that says WHY. `execFileSync` reports only the command line
 * ("Command failed: claude --print --tools ..."), which is how a 2-of-11 failure
 * rate looked like a mystery. Child stderr/stdout tail is included, bounded, with
 * control characters stripped so a hostile or noisy child cannot forge log lines.
 */
export function describeFailure(run, timeoutMs) {
  const clean = (t) => String(t ?? "").replace(/[^\x20-\x7E\n]/g, "").trim().slice(-400);
  const why = run.error?.code === "ETIMEDOUT"
    ? `timed out after ${Math.round(timeoutMs / 1000)}s`
    : run.error
      ? String(run.error.message)
      : `exit ${run.status}${run.signal ? ` (${run.signal})` : ""}`;
  const err = clean(run.stderr);
  const out = clean(run.stdout);
  return `claude ${why}` + (err ? ` | stderr: ${err}` : "") + (!err && out ? ` | stdout: ${out}` : "");
}

/** Reports whether the `claude` CLI is present, answering, AND containable. */
export function claudeCodeAvailable({ bin = process.env.FLEET_CLAUDE_BIN ?? "claude" } = {}) {
  try {
    execFileSync(bin, ["--version"], { encoding: "utf8", timeout: 20_000, stdio: ["ignore", "pipe", "pipe"], env: allowlistedEnv() });
  } catch {
    return false;
  }
  return containedArgs(bin) !== null;
}

/**
 * Picks a transport. The default `api` means "the key you were given, or
 * nothing" — deliberately NOT a fallback to the local CLI, because quietly
 * spending an operator's seat whenever a key happened to be absent is a
 * decision nobody made. `auto` is available for a caller that wants it.
 *
 * Returns null when there is none, and a null transport means the run reports
 * `unjudged` — never that it judged and found nothing.
 */
export function resolveTransport({ apiKey = null, prefer = "api" } = {}) {
  if (prefer === "none") return null;
  if (prefer === "local") return claudeCodeAvailable() ? claudeCodeTransport() : null;
  if (prefer === "api") return anthropicTransport(apiKey);
  return anthropicTransport(apiKey) ?? (claudeCodeAvailable() ? claudeCodeTransport() : null);
}

/**
 * The seat on THIS machine, whatever the person running it already has.
 *
 * The operator supplies the model seat. Both transports can send masked
 * structural context to the operator's model provider. This is distinct from
 * report uploads to our service, which exclude source evidence excerpts.
 *
 * Order is cheapest-for-the-operator first, and it never guesses silently:
 * the caller is handed `why` so the terminal can say which seat ran and what
 * to do if none did.
 */
export function resolveLocalSeat({ env = process.env } = {}) {
  if (env.ANTHROPIC_API_KEY) {
    return {
      seat: anthropicTransport(env.ANTHROPIC_API_KEY),
      why: "your ANTHROPIC_API_KEY — billed to you by Anthropic",
    };
  }
  if (claudeCodeAvailable()) {
    return {
      seat: claudeCodeTransport(),
      why: "your signed-in `claude` CLI — nothing metered",
    };
  }
  return {
    seat: null,
    why:
      "no judging seat on this machine. Install and sign in to Claude Code, or set " +
      "ANTHROPIC_API_KEY. Without one the findings are probe-located and rubric-graded, " +
      "but nothing has removed the false positives.",
  };
}
