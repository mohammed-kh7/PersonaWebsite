/**
 * Choosing which files a dimension actually looks at.
 *
 * A repo does not fit in a context window — FWB is 357k lines — so the fleet
 * cannot "send the codebase". It sends a MANIFEST of every tracked path plus
 * the contents of the files that matter to one dimension.
 *
 * The manifest matters as much as the contents: a dimension that never saw a
 * path cannot claim the repo lacks it. Being able to say "I saw 2,334 files and
 * read these 40" is the difference between a finding and a guess.
 */
import { readFileSync, statSync } from "node:fs";
import { isBuildOutputPath, resolveInside } from "./paths.mjs";
import { listRepoFiles, SECRET_FILE } from "./repo-read.mjs";

/** Never read into a prompt: generated, vendored, or binary. (Build output: BUILD_OUTPUT_DIRS in paths.mjs.) */
const EXCLUDED = [
  /(^|\/)node_modules\//,
  /(^|\/)graphify-out\//,
  /\.(png|jpe?g|gif|webp|avif|svg|ico|woff2?|ttf|mp4|pdf|zip|lock)$/i,
  /package-lock\.json$/,
];

/** Per-dimension interest. Ordered: the earlier a pattern, the higher its priority. */
const INTEREST = {
  security: [/route\.(ts|js)$/, /auth/i, /middleware/i, /api\//, /\.env\.example$/],
  "tenancy-rls": [/schema\.prisma$/, /migrations?\//, /rls/i, /tenant/i, /\bdb\b/],
  // Word boundaries, not substrings. `/order/i` matched `ReorderButtons.tsx`
  // and `RunningBorder.tsx` — "Re-ORDER" and "B-ORDER" — which is the
  // absent-filter-matches-everything class the lens packs warn about, showing
  // up in the selector itself. A dimension fed the wrong files produces
  // findings about the wrong code.
  money: [/payment/i, /webhook/i, /\border(s)?\b/i, /checkout/i, /invoice/i, /ledger/i],
  scaling: [/schema\.prisma$/, /query|repository|service/i, /cache/i, /route\.(ts|js)$/],
  "migration-safety": [/migrations?\//, /schema\.prisma$/, /\.sql$/],
  deps: [/package\.json$/],
  testing: [/\.(test|spec)\.[tj]sx?$/, /\.github\/workflows\//, /vitest|jest|playwright/i],
  "error-surface": [/route\.(ts|js)$/, /error/i, /handler/i, /worker|job|cron/i],
  "docs-parity": [/\.md$/, /README/i],
  "frontend-quality": [/\.(tsx|jsx)$/, /i18n|locale|strings/i],
  "data-ui-coverage": [/schema\.prisma$/, /\.(tsx|jsx)$/, /admin/i],
  "layer-traversal": [/route\.(ts|js)$/, /schema\.prisma$/, /action/i, /service/i],
  "contract-drift": [/route\.(ts|js)$/, /schema|zod|validation/i, /action/i],
};

/** Files on disk (never `git ls-files`: running git in the audited repo is not safe), minus
 *  generated/vendored/binary paths and anything that looks like a secret file. */
export function listTracked(repoPath) {
  return listRepoFiles(repoPath).filter((p) => !isBuildOutputPath(p) && !SECRET_FILE.test(p) && !EXCLUDED.some((rx) => rx.test(p)));
}

/**
 * Ranks the manifest for one dimension and returns as many files as fit.
 *
 * `budgetBytes` is a real ceiling, not a suggestion: going over it does not
 * degrade the audit, it fails the API call outright, which would turn a
 * dimension that could have run into one that errored.
 */
export function selectFiles(repoPath, dimensionId, manifest, budgetBytes = 220_000) {
  const patterns = INTEREST[dimensionId] ?? [/\.(ts|tsx|js|jsx)$/];
  const scored = manifest
    .map((path) => {
      const rank = patterns.findIndex((rx) => rx.test(path));
      return { path, rank: rank === -1 ? Number.MAX_SAFE_INTEGER : rank };
    })
    .filter((f) => f.rank !== Number.MAX_SAFE_INTEGER)
    .sort((a, b) => a.rank - b.rank || a.path.localeCompare(b.path));

  const chosen = [];
  let used = 0;
  for (const { path } of scored) {
    let size;
    try {
      // A symlink in the repo can point anywhere; its target is not the repo's.
      const hit = resolveInside(repoPath, path);
      if (!hit) continue;
      size = statSync(hit.abs).size;
    } catch {
      continue;
    }
    // One enormous file must not consume the whole budget and starve the rest.
    if (size > budgetBytes / 4) continue;
    if (used + size > budgetBytes) break;
    chosen.push(path);
    used += size;
  }
  return chosen;
}

export function readFiles(repoPath, paths) {
  return paths.flatMap((path) => {
    const hit = resolveInside(repoPath, path);
    return hit && !SECRET_FILE.test(path) ? [{ path, text: readFileSync(hit.abs, "utf8") }] : [];
  });
}
