/**
 * The skill scoped to one exact finding.
 *
 * A mechanical fix is a template: it knows the shape of the answer before it
 * sees the code. Most findings are not like that — 36 of 50 on a real repository
 * matched no template at all, and those customers got a spec that said "no rule
 * matched", which is honest and useless.
 *
 * This seat reads the actual code around one finding and writes a patch for it.
 * It runs on the CUSTOMER's machine, on the seat they already have, so it costs
 * the operator nothing per fix and the source never moves.
 *
 * ## The rule that makes an agent-written patch safe
 *
 * **It is a hypothesis until the probe that found the finding stops finding it.**
 * Exactly the contract a mechanical fix is held to, and for a stronger reason:
 * a template's blast radius is known in advance and a model's is not. So:
 *
 *   1. the patch must apply;
 *   2. the finding must be gone when its own lens is re-run;
 *   3. the dead-gate check must still pass — the finding cannot have been
 *      "fixed" by breaking the probe;
 *   4. nothing else in that lens may have appeared.
 *
 * Any of those failing reverts the file and downgrades the finding to a spec.
 * An unverified edit is never kept.
 */
import { lstatSync, readFileSync } from "node:fs";

import { readContained, resolveInside, writeContained } from "../paths.mjs";

/** How much of a file the model is allowed to see, and to return. */
const MAX_FILE_CHARS = 24_000;

/**
 * A "smallest change that removes this finding" that rewrites most of the file
 * is not that, whatever it claims. Changed lines (added + removed) above either
 * bound make the reply a decline.
 */
const MAX_CHANGED_LINES = 400;
const MAX_CHANGED_RATIO = 0.6;

/** Added + removed lines between two bodies, as a multiset difference. */
export function changedLines(before, after) {
  const counts = new Map();
  for (const l of before.split("\n")) counts.set(l, (counts.get(l) ?? 0) + 1);
  let added = 0;
  for (const l of after.split("\n")) {
    const c = counts.get(l) ?? 0;
    if (c > 0) counts.set(l, c - 1);
    else added += 1;
  }
  let removed = 0;
  for (const c of counts.values()) removed += c;
  return added + removed;
}

/**
 * The file a finding points at, as a repo-relative path, or null.
 *
 * The location comes from a report that a model (the interpreter) helped write,
 * so it is untrusted: it must resolve INSIDE the repo (no absolute path outside
 * it, no `..`, no symlink out), be a regular single-link file, and stay out of
 * `.git/`. A directory, a vanished path or an oversized file is null too.
 */
export function fileOf(finding, repoPath) {
  const raw = String(finding?.location ?? "").replace(/:\d+(?:-\d+)?$/, "");
  if (!raw || raw === ".") return null;
  const hit = resolveInside(repoPath, raw, { allowAbsoluteInside: true });
  if (!hit) return null;
  if (hit.rel.split(/[\\/]/).includes(".git")) return null;
  try {
    const st = lstatSync(hit.abs);
    // A hard link can alias a file outside the repo, and realpath cannot see it.
    if (!st.isFile() || st.nlink > 1) return null;
    const body = readFileSync(hit.abs, "utf8");
    return body.length > MAX_FILE_CHARS ? null : hit.rel;
  } catch {
    return null;
  }
}

export function buildFixPrompt({ finding, rubric, filePath, fileBody }) {
  return `You are fixing ONE finding in one file. Nothing else.

## The finding
lens:     ${finding.lens}
severity: ${finding.severity}
where:    ${finding.location}
what:     ${finding.message}

## The rubric criterion it is graded against
${String(rubric).slice(0, 8000)}

## The file, in full — \`${filePath}\`
\`\`\`
${fileBody}
\`\`\`

## Rules

- Return the COMPLETE file with the smallest change that removes this finding.
- Change nothing else. No reformatting, no renaming, no "while I'm here".
- Do NOT weaken or delete a check, a test, or a guard to make the finding go
  away. The probe is re-run after you; silencing it is detected and reverted.
- If the fix cannot be made in this file alone — it needs a migration, a new
  dependency, a decision about behaviour, or edits elsewhere — say so instead
  of guessing.
- Keep the file's existing style, quoting and indentation.

Reply with JSON only:
{"action":"patch"|"cannot-fix-here","why":"one sentence","file":"<the complete file, only when action is patch>"}`;
}

export function parseFixReply(text) {
  const match = String(text ?? "").match(/\{[\s\S]*\}/);
  if (!match) throw new Error("fix agent returned no JSON object");
  let parsed;
  try {
    parsed = JSON.parse(match[0]);
  } catch (error) {
    throw new Error(`fix agent returned unparseable JSON: ${String(error?.message ?? error).slice(0, 120)}`);
  }
  if (!["patch", "cannot-fix-here"].includes(parsed.action)) {
    throw new Error(`fix agent returned an unknown action: ${JSON.stringify(parsed.action).slice(0, 60)}`);
  }
  // A refusal with no reason is how a fixable finding quietly becomes a spec
  // nobody can argue with — the same rule the judge is held to for a downgrade.
  if (parsed.action === "cannot-fix-here" && !String(parsed.why ?? "").trim()) {
    throw new Error("fix agent refused with no reason");
  }
  if (parsed.action === "patch") {
    if (typeof parsed.file !== "string" || parsed.file.length === 0) {
      throw new Error("fix agent claimed a patch and returned no file");
    }
    if (parsed.file.length > MAX_FILE_CHARS) throw new Error("fix agent returned an oversized file");
  }
  return parsed;
}

/**
 * Attempts one finding. Returns `{ fixed, why }` and leaves the tree unchanged
 * unless every check passed.
 *
 * `verify` is injected so the caller owns what "the finding is gone" means —
 * the orchestrator already has that logic and it must not be duplicated here
 * with a second, subtly different opinion.
 */
export async function fixOneWithAgent({ finding, repoPath, rubric, seat, verify, gatesHold }) {
  const rel = fileOf(finding, repoPath);
  if (!rel) return { fixed: false, why: "the finding does not point at a single readable file" };

  const target = resolveInside(repoPath, rel);
  if (!target) return { fixed: false, why: "the finding does not point at a single readable file" };

  let before;
  try {
    before = readContained(repoPath, rel).toString("utf8");
  } catch (error) {
    return { fixed: false, why: `refused to read: ${String(error?.message ?? error).slice(0, 120)}` };
  }
  let reply;
  try {
    const { text } = await seat.ask(buildFixPrompt({ finding, rubric, filePath: rel, fileBody: before }));
    reply = parseFixReply(text);
  } catch (error) {
    return { fixed: false, why: `the fix agent failed: ${String(error?.message ?? error).slice(0, 160)}` };
  }
  if (reply.action === "cannot-fix-here") return { fixed: false, why: reply.why };
  if (reply.file === before) return { fixed: false, why: "the agent returned the file unchanged" };

  const delta = changedLines(before, reply.file);
  const total = Math.max(1, before.split("\n").length);
  // The ratio only means something on a file big enough for a ratio (a 2-line file
  // always changes 100% of its lines to fix one of them).
  if (delta > MAX_CHANGED_LINES || (total > 10 && delta / total > MAX_CHANGED_RATIO)) {
    return { fixed: false, why: `the agent's edit rewrites too much of the file (${delta} changed lines); a verified fix is a small one` };
  }

  // Re-resolve right before the write: the path was checked a model-call ago.
  const again = resolveInside(repoPath, rel);
  if (!again || again.abs !== target.abs) return { fixed: false, why: "the file moved while the agent was working" };
  try {
    writeContained(repoPath, rel, reply.file, target);
  } catch (error) {
    return { fixed: false, why: `refused to write: ${String(error?.message ?? error).slice(0, 120)}` };
  }

  // A hypothesis until the probe says otherwise — and the probe itself must
  // still be alive, or the finding was "fixed" by breaking the check.
  const cleared = verify(finding);
  const alive = gatesHold();
  if (cleared && alive) return { fixed: true, why: reply.why, file: rel };

  try {
    writeContained(repoPath, rel, before, target);
  } catch {
    /* if the path no longer resolves inside the repo we must not write to it */
  }
  return {
    fixed: false,
    why: cleared
      ? "reverted: the edit made the dead-gate check stop passing, so the finding was silenced rather than fixed"
      : "reverted: the finding was still present after the edit",
  };
}
