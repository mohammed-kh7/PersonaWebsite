#!/usr/bin/env node
/**
 * The remediation half of the loop.
 *
 *   node fleet/fix/run-fix.mjs --repo <clone> --report <audit.json> --out <dir>
 *
 * ## R-9: this emits a PATCH. It never opens a PR and never asks for write scope
 *
 * The customer receives a diff and applies it themselves. Opening a PR needs
 * `contents: write` on their repository, which turns the pitch from "it reads my
 * code" into "it changes my code" -- a different sale to a different buyer, and
 * one refusal loses the account. Read-only also means a compromised token cannot
 * alter anyone's source. The RERUN is what proves the patch landed, so the loop
 * closes without write access.
 *
 * ## A fix is a HYPOTHESIS until the probe that found it no longer finds it
 *
 * Every mechanical edit is verified individually, by IDENTITY, before it is kept:
 *
 *   1. the finding cleared        -- re-run that lens, the identity is gone
 *   2. the gate still fires       -- probe-fires.sh still passes, so the edit
 *                                    did not work by weakening the probe
 *   3. nothing else broke         -- after ALL edits, a full rerun must introduce
 *                                    no new finding (the blast-radius sweep)
 *
 * A failed verify reverts that edit and downgrades it to a spec. An unverified
 * edit is never kept, and a failed blast-radius sweep discards the whole patch:
 * a patch that trades one finding for another has not improved the repository.
 */
import { execFileSync } from "node:child_process";
import { lstatSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, realpathSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

import { isMain } from "../is-main.mjs";

import { diffRuns } from "../diff.mjs";
import { findingIdentity } from "../identity.mjs";
import { canonicalRel, readContained, writeContained } from "../paths.mjs";
import { patchSince, restoreSnapshot, takeSnapshot } from "../repo-read.mjs";
import { proveGatesAlive, runFleet, runProbe } from "../run.mjs";
import { fixOneWithAgent } from "./agent.mjs";
import { classify, isAutoApplicable } from "./classify.mjs";

const FIX_DIR = dirname(fileURLToPath(import.meta.url));


/** Every finding the audit actually reported, with its identity and tier. */
export function collectFindings(report) {
  const out = [];
  for (const lens of report?.lenses ?? []) {
    const rows = [...(Array.isArray(lens.candidates) ? lens.candidates : []), ...(lens.interpreter?.findings ?? [])];
    for (const row of rows) {
      // A downgraded candidate was never reported to the customer. Fixing it
      // would be work nobody asked for, against a finding the judge rejected.
      if (row.verdict && row.verdict.ruling === "false-positive") continue;
      const finding = { lens: lens.id, location: row.location, message: row.message, severity: row.severity };
      out.push({ ...finding, identity: row.identity ?? findingIdentity(finding), ...classify(finding) });
    }
  }
  return out;
}

/** Stage 1: is this exact finding gone from a fresh probe run? */
export function findingCleared(finding, repoPath) {
  const { findings, crashed } = runProbe(finding.lens, repoPath);
  // A crashed probe has not cleared anything. Treating a crash as success is
  // the failure this whole file is arranged to avoid.
  if (crashed) return false;
  return !findings.some((f) => findingIdentity(f, repoPath) === finding.identity);
}

const isRealDir = (p) => {
  try {
    return lstatSync(p).isDirectory();
  } catch {
    return false;
  }
};

/** Repo-relative files each mechanical action reads or writes (apply-mechanical.sh); `job-timeouts` globs. */
export function writesFor(repoPath, action) {
  const dir = (p) => isRealDir(join(repoPath, p));
  switch (action) {
    case "engines-node": return ["package.json"];
    case "prepush-hook": return [".husky/pre-push"];
    case "rollback-script": return ["scripts/rollback.sh"];
    case "core-docs": return ["README.md", "docs/ROLLBACK.md", "docs/DEPLOYMENT.md"];
    case "sitemap-robots": { const d = dir("src/app") ? "src/app" : "app"; return [`${d}/sitemap.ts`, `${d}/robots.ts`]; }
    case "gitleaks-workflow": return [".github/workflows/gitleaks.yml"];
    case "job-timeouts": {
      if (!dir(".github/workflows")) return [];
      return readdirSync(join(repoPath, ".github/workflows")).filter((n) => /\.ya?ml$/.test(n)).map((n) => `.github/workflows/${n}`);
    }
    case "logger-scaffold": return [`${dir("src") ? "src/lib" : "lib"}/logger.ts`];
    default: return [];
  }
}

/**
 * Applies one mechanical fix WITHOUT bash ever touching the repository. The shell script runs against a
 * temp STAGING directory (outside the repo) holding byte copies of the files it may read or edit (read
 * through the contained reader); whatever it produces or changes there is written back into the repo
 * one file at a time through `writeContained` (O_NOFOLLOW, vetted parents, same-inode, inside the real
 * root). Bash is handed the staging path only, never a path inside the repo, and every relative path
 * is validated once here in canonical form (no `..`, no control characters, no re-resolution in bash).
 * Returns the list of repo-relative files written.
 */
export function applyMechanical(repoPath, action) {
  const rels = writesFor(repoPath, action);
  for (const rel of rels) canonicalRel(rel);
  const stage = mkdtempSync(join(tmpdir(), "fleet-mech-"));
  try {
    const before = new Map();
    for (const rel of rels) {
      let bytes;
      try {
        lstatSync(join(repoPath, rel));
        bytes = readContained(repoPath, rel); // throws on a symlink / hardlink / symlinked parent
      } catch (error) {
        if (error?.code === "ENOENT") continue;
        throw new Error(`${rel}: ${error?.message ?? error}`);
      }
      const mode = lstatSync(join(repoPath, rel)).mode & 0o777;
      mkdirSync(join(stage, rel, ".."), { recursive: true });
      writeFileSync(join(stage, rel), bytes, { mode });
      before.set(rel, bytes);
    }
    // directory-shape decisions the script makes with `[ -d ... ]`
    for (const d of ["src", "src/app"]) if (isRealDir(join(repoPath, d))) mkdirSync(join(stage, d), { recursive: true });

    execFileSync("bash", [join(FIX_DIR, "apply-mechanical.sh"), stage, action], { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });

    const written = [];
    const walk = (rel) => {
      for (const e of readdirSync(join(stage, rel), { withFileTypes: true })) {
        const r = rel ? `${rel}/${e.name}` : e.name;
        if (e.isDirectory()) walk(r);
        else if (e.isFile() && !r.endsWith(".fixtmp")) {
          canonicalRel(r);
          const bytes = readFileSync(join(stage, r));
          const old = before.get(r);
          if (old && old.equals(bytes)) continue;
          const mode = lstatSync(join(stage, r)).mode & 0o777;
          let exists = true;
          try { lstatSync(join(repoPath, r)); } catch { exists = false; }
          writeContained(repoPath, r, bytes, exists ? { abs: join(realpathSync(repoPath), r) } : undefined, mode);
          written.push(r);
        }
        // symlinks or anything else a script left in staging are never copied back
      }
    };
    walk("");
    return written.join(" ");
  } finally {
    rmSync(stage, { recursive: true, force: true });
  }
}

export async function runFix({
  repoPath,
  report,
  outDir,
  apiKey = null,
  /**
   * The model seat for the per-finding fix agent. Without one, every
   * non-mechanical finding becomes a spec — which is what happened to 36 of 50
   * findings on a real repository before this existed.
   */
  seat = null,
  rubricFor = () => "",
  onProgress = () => {},
}) {
  // Git is never run in the audited repo (its own config can make git execute commands or touch
  // paths outside it). Reverts and the patch come from byte-exact snapshots instead.
  const baseSnap = takeSnapshot(repoPath);
  let goodSnap = baseSnap;
  mkdirSync(join(outDir, "specs"), { recursive: true });
  const findings = collectFindings(report);
  const applied = [];
  const reverted = [];
  const specs = [];
  const runbook = [];
  const doneActions = new Set();

  const agentAttempted = [];
  for (const finding of findings) {
    if (!isAutoApplicable(finding.tier)) {
      // Infrastructure is a runbook entry by definition — there is no file to
      // patch. `deep-dangerous` is never handed to an agent either: a migration
      // rewrite is an outage and a gate edit either silences a live gate or
      // reddens CI for everyone, and neither is worth a model's confidence.
      if (finding.tier === "infra" || finding.tier === "deep-dangerous" || !seat) {
        (finding.tier === "infra" ? runbook : specs).push(finding);
        continue;
      }

      const outcome = await fixOneWithAgent({
        finding,
        repoPath,
        rubric: rubricFor(finding.lens),
        seat,
        verify: (f) => findingCleared(f, repoPath),
        gatesHold: () => proveGatesAlive().ok,
      });
      agentAttempted.push({ ...finding, agent: outcome.why });
      if (outcome.fixed) {
        applied.push({ ...finding, action: "agent-patch", agentWhy: outcome.why });
        onProgress(finding.lens, `agent fixed ${outcome.file}`);
      } else {
        specs.push({ ...finding, failure: outcome.why });
        onProgress(finding.lens, `agent declined: ${String(outcome.why).slice(0, 60)}`);
      }
      continue;
    }
    // One action can close several findings (two lenses both want gitleaks).
    // Running it twice is a no-op, but re-verifying each finding is not.
    if (!doneActions.has(finding.action)) {
      try {
        applyMechanical(repoPath, finding.action);
        doneActions.add(finding.action);
      } catch (error) {
        finding.failure = `apply failed: ${String(error?.message ?? error).slice(0, 200)}`;
        specs.push(finding);
        continue;
      }
    }

    const cleared = findingCleared(finding, repoPath);
    const gatesHold = proveGatesAlive().ok;
    if (cleared && gatesHold) {
      applied.push(finding);
      goodSnap = takeSnapshot(repoPath, goodSnap);
      onProgress(finding.lens, `fixed via ${finding.action}`);
    } else {
      // Revert THIS action's work and spec it instead. Never keep an edit whose
      // effect could not be observed.
      restoreSnapshot(repoPath, goodSnap);
      doneActions.delete(finding.action);
      finding.failure = cleared ? "the dead-gate check stopped passing" : "the finding was still present after the edit";
      reverted.push(finding);
      specs.push(finding);
      onProgress(finding.lens, `reverted: ${finding.failure}`);
    }
  }

  // Blast radius: the full fleet, against the patched tree, diffed against the
  // audit we started from. A fix that introduced a finding elsewhere is not a fix.
  const rerun = await runFleet({ repoPath, apiKey, onProgress });
  const delta = diffRuns(report, rerun, repoPath);
  // The patch covers files the fix CREATED as well as edited ones (most mechanical fixes add a
  // workflow, hook, sitemap.ts ...); it is computed against the snapshot taken before any edit.
  let patch = patchSince(repoPath, baseSnap);
  let discarded = null;
  if (delta.introduced.length > 0) {
    discarded = delta.introduced;
    restoreSnapshot(repoPath, baseSnap);
    patch = "";
    for (const f of applied.splice(0)) specs.push({ ...f, failure: "discarded: the patch introduced a new finding" });
  }

  if (patch) writeFileSync(join(outDir, "patch.diff"), patch);
  for (const [i, f] of specs.entries()) writeFileSync(join(outDir, "specs", `${f.lens}-${i + 1}.md`), specText(f));
  if (runbook.length) writeFileSync(join(outDir, "runbook.md"), runbookText(runbook));

  const result = {
    applied: applied.map(summary),
    reverted: reverted.map(summary),
    specs: specs.map(summary),
    runbook: runbook.map(summary),
    discarded,
    agentAttempted: agentAttempted.length,
    rerun: delta,
    patchBytes: patch.length,
  };
  writeFileSync(join(outDir, "REPORT.json"), JSON.stringify(result, null, 2));
  return result;
}

const summary = (f) => ({
  lens: f.lens,
  identity: f.identity,
  severity: f.severity,
  location: f.location,
  tier: f.tier,
  action: f.action ?? null,
  failure: f.failure ?? null,
});

function specText(f) {
  return [
    `# ${f.lens} — ${f.severity}`,
    "",
    `**Where:** \`${f.location}\``,
    `**Finding id:** \`${f.identity}\``,
    `**Tier:** ${f.tier}`,
    f.why ? `**Why it is not auto-fixed:** ${f.why}` : "",
    f.failure ? `**Auto-fix outcome:** ${f.failure}` : "",
    "",
    "## The finding",
    "",
    f.message,
    "",
    "## What closes it",
    "",
    "Rerun the audit against the same commit after the change. The finding id",
    "above must disappear from the report and no new finding may appear; that",
    "diff -- not the diff of the edit -- is the proof the gap is closed.",
    "",
  ]
    .filter((l) => l !== "")
    .join("\n");
}

function runbookText(rows) {
  return [
    "# Runbook — gaps that are configuration, not code",
    "",
    "These are not fixed by a patch. They are changed in the platform (CDN, env,",
    "credentials) and confirmed by a rerun against the same commit.",
    "",
    ...rows.flatMap((f) => [`## ${f.lens} — ${f.severity}`, "", `- **Where:** ${f.location}`, `- **Finding id:** \`${f.identity}\``, `- ${f.message}`, f.why ? `- **Why a runbook and not a patch:** ${f.why}` : "", ""]),
  ]
    .filter((l) => l !== undefined)
    .join("\n");
}

if (isMain(import.meta.url)) {
  const arg = (flag) => {
    const i = process.argv.indexOf(flag);
    return i === -1 ? undefined : process.argv[i + 1];
  };
  const repoPath = arg("--repo");
  const reportPath = arg("--report");
  const outDir = arg("--out");
  if (!repoPath || !reportPath || !outDir) {
    console.error("usage: node fleet/fix/run-fix.mjs --repo <clone> --report <audit.json> --out <dir>");
    process.exit(2);
  }
  const { readFileSync } = await import("node:fs");
  const result = await runFix({
    repoPath,
    report: JSON.parse(readFileSync(reportPath, "utf8")),
    outDir,
    apiKey: process.env.ANTHROPIC_API_KEY,
    onProgress: (id, note) => console.error(`  ${String(id).padEnd(22)} ${note}`),
  });
  console.error(
    `  applied ${result.applied.length}, reverted ${result.reverted.length}, ` +
      `specs ${result.specs.length}, runbook ${result.runbook.length}, patch ${result.patchBytes}B`,
  );
  console.log(JSON.stringify(result, null, 2));
}
