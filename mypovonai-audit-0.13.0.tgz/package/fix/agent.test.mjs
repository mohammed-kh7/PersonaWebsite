import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { expect, test } from "vitest";

import { buildFixPrompt, fileOf, fixOneWithAgent, parseFixReply } from "./agent.mjs";

function repoWith(name, body) {
  const dir = mkdtempSync(join(tmpdir(), "agentfix-"));
  writeFileSync(join(dir, name), body);
  execFileSync("git", ["-C", dir, "init", "-q"]);
  execFileSync("git", ["-C", dir, "add", "-A"]);
  execFileSync("git", ["-C", dir, "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "i"]);
  return dir;
}
const finding = (over = {}) => ({
  lens: "security",
  severity: "critical",
  location: "a.ts:1",
  message: "unsanitized sink",
  ...over,
});
const seatSaying = (reply) => ({ name: "test", metered: false, ask: async () => ({ text: reply }) });

test("an agent patch is kept ONLY when the probe stops finding it", async () => {
  const dir = repoWith("a.ts", "export const bad = 1;\n");
  const res = await fixOneWithAgent({
    finding: finding(),
    repoPath: dir,
    rubric: "R",
    seat: seatSaying(JSON.stringify({ action: "patch", why: "escaped it", file: "export const good = 1;\n" })),
    verify: () => true,
    gatesHold: () => true,
  });
  expect(res.fixed).toBe(true);
  expect(readFileSync(join(dir, "a.ts"), "utf8")).toContain("good");
});

test("a patch that did NOT clear the finding is reverted", async () => {
  const dir = repoWith("a.ts", "export const bad = 1;\n");
  const res = await fixOneWithAgent({
    finding: finding(),
    repoPath: dir,
    rubric: "R",
    seat: seatSaying(JSON.stringify({ action: "patch", why: "tried", file: "export const other = 1;\n" })),
    verify: () => false,
    gatesHold: () => true,
  });
  expect(res.fixed).toBe(false);
  expect(res.why).toMatch(/still present/);
  expect(readFileSync(join(dir, "a.ts"), "utf8")).toBe("export const bad = 1;\n");
});

test("a patch that SILENCED the probe is reverted, and says so", async () => {
  // The dangerous outcome: the finding is gone because the check is gone. A
  // template's blast radius is known in advance; a model's is not, which is
  // exactly why this check matters more here than for a mechanical fix.
  const dir = repoWith("a.ts", "export const bad = 1;\n");
  const res = await fixOneWithAgent({
    finding: finding(),
    repoPath: dir,
    rubric: "R",
    seat: seatSaying(JSON.stringify({ action: "patch", why: "removed the check", file: "// nothing here\n" })),
    verify: () => true,
    gatesHold: () => false,
  });
  expect(res.fixed).toBe(false);
  expect(res.why).toMatch(/silenced rather than fixed/);
  expect(readFileSync(join(dir, "a.ts"), "utf8")).toBe("export const bad = 1;\n");
});

test("a refusal with no reason is refused — it is how a fixable finding becomes an unarguable spec", () => {
  expect(() => parseFixReply('{"action":"cannot-fix-here"}')).toThrow(/no reason/);
  expect(() => parseFixReply('{"action":"cannot-fix-here","why":"  "}')).toThrow(/no reason/);
  expect(parseFixReply('{"action":"cannot-fix-here","why":"needs a migration"}').action).toBe("cannot-fix-here");
});

test("a claimed patch with no file, an unknown action, and unparseable output are all refused", () => {
  expect(() => parseFixReply('{"action":"patch","why":"x"}')).toThrow(/no file/);
  expect(() => parseFixReply('{"action":"rewrite","why":"x"}')).toThrow(/unknown action/);
  expect(() => parseFixReply("not json")).toThrow(/no JSON/);
});

test("an unchanged file is not counted as a fix", async () => {
  const dir = repoWith("a.ts", "same\n");
  const res = await fixOneWithAgent({
    finding: finding(),
    repoPath: dir,
    rubric: "R",
    seat: seatSaying(JSON.stringify({ action: "patch", why: "no change", file: "same\n" })),
    verify: () => true,
    gatesHold: () => true,
  });
  expect(res.fixed).toBe(false);
  expect(res.why).toMatch(/unchanged/);
});

test("a finding pointing at a directory or a missing file is never handed to the agent", () => {
  const dir = repoWith("a.ts", "x\n");
  expect(fileOf({ location: "." }, dir)).toBeNull();
  expect(fileOf({ location: "does/not/exist.ts" }, dir)).toBeNull();
  expect(fileOf({ location: "a.ts:12" }, dir)).toBe("a.ts");
});

test("the prompt forbids the one shortcut that would pass verification", () => {
  const p = buildFixPrompt({ finding: finding(), rubric: "R", filePath: "a.ts", fileBody: "x" });
  expect(p).toMatch(/Do NOT weaken or delete a check/);
  expect(p).toMatch(/smallest change/);
  expect(p).toMatch(/cannot-fix-here/);
});

// ---- 0.12.3: containment of the fix agent -------------------------------------
import { symlinkSync } from "node:fs";
import { dirname } from "node:path";
import { changedLines } from "./agent.mjs";

test("fileOf refuses locations that leave the repo or touch .git (negative controls)", () => {
  const dir = repoWith("a.ts", "export const bad = 1;\n");
  const outside = join(dirname(dir), "outside-fix.txt");
  writeFileSync(outside, "s");
  symlinkSync(outside, join(dir, "link.ts"));
  expect(fileOf(finding({ location: "a.ts:1" }), dir)).toBe("a.ts");
  expect(fileOf(finding({ location: join(dir, "a.ts") + ":1" }), dir)).toBe("a.ts");
  expect(fileOf(finding({ location: outside }), dir)).toBeNull();
  expect(fileOf(finding({ location: "../outside-fix.txt" }), dir)).toBeNull();
  expect(fileOf(finding({ location: "link.ts" }), dir)).toBeNull();
  expect(fileOf(finding({ location: ".git/config" }), dir)).toBeNull();
  expect(fileOf(finding({ location: "/etc/passwd" }), dir)).toBeNull();
});

test("git is not consulted: a failed agent edit restores the operator's unsaved work byte for byte", async () => {
  const dir = repoWith("a.ts", "export const bad = 1;\n");
  writeFileSync(join(dir, "a.ts"), "export const mine = 'unsaved work';\n");
  const res = await fixOneWithAgent({
    finding: finding(),
    repoPath: dir,
    rubric: "R",
    seat: seatSaying(JSON.stringify({ action: "patch", why: "w", file: "export const mine = 'fixed work';\n" })),
    verify: () => false,
    gatesHold: () => true,
  });
  expect(res.fixed).toBe(false);
  expect(readFileSync(join(dir, "a.ts"), "utf8")).toBe("export const mine = 'unsaved work';\n");
});

test("an edit that rewrites most of the file is declined, not applied", async () => {
  const body = Array.from({ length: 20 }, (_, i) => `export const v${i} = ${i};`).join("\n") + "\n";
  const dir = repoWith("a.ts", body);
  const rewritten = Array.from({ length: 20 }, (_, i) => `export const w${i} = ${i};`).join("\n") + "\n";
  const res = await fixOneWithAgent({
    finding: finding(),
    repoPath: dir,
    rubric: "R",
    seat: seatSaying(JSON.stringify({ action: "patch", why: "w", file: rewritten })),
    verify: () => true,
    gatesHold: () => true,
  });
  expect(res.fixed).toBe(false);
  expect(res.why).toMatch(/rewrites too much/);
  expect(readFileSync(join(dir, "a.ts"), "utf8")).toBe(body);
  expect(changedLines("a\nb\n", "a\nb\n")).toBe(0);
});

test("a prompt-injected reply naming another file cannot move the write (the path is ours, not the model's)", async () => {
  const dir = repoWith("a.ts", "export const bad = 1;\n");
  const outside = join(dirname(dir), "victim.txt");
  writeFileSync(outside, "untouched");
  const reply = JSON.stringify({ action: "patch", why: "w", file: "export const good = 1;\n", path: outside, location: "../victim.txt" });
  await fixOneWithAgent({ finding: finding(), repoPath: dir, rubric: "R", seat: seatSaying(reply), verify: () => true, gatesHold: () => true });
  expect(readFileSync(outside, "utf8")).toBe("untouched");
});
