#!/usr/bin/env bash
# Applies one named MECHANICAL fix to a target checkout, from fix/templates/.
# Pure, deterministic, idempotent: re-running when the artefact is already
# present is a no-op. Only mechanical-tier actions live here -- deep and
# dangerous gaps are spec-routed by the orchestrator and must NEVER get an
# action in this file.
#
# Ported from the Whisky AI OS. `job-timeouts` and `logger-scaffold` are new:
# classify.md named both as mechanical actions but the OS script implemented
# neither, so the orchestrator would have exited 2 on a finding it had just
# classified as auto-fixable.
set -uo pipefail
T="$(cd "$(dirname "$0")/templates" && pwd)"
TARGET="${1:?target repo path}"; ACTION="${2:?action}"

case "$ACTION" in
  engines-node)
    node -e '
      const fs=require("fs"); const p=process.argv[1]+"/package.json";
      const j=JSON.parse(fs.readFileSync(p)); j.engines=j.engines||{};
      j.engines.node=j.engines.node||"20.x";
      fs.writeFileSync(p, JSON.stringify(j,null,2)+"\n");
    ' "$TARGET"; echo "$TARGET/package.json" ;;

  prepush-hook)
    mkdir -p "$TARGET/.husky"; cp "$T/pre-push" "$TARGET/.husky/pre-push"
    chmod +x "$TARGET/.husky/pre-push"; echo "$TARGET/.husky/pre-push" ;;

  rollback-script)
    mkdir -p "$TARGET/scripts"; cp "$T/rollback.sh" "$TARGET/scripts/rollback.sh"
    chmod +x "$TARGET/scripts/rollback.sh"; echo "$TARGET/scripts/rollback.sh" ;;

  core-docs)
    [ -f "$TARGET/README.md" ] || printf '# %s\n' "$(basename "$TARGET")" > "$TARGET/README.md"
    mkdir -p "$TARGET/docs"
    [ -f "$TARGET/docs/ROLLBACK.md" ] || cp "$T/ROLLBACK.md" "$TARGET/docs/ROLLBACK.md"
    [ -f "$TARGET/docs/DEPLOYMENT.md" ] || printf '# Deployment\n\nTODO\n' > "$TARGET/docs/DEPLOYMENT.md"
    echo "$TARGET/README.md $TARGET/docs/" ;;

  sitemap-robots)
    d="$TARGET/app"; [ -d "$TARGET/src/app" ] && d="$TARGET/src/app"
    mkdir -p "$d"
    [ -f "$d/sitemap.ts" ] || cp "$T/sitemap.ts" "$d/sitemap.ts"
    [ -f "$d/robots.ts" ] || cp "$T/robots.ts" "$d/robots.ts"
    echo "$d/sitemap.ts $d/robots.ts" ;;

  gitleaks-workflow)
    mkdir -p "$TARGET/.github/workflows"
    cp "$T/gitleaks.yml" "$TARGET/.github/workflows/gitleaks.yml"
    echo "$TARGET/.github/workflows/gitleaks.yml" ;;

  job-timeouts)
    # Insert `timeout-minutes: 15` into every job that has none. A job is a
    # 2-space key under `jobs:`; its `runs-on` line is the anchor, because every
    # job has exactly one and it sits at a known indent. Additive only -- a job
    # that already declares a timeout is left untouched.
    written=""
    for wf in "$TARGET"/.github/workflows/*.y*ml; do
      [ -f "$wf" ] || continue
      grep -q 'timeout-minutes' "$wf" && continue
      grep -qE '^[[:space:]]{4}runs-on:' "$wf" || continue
      tmp="$wf.fixtmp"
      sed -E 's/^([[:space:]]{4})(runs-on:.*)$/\1\2\n\1timeout-minutes: 15/' "$wf" > "$tmp" && mv "$tmp" "$wf"
      written="$written $wf"
    done
    [ -n "$written" ] || { echo "no timeout-less job found to patch" >&2; exit 3; }
    echo "$written" ;;

  logger-scaffold)
    # Creates the module ONLY. Adopting it at every console.* call site changes
    # behaviour and is classified mechanical-scaffold for exactly that reason:
    # the orchestrator writes a spec for the adoption step.
    d="$TARGET/src/lib"; [ -d "$TARGET/src" ] || d="$TARGET/lib"
    mkdir -p "$d"
    if [ ! -f "$d/logger.ts" ]; then
      cat > "$d/logger.ts" <<'TS'
// Structured logger. One JSON object per line so a log drain can index fields
// instead of regex-ing prose. Adoption (replacing console.* at each call site)
// is a separate, reviewed change -- this module only makes it possible.
type Level = "debug" | "info" | "warn" | "error";

const emit = (level: Level, message: string, fields: Record<string, unknown> = {}) => {
  const line = JSON.stringify({ level, message, ts: new Date().toISOString(), ...fields });
  if (level === "error" || level === "warn") console.error(line);
  else console.log(line);
};

export const logger = {
  debug: (m: string, f?: Record<string, unknown>) => emit("debug", m, f),
  info: (m: string, f?: Record<string, unknown>) => emit("info", m, f),
  warn: (m: string, f?: Record<string, unknown>) => emit("warn", m, f),
  error: (m: string, f?: Record<string, unknown>) => emit("error", m, f),
};
TS
    fi
    echo "$d/logger.ts" ;;

  *) echo "unknown or non-mechanical action: $ACTION" >&2; exit 2 ;;
esac
