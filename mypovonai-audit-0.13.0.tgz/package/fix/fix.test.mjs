import { execFileSync } from "node:child_process";
import { mkdtempSync, readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

import { expect, test } from "vitest";

import { classify, isAutoApplicable, RULES, TIERS } from "./classify.mjs";
import { runFleet } from "../run.mjs";
import { collectFindings, runFix } from "./run-fix.mjs";

const FIX_DIR = dirname(fileURLToPath(import.meta.url));
const FLEET_DIR = join(FIX_DIR, "..");

test("every action a classification rule names actually exists in apply-mechanical.sh", () => {
  // The OS table this was ported from named four actions the script did not
  // implement (job-timeouts, axe-ci, boundedmap, logger-scaffold). The
  // orchestrator would have classified a finding as auto-fixable and then
  // exited 2 calling an action that was never written.
  const script = readFileSync(join(FIX_DIR, "apply-mechanical.sh"), "utf8");
  const missing = RULES.filter((r) => r.action).filter((r) => !new RegExp(`^\\s*${r.action}\\)`, "m").test(script));
  expect(missing.map((r) => r.action)).toEqual([]);
});

test("every rule declares a known tier, and only mechanical tiers carry an action", () => {
  for (const rule of RULES) {
    expect(TIERS).toContain(rule.tier);
    if (rule.action) expect(isAutoApplicable(rule.tier)).toBe(true);
    // A non-mechanical rule must SAY why it is not auto-fixed; a bare "deep"
    // with no reason is how a finding quietly stops being actionable.
    if (!rule.action) expect(rule.why ?? "").not.toBe("");
  }
});

test("every rule matches a message some fixture actually produces", () => {
  // A classification rule that matches nothing is dead in exactly the way a
  // probe with no fixture is dead: it will never fire, and nothing says so.
  const messages = [];
  for (const lens of new Set(RULES.map((r) => r.lens))) {
    for (const fx of [`fixtures/${lens}`, `fixtures/${lens}.b`, `fixtures/${lens}.c`]) {
      if (!existsSync(join(FLEET_DIR, fx))) continue;
      const out = execFileSync("bash", [join(FLEET_DIR, "probes", `${lens}.sh`), join(FLEET_DIR, fx)], {
        encoding: "utf8",
      });
      for (const line of out.split("\n")) {
        if (!line.trim()) continue;
        try {
          const row = JSON.parse(line);
          if (row.type === "finding") messages.push({ lens: row.lens, message: row.message });
        } catch {
          /* not a finding line */
        }
      }
    }
  }
  const unmatched = RULES.filter((r) => r.match).filter(
    (r) => !messages.some((m) => m.lens === r.lens && r.match.test(m.message)),
  );
  expect(unmatched.map((r) => `${r.lens}:${r.match}`)).toEqual([]);
});

test("an unclassified finding defaults to a spec, never to an edit", () => {
  const c = classify({ lens: "a-lens-that-does-not-exist", message: "anything" });
  expect(c.tier).toBe("deep");
  expect(isAutoApplicable(c.tier)).toBe(false);
  expect(c.action).toBeNull();
});

test("migration-safety and gate-integrity are never auto-applicable, whatever the message", () => {
  // A bad migration is an outage, not a diff; a gate edit either silences a live
  // gate or reddens CI for everyone.
  for (const lens of ["migration-safety", "gate-integrity"]) {
    const c = classify({ lens, message: "add a missing file, looks trivial" });
    expect(isAutoApplicable(c.tier)).toBe(false);
    expect(c.tier).toBe("deep-dangerous");
  }
});

test("a judge-downgraded candidate is never picked up for fixing", () => {
  const report = {
    lenses: [
      {
        id: "cicd",
        status: "judged",
        candidates: [
          { location: "a", message: "no gitleaks scan in any workflow", verdict: { ruling: "false-positive", why: "x" } },
          { location: "b", message: "no gitleaks scan in any workflow", verdict: { ruling: "confirmed" } },
        ],
      },
    ],
  };
  expect(collectFindings(report)).toHaveLength(1);
});

/** A throwaway git repo with a known set of mechanical gaps. */
function brokenRepo() {
  const dir = mkdtempSync(join(tmpdir(), "fleet-fix-"));
  mkdirSync(join(dir, ".github", "workflows"), { recursive: true });
  writeFileSync(join(dir, "package.json"), '{"name":"demo"}\n');
  writeFileSync(
    join(dir, ".github", "workflows", "ci.yml"),
    "name: ci\non: [push]\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n      - run: npm ci\n",
  );
  const g = (...a) => execFileSync("git", ["-C", dir, ...a], { encoding: "utf8" });
  g("init", "-q");
  g("add", "-A");
  g("-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "init");
  return dir;
}

test("the patch contains files the fix CREATED, not only files it edited", async () => {
  // `git diff` reports tracked files only, and most mechanical fixes ADD a file.
  // A patch missing them still applies cleanly, so the gap silently survives.
  const repo = brokenRepo();
  const out = mkdtempSync(join(tmpdir(), "fleet-out-"));
  // A REAL baseline from the real fleet. A hand-written partial one makes the
  // blast-radius sweep see every finding the baseline omitted as a regression.
  const report = await runFleet({ repoPath: repo, apiKey: null });
  const result = await runFix({ repoPath: repo, report, outDir: out });
  expect(result.applied.map((a) => a.action)).toContain("gitleaks-workflow");
  const patch = readFileSync(join(out, "patch.diff"), "utf8");
  expect(patch).toContain("gitleaks.yml");
  // and it must actually apply to a clean checkout of the same commit
  const clone = mkdtempSync(join(tmpdir(), "fleet-clone-"));
  execFileSync("git", ["clone", "-q", repo, clone]);
  writeFileSync(join(clone, "p.diff"), patch);
  expect(() => execFileSync("git", ["-C", clone, "apply", "--check", "p.diff"])).not.toThrow();
}, 120_000);

test("a deep finding produces a spec and touches no file", async () => {
  const repo = mkdtempSync(join(tmpdir(), "fleet-deep-"));
  execFileSync("git", ["-C", repo, "init", "-q"]);
  writeFileSync(join(repo, "package.json"), '{"name":"d"}\n');
  execFileSync("git", ["-C", repo, "add", "-A"]);
  execFileSync("git", ["-C", repo, "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "i"]);
  const out = mkdtempSync(join(tmpdir(), "fleet-out-"));
  const report = {
    lenses: [
      {
        id: "migration-safety",
        status: "unjudged",
        candidates: [{ location: "prisma/x.sql", message: "ADD COLUMN NOT NULL with no DEFAULT", severity: "critical" }],
      },
    ],
  };
  const result = await runFix({ repoPath: repo, report, outDir: out });
  expect(result.applied).toEqual([]);
  expect(result.specs).toHaveLength(1);
  expect(existsSync(join(out, "specs", "migration-safety-1.md"))).toBe(true);
  expect(result.patchBytes).toBe(0);
}, 120_000);

test("the fixer never opens a PR, pushes, or asks for write scope", () => {
  // R-9. The customer receives a diff and applies it themselves; a PR needs
  // `contents: write` on their repository, which is a different sale.
  const src = readFileSync(join(FIX_DIR, "run-fix.mjs"), "utf8");
  const body = src.replace(/^[\s\S]*?\*\//, ""); // drop the header comment, which DESCRIBES the rule
  for (const forbidden of ["gh pr", "pull-request", '"push"', "contents: write", '"commit"']) {
    expect(body).not.toContain(forbidden);
  }
});
