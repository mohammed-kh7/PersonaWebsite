# Rollback runbook

TODO: document the recovery paths for this project.

## Deploy rollback
- How to revert the last deploy (railway/vercel/CF rollback command).

## Database rollback
- Latest backup location + restore command.
- PITR window, if any.

## Who to page
- On-call contact + escalation.
