#!/usr/bin/env bash
# Scripted revert path for a bad deploy. Fill in the deploy-target specifics.
set -euo pipefail
echo "Rolling back to the previous release…"
# e.g. railway rollback / vercel rollback / git revert <sha> && redeploy
exit 0
