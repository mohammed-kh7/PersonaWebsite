/**
 * Fix classification — mechanical vs deep vs infra.
 *
 * Ported from the Whisky AI OS `fix/classify.md`, turned from a markdown table
 * into data so it can be TESTED. The markdown version named four actions
 * (`job-timeouts`, `axe-ci`, `boundedmap`, `logger-scaffold`) that
 * `apply-mechanical.sh` did not implement: the orchestrator would have called
 * an unknown action and exited 2. `fix.test.mjs` now asserts every action a
 * rule names exists in the script, and that every rule matches a message some
 * fixture actually produces -- a classification rule that matches nothing is
 * dead in exactly the way a probe with no fixture is dead.
 *
 * A gap is MECHANICAL only if the fix is deterministic, additive, and cannot
 * change existing behaviour: a missing file/field/flag with one correct shape.
 * Anything that requires reading and re-designing existing code is DEEP and
 * gets a spec, never a blind edit. Infra gaps get a runbook entry.
 */

export const TIERS = ["mechanical", "mechanical-scaffold", "deep", "deep-dangerous", "infra"];

/**
 * Ordered; the first rule whose lens matches and whose `match` tests true wins.
 * `match: null` means "every finding from this lens".
 */
export const RULES = [
  // ---- mechanical: add a missing file/field, cannot alter existing behaviour
  { lens: "cicd", match: /no gitleaks scan/i, tier: "mechanical", action: "gitleaks-workflow" },
  { lens: "security", match: /no gitleaks config or workflow/i, tier: "mechanical", action: "gitleaks-workflow" },
  { lens: "cicd", match: /no timeout-minutes/i, tier: "mechanical", action: "job-timeouts" },
  { lens: "deploy-verify", match: /no engines\.node/i, tier: "mechanical", action: "engines-node" },
  { lens: "deploy-verify", match: /pre-push/i, tier: "mechanical", action: "prepush-hook" },
  { lens: "docs-parity", match: /core docs missing/i, tier: "mechanical", action: "core-docs" },
  { lens: "dr", match: /no rollback\.sh/i, tier: "mechanical", action: "rollback-script" },
  { lens: "frontend-quality", match: /storefront missing/i, tier: "mechanical", action: "sitemap-robots" },

  // ---- mechanical(scaffold): the skeleton is deterministic, ADOPTION is not
  {
    lens: "observability",
    match: /no structured logger/i,
    tier: "mechanical-scaffold",
    action: "logger-scaffold",
    why: "the module is a correct skeleton; wiring it into every console.* call site changes behaviour and is spec'd separately",
  },

  // ---- deep + DANGEROUS: never auto-edit, spec only
  {
    lens: "migration-safety",
    match: null,
    tier: "deep-dangerous",
    why: "a migration rewrite is an outage, not a diff -- spec only",
  },
  {
    lens: "dr",
    match: /DROPs a column|destructive migration/i,
    tier: "deep-dangerous",
    why: "expand/contract must be split by a human who knows what is already deployed",
  },
  {
    lens: "gate-integrity",
    match: null,
    tier: "deep-dangerous",
    why: "a gate edit either silences a live gate or reddens CI for everyone, and the negative control must be RUN, not written",
  },

  // ---- infra: a runbook entry, not code
  { lens: "edge-protection", match: null, tier: "infra", why: "WAF / origin-lock / DDoS posture lives in the CDN config, not the repo" },
  { lens: "environments", match: null, tier: "infra", why: "an env-value change (owner role -> app role) is made in the platform, not the checkout" },
  { lens: "unit-economics", match: /no usage\/cost column/i, tier: "deep", why: "cost attribution is a schema change plus a write at every model call -- spec" },
  { lens: "skill-hygiene", match: null, tier: "infra", why: "disposal and reviewer rotation are judgment and credentials, not a diff" },
];

/**
 * The default is `deep`, and that is the point: when unsure, write a spec a
 * human reads. A wrong mechanical auto-edit is worse than a spec.
 */
export const DEFAULT = {
  tier: "deep",
  why: "no rule matched -- defaulting to a spec, because a wrong mechanical edit is worse than a spec a human reads",
};

export function classify(finding) {
  const message = String(finding?.message ?? "");
  for (const rule of RULES) {
    if (rule.lens !== finding?.lens) continue;
    if (rule.match && !rule.match.test(message)) continue;
    return { tier: rule.tier, action: rule.action ?? null, why: rule.why ?? null };
  }
  return { ...DEFAULT, action: null };
}

/** Only these two tiers are ever applied automatically. */
export const isAutoApplicable = (tier) => tier === "mechanical" || tier === "mechanical-scaffold";
