/**
 * Terminal presentation for `mypovonai-audit` -- presentation ONLY.
 *
 * Nothing in here decides what is measured, printed or uploaded; it decides how
 * the same facts are laid out. The site is monochrome, so the CLI is too: there
 * is no colour anywhere in this file. Hierarchy comes from weight, dim, inverse
 * video, box-drawing and glyphs, and every severity carries its own bar glyph
 * (█ ▓ ▒ ░) so the report still reads correctly with colour switched off.
 *
 * Three modes, decided once by `detectCaps`:
 *
 *   plain   not a TTY, TERM=dumb, or --json. The caller prints its original
 *           lines through `console.error`; this file draws nothing. CI logs stay
 *           clean: no escape codes, no spinner frames, no box drawing.
 *   rich    a TTY (or FORCE_COLOR). Banner, phases, score card, grouped findings.
 *   +color  rich AND colour allowed (NO_COLOR unset). Adds bold/dim/inverse and,
 *           only on a real TTY, the animated spinner and progress bar.
 *
 * No dependencies on purpose (deps discipline): a CLI that runs against other
 * people's source should have the smallest supply-chain surface we can give it.
 */

import { END_ART, START_ART } from "./art.mjs";

const CSI = "\u001b[";
const ANSI_RE = /\u001b(?:\[[0-?]*[ -/]*[@-~]|\][^\u0007\u001b]*(?:\u0007|\u001b\\)|[@-Z\\-_])/g;
const CONTROL_RE = /[\u0000-\u0008\u000b-\u001f\u007f-\u009f‪-‮⁦-⁩]/g;

export const stripAnsi = (s) => String(s).replace(ANSI_RE, "");

/**
 * Finding text comes from the audited repository, which an attacker may have
 * written. Printing it raw to a terminal lets a file name or a message move the
 * cursor, rewrite earlier lines or set the window title. Strip escape sequences
 * and control characters (including bidi overrides) before it is drawn.
 */
// Every character a terminal or the Actions runner may treat as ending a line.
const LINE_BREAK_RE = /\r\n|[\r\u0085\u2028\u2029\u000b\u000c]/g;
// Zero-width and soft-hyphen characters: invisible, so `:\u200b:` would render as `::`.
const INVISIBLE_RE = /[\u00ad\u200b-\u200f\u2060-\u2064\ufeff]/g;

export const sanitize = (s) =>
  String(s ?? "")
    .replace(ANSI_RE, "")
    .replace(LINE_BREAK_RE, "\n")
    .replace(CONTROL_RE, "")
    .replace(INVISIBLE_RE, "")
    .replace(/\t/g, " ");

/**
 * GitHub Actions runs a workflow command from any log line that starts with
 * `::` (`::add-mask::`, `::set-env`, `::error file=...`). Finding text is written
 * by the audited repository, so a line like that must never reach a CI log
 * intact. Prefix it; the text stays readable.
 */
export const defang = (line) =>
  String(line).replace(/^((?:[\s\u00ad\u200b-\u200f\u2060-\u2064\ufeff]|\u001b\[[0-9;]*m)*)::/, "$1\u2023 ::");

/** The last gate before bytes leave: split on EVERY line terminator and defang each emitted line. */
export const finalize = (text) =>
  String(text).split(/\r\n|[\n\r\u0085\u2028\u2029\u000b\u000c]/).map(defang).join("\n");

/** Sanitised, multi-line safe: escapes and control characters removed (newlines kept), every `::` line defanged. */
export const safeText = (s) => finalize(sanitize(s));

// ---- width ------------------------------------------------------------------

const ZERO_WIDTH = [
  [0x0300, 0x036f], [0x0483, 0x0489], [0x0591, 0x05bd], [0x05bf, 0x05bf],
  [0x05c1, 0x05c2], [0x05c4, 0x05c5], [0x05c7, 0x05c7], [0x0610, 0x061a],
  [0x064b, 0x065f], [0x0670, 0x0670], [0x06d6, 0x06dc], [0x06df, 0x06e4],
  [0x06e7, 0x06e8], [0x06ea, 0x06ed], [0x0e31, 0x0e31], [0x0e34, 0x0e3a],
  [0x0e47, 0x0e4e], [0x200b, 0x200f], [0x202a, 0x202e], [0x2060, 0x2064],
  [0x20d0, 0x20ff], [0xfe00, 0xfe0f], [0xfe20, 0xfe2f], [0xfeff, 0xfeff],
  [0xe0100, 0xe01ef],
];
const WIDE = [
  [0x1100, 0x115f], [0x231a, 0x231b], [0x2329, 0x232a], [0x23e9, 0x23ec],
  [0x25fd, 0x25fe], [0x2614, 0x2615], [0x2648, 0x2653], [0x267f, 0x267f],
  [0x2693, 0x2693], [0x26a1, 0x26a1], [0x26aa, 0x26ab], [0x26bd, 0x26be],
  [0x26c4, 0x26c5], [0x26ce, 0x26ce], [0x26d4, 0x26d4], [0x26ea, 0x26ea],
  [0x26f2, 0x26f3], [0x26f5, 0x26f5], [0x26fa, 0x26fa], [0x26fd, 0x26fd],
  [0x2705, 0x2705], [0x270a, 0x270b], [0x2728, 0x2728], [0x274c, 0x274c],
  [0x274e, 0x274e], [0x2753, 0x2755], [0x2757, 0x2757], [0x2795, 0x2797],
  [0x27b0, 0x27b0], [0x27bf, 0x27bf], [0x2b1b, 0x2b1c], [0x2b50, 0x2b50],
  [0x2b55, 0x2b55], [0x2e80, 0x303e], [0x3041, 0x33ff], [0x3400, 0x4dbf],
  [0x4e00, 0xa4cf], [0xa960, 0xa97f], [0xac00, 0xd7a3], [0xf900, 0xfaff],
  [0xfe30, 0xfe6f], [0xff00, 0xff60], [0xffe0, 0xffe6], [0x1f300, 0x1f64f],
  [0x1f680, 0x1f6ff], [0x1f900, 0x1f9ff], [0x1fa70, 0x1faff], [0x20000, 0x3fffd],
];
const inRanges = (cp, ranges) => {
  for (const [lo, hi] of ranges) {
    if (cp < lo) return false;
    if (cp <= hi) return true;
  }
  return false;
};

/** Terminal columns one code point occupies: 0 (marks, controls), 1, or 2 (East Asian wide, emoji). */
export function charWidth(cp) {
  if (cp === 0 || cp < 32 || (cp >= 0x7f && cp < 0xa0)) return 0;
  if (cp < 0x300) return 1;
  if (inRanges(cp, ZERO_WIDTH)) return 0;
  if (inRanges(cp, WIDE)) return 2;
  return 1;
}

const segmenter =
  typeof Intl !== "undefined" && Intl.Segmenter
    ? new Intl.Segmenter(undefined, { granularity: "grapheme" })
    : null;
const graphemes = (s) =>
  segmenter ? Array.from(segmenter.segment(s), (x) => x.segment) : Array.from(s);

function graphemeWidth(g) {
  let w = 0;
  for (const ch of g) {
    const cw = charWidth(ch.codePointAt(0));
    if (cw > w) w = cw;
  }
  // An emoji presentation selector turns a narrow symbol into a wide one.
  if (g.includes("️")) w = 2;
  return w;
}

/** Display width of a string, ignoring ANSI escapes. */
export function strWidth(s) {
  let w = 0;
  for (const g of graphemes(stripAnsi(s))) w += graphemeWidth(g);
  return w;
}

const padEnd = (s, width) => s + " ".repeat(Math.max(0, width - strWidth(s)));

/** Cut to `width` columns, ending in an ellipsis when something was removed. */
export function truncate(s, width, ellipsis = "…") {
  if (strWidth(s) <= width) return s;
  const room = Math.max(0, width - strWidth(ellipsis));
  let out = "";
  let used = 0;
  for (const g of graphemes(stripAnsi(s))) {
    const gw = graphemeWidth(g);
    if (used + gw > room) break;
    out += g;
    used += gw;
  }
  return out + ellipsis;
}

/**
 * Wrap to `width` columns. The first line is prefixed with `indent`, every
 * later line with `hang` (a hanging indent). A single token wider than the line
 * is split by grapheme, never mid-codepoint, so CJK and combining sequences
 * survive. Width is display width, so wide characters do not overflow.
 */
export function wrapText(text, width, { indent = "", hang = indent } = {}) {
  const lines = [];
  const prefixFor = () => (lines.length === 0 ? indent : hang);
  for (const para of String(text).split("\n")) {
    const words = para.split(/\s+/).filter(Boolean);
    if (words.length === 0) {
      lines.push(prefixFor().trimEnd());
      continue;
    }
    let cur = "";
    let curW = 0;
    const flush = () => {
      lines.push(prefixFor() + cur);
      cur = "";
      curW = 0;
    };
    for (const word of words) {
      const avail = () => Math.max(1, width - strWidth(prefixFor()));
      const ww = strWidth(word);
      if (cur && curW + 1 + ww <= avail()) {
        cur += ` ${word}`;
        curW += 1 + ww;
        continue;
      }
      if (cur) flush();
      if (ww <= avail()) {
        cur = word;
        curW = ww;
        continue;
      }
      for (const g of graphemes(word)) {
        const gw = graphemeWidth(g);
        if (curW + gw > avail() && cur) flush();
        cur += g;
        curW += gw;
      }
    }
    if (cur) flush();
  }
  return lines;
}

// ---- capabilities -----------------------------------------------------------

/**
 * Decide, once, how this process should draw.
 *
 * FORCE_COLOR (truthy) wins over every other signal, as in Node's own tooling.
 * FORCE_COLOR=0 / false turns colour off but leaves the layout alone. NO_COLOR
 * (any non-empty value) removes every escape code AND the animation, and keeps
 * the layout -- which is why the layout never relies on colour to mean anything.
 */
export function detectCaps({
  stream = process.stderr,
  env = process.env,
  platform = process.platform,
  json = false,
} = {}) {
  const fc = env.FORCE_COLOR;
  const forced = fc !== undefined && fc !== "" && fc !== "0" && fc !== "false";
  const forcedOff = fc === "0" || fc === "false";
  const noColor = env.NO_COLOR !== undefined && env.NO_COLOR !== "";
  const dumb = env.TERM === "dumb";
  const tty = Boolean(stream?.isTTY);

  const cols = Number(stream?.columns) || Number(env.COLUMNS) || 80;
  const width = Math.min(100, Math.max(40, cols));

  const lang = `${env.LC_ALL ?? ""}${env.LC_CTYPE ?? ""}${env.LANG ?? ""}`;
  let unicode;
  if (platform === "win32") {
    // Classic conhost cannot draw box characters; Windows Terminal, VS Code's
    // terminal and anything with a UTF-8 locale can.
    unicode = Boolean(env.WT_SESSION) || env.TERM_PROGRAM === "vscode" || /utf-?8/i.test(lang);
  } else {
    unicode = env.TERM !== "linux" && !/^(C|POSIX)$/.test(env.LC_ALL || env.LANG || "");
  }

  if (json) return { rich: false, color: false, animate: false, unicode, width };
  const rich = forced || (tty && !dumb);
  const color = rich && !noColor && !forcedOff;
  const animate = rich && color && tty && !dumb;
  return { rich, color, animate, unicode, width };
}

// ---- styling ----------------------------------------------------------------

export function makeStyle(color) {
  const wrap = (on, off) => (s) => (color ? `${CSI}${on}m${s}${CSI}${off}m` : s);
  return { bold: wrap(1, 22), dim: wrap(2, 22), inv: wrap(7, 27) };
}

const GLYPHS = {
  unicode: {
    tl: "╭", tr: "╮", bl: "╰", br: "╯", h: "─", v: "│",
    ok: "✓", bad: "✗", warn: "!", dot: "·", arrow: "→",
    fill: "━", rest: "┄",
    sev: { critical: "█", high: "▓", medium: "▒", low: "░" },
    spin: ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"],
  },
  ascii: {
    tl: "+", tr: "+", bl: "+", br: "+", h: "-", v: "|",
    ok: "+", bad: "x", warn: "!", dot: "-", arrow: "->",
    fill: "=", rest: "-",
    sev: { critical: "#", high: "=", medium: "-", low: "." },
    spin: ["|", "/", "-", "\\"],
  },
};
const glyphsFor = (caps) => (caps.unicode ? GLYPHS.unicode : GLYPHS.ascii);

const SEVERITIES = ["critical", "high", "medium", "low"];

/** Ahmad's art is printed only where it fits whole: colour on, UTF-8, and its width + a 2 column margin. */
export const artFits = (art, caps) =>
  Boolean(caps.rich && caps.color && caps.unicode) && caps.width >= Math.max(...art.map(strWidth)) + 2;

// Shading is the design; weight only reinforces it (dim on the light blocks, bold on the solid one).
const shade = (line, s) =>
  line.replace(/[░▒]+|█+/g, (run) => (run[0] === "█" ? s.bold(run) : s.dim(run)));

// ---- wordmark and score font ------------------------------------------------

const WORDMARK = {
  M: ["┏┳┓", "┃╹┃", "╹ ╹"],
  y: ["   ", "╻ ╻", "┗━┫"],
  P: ["┏━┓", "┣━┛", "╹  "],
  o: ["   ", "┏━┓", "┗━┛"],
  v: ["   ", "╻ ╻", " ╹ "],
  O: ["┏━┓", "┃ ┃", "┗━┛"],
  n: ["   ", "┏━┓", "╹ ╹"],
  A: ["┏━┓", "┣━┫", "╹ ╹"],
  I: ["╺┳╸", " ┃ ", "╺┻╸"],
};
const DIGITS = {
  0: ["┏━┓", "┃ ┃", "┗━┛"],
  1: ["╺┓ ", " ┃ ", "╺┻╸"],
  2: ["╺━┓", "┏━┛", "┗━╸"],
  3: ["╺━┓", "╺━┫", "╺━┛"],
  4: ["╻ ╻", "┗━┫", "  ╹"],
  5: ["┏━╸", "┗━┓", "╺━┛"],
  6: ["┏━╸", "┣━┓", "┗━┛"],
  7: ["╺━┓", "  ┃", "  ╹"],
  8: ["┏━┓", "┣━┫", "┗━┛"],
  9: ["┏━┓", "┗━┫", "╺━┛"],
};

const bigText = (text, font) =>
  [0, 1, 2].map((row) => [...text].map((ch) => font[ch][row]).join(" "));

/** The opening banner: wordmark, version and the one promise that matters. At most 6 lines, 60 columns. */
export function renderBanner(caps, version) {
  const s = makeStyle(caps.color);
  const g = glyphsFor(caps);
  const tag = `audit ${version} ${g.dot} probes run on this machine`;
  const lines = [""];
  if (artFits(START_ART, caps)) {
    for (const row of START_ART) lines.push(`  ${shade(row, s)}`);
    lines.push("");
  } else if (caps.unicode && caps.width >= 40) {
    for (const row of bigText("MyPovOnAI", WORDMARK)) lines.push(`  ${s.bold(row)}`);
  } else {
    lines.push(`  ${s.bold("MyPovOnAI")}`);
  }
  for (const row of wrapText(tag, caps.width - 4, { indent: "  " })) lines.push(s.dim(row));
  return lines.join("\n");
}

// ---- score card -------------------------------------------------------------

function box(lines, width, caps) {
  const g = glyphsFor(caps);
  const inner = width - 2;
  const edge = g.h.repeat(inner);
  const out = [`${g.tl}${edge}${g.tr}`];
  for (const line of lines) out.push(`${g.v}${padEnd(`  ${line}`, inner)}${g.v}`);
  out.push(`${g.bl}${edge}${g.br}`);
  return out;
}

function sevLabel(sev, s) {
  const text = ` ${sev}`.padEnd(10);
  if (sev === "critical") return s.inv(text);
  if (sev === "high") return s.bold(text);
  if (sev === "low") return s.dim(text);
  return text;
}

/** Severity counts as a horizontal bar chart; each severity has its own glyph so colour is never needed. */
export function renderBars(counts, caps, barWidth) {
  const s = makeStyle(caps.color);
  const g = glyphsFor(caps);
  const max = Math.max(1, ...SEVERITIES.map((k) => counts[k] ?? 0));
  return SEVERITIES.map((sev) => {
    const n = counts[sev] ?? 0;
    const len = n === 0 ? 0 : Math.max(1, Math.round((n / max) * barWidth));
    const bar = g.sev[sev].repeat(len);
    const styled = sev === "low" ? s.dim(bar) : bar;
    const count = n === 0 ? s.dim(String(n)) : s.bold(String(n));
    return `${sevLabel(sev, s)} ${padEnd(styled, barWidth)} ${" ".repeat(3 - String(n).length)}${count}`;
  });
}

/**
 * The score card. `judged` is true, false or null (unknown); `note` is the
 * honest one-liner about what the score is. Samples are summarised, not listed
 * (the full list is in --json and in the plain output).
 */
export function renderCard({ score, counts, coverage, samples = [], judged = null, label = "probe score", note = null }, caps) {
  const s = makeStyle(caps.color);
  const g = glyphsFor(caps);
  const boxW = Math.min(64, caps.width - 2);
  const innerW = boxW - 6;
  const lines = [""];

  const judgedText = judged === true ? "judged" : judged === false ? "unjudged" : "";
  if (caps.unicode && score !== null) {
    const digits = bigText(String(score), DIGITS);
    const right = [s.bold(label), s.bold(score === null ? "N/A" : `${score}/100`), s.dim(judgedText)];
    digits.forEach((row, i) => lines.push(`${s.bold(row)}   ${right[i]}`.trimEnd()));
  } else {
    lines.push(`${s.bold(score === null ? "N/A" : `${score}/100`)}   ${label}${judgedText ? ` (${judgedText})` : ""}`);
  }
  lines.push("");
  const barWidth = Math.max(8, Math.min(28, innerW - 10 - 1 - 1 - 3));
  lines.push(...renderBars(counts, caps, barWidth));
  lines.push("");
  const ran = coverage?.ran?.length ?? 0;
  const unavail = coverage?.unavailable?.length ?? 0;
  lines.push(
    `${s.dim("lenses")}   ${ran} ran ${g.dot} ${unavail > 0 ? s.bold(`${unavail} unavailable`) : `${unavail} unavailable`}`,
  );
  if (samples.length) {
    const sc = {};
    for (const f of samples) sc[f.severity] = (sc[f.severity] ?? 0) + 1;
    const parts = SEVERITIES.filter((k) => sc[k]).map((k) => `${sc[k]} ${k}`);
    const text = `${samples.length} in fixtures/samples not scored (${parts.join(` ${g.dot} `)}) ${g.dot} --include-samples scores them`;
    wrapText(text, innerW - 9).forEach((row, i) => lines.push(`${i === 0 ? s.dim("samples") + "  " : "         "}${s.dim(row)}`));
  }
  if (unavail > 0) for (const row of wrapText("Partial score: unavailable lenses excluded.", innerW)) lines.push(s.bold(row));
  if (note) for (const row of wrapText(note, innerW)) lines.push(s.dim(row));
  lines.push("");
  return ["", ...box(lines, boxW, caps).map((l) => `  ${l}`), ""].join("\n");
}

// ---- findings ---------------------------------------------------------------

/**
 * EVERY finding, every severity, the full message, grouped worst first. The
 * message wraps to the terminal with a hanging indent; the location sits dim
 * beside the lens. Text is sanitised: it came from the audited repository.
 */
export function renderFindings(findings, caps) {
  const s = makeStyle(caps.color);
  const g = glyphsFor(caps);
  const w = caps.width;
  const known = new Set(SEVERITIES);
  const groups = [...SEVERITIES, "other"].map((sev) => ({
    sev,
    rows: findings.filter((f) => (known.has(f.severity) ? f.severity : "other") === sev),
  }));
  const out = [];
  for (const { sev, rows } of groups) {
    if (rows.length === 0) continue;
    const name = sev.toUpperCase();
    const head =
      sev === "critical" ? s.inv(` ${name} `) : sev === "high" ? s.bold(name) : sev === "low" ? s.dim(name) : name;
    out.push(`  ${head}  ${s.dim(String(rows.length))}`);
    const mark = g.sev[sev] ?? g.dot;
    for (const f of rows) {
      const lens = sanitize(f.lens).replace(/\s+/g, " ");
      const loc = sanitize(f.location).replace(/\s+/g, " ");
      if (strWidth(lens) + 2 + strWidth(loc) <= w - 4) {
        out.push(`  ${mark} ${s.bold(lens)}${loc ? `  ${s.dim(loc)}` : ""}`);
      } else {
        out.push(`  ${mark} ${s.bold(lens)}`);
        for (const row of wrapText(loc, w - 6, { indent: "    ", hang: "    " })) out.push(`  ${s.dim(row)}`);
      }
      for (const row of wrapText(sanitize(f.message), w - 6, { indent: "    ", hang: "    " })) out.push(`  ${row}`);
      out.push("");
    }
  }
  return out.map(defang).join("\n");
}

// ---- time and live line -----------------------------------------------------

export function fmtDuration(ms) {
  if (ms < 1000) return `${Math.round(ms)}ms`;
  const sec = ms / 1000;
  if (sec < 60) return `${sec.toFixed(1)}s`;
  return `${Math.floor(sec / 60)}m ${String(Math.round(sec % 60)).padStart(2, "0")}s`;
}

/** One frame of the live phase line: spinner, label, bar, counts, current lens. Pure, so it can be tested and previewed. */
export function renderLiveLine({ label, done = 0, total = 0, detail = "" }, caps, frame = 0) {
  const s = makeStyle(caps.color);
  const g = glyphsFor(caps);
  const spin = g.spin[frame % g.spin.length];
  let line = `  ${spin} ${label}`;
  if (total > 0) {
    const bw = caps.width < 56 ? 8 : caps.width < 72 ? 12 : 24;
    const filled = Math.min(bw, Math.round((done / total) * bw));
    const count = `${done}/${total}`;
    line += `  ${g.fill.repeat(filled)}${s.dim(g.rest.repeat(bw - filled))} ${s.bold(count)}`;
  }
  const used = strWidth(line);
  if (detail) {
    const room = caps.width - 1 - used - 2;
    if (room >= 6) line += `  ${s.dim(truncate(sanitize(detail), room))}`;
  }
  return truncate(line, caps.width - 1, "");
}

const PHASE_LABELS = {
  gates: "proving gates",
  probe: "probing",
  judge: "judging",
  interpret: "interpreting",
  upload: "uploading findings",
};

// ---- the stateful surface ---------------------------------------------------

/**
 * Everything the CLI calls while it works. In plain mode every method is a
 * no-op except `plain`, which prints the original line; in rich mode `plain` is
 * a no-op and the rest draw. The caller therefore writes each message once.
 */
export function createUi(caps, { write = (t) => process.stderr.write(t), say = (...a) => console.error(...a), now = Date.now } = {}) {
  const s = makeStyle(caps.color);
  const g = glyphsFor(caps);
  const finished = new Set();
  const issues = [];
  let active = null;
  let frame = 0;
  let timer = null;
  let cursorHidden = false;

  const hideCursor = () => {
    if (!caps.animate || cursorHidden) return;
    cursorHidden = true;
    write(`${CSI}?25l`);
    process.once("exit", () => write(`${CSI}?25h`));
  };
  const showCursor = () => {
    if (!cursorHidden) return;
    cursorHidden = false;
    write(`${CSI}?25h`);
  };
  const clearLive = () => {
    if (caps.animate) write(`\r${CSI}2K`);
  };
  const draw = () => {
    if (!caps.animate || !active) return;
    frame += 1;
    write(`\r${CSI}2K${renderLiveLine(active, caps, frame)}`);
  };
  const startTimer = () => {
    if (!caps.animate || timer) return;
    timer = setInterval(draw, 80);
    timer.unref?.();
  };
  const stopTimer = () => {
    if (timer) clearInterval(timer);
    timer = null;
  };

  const ui = {
    caps,
    rich: caps.rich,
    /** Original line, plain mode only. */
    plain(...a) {
      if (!caps.rich) say(...a);
    },
    /** Same wording in both modes: `say` when plain, a quiet indented line when rich. */
    info(text) {
      if (!caps.rich) return say(safeText(text));
      ui.flushLive();
      write(`${finalize(s.dim(`  ${safeText(text)}`))}\n`);
    },
    /** The closing art, last thing on screen. Too narrow: a one-line sign-off. Not rich+colour: nothing. */
    farewell() {
      if (!caps.rich || !caps.color || !caps.unicode) return;
      ui.flushLive();
      if (artFits(END_ART, caps)) {
        write(`\n${END_ART.map((row) => `  ${shade(row, s)}`).join("\n")}\n\n`);
      } else {
        write(`\n${s.dim("  mypovonai")}\n\n`);
      }
    },
    banner(version) {
      if (caps.rich) write(`${renderBanner(caps, version)}\n\n`);
    },
    out(text) {
      if (!caps.rich) return;
      ui.flushLive();
      write(`${finalize(text)}\n`);
    },
    flushLive() {
      if (active && caps.animate) {
        clearLive();
        draw();
      }
    },
    begin(name, label = PHASE_LABELS[name] ?? name) {
      if (!caps.rich || finished.has(name)) return;
      if (active && active.name !== name) ui.end(active.name);
      active = { name, label, start: now(), done: 0, total: 0, detail: "" };
      hideCursor();
      draw();
      startTimer();
    },
    update(patch) {
      if (!active) return;
      Object.assign(active, patch);
      if (caps.animate) draw();
    },
    end(name, summary, ok = true) {
      if (!caps.rich || !active || active.name !== name) return;
      const took = fmtDuration(now() - active.start);
      stopTimer();
      clearLive();
      const mark = ok ? g.ok : g.bad;
      const text = summary ?? defaultSummary(active);
      write(`  ${ok ? mark : s.bold(mark)} ${text}  ${s.dim(took)}\n`);
      finished.add(name);
      active = null;
      showCursor();
    },
    /** Event from runFleet: `{phase, state?, done?, total?, lens?, count?}`. */
    stage(ev) {
      if (!caps.rich || finished.has(ev.phase)) return;
      if (ev.phase === "gates") {
        if (ev.state === "start") ui.begin("gates");
        else ui.end("gates", `${ev.count} gates proven`);
        return;
      }
      if (!active || active.name !== ev.phase) ui.begin(ev.phase);
      ui.update({ done: ev.done ?? 0, total: ev.total ?? 0, detail: ev.lens ?? active?.detail ?? "" });
    },
    /** `onProgress(id, note)`: failures are kept and reported; the rest only name the current lens. */
    note(id, note) {
      if (!caps.rich) return;
      if (/crashed|errored/.test(String(note))) issues.push({ id, note: String(note) });
      if (active) ui.update({ detail: String(id) });
    },
    /** Close whatever is still running and list anything that failed. */
    settle() {
      if (!caps.rich) return;
      if (active) ui.end(active.name);
      for (const { id, note } of issues.splice(0)) {
        write(`${finalize(`  ${s.bold(g.warn)} ${sanitize(id)}  ${s.dim(sanitize(note))}`)}\n`);
      }
    },
    /** Stop cleanly before printing an error. */
    abort() {
      if (!caps.rich) return;
      if (active) ui.end(active.name, undefined, false);
      stopTimer();
      showCursor();
    },
  };
  return ui;
}

function defaultSummary(p) {
  const n = p.total || p.done;
  if (p.name === "probe") return `${n} lenses probed`;
  if (p.name === "judge") return `${n} lenses judged`;
  if (p.name === "interpret") return `${n} lenses interpreted`;
  if (p.name === "gates") return "gates proven";
  return p.label;
}
