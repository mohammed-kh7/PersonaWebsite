/**
 * Which findings are about the product, and which are about sample code.
 *
 * A probe locates; it cannot know that `fixtures/php-secrets/config/services.php`
 * is a deliberately broken input for a test rather than the product's code. Left
 * alone, a repo that keeps fixtures (this package's own: 36 critical, score 0)
 * is graded on code nobody ships. This module is the ONE place that decides, so
 * the score path, the run path and the judge all agree.
 *
 * It is applied AFTER probes run (probes still see everything, and the
 * known-bad-fixture gates in tests/ still prove them alive), and a finding it
 * sets aside is REPORTED, never dropped: see `partitionSamples`.
 */
import { closeSync, constants, fchmodSync, fstatSync, ftruncateSync, lstatSync, mkdirSync, openSync, readFileSync, readSync, realpathSync, rmdirSync, unlinkSync, writeSync } from "node:fs";
import { isAbsolute, join, relative, sep } from "node:path";

import { normalizeLocator } from "./identity.mjs";

/**
 * Directory segments that mean "sample data", wherever they sit in the path.
 * Deliberately conservative -- each is a name tools and people use ONLY for
 * inputs that are not shipped:
 *   fixtures, __fixtures__, test-fixtures   hand-built inputs for tests
 *   testdata                                the Go / generic convention for the same
 *   __snapshots__                           generated test output
 *   __mocks__                               Jest/Vitest manual mocks
 * NOT matched: `test/`, `tests/`, `__tests__/`, `*.test.ts`, `spec/`. Tests can
 * hold a real leaked key or a real defect, and excluding them wholesale would
 * let a repo hide findings by moving them into a test folder.
 */
export const SAMPLE_DIRS = new Set([
  "fixtures",
  "__fixtures__",
  "test-fixtures",
  "testdata",
  "__snapshots__",
  "__mocks__",
]);

/**
 * Generated build output: bundled, minified, someone-else's-code-by-construction. A probe that
 * greps `.open-next/middleware/handler.mjs` grades the bundler, not the product (measured: a
 * model-currency "ids in 2 files" finding on a Next/OpenNext bundle). Matched as RELATIVE
 * directory segments, like SAMPLE_DIRS. Keep identical to BUILD_DIRS / BUILD_EXCL / BUILD_NOTPATH
 * in probes/_lib.sh (build-output.test.mjs asserts it).
 */
export const BUILD_OUTPUT_DIRS = Object.freeze([
  ".open-next",
  ".next",
  ".nuxt",
  ".svelte-kit",
  ".output",
  ".vercel",
  ".wrangler",
  "dist",
  "build",
  "out",
  "coverage",
  ".turbo",
  ".cache",
]);
const BUILD_SET = new Set(BUILD_OUTPUT_DIRS);

/** True when the repo-relative path sits under a build-output directory (file names never count). */
export function isBuildOutputPath(rel) {
  const segments = String(rel ?? "")
    .replace(/:\d+(?:-\d+)?$/, "")
    .replace(/\\/g, "/")
    .split("/")
    .filter((s) => s && s !== ".");
  return segments.slice(0, -1).some((d) => BUILD_SET.has(d));
}

/** `examples/` is documentation in many repos and product code in none of them
 *  ... but a top-level `example/` can be a real app. So it only counts when it
 *  sits UNDER a test directory (`tests/examples/x.ts`). */
const EXAMPLE_DIRS = new Set(["examples", "example"]);
const TEST_DIRS = new Set(["test", "tests", "__tests__", "spec", "e2e"]);

/** True when the repo-relative path has a sample-code directory segment. */
export function isSamplePath(rel) {
  const segments = String(rel ?? "")
    .replace(/:\d+(?:-\d+)?$/, "")
    .replace(/\\/g, "/")
    .split("/")
    .filter((s) => s && s !== ".");
  // The last segment is the file; only directories count.
  const dirs = segments.slice(0, -1);
  let underTest = false;
  for (const dir of dirs) {
    const d = dir.toLowerCase();
    if (SAMPLE_DIRS.has(d)) return true;
    if (TEST_DIRS.has(d)) underTest = true;
    else if (underTest && EXAMPLE_DIRS.has(d)) return true;
  }
  return false;
}

/**
 * Secret-class findings stay SCORED at sample paths: a real key committed into a
 * fixture is still a leak. Class = the two secret lenses, or any finding whose
 * message says a secret/credential/token/key is hard-coded, literal or committed.
 */
const SECRET_LENSES = new Set(["php-secrets", "agent-secrets-in-config"]);
const SECRET_MESSAGE =
  /\b(?:hard-?coded|literal|committed|leaked|plaintext)\b[^.]{0,80}\b(?:secret|token|credential|api[_ -]?key|password|private key)|\b(?:secret|token|credential|api[_ -]?key|password|private key)\b[^.]{0,40}\b(?:hard-?coded|committed|in source)/i;
/** The matched value is obviously a placeholder. */
const FAKE_VALUE = /FAKE|EXAMPLE|dummy|placeholder|x{4,}/i;

export function isSecretClass(finding) {
  return SECRET_LENSES.has(finding.lens) || SECRET_MESSAGE.test(String(finding.message ?? ""));
}

/**
 * Whether a secret-class finding at a sample path is obviously fake. Probes redact
 * the value in their message and evidence, so the flagged LINE is read from disk
 * here (locally; it is never uploaded) and checked for a placeholder marker.
 */
function looksFake(finding, rel, repoPath) {
  const m = String(finding.location ?? "").match(/:(\d+)(?:-\d+)?$/);
  const haystack = [finding.message, ...(finding.evidence ?? [])].join("\n");
  if (FAKE_VALUE.test(haystack.replace(/<redacted>/g, ""))) return true;
  if (!m) return false;
  try {
    const line = readFileSync(join(repoPath, rel), "utf8").split("\n")[Number(m[1]) - 1] ?? "";
    return FAKE_VALUE.test(line);
  } catch {
    return false;
  }
}

/**
 * Splits one lens's findings into `kept` (scored, judged) and `samples` (set
 * aside, reported). `includeSamples` keeps everything, as before.
 */
export function partitionSamples(findings, repoPath, { includeSamples = false } = {}) {
  if (includeSamples) return { kept: findings, samples: [] };
  const kept = [];
  const samples = [];
  for (const f of findings) {
    const rel = normalizeLocator(f.location, repoPath);
    if (!isSamplePath(rel) && !isBuildOutputPath(rel)) kept.push(f);
    else if (isSecretClass(f) && !looksFake(f, rel, repoPath)) kept.push(f);
    else samples.push(f);
  }
  return { kept, samples };
}

/** The transparency line + a per-path list; one wording for run.mjs and cli.mjs. */
export function sampleNotice(samples) {
  const lines = [`${samples.length} finding(s) in test fixtures/sample paths not scored (--include-samples to score them)`];
  for (const f of samples) lines.push(`  ${String(f.severity).padEnd(8)} ${String(f.lens).padEnd(22)} ${f.location}`);
  return lines;
}

/**
 * Containment for any path a MODEL wrote or influenced (an interpreter
 * `location`, a finding handed to the fix agent). The model reads attacker-
 * controlled repo text, so its output is untrusted input, and `join(repo,
 * "../../x")` happily leaves the repo.
 *
 * Returns `{ rel, abs }` -- `abs` is the REAL path (symlinks resolved) -- or
 * null when the path is absolute (unless `allowAbsoluteInside` and it really is
 * inside), contains a `..` segment, does not exist, or resolves (via symlink)
 * outside the repo's real root. Existence is required: this guards reads and
 * overwrites of existing files, never creation.
 */
export function resolveInside(repoPath, candidate, { allowAbsoluteInside = false } = {}) {
  let raw = String(candidate ?? "");
  if (!raw || raw.includes("\0")) return null;
  // Shapes that are not a plain POSIX relative path in any reading: backslashes
  // and drive letters (Windows), and percent-encoded dots/separators that a
  // later decoder would turn into `..` or `/`. Refused outright, not decoded.
  if (raw.includes("\\") || /^[A-Za-z]:/.test(raw) || /%(?:2e|2f|5c|00)/i.test(raw)) return null;
  try {
    const realRoot = realpathSync(repoPath);
    if (isAbsolute(raw)) {
      if (!allowAbsoluteInside) return null;
      const r = relative(repoPath, raw);
      if (r === "" || r === ".." || r.startsWith(".." + sep) || isAbsolute(r)) return null;
      raw = r;
    }
    if (raw.replace(/\\/g, "/").split("/").includes("..")) return null;
    const abs = realpathSync(join(repoPath, raw));
    if (abs !== realRoot && !abs.startsWith(realRoot + sep)) return null;
    if (abs === realRoot) return null;
    return { rel: relative(realRoot, abs), abs };
  } catch {
    return null;
  }
}

/** Throws unless `rel` is already in canonical plain form: relative, no `.`/`..`/empty segments, no control characters or backslashes. */
export function canonicalRel(rel) {
  const s = String(rel ?? "");
  if (!s || /[\u0000-\u001f\u007f\\]/.test(s) || s.startsWith("/") || /^[A-Za-z]:/.test(s)) throw new Error("not a canonical relative path");
  if (s.split("/").some((seg) => seg === "" || seg === "." || seg === "..")) throw new Error("not a canonical relative path");
  return s;
}

/** Relative path -> directory segments + file name, refusing every shape that is not plain POSIX-relative. */
function splitPlain(rel) {
  const raw = String(rel ?? "");
  if (!raw || raw.includes("\0") || raw.includes("\\") || isAbsolute(raw) || /^[A-Za-z]:/.test(raw)) throw new Error("not a plain relative path");
  const segs = raw.split("/").filter((s) => s !== "" && s !== ".");
  if (segs.length === 0 || segs.includes("..")) throw new Error("not a plain relative path");
  return { dirs: segs.slice(0, -1), name: segs[segs.length - 1] };
}

/**
 * Walks the DIRECTORY components under the real root, one lstat each: every existing component must be
 * a real directory (a symlink -- even to a directory inside the repo -- is refused), a missing one is
 * created only when `create`. Returns the real parent directory.
 */
function plainParent(repoPath, dirs, { create = false } = {}) {
  const realRoot = realpathSync(repoPath);
  let cur = realRoot;
  for (const d of dirs) {
    const next = join(cur, d);
    let st;
    try {
      st = lstatSync(next);
    } catch (error) {
      if (!create || error?.code !== "ENOENT") throw new Error("parent directory missing");
      mkdirSync(next);
      st = lstatSync(next);
    }
    if (!st.isDirectory()) throw new Error("a parent component is a symlink or not a directory");
    cur = next;
  }
  const real = realpathSync(cur);
  if (real !== realRoot && !real.startsWith(realRoot + sep)) throw new Error("parent resolves outside the repository");
  return { parent: real, realRoot };
}

/** After open: the descriptor must be the plain file at that path, and the path must still resolve in the root. */
function verifyOpened(fd, parent, name, realRoot) {
  const st = fstatSync(fd);
  if (!st.isFile() || st.nlink > 1) throw new Error("not a plain single-link file");
  const abs = join(parent, name);
  const l = lstatSync(abs);
  if (l.isSymbolicLink() || l.ino !== st.ino || l.dev !== st.dev) throw new Error("file changed between check and use");
  const real = realpathSync(abs);
  if (!real.startsWith(realRoot + sep)) throw new Error("file resolves outside the repository");
  return st;
}

/** Reads a plain file inside the repo; refuses symlinks (final or parent), hardlinks and anything that moves mid-read. */
export function readContained(repoPath, rel) {
  const { dirs, name } = splitPlain(rel);
  const { parent, realRoot } = plainParent(repoPath, dirs);
  const fd = openSync(join(parent, name), constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const st = verifyOpened(fd, parent, name, realRoot);
    const buf = Buffer.alloc(st.size);
    let off = 0;
    while (off < st.size) {
      const n = readSync(fd, buf, off, st.size - off, off);
      if (n === 0) break;
      off += n;
    }
    return buf.subarray(0, off);
  } finally {
    closeSync(fd);
  }
}

/**
 * Writes `body` to a file inside the repo. An EXISTING file is opened O_NOFOLLOW (no O_TRUNC), vetted
 * (plain, single-link, same inode as the path, still inside the real root) and only THEN truncated and
 * written. A missing file is created O_EXCL|O_NOFOLLOW, creating parents one verified directory at a
 * time. `expected` (a resolveInside hit) pins the path the caller vetted earlier; `mode` is applied to
 * the descriptor (fchmod), never to the path.
 */
export function writeContained(repoPath, rel, body, expected, mode) {
  if (expected) {
    const hit = resolveInside(repoPath, rel);
    if (!hit || hit.abs !== expected.abs) throw new Error("path no longer resolves inside the repository");
  }
  const { dirs, name } = splitPlain(rel);
  const { parent, realRoot } = plainParent(repoPath, dirs, { create: !expected });
  const abs = join(parent, name);
  let fd;
  let created = false;
  try {
    fd = openSync(abs, constants.O_WRONLY | constants.O_NOFOLLOW);
  } catch (error) {
    if (error?.code !== "ENOENT" || expected) throw error;
    fd = openSync(abs, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 0o600);
    created = true;
  }
  try {
    try {
      verifyOpened(fd, parent, name, realRoot);
    } catch (error) {
      // A parent swapped for a symlink after the walk can land an O_CREAT outside the root: remove
      // exactly the empty file this call created, so the outside tree ends as it began.
      if (created) {
        try {
          const st = fstatSync(fd);
          const l = lstatSync(abs);
          if (l.ino === st.ino && l.dev === st.dev) unlinkSync(abs);
        } catch { /* nothing more to do */ }
      }
      throw error;
    }
    if (!created) ftruncateSync(fd, 0);
    writeSync(fd, body);
    if (mode !== undefined) fchmodSync(fd, mode);
  } finally {
    closeSync(fd);
  }
}

/** Removes a file this process created. Parents must be real directories; a symlink at the end is unlinked as a link, never followed. */
export function unlinkContained(repoPath, rel) {
  const { dirs, name } = splitPlain(rel);
  const { parent } = plainParent(repoPath, dirs);
  const abs = join(parent, name);
  const l = lstatSync(abs);
  if (l.isDirectory()) throw new Error("refusing to unlink a directory");
  unlinkSync(abs);
}

/** rmdir of an empty directory under verified real parents; never follows a symlink. */
export function rmdirContained(repoPath, rel) {
  const { dirs, name } = splitPlain(rel);
  const { parent } = plainParent(repoPath, dirs);
  rmdirSync(join(parent, name));
}

/**
 * Preflight for writers we do not control (the mechanical shell fixes): refuses when any existing
 * component of `rel` -- parents or the file itself -- is a symlink, or the file is hard-linked.
 * Missing components are fine (the writer creates them).
 */
export function assertPlainPath(repoPath, rel) {
  const { dirs, name } = splitPlain(rel);
  const realRoot = realpathSync(repoPath);
  let cur = realRoot;
  for (const seg of [...dirs, name]) {
    cur = join(cur, seg);
    let st;
    try {
      st = lstatSync(cur);
    } catch (error) {
      if (error?.code === "ENOENT") return;
      throw error;
    }
    if (st.isSymbolicLink()) throw new Error(`${rel}: a path component is a symlink`);
    if (seg === name && st.isFile() && st.nlink > 1) throw new Error(`${rel}: file is hard-linked`);
  }
}
