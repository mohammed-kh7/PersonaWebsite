import { findingIdentity } from "./identity.mjs";

/**
 * Lens statuses in which the lens actually examined the target.
 *
 * `judge-errored` belongs here and `probe-crashed` does not, because the PROBE
 * is what locates a finding -- the judge only confirms or downgrades one the
 * probe already surfaced. A judge that 500s has not hidden anything, so an
 * absence under it is a real absence. A probe that died has hidden everything.
 */
const RAN = new Set(["clean", "partial", "judged", "unjudged", "judge-errored"]);

/**
 * Every finding a run surfaced, keyed by identity, with the lens status that
 * produced it. `runFleet` reports a lens one of several ways; only some of them
 * mean the lens looked.
 */
export function indexFindings(run, repoPath = "") {
  const byIdentity = new Map();
  const lensRan = new Map();
  for (const lens of run?.lenses ?? []) {
    lensRan.set(lens.id, RAN.has(lens.status));
    // `judged`/`unjudged` carry `candidates`; a probe-only run carries none.
    // Interpreter findings count too: they were reported to the customer, so a
    // rerun must be able to say whether they cleared. A lens whose interpreter
    // did not settle (`cannot-tell`, `errored`) has NOT examined its gaps, so
    // absences under it stay unknown rather than becoming cleared.
    const interp = lens.interpreter;
    const rows = [...(Array.isArray(lens.candidates) ? lens.candidates : []), ...(interp?.findings ?? [])];
    if (interp && !["findings", "clean"].includes(interp.ruling)) lensRan.set(lens.id, false);
    for (const row of rows) {
      // A candidate the judge ruled a false positive is not a finding. It was
      // never reported to the customer, so it must not show up as "cleared"
      // later and inflate the fix's score.
      if (row.verdict && row.verdict.ruling === "false-positive") continue;
      const f = { lens: lens.id, location: row.location, message: row.message, severity: row.severity };
      // PREFER the identity stamped at scan time. Recomputing it here would use
      // THIS run's repo path against the PREVIOUS run's recorded location, and
      // the two clones live at different temp paths -- so every baseline finding
      // would fail to normalize, read as cleared, and reappear as introduced.
      // Measured: a correct 7-cleared/6-still rerun became 13 cleared and 6
      // introduced purely because the customer's checkout sat elsewhere.
      const id = row.identity ?? findingIdentity(f, repoPath);
      byIdentity.set(id, { ...f, ruling: row.verdict?.ruling ?? null });
    }
  }
  return { byIdentity, lensRan };
}

/**
 * The rerun's verdict on a fix.
 *
 * `unknown` is the honest bucket and the reason this is not a set subtraction:
 * if a lens crashed (or never ran) in the CURRENT run, its parent findings are
 * absent from the current set for a reason that has nothing to do with the fix.
 * Counting those as `cleared` is how a broken probe grades as a perfect patch.
 */
export function diffRuns(previous, current, repoPath = "") {
  const before = indexFindings(previous, repoPath);
  const after = indexFindings(current, repoPath);

  const cleared = [];
  const stillPresent = [];
  const unknown = [];
  for (const [id, finding] of before.byIdentity) {
    if (after.byIdentity.has(id)) stillPresent.push({ id, ...finding });
    else if (after.lensRan.get(finding.lens)) cleared.push({ id, ...finding });
    else unknown.push({ id, ...finding, why: "lens did not run in the rerun" });
  }

  const introduced = [];
  const unmeasured = [];
  for (const [id, finding] of after.byIdentity) {
    if (before.byIdentity.has(id)) continue;
    // A lens the baseline never ran cannot have had a finding "introduced" by a
    // patch -- nobody looked. This is the mirror of `unknown`: there, absence
    // was unprovable; here, presence is simply new information. Counting it as
    // a regression makes the blast-radius sweep discard correct patches, which
    // is exactly what it did the first time this ran against a partial baseline.
    if (before.lensRan.has(finding.lens)) introduced.push({ id, ...finding });
    else unmeasured.push({ id, ...finding, why: "this lens was not run in the baseline" });
  }

  return {
    cleared,
    stillPresent,
    introduced,
    unknown,
    unmeasured,
    // A fix "held" only when something actually cleared, nothing regressed, and
    // nothing is unaccounted for. All three are required: a patch that clears
    // one finding while introducing another has not improved the repo, and a
    // patch whose lens went dark has not been measured at all.
    held: cleared.length > 0 && introduced.length === 0 && unknown.length === 0,
  };
}
