# Lens pack: AI-built app failure modes (2026-09)

15 lenses from 11 reels — 5 by `@-MM` (`#aidirectedengineering`, the same source as the
2026-08 pack) and 4 by `@haydenschmitty` (`#claudecode #vibecoding`). Each is a single
claim about how an AI-built production system fails, expressed as a check.

Two further claims from these reels are **already graded** and are not repeated here:
wide-open CORS (2026-08 pack L10) and SSRF via a server-side fetch of a user-supplied URL
(L11). A tenth reel — `mirroir-mcp`, driving a real iPhone from Claude Code through macOS
iPhone Mirroring — is an OS tooling capability, not an audit lens; it is recorded in the
ideas note rather than here.

**How to use:** run the checks, then **read the code behind every hit before recording a
finding**. The checks locate candidates; they do not judge. On the first run of this pack
one candidate was discarded on inspection (see the fleet status), and a grep count
reported as a finding is how an audit manufactures false accusations —
`feedback-audit-findings-are-claims-not-facts`.

**Fleet status.** Applied to `force-website-builder` (2026-09-04): 11 code-auditable,
**11 pass, 0 gaps**, 2 not applicable. L14-L15 applied (2026-09-10): **1 gap found and
fixed** (L14 — one `jwt.verify` of eight did not pin `algorithms`), L15 clean. Both now
ship as GATES in that repo (`tests/unit/jwt-verification-lens.test.ts`,
`tests/unit/raw-sql-escape-hatch-lens.test.ts`) rather than as a one-time result — see
`standard/closed-loop-audit.md` for why a finding without a rerun is half an audit. **Not yet applied** to `gcc-horse-market`,
`Force-Media-CRM`, `whatsapp-broadcaster`, `force-merchant-intel`, `umbra`, or the
menu/landing repos — run them there and record the result.

**Why this pack matters more than its pass rate.** L6 is the exact defect that produced a
P0 in `force-website-builder` on 2026-09-03: a gateway refund on a cash-on-delivery order
refunded an arbitrary *other* order, because Prisma drops an `undefined` filter and the
`where` collapsed to empty. The lens was not derived from that incident — it arrived
independently from a reel — which is the argument for keeping packs: the same failure
mode is being described from the outside while it is being paid for on the inside.

---

## Security

**L1 — The URL is trusted instead of the session.** An endpoint loads a record by the id
in the path and never asks whether the caller owns it. Change the number, read someone
else's account. Sequential ids make it enumerable.
→ Every endpoint taking a record id verifies ownership against the session, and ids are
UUIDs rather than sequential.
`grep -rnE "params\.(id|userId|orderId|customerId)" apps/api/src/routes | head -40`
Then read each: a tenant scope, an ownership comparison, or an unguessable capability
token all count. A v4 uuid handed back to the creator moments earlier is a legitimate
guest model **if** it is documented and the row is confirmed ownerless.

**L2 — Server credentials shipped to the browser.** Server logic and client components in
one file; the bundler inlines the connection string into the client chunk.
→ `server-only` on modules holding secrets, server/client files separated, and a build
scan that greps the production bundle for credential shapes.
`grep -rn "server-only" apps/*/package.json` ·
`grep -rniE "process\.env\.(DATABASE_URL|.*_SECRET|.*_TOKEN)" apps/web/src apps/admin/src`
A CI job that scans the built client output is the gate; the package is the guard rail.

**L3 — The checkout price comes from the client.** The amount is posted from the
frontend; the server passes it to the payment provider without checking it against the
catalogue. Change it to one, and it is charged.
→ Line prices are read server-side from the product/variant row at order time. The
client's asserted price and total are never persisted or charged.
`grep -rnE "body\.(price|total|amount)|input\.price" apps/api/src/services apps/api/src/routes`

**L4 — The error page is the reconnaissance.** A broken link returns the database name,
the table, the ORM and the failing query, because development error handling shipped to
production.
→ Responses are shaped by environment; internals go to the log with a correlation id, and
the client gets a code and a message that names nothing.
`grep -rniE "err\.(stack|message)" apps/api/src/middleware/error-handler.ts`
Read the branches: the test is what reaches the *client*, not what is logged.

**L5 — The OAuth redirect is open.** A login link delivers the token to a server you have
never seen; the user believes they signed in.
→ Redirect URIs pinned to exact registered URLs, a `state` parameter enforced on every
request, token scopes minimised.
`grep -rniE "redirect_uri|oauth|state=" apps/api/src/routes/auth*.ts`
Not applicable to systems that mint their own sessions and integrate no external IdP.

**L6 — A dynamic ORM condition collapses to "match anything".** A filter built from an
optional value is dropped by the ORM when the value is `undefined`, so the `where` empties
and the query returns an arbitrary row instead of none.
→ Every query whose filter can receive an optional value either rejects the absent case
before querying, or constrains the column so absence cannot match.
`grep -rnE "findFirst|findUnique|updateMany|deleteMany" apps/api/src --include=*.ts -A6 | grep -nE "where: \{[^}]*\$\{?[a-zA-Z]+\??\}?"`
Prisma drops `undefined` keys entirely — an empty `where` is a full-table match, not a
no-match. This is the one that cost a real P0.

**L7 — The API returns more than the interface renders.** Endpoints select whole rows, so
fields the UI never shows — internal flags, cost prices, other people's identifiers — ship
to anyone who opens the network tab.
→ Explicit `select` on read paths, shaped to what the surface actually renders.
`grep -rn "findMany(" apps/api/src --include=*.ts -A4 | grep -c "select:"`
Compare against the total: a low ratio is the candidate, not the finding.

**L8 — Stored cross-site scripting.** User-supplied content is persisted and later
rendered as markup, so the payload executes for every subsequent viewer.
→ Inputs that end up in `href`, `src`, `dangerouslySetInnerHTML` or a template are
validated on write and escaped on read.
`grep -rn "dangerouslySetInnerHTML" apps/web/src apps/admin/src` ·
`grep -rniE "addressUrl|website|redirect|link" apps/api/src/routes/*.ts | grep -i "z\."`

## Performance and shape

**L9 — N+1 queries.** A list renders, and each row triggers its own query for a relation.
→ Relations are loaded with the parent (`include`/`select`), or batched.
`grep -rnE "for \(|\.map\(async" apps/api/src/services --include=*.ts -A4 | grep -nE "await prisma\."`

**L10 — Unpaginated reads.** An endpoint returns every row, so the page slows in
proportion to how successful the merchant is.
→ Every list endpoint takes a bounded limit, with a hard server-side cap the client
cannot raise.
`grep -rn "findMany(" apps/api/src/routes --include=*.ts -A6 | grep -c "take:"`

**L11 — Everything is synchronous.** Third-party calls, emails and image work happen
inside the request, so the user waits for work that did not need to block them.
→ Anything over a few hundred milliseconds, or calling a third party, is queued.
`grep -rnE "await (fetch|axios|sendEmail|resend)" apps/api/src/routes --include=*.ts`

**L12 — No connection pooler.** Every request opens and closes its own database
connection; connections are expensive and finite, so the ceiling arrives early.
→ A pooler in front of the database in transaction mode, with the app pointed at it.
`grep -rn "pooler\|pgbouncer\|connection_limit" packages/database docs/ENVIRONMENT.md`

## Interface

**L13 — Icon-only controls with no label.** A button is an icon, with no text and no
tooltip, so its meaning is guessable at best and invisible to a screen reader.
→ Every interactive control carries a visible label, an `aria-label`, or a tooltip.
`grep -rnE "<(button|IconButton)[^>]*>\s*<[A-Z]" apps/admin/src apps/web/src --include=*.tsx | head -40`
Then read them: an adjacent `<span className="sr-only">` or `aria-label` counts.

## Security (added 2026-09-10)

**L14 — The claims are read without checking the envelope was sealed.** The auth layer
DECODES a JWT to read `role` and never VERIFIES the signature. A user base64-decodes their
own token, flips `member` to `admin`, re-encodes, and the server grants every protected
route — no alert, no log line. The same shortcut skips `exp` (a stolen token then works
forever) and `iss` (a token minted by a different tenant of the same auth provider is
accepted). It survives review because it works perfectly for honest users; only a
deliberately modified token reveals the authorization layer is absent.
→ Signature verified before ANY claim is read; `exp`, `iss` and `aud` all checked;
`algorithms` pinned; the provider's server-side SDK preferred over hand-rolled parsing,
because it also handles key rotation.
`grep -rn "jwt.decode\|jwtDecode\|decodeJwt\|atob(" apps --include=*.ts | grep -v test`
`grep -rn -A6 "jwt.verify" apps/api/src --include=*.ts | grep -v test | grep -c algorithms`
Then read each: `decode` AFTER a successful `verify` (re-extracting `jti` cheaply) is
correct and common — the question is only whether a verify precedes it. Compare the
`decode` count against the `verify` count; a decode with no verify in the same function is
the finding. `ignoreExpiration: true` is defensible ONLY where the call establishes
identity and never authorises, and it must say so in place.

**L15 — The ORM protected you; the escape hatch does not.** The AI needs a join or a
search the query builder cannot express, drops to raw SQL, and every protection the ORM
provided disappears at that line. A crafted string in a search field, a filter, or a SORT
PARAMETER reaches the database as command rather than as data.
→ Raw queries use the ORM's PARAMETERISED form; any identifier that must be interpolated
(a column name, a savepoint, a `SET LOCAL`) comes from a closed allowlist of literals,
never caller text; every input is constrained by type and length BEFORE the query, and
unexpected input is REJECTED rather than sanitised.
`grep -rn --include=*.ts -F -e queryRawUnsafe -e executeRawUnsafe apps packages | grep -v node_modules`
`grep -rn --include=*.ts -F 'Prisma.raw(' apps packages | grep -v node_modules`
Prisma has three shapes and only two are obvious: `` $queryRaw`...${v}...` `` is
PARAMETERISED; `` $queryRawUnsafe(`...${v}`) `` is a built string; and `Prisma.raw(v)`
injects verbatim **inside** a tagged template that parameterises everything else — the
third is the one that hides. Postgres cannot bind a parameter in `SAVEPOINT` or
`SET LOCAL`, so those legitimately interpolate; the question is whether the value is
generated internally or validated first. A sort parameter mapped through a ternary to
fixed column literals is a pass; `options.sortBy || 'default'` reaching `Prisma.raw` is
the finding.
