# PHP / Laravel lens pack — 2026-09-23

**Source:** one real Laravel 11 / PHP 8.3 client snapshot (`_clients/work-wise-audit/src`,
~2,760-line `AdminController`, 231 routes, no git history), audited by hand first. The
hand audit is the ground truth every lens here was calibrated against.

**Fleet status:** all 11 shipped as graded lenses (`fleet/lenses/php-*.json`,
`fleet/rubric/php-*.md`, probe + known-bad fixture + clean twin each). Calibration
per finding: `fleet/fixtures/CALIBRATION-work-wise.md`.

## Why this pack exists

The fleet ran 34 probes over that repository and 28 lenses answered *"no TS/TSX source
found"*. It produced three generic findings and **missed the entire `/admin` panel**,
which was gated by one hard-coded password compared with `===` to `$request->input('password')`
inside a route closure. Nothing in the fleet was looking at PHP.

A lens that cannot see the stack is not a lens that found nothing — it is a lens that
was never asked.

## The claims

| # | id | Claim | Calibrated result on the source repo |
|---|---|---|---|
| 1 | `php-secrets` | A credential compared to a literal, assigned in source, or shipped as an `env()` default | 1 critical — the admin gate, value redacted |
| 2 | `php-authz` | A privileged route with no middleware in its own chain **or any enclosing group** | 0 — 128 privileged routes all covered |
| 3 | `php-idor` | A record loaded by client-supplied id with no ownership scope or policy | 8 critical (publicly reachable) + 41 high |
| 4 | `php-mass-assignment` | `$request->all()` into `create`/`update`/`fill`; `$guarded = []` | 0 — every model uses `$fillable` |
| 5 | `php-sqli` | Raw SQL carrying request data or interpolation | 0 — every raw call is parameter-bound |
| 6 | `php-blade-xss` | `{!! !!}` echoing request or model data | 0 — the raw echoes are escaped or view-local |
| 7 | `php-uploads` | Upload with no mime/size rule, web-reachable destination, or client-supplied filename | 4 |
| 8 | `php-throttle` | A sensitive POST route, or the `web` group, with no `throttle:` | 12 |
| 9 | `php-config` | Debug on, CSRF exceptions, session cookie flags with no safe default | 1 |
| 10 | `php-deps` | Structural dependency facts only — no guessed CVEs | 0 |
| 11 | `php-hygiene` | Backups and misplaced source in a deployable path | 5 (276 backup files) |

## What this pack taught the fleet, beyond PHP

- **A lens is only as alive as its stack detector.** `is_php` excluded `vendor/` but not
  `node_modules/`, so one stray `.php` file inside a single npm dependency made a Next.js
  repository answer "yes, this is PHP".
- **Filter the value, never the line.** A placeholder filter that greps the whole line
  matches the quoted *key*: `'password' => '<a real password>'` was dropped as a
  placeholder. Right count on the calibration repo, wrong reason, dangerous direction.
- **Severity follows reachability.** 41 unscoped admin methods are a code-boundary defect
  (high); the 8 a public route can reach are the exploit (critical). Marking all 49
  critical would have buried the 8 that matter.
- **The obvious glob is the wrong glob.** `*.bak` matches zero files in a repo holding 276
  backups, because every one is named `Controller.php.bak_20260725_applylock`.
- **A count is a measurement.** 269 (`*.bak*`) + 6 (`*_bak_*`) + 1 (`*.orig`) = 276, and
  the hand audit's "269–275" counted only the first shape.
