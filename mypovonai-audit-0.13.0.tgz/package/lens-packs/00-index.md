# Audit lens packs

Source packs of failure-mode claims, kept verbatim, that feed the graded rubric in
`standard/`.

## Why packs live here and not only in `standard/`

`standard/` is the **rubric**: 30 graded concerns, each reworded into the house
vocabulary. A pack is the **source**: the original claims, in the words they arrived in,
with the concrete scenario attached ("a bakery paying 22% delivery fees…", "14,000 requests
to your login endpoint last night").

Both are needed, for three reasons:

1. **A lens used once is a lost lens.** A pack applied to one repo and then discarded
   bought a single audit. Kept here with a fleet-status line, it re-runs against every repo
   that has not been checked yet.
2. **The mapping has to stay re-derivable.** When a `standard/` doc gets reworded, the
   claim it came from is still here to check the wording against. Without the source, a
   concern can drift until it no longer covers the failure that motivated it — and nothing
   would show that drift.
3. **The scenario is the teaching.** "Configure your WAF" is forgettable; "14,000 requests
   hit your login endpoint last night, all of them scanners, sailing through the Cloudflare
   you already pay for" is not. Graded rubrics necessarily lose that, and the loss is what
   makes a rule easy to skip.

## How to use a pack

Run its checks against a target repo, then **read the code behind every hit before
recording a finding**. The checks are deliberately noisy: they locate candidates, they do
not judge. Recording a grep count as a finding is how an audit manufactures false
accusations — see `~/.claude/.../memory/feedback-audit-findings-are-claims-not-facts`.

Record the outcome in the pack's fleet-status line so the next run knows what is already
covered.

## Packs

| Pack | Source | Lenses | Fed into `standard/` |
| --- | --- | --- | --- |
| [`reel-lenses-2026-09.md`](reel-lenses-2026-09.md) | 9 reels, `@-MM` + `@haydenschmitty`, 2026-09-04 | 13 (11 code, 1 a11y, 1 infra) | lens 29 `absent-filter-matches-everything` (L6); the other 12 graded by existing lenses |
| [`reel-lenses-2026-08.md`](reel-lenses-2026-08.md) | 21 reels, `@-MM` / `#aidirectedengineering`, 2026-08-31 | 21 (17 code, 2 process, 2 business) | lens 26 `skill-hygiene` (L2, L5); the other 17 already graded by existing lenses |
| [`php-laravel-2026-09.md`](php-laravel-2026-09.md) | one real Laravel 11 / PHP 8.3 client snapshot, 2026-09-23 | 11 (`php-*`) | all 11 ship as graded lenses in `fleet/lenses/` — this pack is the source, `rubric/php-*.md` the rubric |
| _(2026-08-08 reel fleet)_ | earlier reel fleet | — | lenses 21–25: `migration-safety`, `error-surface`, `ai-transparency`, `edge-protection`, `unit-economics` |

## Adding a pack

1. Drop the distilled claims here as `<slug>.md`, one claim per lens, each with its check.
2. Run it against at least one repo and write the report in that repo's `docs/audits/`.
3. For any claim **no existing `standard/` lens grades**, add a `standard/<id>.md` and
   register it in `standard/00-index.md`. That is the step that turns a pack into a gate.
4. Add the row above, with the fleet status.
