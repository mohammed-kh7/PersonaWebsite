#!/usr/bin/env bash
# php-mass-assignment probe — evidence for rubric/php-mass-assignment.md.
#
# Two independent ways a request body ends up writing whatever columns it wants:
#   1. `$request->all()`/`->except(...)` reaches `create(`/`update(`/`fill(`/
#      `forceFill(` — directly, or via a variable assigned from one and passed
#      to the other later in the SAME method (`$data = $request->all(); ...
#      Model::create($data);`).
#   2. A Model declares `protected $guarded = [];` (or `['']`) — Eloquent's
#      documented way of saying "nothing is guarded," which makes `id`,
#      `is_admin`, `role`, every column, mass-assignable through (1) even when
#      the controller code looks careful.
#
# Neither check is a data-flow analyser: (1) only follows ONE assignment hop
# inside the same method body, and does not know what a helper function does
# with a variable passed into it. Calibrated on a repo where every ::create()
# call site builds its array from named literals against an explicit
# $fillable, and confirmed silent there (see fixtures/CALIBRATION-work-wise.md).
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

is_laravel || { skipped "php-mass-assignment" "not a Laravel application (no composer dependency, no routes/ + app/)"; exit 0; }
files="$(php_files)"
[ -n "$files" ] || { skipped "php-mass-assignment" "no PHP source outside vendor/"; exit 0; }

# --- helper: print "startline:endline" for every function/method in a file --
method_ranges() {
  awk '
    function braces(s, ch,   n,i,c) { n=0; for (i=1;i<=length(s);i++) { c=substr(s,i,1); if (c==ch) n++ }; return n }
    BEGIN { in_m=0 }
    {
      if (!in_m && $0 ~ /function[ \t]+[A-Za-z_][A-Za-z0-9_]*[ \t]*\(/) { in_m=1; start=NR; depth=0; seen=0 }
      if (in_m) {
        o=braces($0,"{"); c=braces($0,"}")
        if (o>0) seen=1
        depth+=o-c
        if (seen && depth<=0) { print start":"NR; in_m=0 }
      }
    }' "$1"
}

# --- 1. $request->all()/->except(...) reaches create/update/fill/forceFill (high) ---
while IFS= read -r f; do
  [ -n "$f" ] || continue
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*|*/vendor/*) continue ;; esac
  [[ "$rel" == *Controller*.php ]] || continue

  while IFS= read -r range; do
    [ -n "$range" ] || continue
    start="${range%%:*}"; end="${range##*:}"
    body="$(sed -n "${start},${end}p" "$f")"

    # Direct: the write call's own argument IS $request->all()/except(...) or
    # request()->all()/except(...).
    direct_hit="$(grep -nE -- '(::create\(|->create\(|->update\(|->fill\(|->forceFill\()[[:space:]]*(\$request->(all\(\)|except\()|request\(\)->(all\(\)|except\())' <<<"$body" | head -1)"

    # Indirect, one hop: `$data = $request->all();` / `= $request->except(...)`
    # / `= request()->all()` earlier in the SAME method, then that exact
    # variable reaches a write call later in the method.
    indirect_hit=""
    while IFS= read -r av; do
      [ -n "$av" ] || continue
      var="$(sed -E 's/^\$([A-Za-z_][A-Za-z0-9_]*).*/\1/' <<<"$av")"
      [ -n "$var" ] || continue
      hit="$(grep -nE -- "(::create\(|->create\(|->update\(|->fill\(|->forceFill\()[[:space:]]*\\\$${var}\b" <<<"$body" | head -1)"
      [ -n "$hit" ] && { indirect_hit="$hit"; break; }
    done < <(grep -oE -- '\$[A-Za-z_][A-Za-z0-9_]*[[:space:]]*=[[:space:]]*(\$request->(all\(\)|except\()|request\(\)->(all\(\)|except\())' <<<"$body")

    hit="${direct_hit:-$indirect_hit}"
    [ -n "$hit" ] || continue
    offset="${hit%%:*}"
    ln=$((start + offset - 1))
    line="$(sed -E 's/^[0-9]+://' <<<"$hit" | sed 's/^[[:space:]]*//' | cut -c1-140)"
    finding "php-mass-assignment" "high" "$rel:$ln" \
      "the whole request body reaches a mass-assignment write with no field allowlist at the call site: $line"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <(method_ranges "$f")
done <<< "$files"

# --- 2. a Model declares $guarded = [] (high) --------------------------------
# `$guarded = []` is Eloquent's own words for "nothing is guarded" -- every
# column becomes fillable, including a primary key or a role/is_admin flag
# nobody meant to expose. `$fillable` (an explicit allowlist) never matches this.
while IFS= read -r f; do
  [ -n "$f" ] || continue
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*|*/vendor/*) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    # Skip a `//` comment merely MENTIONING the pattern (a doc-comment saying
    # "never do $guarded = [] here" is not the declaration itself).
    grep -qE '^[0-9]+:[[:space:]]*(//|\*|#)' <<<"$m" && continue
    finding "php-mass-assignment" "high" "$rel:$ln" \
      "\$guarded = [] leaves every column mass-assignable — including an id, role or is_admin flag — the moment any write call anywhere reaches this model with unfiltered input"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <({ grep -nE -- '\$guarded[[:space:]]*=[[:space:]]*\[[[:space:]]*\]' "$f" 2>/dev/null; \
             grep -nE -- "\\\$guarded[[:space:]]*=[[:space:]]*\\[[[:space:]]*''[[:space:]]*\\]" "$f" 2>/dev/null; } \
           | sort -t: -k1,1n -u)
done <<< "$files"

exit 0
