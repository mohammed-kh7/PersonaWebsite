#!/usr/bin/env bash
# state-transition-integrity probe — evidence for standard/state-transition-integrity.md.
# HEURISTIC static scan. It locates candidates; the finding text says to READ the
# handler, because a guard can live one call away (a state machine, a unique index).
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"
if [ -z "$files" ]; then
  skipped "state-transition-integrity" "no TS/TSX source found — no state-transition handlers to grade"
  exit 0
fi

# unguarded-transition: inside a function named like a state change
# (approve/review/restore/grant/suspend/revoke/publish/...), a Prisma
# update/updateMany whose `data` sets `status:` while its `where` names no
# current state. Precision rules (calibrated on gcc-horse-market 2026-10-08):
#   - an ATOMIC CLAIM earlier in the same function (a guarded updateMany whose
#     `count === 0` loser returns) means the transition is already
#     conditional: no finding;
#   - a status READ-AND-BRANCH earlier in the same function (`x.status` compared
#     / .includes()) is a check-then-act. With no side effect after the write
#     (audit row, notification, ...) the only residual is an idempotent
#     double-write: no finding. With a side effect after it, a race runs the side
#     effect twice: medium;
#   - NO state read at all: high. The unguarded write is the defect.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*spec*|*__tests__*|*.d.ts) continue ;; esac
  hits="$(awk '
    function reset() { guard = 0; claim = 0 }
    { L[NR] = $0 }
    END {
      fn = ""; reset()
      for (i = 1; i <= NR; i++) {
        line = L[i]
        if (line ~ /^[ \t]*(\/\/|\*|\/\*)/) continue
        nf = 0
        if (match(line, /function +[A-Za-z0-9_]+/)) { fn = substr(line, RSTART + 9, RLENGTH - 9); gsub(/ /, "", fn); nf = 1 }
        else if (match(line, /(const|let) +[A-Za-z0-9_]+ *= *(async)? *(\(|[A-Za-z_]+ *=>)/)) {
          t = substr(line, RSTART, RLENGTH); sub(/^(const|let) +/, "", t); sub(/ *=.*/, "", t); fn = t; nf = 1
        }
        else if (match(line, /^[ \t]*(async +)?[A-Za-z0-9_]+ *\([^)]*\)[^{;]*\{ *$/)) {
          t = substr(line, RSTART, RLENGTH); sub(/^[ \t]*(async +)?/, "", t); sub(/ *\(.*/, "", t)
          if (t !~ /^(if|for|while|switch|catch|return|else)$/) { fn = t; nf = 1 }
        }
        if (nf) reset()
        if (line ~ /count *===? *0/) claim = 1
        if (line ~ /\.(status|suspendedAt|revokedAt)/ && line ~ /(===|!==|\.includes\(|\.[a-zA-Z]+ *[!=]=|if *\(!?[a-zA-Z.?]*\.(suspendedAt|revokedAt)|\[.*\]\.includes)/) guard = 1
        lf = tolower(fn)
        if (lf !~ /(approve|review|restore|grant|suspend|reactivate|revoke|publish|reject|activate|moderate)/) continue
        if (line !~ /\.update(Many)?\(/) continue
        w = ""
        for (j = i; j <= i + 10 && j <= NR; j++) w = w " " L[j]
        wh = ""; dt = ""
        if (match(w, /where: *\{[^}]*\}/)) wh = substr(w, RSTART, RLENGTH)
        if (match(w, /data: *\{[^}]*\}/)) dt = substr(w, RSTART, RLENGTH)
        if (!(dt ~ /status *:/ && wh !~ /(status|suspendedAt|revokedAt|state)/)) continue
        if (claim) continue
        if (!guard) { print i " high"; continue }
        se = 0
        for (j = i + 1; j <= i + 30 && j <= NR; j++) { if (L[j] ~ /^}/) break; if (L[j] ~ /(\.create\(|recordAdminAction|auditLog|AuditLog|notify\(|enqueue|\.send\()/) se = 1 }
        if (se) print i " medium"
      }
    }' "$f" 2>/dev/null | head -5)"
  while read -r hit sev; do
    [ -z "$hit" ] && continue
    if [ "$sev" = "high" ]; then
      finding "state-transition-integrity" "high" "$rel:$hit" "a state-changing handler writes 'status' with no current state in the where clause and never reads the current state — a repeat or a concurrent call runs its audit row and notification twice, and an undo cannot know what it is undoing; make it updateMany({ where: { id, status: <expected> } }) and branch on count === 0 (state-transition-integrity 1)"
    else
      finding "state-transition-integrity" "medium" "$rel:$hit" "a state-changing handler checks the current state, then writes 'status' unconditionally and logs/notifies after — a concurrent second call passes the same check and runs the side effect twice; fold the expected state into the write's where and branch on count === 0 (state-transition-integrity 1)"
    fi
    evidence "grep -nE 'update(Many)?\\(' $(qpath "$rel")"
  done <<< "$hits"
done <<< "$files"

# aggregate-status-over-list (medium 5): an admin screen that takes element [0]
# of a per-role/per-profile list and shows it as THE status. "Latest wins" put
# one role's status next to another role's chip.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*spec*|*__tests__*|*.d.ts) continue ;; esac
  case "$rel" in *admin*|*Admin*|*backoffice*|*dashboard*) ;; *) continue ;; esac
  ln="$(grep -nE '(kyc|verification|profile|role)[A-Za-z]*\[0\]' "$f" 2>/dev/null | grep -vE '^[0-9]+:[[:space:]]*(//|\*|/\*)' | head -1 | cut -d: -f1)"
  [ -z "$ln" ] && continue
  finding "state-transition-integrity" "medium" "$rel:$ln" "an admin surface takes element [0] of a per-role/per-profile list as the status — with several profiles it shows the latest one next to the wrong chip; render each entity's own status and actions (state-transition-integrity 5)"
  evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
done <<< "$files"

exit 0
