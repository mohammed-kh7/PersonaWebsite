#!/usr/bin/env bash
# php-unvalidated-write probe — evidence for rubric/php-unvalidated-write.md.
#
# A controller method that WRITES using request data and never validates it.
#
# Ground truth (SEC-008, backend #4 and #10): the reference repo's public
# "apply for a job" endpoint — the single most business-critical write in the
# application — has no `$request->validate()` at all, and inserts every
# non-excluded input key straight into a table keyed by a client-supplied id.
#
# THIS IS THE NOISE MINEFIELD OF THE PACK. That repo has 98 public methods in
# one controller, 30 validate call-sites and zero FormRequest classes. A finding
# per unvalidated method would produce a list nobody reads, which is the same
# outcome as finding nothing — the failure an earlier route-authz attempt hit
# with 110 findings, none real. Two deliberate narrowings keep it defensible:
#   * only methods that actually WRITE (a read is not this lens's business), and
#   * only methods a ROUTE can reach (a helper nobody can call over HTTP is a
#     different risk, and one this lens would be guessing about).
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

is_laravel || { skipped "php-unvalidated-write" "not a Laravel application (no composer dependency, no routes/ + app/)"; exit 0; }
files="$(php_files)"
[ -n "$files" ] || { skipped "php-unvalidated-write" "no PHP source outside vendor/"; exit 0; }

WRITE_CALL='::create\(|->create\(|->update\(|->fill\(|->forceFill\(|->save\(|->insert\(|->insertGetId\(|->updateOrCreate\(|->firstOrCreate\('
REQUEST_DATA='request\(\)|_POST|_GET|_REQUEST'
VALIDATES='->validate\(|Validator::make|->validated\(|FormRequest|Request \$[a-zA-Z_]+\)[[:space:]]*:[[:space:]]*'

# Routed method names. Only these are considered: a method no route names is a
# different risk and this lens would be guessing at its reachability.
ROUTED="$(mktemp "${TMPDIR:-/tmp}/uwroutes-XXXXXX")"
trap 'rm -f "$ROUTED"' EXIT
route_files | while IFS= read -r rf; do
  [ -n "$rf" ] || continue
  grep -ohE "['\"][a-zA-Z_][a-zA-Z0-9_]*['\"][[:space:]]*\]" "$rf" 2>/dev/null | tr -d "'\"] " 
  grep -ohE "@[a-zA-Z_][a-zA-Z0-9_]*" "$rf" 2>/dev/null | tr -d '@'
done | sort -u > "$ROUTED"

# How many to report individually before collapsing the rest into a count.
# 20, not 5: the cap exists to stop a pathological repo producing a list nobody
# reads, but set too low it hides the finding that matters most — at 5 it
# suppressed storeCompanyForm(), the public apply-for-a-job endpoint and the
# single most business-critical write in the reference application, which is the
# one the hand audit led with. A cap that hides the headline is worse than no cap.
CAP=20
n_unvalidated=0
examples=""
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*|*/database/*|*/vendor/*) continue ;; esac
  case "$rel" in */Http/Controllers/*) ;; *) continue ;; esac
  delegated="$(node "$(dirname "$0")/_php-validation.mjs" "$f" 2>/dev/null || true)"
  total_lines="$(wc -l < "$f" | tr -d ' ')"
  # Method ranges by brace matching from each `function name(`.
  while IFS= read -r m; do
    start="${m%%:*}"
    mname="$(printf '%s' "${m#*:}" | grep -oE 'function[[:space:]]+[A-Za-z_][A-Za-z0-9_]*' | awk '{print $2}')"
    [ -n "$mname" ] || continue
    grep -qx "$mname" "$ROUTED" || continue
    # find the matching close brace
    end="$start"; depth=0; opened=0
    while IFS= read -r line; do
      o="${line//[^\{]/}"; c="${line//[^\}]/}"
      depth=$((depth + ${#o} - ${#c}))
      [ ${#o} -gt 0 ] && opened=1
      if [ "$opened" -eq 1 ] && [ "$depth" -le 0 ]; then break; fi
      end=$((end + 1))
    done < <(sed -n "${start},${total_lines}p" "$f")
    body="$(sed -n "${start},${end}p" "$f")"
    # a write carrying request data
    grep -qE -e "$WRITE_CALL" <<<"$body" || continue
    grep -qE -e 'request->|request\(\)|_POST|_GET|_REQUEST' <<<"$body" || continue
    # any validation at all in this method, or an injected FormRequest
    grep -qE -e "$VALIDATES" <<<"$body" && continue
    grep -qE -e '\(([A-Za-z_]+Request)[[:space:]]+' <<<"$(sed -n "${start}p" "$f")" && continue
    grep -qxF -- "$mname" <<< "$delegated" && continue
    n_unvalidated=$((n_unvalidated + 1))
    [ "$n_unvalidated" -le "$CAP" ] && examples="$examples $rel:$start ($mname)"
    if [ "$n_unvalidated" -le "$CAP" ]; then
      finding "php-unvalidated-write" "critical" "$rel:$start" \
        "$mname() is reachable from a route, writes to the database using request data, and validates none of it — every key the client sends reaches persistence with neither a type, a length, nor a permitted-value check"
      evidence "sed -n '$(num "$start"),$(num "$end")p' $(qpath "$rel") | grep -nE 'validate|create\\(|update\\(|insert\\('"
    fi
  done < <(grep -nE '^[[:space:]]*(public|protected|private)?[[:space:]]*function[[:space:]]+[A-Za-z_]' "$f")
done <<< "$files"

# A cap, reported honestly rather than silently: a reader needs to know the list
# was truncated, and by how much.
if [ "$n_unvalidated" -gt "$CAP" ]; then
  finding "php-unvalidated-write" "high" "app/Http/Controllers" \
    "$n_unvalidated routed methods write request data with no validation at all; the $CAP examples are reported individually above and the rest are not, because a finding per method would be a list nobody reads"
  evidence "grep -rlE 'function ' app/Http/Controllers | head   # then read each method for a validate() call"
fi

# --- 2. no FormRequest classes anywhere (high) ------------------------------
# Reported once. Absence of FormRequest classes does not prove that
# validation cannot be shared through ordinary controller helpers.
if [ "$n_unvalidated" -gt 0 ]; then
  req_dir="$ROOT/app/Http/Requests"
  n_req=0
  [ -d "$req_dir" ] && n_req="$(find "$req_dir" -name '*.php' -type f 2>/dev/null | grep -c .)"
  if [ "$n_req" -eq 0 ]; then
    finding "php-unvalidated-write" "high" "app/Http/Requests" \
      "the application declares no FormRequest classes at all under app/Http/Requests, and $n_unvalidated routed write(s) match the missing-validation predicate"
    evidence "ls app/Http/Requests 2>&1   # absent or empty"
  fi
fi
exit 0
