#!/usr/bin/env bash
# psp-account-survival probe — evidence for standard/psp-account-survival.md.
# Gated on the repo actually taking card payments: `money` grades the payment
# path, this grades the account that receives the money.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

# A processor SDK or a checkout call is what makes this standard apply. Package
# manifests and source both count: a hosted-checkout integration may be nothing
# but a fetch to the provider.
takes_money=0
for manifest in "$ROOT/package.json" "$ROOT/apps"/*/package.json "$ROOT/packages"/*/package.json; do
  [ -f "$manifest" ] || continue
  grep -qiE '"(stripe|@polar-sh/[a-z]+|@paddle/[a-z-]+|lemonsqueezy|myfatoorah|tap-payments|checkout-sdk-node)"' "$manifest" 2>/dev/null && takes_money=1
done
if [ "$takes_money" = "0" ]; then
  grep -rqiE 'api\.stripe\.com|api\.polar\.sh|api\.paddle\.com|api\.lemonsqueezy\.com|apitest\.myfatoorah|api\.myfatoorah' "$ROOT" \
    --include='*.ts' --include='*.tsx' --include='*.js' --include='*.mjs' \
    --exclude-dir=node_modules "${BUILD_EXCL[@]}" 2>/dev/null && takes_money=1
fi
if [ "$takes_money" = "0" ]; then
  skipped "psp-account-survival" "no payment processor integration found — the account-survival standard is N/A"
  exit 0
fi

# policy-pages-missing (high 1,3): terms/refund/cancellation AND privacy have to
# exist somewhere a reviewer crawling the live site can reach.
has_terms=0
has_privacy=0
while IFS= read -r p; do
  case "$(printf '%s' "$p" | tr 'A-Z' 'a-z')" in
    *refund*|*cancellation*|*terms*|*legal*|*tos*) has_terms=1 ;;
  esac
  case "$(printf '%s' "$p" | tr 'A-Z' 'a-z')" in
    *privacy*) has_privacy=1 ;;
  esac
done < <(build_find -type f \( -name '*.tsx' -o -name '*.ts' -o -name '*.mdx' -o -name '*.md' -o -name '*.html' \))

if [ "$has_terms" = "0" ] || [ "$has_privacy" = "0" ]; then
  missing=""
  [ "$has_terms" = "0" ] && missing="$missing refund/cancellation terms"
  [ "$has_privacy" = "0" ] && missing="$missing privacy policy"
  finding "psp-account-survival" "high" "$ROOT" "the repo takes card payments but publishes no$missing — a processor holds payouts at activation while a reviewer looks for exactly these on the live site (psp-account-survival 1,3)"
  evidence "find $(qpath "$ROOT") -iname '*refund*' -o -iname '*privacy*' -o -iname '*terms*' | grep -vE '/($BUILD_ALT|node_modules)/'"
fi

# support-contact-missing (high 2): a human the buyer can reach, on the site.
if ! grep -rqiE 'mailto:[a-z0-9._%-]+@|/contact|/support' "$ROOT" \
     --include='*.tsx' --include='*.ts' --include='*.mdx' --include='*.html' \
     --exclude-dir=node_modules "${BUILD_EXCL[@]}" 2>/dev/null; then
  finding "psp-account-survival" "high" "$ROOT" "no support address or contact route in the app surface — a buyer who cannot find you contacts the processor instead, and repeated contacts are a signal about the merchant (psp-account-survival 2)"
  evidence "grep -rn 'mailto:' $(qpath "$ROOT") --include='*.tsx' | grep -vE '/($BUILD_ALT|node_modules)/'"
fi

exit 0
