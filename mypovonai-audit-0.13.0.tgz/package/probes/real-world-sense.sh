#!/usr/bin/env bash
# real-world-sense probe — evidence for standard/real-world-sense.md.
#
# Most of this lens is judge work ("nothing is logical until it makes sense"):
# location pairing of times and currency, an owner offered buyer actions on their
# own item, cancel-while-pending, identity reuse. A probe cannot see those and
# this one does not pretend to. It covers only the slices that are MECHANICALLY
# checkable, each calibrated on a real finding from gcc-horse-market 2026-10-07:
#   1  gate order      — a KYC/verified check before the sign-in check, so a
#                        signed-out guest is told "verify your ID" (crit 2)
#   2  video route     — media served with no HTTP Range / 206 support, so video
#                        cannot be seeked and iOS refuses to play it (crit 3)
#   3  directory       — a services directory query with no country filter in a
#                        domain that has countries: a UAE vet for a Kuwait horse (crit 1)
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"
if [ -z "$files" ]; then
  skipped "real-world-sense" "no TS/TSX source found — nothing for the mechanical slices to scan"
  exit 0
fi

is_input() { case "$1" in *test*|*spec*|*__tests__*|*.d.ts|node_modules/*|*/node_modules/*) return 0 ;; esac; return 1; }

# --- 1. kyc-before-signin (high) --------------------------------------------
# Within ONE function the first verified/KYC check precedes the first signed-in
# check. Read the function before recording: a server handler whose session is
# resolved by middleware is a pass.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"; is_input "$rel" && continue
  # The session is enforced BEFORE the handler runs when the route registration
  # carries session middleware (`app.get(path, requireSession, async (c) => ..)`);
  # a helper in such a file reads c.get('userId') and is only reached signed in.
  grep -qE '\.(get|post|put|patch|delete|use)\(.*(requireSession|requireAuth|authenticate|isAuthenticated|withAuth)' "$f" 2>/dev/null && continue
  ln="$(awk '
    function flush() { if (kyc && auth && kyc < auth) { print kyc; found = 1 } kyc = 0; auth = 0 }
    /^[ \t]*(\/\/|\*|\/\*)/ { next }
    {
      isfn = 0
      if ($0 ~ /function +[A-Za-z0-9_]+/) isfn = 1
      else if ($0 ~ /(const|let) +[A-Za-z0-9_]+ *= *(async)? *(\(|[A-Za-z_]+ *=>)/) isfn = 1
      if (isfn) { flush(); if (found) exit }
      if (!kyc && $0 ~ /(!kycApproved|!isKycApproved|requireApprovedKyc|requireKyc|!isVerified|!identityVerified|kycStatus *!== *.approved)/) kyc = NR
      if (!auth && $0 ~ /(!token|!isAuthed|!isSignedIn|!signedIn|!session|!isLoggedIn|requireAuth|requireSession|!userId)/) auth = NR
    }
    END { if (!found) flush() }' "$f" 2>/dev/null | head -1)"
  [ -z "$ln" ] && continue
  finding "real-world-sense" "high" "$rel:$ln" "a verified/KYC check runs before the signed-in check in the same function — a signed-out guest is told to verify their identity instead of to sign in; order the gates guest -> signed-in -> verified -> owner (real-world-sense 2)"
  evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
done <<< "$files"

# --- 2. video-without-range (high) -------------------------------------------
# A file that SERVES video (a response body, a stream) and mentions no Range /
# 206 / Accept-Ranges anywhere: the player cannot seek and iOS AVPlayer refuses
# a stream that ignores Range. An upload allow-list that merely names video/mp4
# is not serving, so a response/stream call is required too.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"; is_input "$rel" && continue
  grep -qiE 'video/(mp4|quicktime|webm)|\.mp4|getVideo|serveVideo' "$f" 2>/dev/null || continue
  grep -qE 'new Response\(|c\.body\(|res\.(send|end|pipe)|createReadStream|reply\.send|\.pipe\(' "$f" 2>/dev/null || continue
  # comments do not count: a comment naming Range is not code answering it
  grep -vE '^[[:space:]]*(//|\*|/\*)' "$f" 2>/dev/null | grep -qiE 'range|206|accept-ranges' && continue
  ln="$(grep -niE 'video/(mp4|quicktime|webm)|\.mp4|getVideo|serveVideo' "$f" | head -1 | cut -d: -f1)"
  finding "real-world-sense" "high" "$rel:$ln" "a route serves video with no Range / 206 / Accept-Ranges handling — the player cannot seek and iOS refuses to play a stream that ignores Range; answer a ranged request with 206 + Content-Range (real-world-sense 3)"
  evidence "grep -niE 'range|206|accept-ranges' $(qpath "$rel") || echo 'no range handling'"
done <<< "$files"

# --- 3. directory-without-country (medium) -----------------------------------
# Only meaningful where the domain HAS countries: a schema column or any source
# naming one. A services directory (vets, carriers, providers, agents) whose
# list query filters on nothing place-shaped shows a Kuwaiti buyer a Dubai vet.
SCHEMA="$(product_find --first -name schema.prisma)"
has_country=0
[ -n "$SCHEMA" ] && grep -qiE '^[[:space:]]*country' "$SCHEMA" 2>/dev/null && has_country=1
if [ "$has_country" = 0 ]; then
  while IFS= read -r f; do
    rel="${f#"$ROOT"/}"; is_input "$rel" && continue
    grep -qE '\bcountry\b' "$f" 2>/dev/null && { has_country=1; break; }
  done <<< "$files"
fi
if [ "$has_country" = 1 ]; then
  while IFS= read -r f; do
    rel="${f#"$ROOT"/}"; is_input "$rel" && continue
    # A directory is something USERS list. Background work is not one.
    case "$rel" in sweeps/*|*/sweeps/*|jobs/*|*/jobs/*|cron/*|*/cron/*|workers/*|*/workers/*|scripts/*|*/scripts/*|seed*|*/seed*|migrations/*|*/migrations/*) continue ;; esac
    case "$rel" in *vet*|*provider*|*carrier*|*transport*|*directory*|*agent*) ;; *) continue ;; esac
    # Judge the QUERY, not the file: a file that mentions a country elsewhere
    # can still list providers with no place filter. Skip lists scoped to one
    # person (own bookings), one tenant (storeId/tenantId: config and audit
    # reads inside a multi-tenant app) or one id set; those are not directories.
    while IFS= read -r ln; do
      # win = the call; ctx = 40 lines before it too, where the `where` is usually built
      win="$(sed -n "${ln},$((ln + 14))p" "$f")"
      ctx="$(sed -n "$(( ln > 40 ? ln - 40 : 1 )),$((ln + 14))p" "$f")"
      grep -qE 'take|orderBy' <<<"$win" || continue
      grep -qE 'country|region|city|location' <<<"$ctx" && continue
      grep -qE '(userId|buyerId|sellerId|ownerId|vetId|providerId|carrierId|companyId|actorId|callerId|storeId|tenantId|orgId|merchantId)|partyFilter|[Cc]ron|[Ss]weep|inngest|id:[[:space:]]*\{[[:space:]]*in' <<<"$ctx" && continue
      finding "real-world-sense" "medium" "$rel:$ln" "a services-directory list query has no country/region filter in a domain that has countries — a buyer in one country is shown providers from another, and a newest-first cap fills with whoever listed last; filter by the item's or viewer's country (real-world-sense 1)"
      evidence "sed -n '$(num "$ln"),$(( $(num "$ln") + 14 ))p' $(qpath "$rel")"
      break
    done < <(grep -n 'findMany' "$f" | cut -d: -f1)
  done <<< "$files"
fi

exit 0
