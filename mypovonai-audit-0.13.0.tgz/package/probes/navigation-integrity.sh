#!/usr/bin/env bash
# navigation-integrity probe — evidence for standard/navigation-integrity.md.
# Gated on a React Native / Expo / React Navigation project existing — anything
# else cleanly N/As (a web-only repo has no native-stack to ghost).
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

# Judged on the path RELATIVE to $ROOT (see is_php in _lib.sh for why an absolute
# -not -path hides the fixtures from the probe that owns them once installed).
rn_manifest=""
while IFS= read -r pj; do
  rel="${pj#"$ROOT"/}"
  case "$rel" in node_modules/*|*/node_modules/*) continue ;; esac
  if grep -qE '"(react-native|expo|expo-router|@react-navigation/[a-z-]+)"[[:space:]]*:' "$pj" 2>/dev/null; then
    rn_manifest="$pj"; break
  fi
done < <(build_find --maxdepth 4 -name package.json -type f)

if [ -z "$rn_manifest" ]; then
  skipped "navigation-integrity" "no react-native / expo / @react-navigation dependency — no native-stack to grade"
  exit 0
fi

# raw-beforeremove-veto (high 1): a `beforeRemove` listener that calls
# preventDefault. native-stack ignores it on the iOS swipe-dismiss: the view is
# removed natively while JS keeps the route, and every later navigation is dead.
# The fix is usePreventRemove, which feeds native-stack's preventedRoutes.
# A test that asserts this very pattern is INPUT, not product code: skipped.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in
    node_modules/*|*/node_modules/*|*test*|*spec*|*__tests__*|*.d.ts|dist/*|*/dist/*|.expo/*|*/.expo/*) continue ;;
  esac
  while IFS=: read -r ln _; do
    [ -z "$ln" ] && continue
    # preventDefault within the next 12 lines = the listener body
    if sed -n "${ln},$((ln + 12))p" "$f" 2>/dev/null | grep -q 'preventDefault'; then
      finding "navigation-integrity" "high" "$rel:$ln" "a raw 'beforeRemove' listener calls preventDefault — native-stack ignores it on the iOS swipe-dismiss, so the modal closes natively while JS keeps the route and all later navigation is dead; use usePreventRemove plus an explicit close (navigation-integrity 1)"
      evidence "grep -rn -A12 beforeRemove $(qpath "$rel") | grep -n preventDefault"
      break
    fi
  done < <(grep -nE "beforeRemove" "$f" 2>/dev/null | grep -vE '^[0-9]+:[[:space:]]*(//|\*|/\*)')
done < <(build_find \( -name '*.ts' -o -name '*.tsx' -o -name '*.js' -o -name '*.jsx' \) -type f)

exit 0
