#!/usr/bin/env bash
# migration-safety probe — evidence for standard/migration-safety.md.
# Operates on prisma migration SQL. Only flags patterns that are dangerous
# REGARDLESS of table size, so it does not flood a Prisma repo (Prisma emits
# plain CREATE INDEX for everything — flagging that would fire on every repo,
# so this probe deliberately does NOT grade the CONCURRENTLY criterion; the
# interpreter judges it against table size).
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

MIG_DIR="$(product_find --first -type d -name migrations -path '*prisma*')"
if [ -z "$MIG_DIR" ]; then
  skipped "migration-safety" "no prisma/migrations directory"
  exit 0
fi

# Only the NEWEST migration is actionable: older ones already ran on prod and
# flagging them is archaeology, not a fix (same scoping as dr.sh). The
# interpreter can widen if a full-history audit is requested.
newest="$(ls -d "$MIG_DIR"/*/ 2>/dev/null | sort | tail -1)"
if [ -z "$newest" ]; then
  skipped "migration-safety" "no migration folders under $MIG_DIR"
  exit 0
fi

for sqlf in "$newest"migration.sql; do
  [ -e "$sqlf" ] || continue
  rel="${sqlf#"$ROOT"/}"
  sql="$(cat "$sqlf" 2>/dev/null)"

  # replace-in-place (crit 21.1): the SAME migration ADDs and DROPs a column of
  # the same name — an expand and contract collapsed into one irreversible step.
  added="$(grep -oiE 'ADD COLUMN "?[A-Za-z_][A-Za-z0-9_]*"?' <<<"$sql" | grep -oiE '"?[A-Za-z_][A-Za-z0-9_]*"?$' | tr -d '"' | sort -u)"
  dropped="$(grep -oiE 'DROP COLUMN "?[A-Za-z_][A-Za-z0-9_]*"?' <<<"$sql" | grep -oiE '"?[A-Za-z_][A-Za-z0-9_]*"?$' | tr -d '"' | sort -u)"
  if [ -n "$added" ] && [ -n "$dropped" ]; then
    both="$(comm -12 <(printf '%s\n' "$added") <(printf '%s\n' "$dropped") 2>/dev/null)"
    if [ -n "$both" ]; then
      col="$(head -1 <<<"$both")"
      finding "migration-safety" "critical" "$rel" "one migration both ADDs and DROPs column '$col' — a replace-in-place; the drop must ship in a separate later migration (expand/contract)"
      evidence "grep -niE 'ADD COLUMN|DROP COLUMN' $(qpath "$sqlf")"
    fi
  fi

  # notnull-no-default (crit 21.5): ADD COLUMN ... NOT NULL with no DEFAULT on
  # the same statement fails on every existing row of a populated table.
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    grep -qiE 'NOT +NULL' <<<"$line" || continue
    grep -qiE 'DEFAULT' <<<"$line" && continue
    col="$(grep -oiE 'ADD COLUMN "?[A-Za-z_][A-Za-z0-9_]*"?' <<<"$line" | grep -oiE '"?[A-Za-z_][A-Za-z0-9_]*"?$' | tr -d '"' | head -1)"
    finding "migration-safety" "critical" "$rel" "ADD COLUMN '$col' NOT NULL with no DEFAULT — fails on every existing row; a boot-time outage on a populated table"
    evidence "grep -niE 'ADD COLUMN.*NOT NULL' $(qpath "$sqlf")"
    break
  done < <(grep -iE 'ADD COLUMN' <<<"$sql")

done

exit 0
