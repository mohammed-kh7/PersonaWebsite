#!/usr/bin/env bash
# unit-economics probe — evidence for standard/unit-economics.md.
# Gated on the project actually using AI (the dominant variable cost). No AI →
# the model-cost attribution criteria N/A; other infra-cost items are
# interpreter-only.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

GREP_INC=(--include='*.ts' --include='*.tsx' --exclude-dir=node_modules "${BUILD_EXCL[@]}")
AI_SDK='@anthropic-ai/|openai|@ai-sdk/|GoogleGenerativeAI|generateText\(|generateObject\(|@google/genai|chat\.completions'
if ! grep -rqE "$AI_SDK" "${GREP_INC[@]}" "${PRODUCT_EXCL[@]}" "$ROOT" 2>/dev/null; then
  skipped "unit-economics" "no AI SDK — model-cost attribution (25.2/25.3) N/A; other infra-cost attribution is interpreter-only"
  exit 0
fi

# ai-no-tenant-cost (high 25.2/25.3): AI usage must be attributed per tenant
# with a cost. Look for a usage table that has BOTH a tenant column and token/
# cost columns — the two halves per-customer margin needs.
if has_prisma; then
  SCHEMA="$(product_find --first -name schema.prisma)"
  body="$(cat "$SCHEMA" 2>/dev/null)"
  HAS_TENANT_COL=0; HAS_COST_COL=0
  grep -qiE 'storeId|tenantId|store_id|tenant_id|accountId' <<<"$body" && HAS_TENANT_COL=1
  grep -qiE 'inputTokens|outputTokens|promptTokens|completionTokens|input_tokens|output_tokens|cost(Micros|Cents|_micros)?|tokensUsed' <<<"$body" && HAS_COST_COL=1
  # both signals must co-occur; a schema with tenants but no cost column cannot
  # derive per-customer AI spend.
  if [ "$HAS_COST_COL" = "0" ]; then
    finding "unit-economics" "high" "${SCHEMA#"$ROOT"/}" "the project uses AI but no usage/cost column (tokens or cost per row) exists in the schema — per-tenant model spend is not derivable, so margin per customer is unknown (unit-economics 25.2/25.3)"
    evidence "grep -niE 'inputTokens|outputTokens|costMicros|storeId' $(qpath "$SCHEMA")"
  fi
fi


exit 0
