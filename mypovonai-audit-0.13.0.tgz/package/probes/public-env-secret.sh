#!/usr/bin/env bash
# public-env-secret: bounded source candidates; see rubric/public-env-secret.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "public-env-secret" "$rel"; continue; fi
  finding "public-env-secret" "critical" "$rel:$line" "Public-prefixed secret/password/private-key/access-token/API-key assignments must not contain non-placeholder literal values."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "public-env-secret" "$ROOT")
exit 0
