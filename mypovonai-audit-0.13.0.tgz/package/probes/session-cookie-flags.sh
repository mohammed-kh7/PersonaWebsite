#!/usr/bin/env bash
# session-cookie-flags: bounded source candidates; see rubric/session-cookie-flags.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "session-cookie-flags" "$rel"; continue; fi
  finding "session-cookie-flags" "high" "$rel:$line" "Session/auth/token cookies set in a function require explicit HttpOnly, Secure and SameSite attributes."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "session-cookie-flags" "$ROOT")
exit 0
