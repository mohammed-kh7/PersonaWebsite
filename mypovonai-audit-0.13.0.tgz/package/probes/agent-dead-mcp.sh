#!/usr/bin/env bash
# agent-dead-mcp probe — evidence for standard/gate-integrity.md (a control that cannot
# work reads as present) as applied to an AGENT SETUP's MCP servers. N/A (skipped) on a
# product repo.
#
# For every mcpServers entry in .mcp.json / .claude.json / settings.json /
# .claude/settings.json, each `${VAR}` used in a `headers` or `env` value must be provided
# somewhere in the setup: a `VAR=` line in any *.env / .env* / .env.example file under
# $ROOT (via agent_files, transcripts pruned), or the `env` block of settings.json.
# A server whose credential nothing provides authenticates as nobody: dead, but listed.
# JSON is parsed with node (a hard dependency of this package). `${VAR:-default}` is
# skipped: it carries its own fallback.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_agent_setup; then
  skipped "agent-dead-mcp" "not an agent setup (no CLAUDE.md, .claude/settings.json, settings.json+skills/, or agents/*.md) — there are no MCP servers whose credentials could be checked"
  exit 0
fi

PROVIDED=""
while IFS= read -r e; do
  [ -n "$e" ] || continue
  PROVIDED="${PROVIDED}$(sed -nE 's/^[[:space:]]*(export[[:space:]]+)?([A-Za-z_][A-Za-z0-9_]*)=.*/\2/p' "$ROOT/$e" 2>/dev/null)"$'\n'
done < <(agent_files '*.env' '.env' '.env.*')

for rel in .mcp.json .claude.json settings.json .claude/settings.json; do
  f="$ROOT/$rel"
  [ -f "$f" ] && inside_root "$f" || continue
  extra="$(node -e '
    try { const s = JSON.parse(require("fs").readFileSync(process.argv[1], "utf8")); console.log(Object.keys(s.env ?? {}).join("\n")); } catch {}
  ' "$f" 2>/dev/null)"
  while IFS=$'\t' read -r server var; do
    [ -n "$server" ] || continue
    grep -qxF -- "$var" <<<"$PROVIDED"$'\n'"$extra" && continue
    finding "agent-dead-mcp" "medium" "$rel" "MCP server $server authenticates with \${$var}, which nothing in this setup provides"
    evidence "grep -n mcpServers $(qpath "$rel")"
  done < <(node -e '
    try {
      const s = JSON.parse(require("fs").readFileSync(process.argv[1], "utf8"));
      for (const [name, srv] of Object.entries(s.mcpServers ?? {})) {
        const seen = new Set();
        for (const bag of [srv.headers, srv.env]) for (const v of Object.values(bag ?? {})) {
          for (const m of String(v).matchAll(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g)) seen.add(m[1]);
        }
        for (const v of seen) console.log(name + "\t" + v);
      }
    } catch {}
  ' "$f" 2>/dev/null)
done

exit 0
