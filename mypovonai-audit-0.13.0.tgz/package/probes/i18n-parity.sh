#!/usr/bin/env bash
# i18n-parity: bounded source candidates; see rubric/i18n-parity.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "i18n-parity" "$rel"; continue; fi
  finding "i18n-parity" "medium" "$rel:$line" "Literal translation keys referenced by source must exist in at least one EN/AR JSON catalog, even when both catalogs omit them."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "i18n-parity" "$ROOT")
exit 0
