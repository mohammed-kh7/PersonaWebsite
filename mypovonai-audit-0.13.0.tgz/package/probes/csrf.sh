#!/usr/bin/env bash
# csrf: bounded source candidates; see rubric/csrf.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "csrf" "$rel"; continue; fi
  finding "csrf" "high" "$rel:$line" "Cookie/session-authenticated route writes require a visible local CSRF or origin validation check."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "csrf" "$ROOT")
exit 0
