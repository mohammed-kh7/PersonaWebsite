#!/usr/bin/env bash
# architecture probe — evidence for standard/architecture.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

# money-float (crit 7): a money AMOUNT column typed Float in the schema. Float
# is unambiguously wrong for money (binary rounding). Decimal is debatable
# (some teams use it) — left to the interpreter, flagged separately if seen.
if has_prisma; then
  SCHEMA="$(product_find --first -name schema.prisma)"
  hit="$(grep -niE '^[[:space:]]*(price|amount|total|subtotal|balance|cost|paid|refund|payout)[A-Za-z]* +Float' "$SCHEMA" 2>/dev/null | head -1)"
  if [ -n "$hit" ]; then
    ln="${hit%%:*}"
    finding "architecture" "critical" "${SCHEMA#"$ROOT"/}:$ln" "a money amount column is typed Float — binary floating point rounds money wrong; store minor units as Int (architecture 7)"
    evidence "grep -niE '(price|amount|total|balance) +(Float|Decimal)' $(qpath "$SCHEMA")"
  fi
fi

# tx-no-maxwait (high 9): a bare prisma.$transaction([...]) / $transaction(async)
# with no options object and no withMoneyTx wrapper anywhere. The 2s default
# maxWait aborts money transactions under load.
files="$(src_files)"
if [ -n "$files" ]; then
  HAS_WRAPPER=0
  grep -rqE "withMoneyTx|withTransaction|maxWait" --include='*.ts' --exclude-dir=node_modules "${BUILD_EXCL[@]}" "$ROOT" 2>/dev/null && HAS_WRAPPER=1
  if [ "$HAS_WRAPPER" = "0" ]; then
    while IFS= read -r f; do
      rel="${f#"$ROOT"/}"
      case "$rel" in *.test.*|*.spec.*|*.d.ts) continue ;; esac
      hit="$(grep -nE 'prisma\.\$transaction\(' "$f" 2>/dev/null | head -1)"
      [ -z "$hit" ] && continue
      ln="${hit%%:*}"
      finding "architecture" "high" "$rel:$ln" "prisma.\$transaction with no {maxWait,timeout} and no withMoneyTx wrapper — the 2s default maxWait aborts the tx under load (architecture 9)"
      evidence "grep -nE '\\\$transaction\\(|maxWait|withMoneyTx' $(qpath "$f")"
      break
    done <<<"$files"
  fi
fi

exit 0
