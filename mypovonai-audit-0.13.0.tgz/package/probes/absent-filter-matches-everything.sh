#!/usr/bin/env bash
# absent-filter-matches-everything probe — evidence for
# standard/absent-filter-matches-everything.md, §2 check 1:
#   "Every findFirst/findUnique/updateMany/deleteMany whose `where` reads an
#    optional or nullable value."
#
# Detection (per .ts/.tsx/.js/.mjs file that mentions `prisma`, one awk pass):
#   1. Optional names are SCOPED: the parameters of the nearest preceding function
#      signature line (`NAME?:` or `NAME: <type> | undefined`), plus locals declared
#      `let|var NAME: <type> | undefined`. An optional interface field elsewhere in
#      the file is NOT in scope.
#   2. A call matching (findFirst|findUnique|updateMany|deleteMany)( whose `where: { ... }`
#      is on the call line or within the next 3 lines, closing on that line or LATER lines
#      (a multi-line object: top-level entries of each line are read, nested objects and
#      arrays are skipped), where an entry VALUE is a bare identifier in that set: shorthand
#      `NAME` or `key: NAME`. `{ id: order.id }` / calls are never matched.
#   3. Unguarded = none of the 5 lines before the call (or the call line) has
#      `if (!NAME`, `NAME ??`, or `throw`.
# Schema nullability (§2 check 2) is handed to the interpreter.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

FILES=()
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in node_modules/*|*/node_modules/*|*.d.ts|dist/*|*/dist/*|.next/*|*/.next/*) continue ;; esac
  grep -qi 'prisma' "$f" 2>/dev/null && FILES+=("$f")
done < <(build_find \( -name '*.ts' -o -name '*.tsx' -o -name '*.js' -o -name '*.mjs' \) -type f)

if [ "${#FILES[@]}" -eq 0 ]; then
  skipped "absent-filter-matches-everything" "no .ts/.tsx/.js/.mjs source mentioning prisma — there is no ORM where-clause to examine in this repo"
  exit 0
fi

for f in "${FILES[@]}"; do
  rel="${f#"$ROOT"/}"
  awk '
    # Optional names are scoped: the PARAMETERS of the nearest preceding function
    # signature line, plus locals declared `let|var NAME: T | undefined`. Only a real
    # function BOUNDARY resets the scope: a `function`, a method signature, a named
    # arrow (`const f = (..) =>`, `name: (..) =>`) -- not a callback such as `.map((x) => ..)`.
    function sig(l) {
      if (l ~ /^[ \t]*(if|for|while|switch|catch|return)[ \t]*\(/) return 0
      if (l ~ /function[ \t]*[A-Za-z0-9_$]*[ \t]*\(/) return 1
      if (l ~ /=>/) {
        if (l ~ /^[ \t]*(export[ \t]+)?(default[ \t]+)?(const|let|var)[ \t]+[A-Za-z_$][A-Za-z0-9_$]*[^=]*=[ \t]*(async[ \t]*)?[(A-Za-z_$]/) return 1
        if (l ~ /^[ \t]*[A-Za-z_$][A-Za-z0-9_$]*[ \t]*:[ \t]*(async[ \t]*)?\(.*\)[ \t]*(:[^=]*)?=>/) return 1
        return 0
      }
      return (l ~ /^[ \t]*((public|private|protected|static|async|export)[ \t]+)*[A-Za-z_$][A-Za-z0-9_$]*[ \t]*\(.*\)[ \t]*(:[^{]*)?\{[ \t]*$/)
    }
    function addopt(s,   n, seg) {
      while (match(s, /[A-Za-z_$][A-Za-z0-9_$]*\?:/)) { n = substr(s, RSTART, RLENGTH - 2); opt[n] = 1; s = substr(s, RSTART + RLENGTH) }
    }
    function addundef(s,   seg) {
      while (match(s, /[A-Za-z_$][A-Za-z0-9_$]*[ \t]*:[^,)=;]*\|[ \t]*undefined/)) {
        seg = substr(s, RSTART, RLENGTH); sub(/[ \t]*:.*/, "", seg); opt[seg] = 1; s = substr(s, RSTART + RLENGTH)
      }
    }
    # Entries of one where-object fragment (text between the braces, or one line of a
    # multi-line object). An entry whose VALUE is a bare optional identifier, unguarded in
    # the 5 lines before the CALL (or on the call line), is a finding reported at `at`.
    function check(w, callln, at,   k, e, v, n, i, h, guarded, ent) {
      k = split(w, ent, ",")
      for (e = 1; e <= k; e++) {
        v = ent[e]; gsub(/^[ \t]+|[ \t]+$/, "", v)
        if (v ~ /^[A-Za-z_$][A-Za-z0-9_$]*[ \t]*:[ \t]*[A-Za-z_$][A-Za-z0-9_$]*$/) sub(/^[^:]*:[ \t]*/, "", v)
        else if (v !~ /^[A-Za-z_$][A-Za-z0-9_$]*$/) continue
        n = v
        if (!(n in opt)) continue
        guarded = 0
        for (i = 1; i <= 5; i++) {
          h = hist[callln - i]
          if (h ~ ("if[ \t]*\\([ \t]*!" n) || h ~ (n "[ \t]*\\?\\?") || h ~ /throw/) guarded = 1
        }
        h = hist[callln]
        if (h ~ ("if[ \t]*\\([ \t]*!" n) || h ~ (n "[ \t]*\\?\\?")) guarded = 1
        if (!guarded) print at ":" n
      }
    }
    function nchar(s, c,   t) { t = s; return gsub(c, "", t) }
    {
      hist[FNR] = $0
      if (sig($0)) {
        delete opt
        p = $0; sub(/^[^(]*\(/, "", p); sub(/\)[^)]*$/, "", p)
        addopt(p); addundef(p)
      }
      if ($0 ~ /(let|var)[ \t]+[A-Za-z_$]/) { l = $0; sub(/.*(let|var)[ \t]+/, "", l); addundef(l) }
      if (inw) {
        # inside a multi-line where object: entries only at depth 1 (nested objects/arrays are skipped)
        if (depth == 1) { line = $0; sub(/\/\/.*$/, "", line); check(line, callln, FNR) }
        depth += nchar($0, "{") - nchar($0, "}")
        if (depth <= 0) inw = 0
        next
      }
      if ($0 ~ /(findFirst|findUnique|updateMany|deleteMany)[ \t]*\(/) { callln = FNR; pend = 3 }
      if (pend > 0 && $0 ~ /where:[ \t]*\{/) {
        if (match($0, /where:[ \t]*\{[^}]*\}/)) {
          w = substr($0, RSTART, RLENGTH); sub(/^where:[ \t]*\{/, "", w); sub(/\}$/, "", w)
          check(w, callln, FNR)
        } else {
          # `where: {` opens here and closes on a later line
          w = $0; sub(/.*where:[ \t]*\{/, "", w)
          check(w, callln, FNR)
          inw = 1; depth = 1 + nchar(w, "{") - nchar(w, "}")
          if (depth <= 0) inw = 0
        }
        pend = 0
      } else if (pend > 0) pend--
    }
  ' "$f" 2>/dev/null | while IFS=: read -r ln name; do
    finding "absent-filter-matches-everything" "high" "$rel:$ln" "optional value in a where: '$name' can be undefined and the ORM drops undefined keys — the query matches the first row instead of none"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done
done

exit 0
