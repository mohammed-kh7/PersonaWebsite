#!/usr/bin/env bash
# error-surface probe — evidence for standard/error-surface.md.
# Scopes every check to an HTTP RESPONSE call so it does not false-flag a
# logger line (logger.error({ err: e.message }) is correct — private sink).
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"
if [ -z "$files" ]; then
  skipped "error-surface" "no TS/TSX source found"
  exit 0
fi

# A response call, on one line: res.json / res.send / NextResponse.json /
# Response.json / c.json (hono) / reply.send (fastify).
RESP='(res|reply)\.(status\([0-9]+\)\.)?(json|send)\(|NextResponse\.json\(|Response\.json\(|c\.json\('

while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *.test.*|*.spec.*|*.d.ts) continue ;; esac

  # stack-in-response (crit 22.2): a stack trace reaches the client.
  hit="$(grep -nE "$RESP" "$f" 2>/dev/null | grep -E '\.stack\b' | head -1)"
  if [ -n "$hit" ]; then
    ln="${hit%%:*}"
    finding "error-surface" "critical" "$rel:$ln" "a stack trace is placed into an HTTP response — internals leak to the user in every environment (22.2)"
    evidence "grep -nE '(json|send)\\(.*\\.stack' $(qpath "$f")"
    continue
  fi

  # raw-error-in-response (high 22.2): err.message / e.message echoed to client.
  hit="$(grep -nE "$RESP" "$f" 2>/dev/null | grep -E '\b(err|error|e)\.(message|code|detail|meta)\b' | head -1)"
  if [ -n "$hit" ]; then
    ln="${hit%%:*}"
    finding "error-surface" "high" "$rel:$ln" "a raw error field (err.message/code/meta) is echoed in an HTTP response — the public shape should be owned by one error middleware (22.1/22.2)"
    evidence "grep -nE '(json|send)\\(.*(err|error|e)\\.(message|code)' $(qpath "$f")"
  fi
done <<<"$files"

exit 0
