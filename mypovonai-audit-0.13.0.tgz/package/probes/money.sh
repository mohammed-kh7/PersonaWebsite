#!/usr/bin/env bash
# money probe — evidence for standard/money.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

SCHEMA="$(product_find --first -name schema.prisma)"
files="$(src_files)"

if [ -z "$SCHEMA" ] && [ -z "$files" ]; then
  skipped "money" "no prisma schema and no TS source — no money layer to grade"
  exit 0
fi

# --- integer-minor-units (crit): Float/Decimal on a money column -------------
# A percentage/rate column is legitimately Decimal (e.g. percentageFee
# Decimal(5,2) = "2.5 for 2.5%") — it is a RATE, not minor-units money.
# Calibrated out on FWB 2026-08-13: percentageFee was a false positive.
if [ -n "$SCHEMA" ]; then
  while IFS= read -r line; do
    ln="${line%%:*}"
    col="$(sed -E 's/^[0-9]+:[[:space:]]*//' <<<"$line" | awk '{print $1}')"
    case "$col" in
      *[Pp]ercent*|*[Rr]ate*|*[Rr]atio*|*[Pp]ct*) continue ;;  # rate, not money
    esac
    finding "money" "critical" "${SCHEMA#"$ROOT"/}:$ln" "money column '$col' typed Float/Decimal — must be integer minor units (fils/cents)"
    evidence "grep -nE '(amount|price|total|subtotal|balance|fee)[A-Za-z]* +(Float|Decimal)' $(qpath "$SCHEMA")"
  done < <(grep -nEi '(amount|price|total|subtotal|balance|fee)[A-Za-z]* +(Float|Decimal)' "$SCHEMA" 2>/dev/null)
fi

# --- centralized-money-helper (high): a money.ts/discount.ts with a sibling test
if [ -n "$files" ]; then
  # NOTE: use here-strings (<<<), NOT `printf | grep -q`. Under `set -o pipefail`
  # a `grep -q` exits on first match and SIGPIPEs the upstream printf (141),
  # which pipefail then reports as the PIPELINE's status — flipping a negated
  # test so a found sibling reads as missing. Calibrated out on FWB 2026-08-13:
  # discount.test.ts existed but was reported "no sibling test".
  helper="$(grep -iE '/(money|discount)\.ts$' <<<"$files" | grep -viE 'test|spec' | head -1)"
  if [ -z "$helper" ]; then
    finding "money" "high" "$ROOT" "no money.ts/discount.ts helper — money math is likely scattered across handlers"
    evidence "find $(qpath "$ROOT") -name money.ts -o -name discount.ts | grep -vE '/($BUILD_ALT|node_modules)/'"
  else
    base="$(basename "$helper" .ts)"
    if ! grep -qiE "/${base}\.(test|spec)\.ts$" <<<"$files"; then
      finding "money" "high" "${helper#"$ROOT"/}" "money helper '$base' has no sibling test — money math is untested"
      evidence "find $(qpath "$ROOT") -iname $(qpath "${base}.test.ts") -o -iname $(qpath "${base}.spec.ts") | grep -vE '/($BUILD_ALT|node_modules)/'"
    fi
  fi
fi

exit 0
