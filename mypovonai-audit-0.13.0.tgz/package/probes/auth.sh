#!/usr/bin/env bash
# auth probe — evidence for standard/auth.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"
if [ -z "$files" ]; then
  skipped "auth" "no TS/TSX source found"
  exit 0
fi

# --- uniform role-check helper (crit): mixing authorize() and requireRole() ---
# Two different role-check idioms in one codebase means a route can be guarded
# by the weaker/older one. The standard mandates ONE helper name.
# Consider PROD source only — a test asserting on requireRole is not a mixed
# guard idiom in the routing layer. Report the first PROD requireRole call site
# so the finding points at real routing, not a spec file (calibrated 2026-08-13).
prod_files="$(grep -viE '/(tests?|__tests__|__mocks__)/|\.(test|spec)\.ts' <<<"$files")"
has_authorize=0; has_requirerole=0
prod_paths=()
while IFS= read -r f; do
  [ -n "$f" ] && prod_paths+=("$f")
done <<< "$prod_files"
if [ "${#prod_paths[@]}" -gt 0 ]; then
  grep -qE '\bauthorize\(' "${prod_paths[@]}" 2>/dev/null && has_authorize=1
  grep -qE '\brequireRole\(' "${prod_paths[@]}" 2>/dev/null && has_requirerole=1
fi
if [ "$has_authorize" = "1" ] && [ "$has_requirerole" = "1" ]; then
  hit="$(grep -rlE '\brequireRole\(' "${prod_paths[@]}" 2>/dev/null | grep -viE 'rbac|middleware' | head -1)"
  # If the only prod hits are the rbac/middleware module, requireRole is likely
  # the PRIMITIVE that authorize() wraps — one system, not two idioms. Downgrade.
  if [ -z "$hit" ]; then
    hit="$(grep -rlE '\brequireRole\(' "${prod_paths[@]}" 2>/dev/null | head -1)"
    finding "auth" "medium" "${hit#"$ROOT"/}" "requireRole() appears only in the rbac/middleware module — likely the primitive authorize() wraps; confirm no route calls it directly"
  else
    finding "auth" "critical" "${hit#"$ROOT"/}" "a route uses requireRole() while the codebase also uses authorize() — two role-check idioms; a route may be guarded by the weaker one"
  fi
  evidence "grep -rn 'requireRole(' $(qpath "$ROOT") --include='*.ts' | grep -vE '/($BUILD_ALT|node_modules)/' | grep -viE '\\.(test|spec)\\.'"
fi

# --- auth rate limit (high): login path must have a rate limiter -------------
source_paths=()
while IFS= read -r f; do
  [ -n "$f" ] && source_paths+=("$f")
done <<< "$files"
login_file="$(grep -rlE "'/(auth/)?login'|\"/(auth/)?login\"|router\.(post|use).*login" "${source_paths[@]}" 2>/dev/null | head -1)"
if [ -n "$login_file" ]; then
  if ! grep -rqiE 'ratelimit|rate-limit|rateLimiter|authLimiter|express-rate-limit' "${source_paths[@]}" 2>/dev/null; then
    finding "auth" "high" "${login_file#"$ROOT"/}" "login route present but no rate-limit middleware found anywhere — credential stuffing is ungated"
    evidence "grep -rniE 'ratelimit|rate-limit|authLimiter' $(qpath "$ROOT") --include='*.ts' | grep -vE '/($BUILD_ALT|node_modules)/'"
  fi
fi

# --- open-redirect validation (crit 11): a post-auth redirect target reads --
# straight from req.query/body with no allowlist/same-origin check nearby.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*spec*|*fixture*|*.d.ts) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    win="$(sed -n "${ln},$((ln+5))p" "$f" 2>/dev/null)"
    grep -qiE '\.redirect\(' <<<"$win" || continue
    grep -qiE 'allowlist|isSafeRedirect|sameOrigin|validateRedirect|assertSameOrigin' <<<"$win" && continue
    finding "auth" "critical" "$rel:$ln" "a post-auth redirect target comes from req.query/body with no allowlist/same-origin check nearby — an attacker-controlled return-to can hand a just-authenticated user to a phishing site (auth 11)"
    evidence "sed -n '$(num "$ln"),$(( $(num "$ln") + 3 ))p' $(qpath "$f")"
  done < <(grep -nE "req\.(query|body)\.(returnTo|redirect|next|continue|redirect_uri)" "$f" 2>/dev/null)
done <<< "$files"

exit 0
