#!/usr/bin/env bash
# feature-flags probe — evidence for standard/feature-flags.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

GREP_INC=(--include='*.ts' --include='*.tsx' --exclude-dir=node_modules "${BUILD_EXCL[@]}")

# no-api-gate (crit 1/2): the app has a plan / subscription concept but no
# feature-gate primitive anywhere — UI hiding alone leaks billing features.
HAS_PLAN=0
if has_prisma; then
  SCHEMA="$(product_find --first -name schema.prisma)"
  grep -qiE '^model +(Subscription|Plan)\b|\bplan\b +[A-Za-z]|plan(Id|Tier|Type) ' "$SCHEMA" 2>/dev/null && HAS_PLAN=1
fi
grep -rqE "PLAN_BASELINE|planBaseline|SubscriptionPlan|billingPlan" "${GREP_INC[@]}" "$ROOT" 2>/dev/null && HAS_PLAN=1
if [ "$HAS_PLAN" = "1" ]; then
  if ! grep -rqE "requireFeature|requirePlan|hasFeature|featureEnabled|requireEntitlement|isFeatureEnabled|assertFeature" "${GREP_INC[@]}" "$ROOT" 2>/dev/null; then
    finding "feature-flags" "critical" "$ROOT" "the app has a plan/subscription concept but no feature-gate primitive (requireFeature/hasFeature) anywhere — plan-gated features are enforced by UI hiding alone, a billing leak (feature-flags 1/2)"
    evidence "grep -rnE 'requireFeature|hasFeature|requireEntitlement|PLAN_BASELINE' $(qpath "$ROOT") --include='*.ts'"
  fi
fi

# scattered-plan-check (high 5): hardcoded plan-string comparisons outside the
# single plan-baseline module.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *.test.*|*.spec.*|*.d.ts) continue ;; esac
  # the source-of-truth files are allowed to compare plan strings
  case "$rel" in *plan-baseline*|*plan-baselines*|*features.ts|*plans.ts|*feature-flags*|*entitlement*) continue ;; esac
  hit="$(grep -niE "\bplan ===? *['\"]|\.plan ===? *['\"]|planTier ===? *['\"]|=== *['\"](free|starter|basic|pro|growth|business|enterprise|premium)['\"]" "$f" 2>/dev/null | head -1)"
  [ -z "$hit" ] && continue
  ln="${hit%%:*}"
  finding "feature-flags" "high" "$rel:$ln" "a hardcoded plan-string comparison outside the plan-baseline module — plan→feature mapping must have one source of truth, not scattered string checks (feature-flags 5)"
  evidence "grep -nE \"plan ===|=== '(free|pro|enterprise)'\" $(qpath "$f")"
  break
done <<<"$(src_files)"

exit 0
