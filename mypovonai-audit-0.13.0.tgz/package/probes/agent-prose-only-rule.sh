#!/usr/bin/env bash
# agent-prose-only-rule probe — evidence for standard/verify-before-assert.md and
# agent-containment.md ("a rule only in CLAUDE.md is a preference, not a gate").
# Heuristic, low. N/A (skipped) on a product repo.
#
#   n = lines of CLAUDE.md matching  (^|[^A-Za-z])(NEVER|ALWAYS|MUST)([^A-Za-z]|$)
#   n >= 5  and  settings.json / .claude/settings.json register ZERO PreToolUse hooks
#     -> low, "needs validation: <n> binding rules in CLAUDE.md and no PreToolUse hook ..."
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_agent_setup; then
  skipped "agent-prose-only-rule" "not an agent setup (no CLAUDE.md, .claude/settings.json, settings.json+skills/, or agents/*.md) — there are no binding rules in prose to compare against hooks"
  exit 0
fi

{ [ -f "$ROOT/CLAUDE.md" ] && inside_root "$ROOT/CLAUDE.md"; } || exit 0
n="$(grep -cE '(^|[^A-Za-z])(NEVER|ALWAYS|MUST)([^A-Za-z]|$)' "$ROOT/CLAUDE.md" 2>/dev/null)"
[ "${n:-0}" -ge 5 ] || exit 0

pre=0
for s in "$ROOT/settings.json" "$ROOT/.claude/settings.json"; do
  [ -f "$s" ] && inside_root "$s" || continue
  c="$(node -e '
    try {
      const h = JSON.parse(require("fs").readFileSync(process.argv[1], "utf8")).hooks?.PreToolUse ?? [];
      console.log(h.reduce((a, g) => a + (g.hooks ?? []).length, 0));
    } catch { console.log(0); }
  ' "$s" 2>/dev/null)"
  pre=$((pre + ${c:-0}))
done

if [ "$pre" -eq 0 ]; then
  finding "agent-prose-only-rule" "low" "CLAUDE.md" "needs validation: $n binding rules in CLAUDE.md and no PreToolUse hook enforces any of them — a rule only in prose is a preference"
  evidence "grep -nE 'NEVER|ALWAYS|MUST' CLAUDE.md; grep -n PreToolUse settings.json .claude/settings.json  # (none found)"
fi

exit 0
