#!/usr/bin/env bash
# php-config probe — evidence for rubric/php-config.md.
#
# The finding class this lens exists for: config that is CORRECT in the
# framework's own default (Laravel ships `'debug' => (bool) env('APP_DEBUG',
# false)`, a safe fallback) but gets overridden by whatever the deploy actually
# committed — a debug flag hard-coded true, a committed .env, a CSRF exemption
# nobody remembers adding, or a session cookie flag with no safe default at
# all. Calibrated against a real Laravel 11 snapshot where the ONLY finding is
# `SESSION_SECURE_COOKIE` resolving to null because it has no second argument.
#
# NOTHING HERE PRINTS THE CONTENTS OF A COMMITTED .env FILE. A committed .env
# is itself the finding; the excerpt only ever shows the matched KEY=VALUE
# line for the two boolean-ish keys this probe looks for (APP_DEBUG, APP_ENV),
# and even those pass through redact_secrets in case the same line was hand-
# edited to carry something else.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_laravel; then
  skipped "php-config" "not a Laravel application (no composer dependency, no routes/ + app/)"
  exit 0
fi

# --- 1. a committed .env / .env.production carries an unsafe value (critical)
# `.env.example` is the template and is expected to be committed; a REAL
# `.env`/`.env.production` sitting in the repo means whatever it contains
# shipped to every clone, every CI runner, every contractor who ever cloned
# the repo — and if it also flips debug on or points at `local`, that is now
# the value production boots with unless the host's own env vars override it.
env_found=0
for name in .env .env.production; do
  [ -f "$ROOT/$name" ] || continue
  env_found=1
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-120)"
    finding "php-config" "critical" "$name:$ln" \
      "a committed env file sets an unsafe value that ships to every clone: $safe"
    evidence "sed -n '$(num "$ln")p' $(qpath "$name")"
  done < <(grep -nE '^[[:space:]]*APP_DEBUG[[:space:]]*=[[:space:]]*(true|1)([[:space:]]|$)' "$ROOT/$name" 2>/dev/null
           grep -nE "^[[:space:]]*APP_ENV[[:space:]]*=[[:space:]]*['\"]?local['\"]?([[:space:]]|$)" "$ROOT/$name" 2>/dev/null)
done

# --- 2. a committed .env file exists at all (high) -------------------------
# Even a "clean" committed .env (debug off, env=production) is a hygiene and
# secrets-handling failure in its own right: whatever else lives in it —
# DB_PASSWORD, APP_KEY, mail credentials — shipped into version control the
# moment the file was added, independent of what the two flags above say.
if [ "$env_found" -eq 1 ]; then
  for name in .env .env.production; do
    [ -f "$ROOT/$name" ] || continue
    finding "php-config" "high" "$name:1" \
      "a real env file is committed to the repository — it belongs in .gitignore, never in source control, regardless of the values it currently holds"
    evidence "test -f $(qpath "$ROOT/$name") && echo 'present on disk (the audit never runs git in the audited repo; confirm it is tracked with git ls-files yourself)'"
  done
fi

# --- 3. 'debug' hard-coded true in config/app.php (critical) ---------------
# Laravel's own scaffold is `'debug' => (bool) env('APP_DEBUG', false)` — a
# safe default. A literal `true` here overrides whatever the environment says,
# and a debug page leaks the stack trace, the .env values interpolated into
# it, and the full request on every unhandled exception.
cfg="$ROOT/config/app.php"
if [ -f "$cfg" ]; then
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    finding "php-config" "critical" "config/app.php:$ln" \
      "'debug' is hard-coded true in config/app.php, overriding whatever APP_DEBUG says in production: $(printf '%s' "$text" | sed 's/^[[:space:]]*//' | cut -c1-100)"
    evidence "sed -n '$(num "$ln")p' config/app.php"
  done < <(grep -nE "^[[:space:]]*'debug'[[:space:]]*=>[[:space:]]*true[[:space:]]*,?[[:space:]]*\$" "$cfg" 2>/dev/null)
fi

# --- 4. a non-empty $except array in VerifyCsrfToken.php (critical) --------
# Laravel's default VerifyCsrfToken has `protected $except = [];` — an empty
# array. Anything added to it is a named list of routes that accept a POST/PUT
# /DELETE with NO CSRF token check at all, which is only safe when every one
# of those routes is also read-only or independently authenticated another way.
csrf="$ROOT/app/Http/Middleware/VerifyCsrfToken.php"
if [ -f "$csrf" ]; then
  # The array can span multiple lines (`$except = [\n    'route/*',\n];`), so
  # this greps the OPENING line, then pulls everything from there down to the
  # first closing `];` and checks that whole block for a quoted string —
  # single-line `$except = ['admin/*'];` and multi-line both land in the same
  # block, so one check covers both shapes instead of two brittle regexes.
  except_ln="$(grep -n '\$except[[:space:]]*=[[:space:]]*\[' "$csrf" 2>/dev/null | head -1 | cut -d: -f1)"
  if [ -n "$except_ln" ]; then
    block="$(sed -n "${except_ln},\$p" "$csrf" | sed -n '1,/\];/p')"
    if grep -qE "'[^']+'" <<<"$block"; then
      finding "php-config" "critical" "app/Http/Middleware/VerifyCsrfToken.php:$except_ln" \
        "\$except carries at least one route pattern — CSRF protection is disabled for those routes; every one of them needs its own auth/verification story"
      evidence "sed -n '$(num "$except_ln"),+6p' app/Http/Middleware/VerifyCsrfToken.php"
    fi
  fi
fi

# --- 5. session cookie flags unset or permissive in config/session.php (high)
# `'secure' => env('SESSION_SECURE_COOKIE'),` with NO second argument resolves
# to null (falsy) unless .env sets it — cookies ride over plain HTTP whenever
# the var is missing. `'same_site' => 'none'` is the one value that is always
# permissive regardless of a default. `http_only` defaulting to false leaves
# the session cookie readable from JS.
sess="$ROOT/config/session.php"
if [ -f "$sess" ]; then
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    reason="left with no safe default — it resolves falsy the day the env var is unset"
    grep -qE "secure.*,[[:space:]]*false[[:space:]]*\)|secure'[[:space:]]*=>[[:space:]]*false[[:space:]]*,?[[:space:]]*\$" <<<"$text" && reason="defaults to false — the session cookie is allowed over plain HTTP"
    grep -qE "same_site.*'none'" <<<"$text" && reason="hard-set to 'none', the one value that is always permissive"
    grep -qE "http_only.*,[[:space:]]*false[[:space:]]*\)|http_only'[[:space:]]*=>[[:space:]]*false" <<<"$text" && reason="defaults to false, so the session cookie is readable from JavaScript"
    finding "php-config" "high" "config/session.php:$ln" \
      "a session cookie flag is $reason: $(printf '%s' "$text" | sed 's/^[[:space:]]*//' | cut -c1-110)"
    evidence "sed -n '$(num "$ln")p' config/session.php"
    # SESSION_SECURE_COOKIE resolving to null-without-a-default is the exact
    # ground-truth finding on the calibration repo (SEC-011): the code-level
    # default in `config/app.php:debug` is safe, but this one has none at all.
  done < <(grep -nE "'secure'[[:space:]]*=>[[:space:]]*env\([[:space:]]*['\"]SESSION_SECURE_COOKIE['\"][[:space:]]*\)[[:space:]]*,?[[:space:]]*\$" "$sess" 2>/dev/null
           grep -nE "'secure'[[:space:]]*=>[[:space:]]*(env\([^,]+,[[:space:]]*false\)|false)[[:space:]]*,?[[:space:]]*\$" "$sess" 2>/dev/null
           grep -nE "'same_site'[[:space:]]*=>[[:space:]]*(env\([^)]*,[[:space:]]*)?['\"]none['\"]" "$sess" 2>/dev/null
           grep -nE "'http_only'[[:space:]]*=>[[:space:]]*(env\([^,]+,[[:space:]]*false\)|false)[[:space:]]*,?[[:space:]]*\$" "$sess" 2>/dev/null)
fi

exit 0
