#!/usr/bin/env bash
# rsc-payload-exposure probe — evidence for standard/rsc-payload-exposure.md.
# Gated on a framework that serialises server-rendered props to the browser.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"
if [ -z "$files" ]; then
  skipped "rsc-payload-exposure" "no TS/TSX source found"
  exit 0
fi

# The serialising boundary is the client component, so the client components are
# the whole search space. No client components, nothing crosses.
client_files="$(grep -rlE '^[[:space:]]*["'"'"']use client["'"'"']' "$ROOT" \
  --include='*.tsx' --include='*.jsx' --exclude-dir=node_modules "${BUILD_EXCL[@]}" 2>/dev/null)"
if [ -z "$client_files" ]; then
  skipped "rsc-payload-exposure" "no client components — nothing serialises across a server/client boundary"
  exit 0
fi

# Exported component names from those files. These, and only these, are the tags
# whose props reach the browser.
names="$(while IFS= read -r f; do
  grep -hoE 'export (default )?function [A-Z][A-Za-z0-9_]*' "$f" 2>/dev/null
done <<< "$client_files" | awk '{print $NF}' | sort -u)"
[ -z "$names" ] && { skipped "rsc-payload-exposure" "client components export no named component"; exit 0; }
pattern="$(printf '%s' "$names" | tr '\n' '|')"

while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*spec*|*fixture*|*.d.ts) continue ;; esac
  grep -qE '^[[:space:]]*["'"'"']use client["'"'"']' "$f" 2>/dev/null && continue

  # An object-shaped prop handed to a client component. The prop NAMES are the
  # signal: a value called after a table or a record is the thing that arrived
  # from a query, and it serialises whole.
  while IFS= read -r m; do
    ln="${m%%:*}"
    finding "rsc-payload-exposure" "high" "$rel:$ln" "a row-shaped object is passed to a client component — every field it carries is serialised into the RSC payload the browser parses, not just the ones rendered (rsc-payload-exposure 1-3)"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <(grep -nE "<($pattern)[^>]*[[:space:]](user|row|record|profile|customer|account|member|order|payment|subscription|scan|report)[A-Za-z0-9_]*=\{[a-z][A-Za-z0-9_.]*\}" "$f" 2>/dev/null)

  # A spread carries every field by construction, whatever it is called.
  while IFS= read -r m; do
    ln="${m%%:*}"
    finding "rsc-payload-exposure" "high" "$rel:$ln" "an object is spread into a client component — a spread ships every field the object holds, including the ones nothing renders (rsc-payload-exposure 3)"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <(grep -nE "<($pattern)[^>]*\{\.\.\.[a-z][A-Za-z0-9_.]*\}" "$f" 2>/dev/null)
done <<< "$files"

exit 0
