#!/usr/bin/env bash
# supply-chain probe — evidence for standard/supply-chain.md.
#
# What CI trusts is what an attacker inherits. A mutable action tag is a
# standing invitation: the tag moves, and the next run executes something
# nobody reviewed, with whatever secrets the job holds.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

WF_DIR="$ROOT/.github/workflows"
if [ ! -d "$WF_DIR" ]; then
  skipped "supply-chain" "no .github/workflows — there is no CI to trust anything. N/A, which is a verdict rather than a pass."
  exit 0
fi

# Every `uses:` line, as file:line:content. Collected once.
USES="$(grep -rnE '^[[:space:]]*-?[[:space:]]*uses:[[:space:]]*[^ ]+' "$WF_DIR" 2>/dev/null)"; read_status=$?; if [ "$read_status" -gt 1 ]; then skipped "supply-chain" "coverage incomplete: cannot read every workflow"; exit 0; fi

# --- 1 + 2. mutable refs -----------------------------------------------------
# A branch ref is called out separately from a tag: a tag at least records which
# version was intended, a branch records nothing at all.
while IFS= read -r line; do
  [ -n "$line" ] || continue
  f="${line%%:*}"; rest="${line#*:}"; ln="${rest%%:*}"; body="${rest#*:}"
  ref="$(printf '%s' "$body" | sed -nE 's/.*uses:[[:space:]]*[^@]+@([^[:space:]#]+).*/\1/p')"
  [ -n "$ref" ] || continue
  # A local action (./path) has no ref to pin.
  grep -qE 'uses:[[:space:]]*\./' <<<"$body" && continue

  if grep -qE '^(main|master|develop|trunk)$' <<<"$ref"; then
    finding "supply-chain" "critical" "${f#"$ROOT"/}:$ln" "a workflow step runs an action from a BRANCH ($ref) — a branch has no version identity, so what executes changes whenever someone pushes to it, with this job's secrets in reach (supply-chain 2)"
    evidence "grep -nE 'uses:.*@(main|master|develop)' $(qpath "${f#"$ROOT"/}")"
  elif ! grep -qE '^[0-9a-f]{40}$' <<<"$ref"; then
    finding "supply-chain" "critical" "${f#"$ROOT"/}:$ln" "a workflow step is pinned to the mutable tag '$ref' rather than a commit SHA — a tag is a pointer the upstream can move, and moving it changes what runs here without a diff anyone reviews (supply-chain 1)"
    evidence "grep -nE 'uses:' $(qpath "${f#"$ROOT"/}")"
  fi
done <<EOF
$USES
EOF

# --- 3. a reusable workflow consumed at a branch -----------------------------
hit="$(printf '%s' "$USES" | grep -E 'uses:[^@]*\.github/workflows/[^@]+@(main|master|develop)' | head -1)"
if [ -n "$hit" ]; then
  f="${hit%%:*}"; rest="${hit#*:}"; ln="${rest%%:*}"
  finding "supply-chain" "high" "${f#"$ROOT"/}:$ln" "a shared reusable workflow is consumed at a branch — one merge upstream changes this repository's CI instantly and unreviewed, and a bad merge breaks every consumer at once (supply-chain 3)"
  evidence "grep -nE '.github/workflows/.*@(main|master)' $(qpath "${f#"$ROOT"/}")"
fi

# --- 4. provenance vs vuln counting -----------------------------------------
if grep -rqE 'npm (ci|install|audit)' "$WF_DIR" 2>/dev/null; then
  if ! grep -rqE 'npm audit signatures' "$WF_DIR" 2>/dev/null; then
    finding "supply-chain" "high" "${WF_DIR#"$ROOT"/}" "CI installs packages but never runs 'npm audit signatures' — it counts known CVEs and never checks WHO published the code it is running. A compromised package is signature-visible before it is ever CVE-visible (supply-chain 4)"
    evidence "grep -rn 'npm audit' $(qpath "${WF_DIR#"$ROOT"/}")"
  fi
fi

# --- 5. the same action at two versions --------------------------------------
drift="$(printf '%s' "$USES" \
  | sed -nE 's/.*uses:[[:space:]]*([^@[:space:]]+)@([^[:space:]#]+).*/\1 \2/p' \
  | sort -u | awk '{ c[$1]++ } END { for (a in c) if (c[a] > 1) print a }' | head -1)"
if [ -n "$drift" ]; then
  ln="$(printf '%s' "$USES" | grep -F "$drift@" | head -1 | cut -d: -f2)"
  f="$(printf '%s' "$USES" | grep -F "$drift@" | head -1 | cut -d: -f1)"
  finding "supply-chain" "medium" "${f#"$ROOT"/}:${ln:-1}" "the action '$drift' is used at more than one version in this repository — one of them is silently running older behaviour, and nobody chose which (supply-chain 5)"
  evidence "grep -rn $(qpath "$drift@") $(qpath "${WF_DIR#"$ROOT"/}")"
fi

# --- 6. pinning is gated, not swept once -------------------------------------
# What counts as a gate is an INVOCATION of a pinning checker, not a step whose
# name mentions pinning. A human-written step title is not a control; broadening
# this to match one would be the absent-filter failure, where a pattern loose
# enough to catch every good repo also catches every bad one.
if ! grep -rqiE 'pin-actions|ratchet|action-pin|--check.*pin|pinned-actions|supply-chain\.sh' "$WF_DIR" 2>/dev/null; then
  finding "supply-chain" "high" "${WF_DIR#"$ROOT"/}" "nothing in CI CHECKS the pinning — a one-time sweep decays, because the next workflow someone adds reintroduces a mutable tag and no gate notices (supply-chain 6)"
  evidence "grep -rniE 'pin-actions|--check' $(qpath "${WF_DIR#"$ROOT"/}")"
fi

# --- 7. vendored source without provenance -----------------------------------
VEND="$(PF_KEEP_VENDOR=1 product_find --first --maxdepth 3 -type d \( -name vendor -o -name vendored -o -name third_party \))"
if [ -n "$VEND" ]; then
  PROV="$(PF_KEEP_VENDOR=1 product_find --first --maxdepth 3 -iname 'VENDOR-PROVENANCE.md')"
  if [ -z "$PROV" ]; then
    finding "supply-chain" "high" "${VEND#"$ROOT"/}" "third-party source is vendored with no provenance manifest — nobody can say which upstream commit this copy came from, so nobody can tell whether an upstream fix has landed here (supply-chain 7)"
    evidence "ls $(qpath "${VEND#"$ROOT"/}"); find $(qpath "$ROOT") -iname 'VENDOR-PROVENANCE.md'"
  elif ! grep -qE '[0-9a-f]{40}' "$PROV" 2>/dev/null; then
    finding "supply-chain" "high" "${PROV#"$ROOT"/}" "the vendor provenance manifest records no 40-hex upstream commit — a version string is not provenance, because a version can be republished and a commit cannot (supply-chain 7)"
    evidence "cat $(qpath "${PROV#"$ROOT"/}")"
  fi
fi

workflow_count="$(find "$WF_DIR" -type f \( -name '*.yml' -o -name '*.yaml' \) -print | wc -l)"
ref_count="$(printf '%s\n' "$USES" | grep -cE '[^[:space:]]')" || ref_count=0
if [ "$workflow_count" -gt 0 ]; then
  printf '{"type":"checked","lens":"supply-chain","workflows":%d,"action_refs":%d}\n' "$workflow_count" "$ref_count"
else
  skipped "supply-chain" "no YAML workflows to inspect"
fi
exit 0
