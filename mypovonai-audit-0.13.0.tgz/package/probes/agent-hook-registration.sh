#!/usr/bin/env bash
# agent-hook-registration probe — evidence for standard/gate-integrity.md (a gate that
# is installed but never registered cannot fail) as applied to an AGENT SETUP.
#
# A hook script that exists on disk but is absent from settings.json `hooks` never
# fires: the exact dead-gate case agent-containment.md criterion 5 names
# (ops/self-eval-gate.sh was documented as a Stop hook and registered nowhere).
#
# Candidates (via agent_files, which prunes transcripts, plugins/, removed-*/, backups and
# vendored trees - plugins register their own hooks through hooks.json): a file carrying a
# `# claude-hook: <Event>` line of its own, or an EXECUTABLE script under scripts/hooks/,
# .claude/hooks/ or hooks/ at the root. Helper modules (_*, __init__*) never count. Registered = the basename appears inside the `hooks` object of
# settings.json or .claude/settings.json. N/A (skipped) on a product repo.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_agent_setup; then
  skipped "agent-hook-registration" "not an agent setup (no CLAUDE.md, .claude/settings.json, settings.json+skills/, or agents/*.md) — there are no hooks whose registration could be checked"
  exit 0
fi

# What settings.json registers, as one blob of the `hooks` object(s). Unparseable
# settings fall back to the raw text so a bad file never reads as "nothing registered".
REG="$(
  for s in "$ROOT/settings.json" "$ROOT/.claude/settings.json"; do
    [ -f "$s" ] && inside_root "$s" || continue
    node -e '
      const fs = require("fs"); const t = fs.readFileSync(process.argv[1], "utf8");
      try { process.stdout.write(JSON.stringify(JSON.parse(t).hooks ?? {})); } catch { process.stdout.write(t); }
    ' "$s" 2>/dev/null
    printf '\n'
  done
)"

while IFS= read -r rel; do
  [ -n "$rel" ] || continue
  f="$ROOT/$rel"
  name="$(basename "$rel")"
  # Helper modules (_base.py, __init__.py, _lib.sh) are imported by hooks, not run by Claude.
  case "$name" in _*|__init__*) continue ;; esac
  # A hook = the declaration as its OWN line (a comment that merely mentions the marker is
  # not one), or an executable script sitting in one of the three hook dirs at the root.
  if grep -qE '^# claude-hook:[[:space:]]+[A-Za-z]+[[:space:]]*$' "$f" 2>/dev/null; then :
  else
    case "$rel" in scripts/hooks/*|.claude/hooks/*|hooks/*) [ -x "$f" ] || continue ;; *) continue ;; esac
  fi
  grep -qF -- "$name" <<<"$REG" && continue
  finding "agent-hook-registration" "high" "$rel" "hook installed but not registered: $name never fires — register it in settings.json hooks"
  evidence "grep -rnF -- $(qpath "$name") settings.json .claude/settings.json  # (none found)"
done < <(agent_files '*.sh' '*.mjs' '*.js' '*.py')

exit 0
