#!/usr/bin/env bash
# edge-protection probe — evidence for standard/edge-protection.md.
# Most of this standard (WAF, origin lockdown, DDoS playbook) is INFRA, not
# code — the probe can only speak to the one code-detectable criterion
# (expensive endpoints carrying their own limit) and hands the rest to the
# interpreter with an explicit skipped note.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"
if [ -z "$files" ]; then
  skipped "edge-protection" "no TS/TSX source found"
  exit 0
fi

# expensive-endpoint-no-limit (crit 24.4): a route handler whose PATH marks it
# expensive (ai / generate / export / search / image / upload) that references
# no rate-limiter anywhere in the file. Only server route files (route.ts /
# api handlers / a POST|GET export) are considered.
LIMITER='rateLimit|ratelimit|RateLimit|Ratelimit|limiter|@upstash/ratelimit|rate-limit|throttle|checkLimit|consume\('
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *.test.*|*.spec.*|*.d.ts|*components/*|*.tsx) continue ;; esac
  # expensive by path/name
  case "$rel" in
    *ai/*|*generate*|*export*|*search*|*image*|*upload*|*embedding*|*completion*) : ;;
    *) continue ;;
  esac
  # must actually be a server handler (exports a method / is a route file)
  grep -qE 'export (async )?function (GET|POST|PUT|PATCH|DELETE)|route\.(get|post)|router\.(get|post)|export const (GET|POST)' "$f" 2>/dev/null || \
    case "$rel" in */route.ts|*/route.tsx) : ;; *) continue ;; esac
  body="$(cat "$f" 2>/dev/null)"
  grep -qiE "$LIMITER" <<<"$body" && continue
  finding "edge-protection" "critical" "$rel" "expensive endpoint (ai/generate/export/search/image) with no rate-limiter reference — a cost-amplification and abuse vector with no tighter cap (24.4)"
  evidence "grep -niE 'rateLimit|ratelimit|throttle|consume' $(qpath "$f")  # (none found)"
done <<<"$files"

# The infra half of this standard cannot be seen from code.

exit 0
