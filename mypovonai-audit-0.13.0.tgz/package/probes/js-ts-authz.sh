#!/usr/bin/env bash
# js-ts-authz: bounded source candidates; see rubric/js-ts-authz.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "js-ts-authz" "$rel"; continue; fi
  finding "js-ts-authz" "high" "$rel:$line" "Administrative route mutations require a local role, permission, or ownership guard."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "js-ts-authz" "$ROOT")
exit 0
