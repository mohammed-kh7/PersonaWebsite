#!/usr/bin/env bash
# testing probe — evidence for standard/testing.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

WF_DIR="$ROOT/.github/workflows"
has_tests=0
[ -d "$ROOT/tests" ] || [ -d "$ROOT/test" ] || [ -n "$(product_find --first -type d -name '__tests__')" ] && has_tests=1
# Co-located suites (src/**/*.test.ts, *.spec.ts) ARE a test layer: unmasked when the sample-dir
# integration false positive stopped short-circuiting this branch (measured on this repo).
[ "$has_tests" = "0" ] && [ -n "$(product_find --first -type f \( -name '*.test.ts' -o -name '*.test.tsx' -o -name '*.test.mjs' -o -name '*.spec.ts' -o -name '*.spec.tsx' \))" ] && has_tests=1
has_integration=0
[ -n "$(product_find --first -type d -name integration)" ] && has_integration=1

# integration-blocking (crit): integration tests must run in CI
if [ "$has_integration" = "1" ]; then
  if [ ! -d "$WF_DIR" ] || ! grep -rqiE 'test:integration|tests/integration|vitest.*integration' "$WF_DIR" 2>/dev/null; then
    finding "testing" "critical" "$WF_DIR" "tests/integration exists but no workflow runs it — integration coverage is not CI-gated"
    evidence "grep -rniE 'test:integration|tests/integration' $(qpath "$WF_DIR")"
  fi
elif [ "$has_tests" = "0" ]; then
  finding "testing" "high" "$ROOT" "no tests/ or __tests__ directory found — the project has no test layer"
  evidence "find $(qpath "$ROOT") -type d \\( -name tests -o -name __tests__ \\) -not -path '*/node_modules/*'"
fi

# teardown-discipline (high): a REAL truncate/prisma-delete in a test with no
# teardown. Two calibration guards (FWB 2026-08-13):
#  - match only `prisma.<model>.deleteMany(` / `TRUNCATE`, NOT a bare
#    `deleteMany:` which is a vi.mock factory PROPERTY, not a DB call (that
#    false-flagged 3 pure unit tests).
#  - a global teardown (vitest setupFiles / globalSetup / a tests/setup.*) IS
#    the teardown discipline; per-file afterAll is then not required.
GLOBAL_TEARDOWN=0
if grep -rqiE 'setupFiles|globalSetup|globalTeardown' "$ROOT"/vitest*.config.* "$ROOT"/jest.config.* 2>/dev/null; then  # build-ok: named config files at the root
  GLOBAL_TEARDOWN=1
fi
REAL_MUT='prisma\.[a-z][A-Za-z]*\.deleteMany\(|\bTRUNCATE\b|\$executeRaw[^`]*TRUNCATE'
if [ "$GLOBAL_TEARDOWN" = "0" ]; then
  while IFS= read -r f; do
    rel="${f#"$ROOT"/}"
    case "$rel" in *fixture*|*mock*) continue ;; esac
    grep -qiE "$REAL_MUT" "$f" 2>/dev/null || continue
    grep -qiE 'afterAll|afterEach' "$f" 2>/dev/null && continue
    ln=$(grep -niE "$REAL_MUT" "$f" | head -1 | cut -d: -f1)
    finding "testing" "high" "$rel:$ln" "test truncates/deletes real DB rows with no afterAll/afterEach and no global teardown — leaks state into the next suite"
    evidence "grep -niE 'prisma\\.[a-z].*deleteMany|TRUNCATE|afterAll|afterEach' $(qpath "$f")"
  done < <(src_files | grep -iE '\.(test|spec)\.ts')
fi

exit 0
