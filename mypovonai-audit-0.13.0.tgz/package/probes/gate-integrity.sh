#!/usr/bin/env bash
# gate-integrity probe — evidence for standard/gate-integrity.md.
#
# The lens is "a gate's PASS is evidence only if that same gate, unchanged, can
# be made to fail". Most of that is a property of the gate's HISTORY (was a
# negative control ever run?) and is invisible to a grep. What IS mechanically
# visible is a route to "pass" that never reads the artifact — and every one of
# the four checks below is a route the standard names verbatim:
#   §2  a machine-readable report sent to /dev/stdout — the report never exists
#   §2  a scanner neutered by `|| true` / continue-on-error / a parser fallback
#   §2  a deprecated subcommand with no version pin — one release from exit 0
#   §3  a trust-boundary branch on a bare truthy injected value
# The negative control, the receipt and the empty-input FAIL are handed to the
# interpreter: their ABSENCE produces no token to match on.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

SCANNERS='gitleaks|semgrep|trivy|snyk|secretlint|osv-scanner|codeql|bandit|zap-baseline|npm audit|pnpm audit|yarn audit'

# grep -rn emits `path:line:text`; turn each hit into a located finding.
# A comment that QUOTES the bad pattern is not the bad pattern. Calibration
# precedent: a doc comment reading "NO dangerouslySetInnerHTML" was a security
# false positive, and three fixtures have already tripped a probe by naming the
# trigger word. grep -rn emits `path:line:text`, so anchor on the text field.
NOT_COMMENT='^[^:]*:[0-9]+:[[:space:]]*(//|#|\*|/\*)'

emit() { # severity pattern message   (grep -rn output on stdin)

  local sev="$1" pat="$2" msg="$3" line f rest n
  while IFS= read -r line; do
    [ -n "$line" ] || continue
    f="${line%%:*}"; rest="${line#*:}"; n="${rest%%:*}"
    finding "gate-integrity" "$sev" "${f#"$ROOT"/}:$n" "$msg"
    evidence "grep -nE '$pat' $(qpath "$f")"
  done
}

OPS=(--include='*.sh' --include='*.bash' --include='*.yml' --include='*.yaml' --include='*.mjs' --include='*.js' --include='*.ts' --exclude-dir=node_modules "${BUILD_EXCL[@]}")
TS=(--include='*.ts' --include='*.tsx' --exclude-dir=node_modules "${BUILD_EXCL[@]}")

# --- report-sink (critical, §2) -------------------------------------------
# Measured on gitleaks 8.30.1: --report-path /dev/stdout receives NOTHING; the
# log stream and the report stream are different sinks. The parser then reads
# an empty string and reports 0 findings — for any corpus, forever.
P_SINK='--(report-path|report_path|output|out|sarif|json-output)[[:space:]=]+/dev/std(out|err)'
# -e, not a bare pattern: the pattern STARTS with `--`, which BSD grep (the
# macOS default this probe runs under) would otherwise consume as an option.
grep -rnE -e "$P_SINK" "${OPS[@]}" "$ROOT" 2>/dev/null | grep -vE "$NOT_COMMENT" | head -25 \
  | emit "critical" "$P_SINK" "a machine-readable scanner report is written to /dev/stdout|/dev/stderr — several scanners treat the report sink and the log sink as different streams, so the report never exists, the parser reads an empty string and the gate reports 0 findings for ANY input; write to a real file with --report-path and read it back (gate-integrity 2)"

# --- scanner-fail-open (critical, §2) -------------------------------------
# Three routes to a green that never read the artifact. All three lived in one
# 40-line gate; the second survived the fix to the first, because that fix
# addressed the observed path rather than the class.
P_ORTRUE="($SCANNERS)[^|]*\\|\\|[[:space:]]*true"
# CALIBRATED (foundation self-audit, 2026-09-02): `npm audit --json … > "$f" || true`
# is the standard's OWN prescription — bind the verdict to an artifact, not to the
# exit code — so a scanner line that captures structured output to a real file is
# not a neutered gate. Excluded: a --json/--format run redirected to a file that is
# not /dev/std*. A bare `npm audit --audit-level=high || true` still fires.
P_ARTIFACT_BOUND='(--json|--format[[:space:]=])[^|]*>[[:space:]]*"?[^|/]'
# CALIBRATED (judged run, 2026-10-09): `scanner … > "$RUNNER_TEMP/x.err" 2>&1 || true` followed, in the
# SAME step, by a command that READS that file (`node audit-gate.mjs … "$RUNNER_TEMP/x.err"`) is the
# artifact-bound pattern, not a neutered gate: the verdict comes from the parser. Likewise a step that
# does `set +e`, captures `rc=$?` and asserts `$rc` later. Exempt when (a) the line redirects to a real
# file whose exact path string appears in a LATER line of the same step other than as a redirect
# target, or (b) the step has `set +e`, a `NAME=$?` capture and a later use of $NAME. A bare
# `scanner … || true` with no consumer still fires. For .yml a step runs from its `- name:`/`- run:`
# line to the next step line at the same or lower indent; any other file is one block.
or_true_consumed() { # file line   -> 0 when the neutered exit code has a consumer
  awk -v n="$2" -v yml="$([[ "$1" == *.yml || "$1" == *.yaml ]] && echo 1 || echo 0)" '
    { L[NR] = $0 }
    END {
      s = 1; e = NR; ind = 0
      if (yml == 1) {
        for (i = n; i >= 1; i--) if (L[i] ~ /^[[:space:]]*-[[:space:]]+[A-Za-z_-]+:/) { s = i; match(L[i], /^[[:space:]]*/); ind = RLENGTH; break }
        for (i = n + 1; i <= NR; i++) if (L[i] ~ /^[[:space:]]*-[[:space:]]+[A-Za-z_-]+:/) { match(L[i], /^[[:space:]]*/); if (RLENGTH <= ind) { e = i - 1; break } }
      }
      t = ""
      if (match(L[n], />[[:space:]]*"?[^"[:space:]|&;>]+"?/)) { t = substr(L[n], RSTART, RLENGTH); sub(/^>[[:space:]]*"?/, "", t); sub(/"$/, "", t) }
      if (t != "" && t !~ /^\/dev\// && t !~ /^&/) {
        for (i = n + 1; i <= e; i++) {
          if (L[i] ~ /^[[:space:]]*#/) continue
          p = index(L[i], t)
          if (p > 0 && substr(L[i], 1, p - 1) !~ />[[:space:]]*"?$/) exit 0
        }
      }
      sete = 0; v = ""
      for (i = s; i <= e; i++) {
        if (L[i] ~ /set \+e/) sete = 1
        if (sete && i > n - 3 && match(L[i], /^[[:space:]]*[A-Za-z_][A-Za-z0-9_]*=\$\?/)) { v = L[i]; sub(/^[[:space:]]*/, "", v); sub(/=.*/, "", v); vi = i }
      }
      if (v != "") for (i = vi + 1; i <= e; i++) if (L[i] ~ ("(exit|if|\\[|test|\\|\\|).*\\$\\{?" v "\\}?")) exit 0
      exit 1
    }' "$1"
}
grep -rnE "$P_ORTRUE" "${OPS[@]}" "$ROOT" 2>/dev/null | grep -vE "$NOT_COMMENT" \
  | grep -vE "$P_ARTIFACT_BOUND" \
  | while IFS= read -r hit; do
      hf="${hit%%:*}"; hn="${hit#*:}"; hn="${hn%%:*}"
      case "$hn" in ''|*[!0-9]*) printf '%s\n' "$hit"; continue ;; esac
      or_true_consumed "$hf" "$hn" || printf '%s\n' "$hit"
    done | head -25 \
  | emit "critical" "$P_ORTRUE" "a security scanner invocation is neutered with '|| true' — the step can no longer go red, so its green is a report about the shell, not about the tree (gate-integrity 2/4: never ship a gate whose only proof of life is that it is green)"

# CALIBRATED (FWB, 2026-09-02): a bare `?? []` anywhere in a gate file is too
# wide. FWB's audit-gate.mjs uses `v.via ?? []` as a PER-ENTRY field default
# inside a loop that has already read and parsed the report — and its top-level
# routes are correct (empty output -> exit 1, JSON.parse unguarded -> throws).
# The documented defect is a fallback on the REPORT READ ITSELF, so the read and
# the fallback must appear together, or the fallback must be the verbatim
# `catch { return [] }` the standard names.
P_FALLBACK="((JSON\\.parse|readFileSync|readFile|cat[[:space:]]|\\.json).*(\\?\\?[[:space:]]*\\[\\]|\\|\\|[[:space:]]*echo[[:space:]]*['\"]\\[\\]['\"])|catch[^{]*\\{[[:space:]]*return[[:space:]]*\\[\\])"
while IFS= read -r f; do
  [ -n "$f" ] || continue
  grep -qE "$SCANNERS|report-path|reportPath" "$f" 2>/dev/null || continue
  grep -nE "$P_FALLBACK" "$f" 2>/dev/null | head -5 | while IFS= read -r hit; do
    finding "gate-integrity" "critical" "${f#"$ROOT"/}:${hit%%:*}" "a gate's report parse falls back to an empty result (?? [] / || echo '[]' / catch -> []) — a parser fallback converts a BROKEN gate into a passing one; on a parse error the gate must throw, not empty itself (gate-integrity 2)"
    evidence "grep -nE $(qpath "$P_FALLBACK") $(qpath "$f")"
  done
done < <(grep -rlE "$SCANNERS|report-path|reportPath" "${OPS[@]}" "$ROOT" 2>/dev/null | head -40)

# continue-on-error on a workflow that runs a security scanner: the job reports
# success whatever the scanner found.
WF_DIR="$ROOT/.github/workflows"
if [ -d "$WF_DIR" ]; then
  for wf in "$WF_DIR"/*.yml "$WF_DIR"/*.yaml; do
    [ -e "$wf" ] || continue
    grep -qE "$SCANNERS" "$wf" 2>/dev/null || continue
    # CALIBRATED (foundation self-audit, 2026-09-02): "the file contains a scanner
    # AND contains continue-on-error" is too coarse — reusable-ci.yml has an npm
    # audit step at line 223 and a `continue-on-error` on an UPLOAD-ARTIFACT step
    # 99 lines away. Require the two to sit in the same step: within 10 lines.
    hit=""
    while IFS= read -r cn; do
      [ -n "$cn" ] || continue
      while IFS= read -r sn; do
        [ -n "$sn" ] || continue
        d=$(( sn > cn ? sn - cn : cn - sn ))
        [ "$d" -le 10 ] && { hit="$cn"; break; }
      done < <(grep -nE "$SCANNERS" "$wf" | cut -d: -f1)
      [ -n "$hit" ] && break
    done < <(grep -nE '^[[:space:]]*continue-on-error:[[:space:]]*true' "$wf" | cut -d: -f1)
    [ -n "$hit" ] || continue
    finding "gate-integrity" "critical" "${wf#"$ROOT"/}:$hit" "a security-scanner step sets continue-on-error: true — the job goes green whatever the scan found; a gate that cannot fail reports success (gate-integrity 2/4)"
    evidence "grep -nE 'continue-on-error|$SCANNERS' $(qpath "$wf")"
  done
fi

# --- gate-tool-pinning (medium, §2) ---------------------------------------
# `detect` is deprecated and absent from `gitleaks --help` on 8.30.1. Pinned, it
# still works; unpinned, the gate is one release from exit 0 with no output.
while IFS= read -r f; do
  [ -n "$f" ] || continue
  grep -qE 'GITLEAKS_VERSION|gitleaks@|gitleaks[_-]version|v8\.[0-9]+\.[0-9]+' "$f" 2>/dev/null && continue
  n=$(grep -nE 'gitleaks[[:space:]]+detect' "$f" | head -1 | cut -d: -f1)
  finding "gate-integrity" "medium" "${f#"$ROOT"/}:$n" "the secret gate calls the deprecated 'gitleaks detect' subcommand with no version pin in the same file — a deprecated subcommand is one release away from exiting 0 with no output; pin the version and self-test the subcommand (gitleaks --help | grep -w detect) (gate-integrity 2)"
  evidence "grep -nE 'gitleaks' $(qpath "$f")"
done < <(grep -rlE 'gitleaks[[:space:]]+detect' "${OPS[@]}" "$ROOT" 2>/dev/null | head -20)

# --- truthy-entitlement-seam (high, §3) -----------------------------------
# Narrow on purpose: the value must be an entitlement/authorization CALL that is
# branched on directly. `if (isAdmin)` on a locally-derived boolean is not this
# defect; `entitled ? allow : deny` where `entitled` crossed a DI seam is. Every
# one of {}, 1, "yes" and the string "false" is truthy.
P_SEAM='(if[[:space:]]*\([[:space:]]*await[[:space:]]+[A-Za-z_$.]*([Ee]ntitl|[Hh]asAccess|[Ii]sAuthorized|[Cc]anAccess|[Hh]asEntitlement)[A-Za-z_$]*\()|((await[[:space:]]+)?[A-Za-z_$.]*([Ee]ntitl|[Hh]asAccess|[Ii]sAuthorized|[Cc]anAccess)[A-Za-z_$]*\([^)]*\)\)?[[:space:]]*\?[^?])'
grep -rnE "$P_SEAM" "${TS[@]}" "$ROOT" 2>/dev/null | grep -v '=== true' | grep -vE "$NOT_COMMENT" | head -25 \
  | emit "high" "$P_SEAM" "an entitlement/authorization result is branched on for truthiness rather than compared to a literal — TypeScript erases at runtime, so an injected () => Promise<boolean> can return {}, 1, \"yes\" or the string \"false\" (all truthy, and \"false\" is the one that READS as a denial) and each grants access; use === true or parse the value at the seam (gate-integrity 3)"

# --- checklist-silent-pass (medium) ---------------------------------------
# An agent checklist that runs "silently" cannot fail: a skipped rule and a passed
# rule look identical (standard/gate-integrity.md, visible-skip).
while IFS= read -r rel; do
  [ -n "$rel" ] || continue
  finding "gate-integrity" "medium" "$rel" "needs validation: checklist runs silently: agent instructions say to run checks silently — record each item as done (evidence) or skip: <reason>"
  evidence "grep -niE 'silently' $(qpath "$rel")"
done < <(silent_checklist_files)

# Runtime negative-control/receipt proof is outside this static lens; see scope rulings.

exit 0
