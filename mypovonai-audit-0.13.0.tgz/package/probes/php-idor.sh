#!/usr/bin/env bash
# php-idor probe — evidence for rubric/php-idor.md.
#
# The finding that made this pack necessary: CompanyController::offers/commission
# fetch a company by the ROUTE PARAMETER named after the table's own primary key
# (`->where('company_id', $company_id)`), and nothing else scopes the query — the
# where() clause LOOKS like an ownership check because its column name matches
# the vocabulary ("company_id") but it is comparing the id to ITSELF. Any visitor
# can walk `company_id` from 1..N and read every company's confidential
# commission data with zero auth. A probe that treats "a where() naming a
# tenant-ish column" as proof of scoping would call this repo clean.
#
# ANALYSIS IS PER METHOD, not per line: a method is "scoped" only when an
# ownership-shaped column (user_id/company_id/tenant_id/owner_id) appears
# ALONGSIDE a second, DIFFERENT filter column (e.g. the record's own `id`) in
# the same method — that second column is what proves the ownership column is
# an added constraint, not the lookup's only key wearing an ownership-shaped
# name. `authorize()`/`Gate::`/`->can(` and an authenticated-relationship
# traversal (`auth()->user()->companies()->find(...)`) also count as scoped.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

is_laravel || { skipped "php-idor" "not a Laravel application (no composer dependency, no routes/ + app/)"; exit 0; }

controller_files="$(find "$ROOT" -type f -path '*/Controllers/*.php' \
  -not -path '*/vendor/*' -not -path '*/node_modules/*' -not -path '*/storage/*' 2>/dev/null)"
[ -n "$controller_files" ] || { skipped "php-idor" "no app/Http/Controllers PHP source found"; exit 0; }

# --- helper: print "startline:endline" for every function in a file ---------
# Laravel controllers in the calibration repo keep each chained call on its own
# line and never use "{$var}" string interpolation (checked: zero hits), so a
# plain per-line brace count is a safe way to find a method's matching close.
method_ranges() {
  awk '
    function braces(s, ch,   n,i,c) { n=0; for (i=1;i<=length(s);i++) { c=substr(s,i,1); if (c==ch) n++ }; return n }
    BEGIN { in_m=0 }
    {
      if (!in_m && $0 ~ /function[ \t]+[A-Za-z_][A-Za-z0-9_]*[ \t]*\(/) { in_m=1; start=NR; depth=0; seen=0 }
      if (in_m) {
        o=braces($0,"{"); c=braces($0,"}")
        if (o>0) seen=1
        depth+=o-c
        if (seen && depth<=0) { print start":"NR; in_m=0 }
      }
    }' "$1"
}

VULN="$(mktemp "${TMPDIR:-/tmp}/php-idor-vuln-XXXXXX")"
trap 'rm -f "$VULN"' EXIT

# --- 1. a controller method loads a client-supplied id with no ownership scope (critical) ---
while IFS= read -r f; do
  [ -n "$f" ] || continue
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*|*/vendor/*) continue ;; esac
  class="$(grep -m1 -oE 'class[[:space:]]+[A-Za-z_][A-Za-z0-9_]*' "$f" | awk '{print $2}')"
  [ -n "$class" ] || continue

  while IFS= read -r range; do
    [ -n "$range" ] || continue
    start="${range%%:*}"; end="${range##*:}"
    mname="$(sed -n "${start}p" "$f" | grep -oE 'function[[:space:]]+[A-Za-z_][A-Za-z0-9_]*' | awk '{print $2}')"
    [ -n "$mname" ] || continue
    [ "$mname" = "__construct" ] && continue
    body="$(sed -n "${start},${end}p" "$f")"

    # Any Eloquent single-record lookup by a VARIABLE id (never a hard-coded one).
    has_find=0
    grep -qE '(::find\(|->find\(|findOrFail\()[[:space:]]*\$' <<<"$body" && has_find=1
    grep -qE 'findOrFail\([[:space:]]*request\(' <<<"$body" && has_find=1

    # Local aliases for the logged-in user (`$user = Auth::user();`,
    # `$applicantId = Auth::id();`), so a later `->where('user_id', $user->user_id)`
    # or `->where('applicant_id', $applicantId)` reads as session-scoped, not a
    # client-supplied id wearing an ownership-shaped column name.
    auth_vars="$(grep -oE -- '\$[A-Za-z_][A-Za-z0-9_]*[[:space:]]*=[[:space:]]*Auth::(user|id)\(\)' <<<"$body" \
      | sed -E 's/^\$([A-Za-z_][A-Za-z0-9_]*).*/\1/' | sort -u)"
    # Same idea for a value captured from the request under a NEW name, e.g.
    # `$jobId = request('job');` used two lines later as `->where('id', $jobId)`.
    request_vars="$(grep -oE -- '\$[A-Za-z_][A-Za-z0-9_]*[[:space:]]*=[[:space:]]*(\$request->|request\()' <<<"$body" \
      | sed -E 's/^\$([A-Za-z_][A-Za-z0-9_]*).*/\1/' | sort -u)"

    # This method's OWN parameters (route-bound variables) -- every $token in
    # its signature line, e.g. `updateCompanyJob(Request $request, $id, $jobId)`
    # -> {request, id, jobId}. A where() value has to resolve to one of these
    # (or to $request->/request(...) directly) to be CLIENT-supplied at all.
    # Without this, `DB::table('contactus')->orderBy('id')->first(); ->where('id',
    # $firstRow->id)->update(...)` reads as an id lookup: $firstRow->id is the
    # SERVER's own prior query result, not anything a visitor can choose.
    params="$(sed -n "${start}p" "$f" | grep -oE '\$[A-Za-z_][A-Za-z0-9_]*' | sed 's/^\$//' | sort -u)"

    # Every ->where('col', VALUE) with a non-literal VALUE. orWhere never matches
    # this pattern (the substring is "->where(", "->orWhere(" doesn't contain it),
    # which is correct: an OR'd condition is not an ownership constraint.
    cols=""
    auth_scoped=0
    while IFS= read -r wc; do
      [ -n "$wc" ] || continue
      col="$(sed -E "s/.*\(['\"]([A-Za-z_]+)['\"].*/\1/" <<<"$wc")"
      val="$(sed -E 's/.*,[[:space:]]*//; s/\)[[:space:]]*$//' <<<"$wc")"
      grep -qE "^[0-9]+\$|^'[^']*'\$|^\"[^\"]*\"\$" <<<"$val" && continue
      # The value comes from the SESSION, not the request: Auth::id()/auth()->id(),
      # or the local alias captured above (`$user->user_id`). A where() scoped to
      # the caller's own identity needs no second column to be safe.
      # (Not requiring the closing paren: a nested call like `Auth::id()` can get
      # truncated by the outer [^)]+ capture at its own inner ")".)
      vname="$(sed -E 's/^\$([A-Za-z_][A-Za-z0-9_]*).*/\1/' <<<"$val")"
      is_auth=0
      grep -qE -- 'Auth::id\(|auth\(\)->id\(' <<<"$val" && is_auth=1
      [ -n "$auth_vars" ] && grep -qxF "$vname" <<<"$auth_vars" && is_auth=1
      [ "$is_auth" -eq 1 ] && { auth_scoped=1; cols="$cols $col"; continue; }
      # CLIENT-supplied only: $request->..., request(...), this method's own
      # route parameter, or a local var captured from one of those two above.
      # Anything else (a variable this method computed itself, e.g. from a prior
      # query) is not attacker-controlled and isn't a lookup candidate at all --
      # skip it rather than call it either safe or unsafe.
      is_client=0
      grep -qE -- '^\$request->|^request\(' <<<"$val" && is_client=1
      [ "$is_client" -eq 0 ] && grep -qxF "$vname" <<<"$params" && is_client=1
      [ "$is_client" -eq 0 ] && [ -n "$request_vars" ] && grep -qxF "$vname" <<<"$request_vars" && is_client=1
      [ "$is_client" -eq 1 ] || continue
      cols="$cols $col"
    # `--` ends option parsing: the pattern's own leading "-" (from PHP's "->")
    # is otherwise read as a grep FLAG and dies with "invalid option -- >".
    done < <(grep -oE -- "->where\([[:space:]]*['\"][A-Za-z_]+['\"][[:space:]]*,[[:space:]]*[^)]+\)" <<<"$body")
    [ "$has_find" -eq 1 ] && cols="$cols id"
    cols="$(tr ' ' '\n' <<<"$cols" | grep -v '^$' | sort -u)"

    has_id_lookup=0
    grep -qE '^(id|[A-Za-z_]+_id)$' <<<"$cols" && has_id_lookup=1
    [ "$has_id_lookup" -eq 1 ] || continue

    ownership_present=0
    grep -qE '^(user_id|company_id|tenant_id|owner_id)$' <<<"$cols" && ownership_present=1
    distinct_count="$(printf '%s\n' "$cols" | grep -c .)"

    safe=0
    [ "$ownership_present" -eq 1 ] && [ "$distinct_count" -ge 2 ] && safe=1
    [ "$auth_scoped" -eq 1 ] && safe=1
    grep -qE '\->authorize\(|Gate::|->can\(' <<<"$body" && safe=1
    grep -qE 'auth\(\)->user\(\)->|Auth::user\(\)->' <<<"$body" && safe=1

    [ "$safe" -eq 1 ] && continue

    printf '%s::%s\n' "$class" "$mname" >> "$VULN"
    # HIGH, not critical: severity follows REACHABILITY. Most of these sit behind
    # the admin gate, where loading any record by id is the admin's job -- the
    # rubric already grades that 1, "not exploitable by an anonymous visitor".
    # Criterion 2 below re-reports the subset a PUBLIC route can reach, and that
    # one is critical. Marking all 41 method-level hits critical on the
    # calibration repo would have shipped 41 false alarms next to 8 real ones.
    finding "php-idor" "high" "$rel:$start" \
      "$class::$mname() loads a record by a client-supplied id with no ownership scope in the method body — no additional where() on user_id/company_id/tenant_id/owner_id, no policy check, no relationship traversal"
    evidence "sed -n '$(num "$start"),$(num "$end")p' $(qpath "$rel") | grep -nE \"find\\(|where\\(\""
  done < <(method_ranges "$f")
done <<< "$controller_files"

# --- 2. a public route (no middleware group) forwards straight to a method flagged above (critical) ---
# Only fires for routes calling a method the check above ALREADY flagged: this
# keeps it from flagging the many intentionally-public {id} routes in this repo
# (job listings, offer details) that carry no per-owner data and no scope bug.
route_files_list="$(route_files)"
if [ -n "$route_files_list" ] && [ -s "$VULN" ]; then
  while IFS= read -r rf; do
    [ -n "$rf" ] || continue
    rrel="${rf#"$ROOT"/}"
    # Track whether each route line sits inside a Route::group()/middleware()
    # closure: a running brace-depth count over the whole file. Depth 0 at the
    # Route::VERB( line means no enclosing group wraps it.
    while IFS= read -r hit; do
      [ -n "$hit" ] || continue
      ln="${hit%%:*}"; rest="${hit#*:}"
      depth_before="${rest%%:*}"; line="${rest#*:}"
      [ "$depth_before" -eq 0 ] || continue
      grep -qE '\->middleware\(' <<<"$line" && continue
      ctrl="$(sed -E "s/.*\[[[:space:]]*\\\\?([A-Za-z_]+)::class[[:space:]]*,[[:space:]]*['\"]([A-Za-z_]+)['\"][[:space:]]*\].*/\1::\2/" <<<"$line")"
      case "$ctrl" in *::*) : ;; *) continue ;; esac
      grep -qxF "$ctrl" "$VULN" || continue
      finding "php-idor" "critical" "$rrel:$ln" \
        "route forwards to $ctrl with no auth/gate middleware group and no ->middleware() on the route itself — the unscoped id lookup above is reachable by anyone"
      evidence "sed -n '$(num "$ln")p' $(qpath "$rrel")"
    done < <(awk '
      function braces(s, ch,   n,i,c) { n=0; for (i=1;i<=length(s);i++) { c=substr(s,i,1); if (c==ch) n++ }; return n }
      BEGIN { depth=0 }
      {
        before=depth
        if ($0 ~ /Route::(get|post|put|patch|delete|match|any)\(/) print NR":"before":"$0
        depth += braces($0,"{") - braces($0,"}")
      }' "$rf")
  done <<< "$route_files_list"
fi

exit 0
