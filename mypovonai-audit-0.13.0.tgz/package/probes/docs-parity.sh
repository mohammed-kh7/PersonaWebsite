#!/usr/bin/env bash
# docs-parity probe — evidence for standard/docs-parity.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

# missing-core-docs (high 1/5): README + DEPLOYMENT + ROLLBACK must exist.
missing=""
[ -f "$ROOT/README.md" ] || missing="$missing README.md"
[ -f "$ROOT/docs/DEPLOYMENT.md" ] || [ -f "$ROOT/DEPLOYMENT.md" ] || missing="$missing docs/DEPLOYMENT.md"
[ -f "$ROOT/docs/ROLLBACK.md" ] || [ -f "$ROOT/ROLLBACK.md" ] || missing="$missing docs/ROLLBACK.md"
if [ -n "$missing" ]; then
  finding "docs-parity" "high" "$ROOT" "core docs missing:$missing — a deploy/rollback runbook is not optional for a production app (docs-parity 1/5)"
  evidence "ls $(qpath "$ROOT/README.md") $(qpath "$ROOT/docs/DEPLOYMENT.md") $(qpath "$ROOT/docs/ROLLBACK.md") 2>&1"
fi

# stale-stack-drift (medium 9): README/ROADMAP naming a retired stack.
for doc in "$ROOT/README.md" "$ROOT/ROADMAP.md" "$ROOT/docs/ROADMAP.md"; do
  [ -f "$doc" ] || continue
  # unambiguous retired tokens only (grep -E has no lookahead, so avoid 'Claude'
  # which collides with 'Claude Code' footers — Stripe/Next14 are clean tells).
  hit="$(grep -niE '\bStripe\b|Next\.?js ?14\b|\bNext 14\b' "$doc" 2>/dev/null | head -1)"
  [ -z "$hit" ] && continue
  ln="${hit%%:*}"
  finding "docs-parity" "medium" "${doc#"$ROOT"/}:$ln" "README/ROADMAP names a retired stack token (Stripe / Next.js 14) that contradicts the real stack — stale docs mislead onboarding (docs-parity 9)"
  evidence "grep -niE 'Stripe|Next.?js 14' $(qpath "${doc#"$ROOT"/}")"
  break
done

exit 0
