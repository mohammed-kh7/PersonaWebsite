/** Dependency-free, bounded source candidates. These are NOT whole-program proofs. */
import { readdirSync, lstatSync, realpathSync, openSync, readFileSync, closeSync, constants } from 'node:fs';
import { join, relative, resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
const EXCLUDED = new Set(['node_modules','vendor','.git','graphify-out','fixtures','__fixtures__','test-fixtures','testdata','__snapshots__','__mocks__','.open-next','.next','.nuxt','.svelte-kit','.output','.vercel','.wrangler','dist','build','out','coverage','.turbo','.cache']);
const SOURCE = new Set(['.ts','.tsx','.js','.jsx','.mjs','.cjs','.sql','.prisma','.json','.html','.vue','.svelte']);
const LIMIT = 1024 * 1024;
function readBounded(file, root) {
  const real = realpathSync(file);
  if (real !== root && !real.startsWith(root + '/')) return null;
  if (lstatSync(file).isSymbolicLink() || lstatSync(file).size > LIMIT) return null;
  const fd = openSync(file, constants.O_RDONLY | constants.O_NOFOLLOW);
  try { const b = readFileSync(fd); return b.length > LIMIT || b.includes(0) ? null : b.toString('utf8'); }
  finally { closeSync(fd); }
}
export function sourceFiles(root) {
  root = realpathSync(root);
  const files = [], skipped = []; let entriesSeen = 0, bytesSeen = 0, budgetHit = false;
  function walk(dir, depth = 0) {
    if (depth > 64 || entriesSeen > 50000 || bytesSeen > 32 * LIMIT) { budgetHit = true; return; }
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      if (++entriesSeen > 50000 || bytesSeen > 32 * LIMIT) { budgetHit = true; return; }
      const file = join(dir, entry.name), rel = relative(root, file);
      if (entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) { if (!EXCLUDED.has(entry.name)) walk(file, depth + 1); continue; }
      if (!entry.isFile() || !(SOURCE.has(extname(file)) || /(?:^|\/)\.env(?:\.|$)/.test(rel)) || /(?:\.d\.[cm]?ts|\.(?:test|spec)\.[^.]+)$/.test(file)) continue;
      if (files.length >= 10000) { skipped.push('source-file budget exceeded'); return; }
      try { const text = readBounded(file, root); if (text === null) skipped.push(`binary/oversized/unreadable source: ${rel}`); else { bytesSeen += Buffer.byteLength(text); files.push({ rel, text }); } }
      catch { skipped.push(`unreadable source: ${rel}`); }
    }
  }
  walk(root); if (budgetHit) skipped.push('source traversal budget exceeded; scan is incomplete'); return { files, skipped };
}
// Replace comments with spaces, preserving lines and strings. Braces inside strings
// do not close handlers; unlike regex slicing, a sibling guard cannot bleed in.
export function lexical(text) {
  const chars = text.split(''); let quote = '', escape = false, line = false, block = false;
  const structure = text.split('');
  for (let i=0; i<chars.length; i++) {
    const c=chars[i], n=chars[i+1];
    if (line) { if(c==='\n') line=false; else chars[i]=structure[i]=' '; continue; }
    if (block) { if(c==='*'&&n==='/') { chars[i]=structure[i]=chars[i+1]=structure[i+1]=' '; i++; block=false; } else if(c!=='\n') chars[i]=structure[i]=' '; continue; }
    if (quote) { if(c!=='\n') structure[i]=' '; if(escape) escape=false; else if(c==='\\') escape=true; else if(c===quote) quote=''; continue; }
    if(c==='"'||c==="'"||c==='`') { quote=c; structure[i]=' '; continue; }
    if(c==='/'&&n==='/') { chars[i]=structure[i]=chars[i+1]=structure[i+1]=' '; i++; line=true; }
    else if(c==='/'&&n==='*') { chars[i]=structure[i]=chars[i+1]=structure[i+1]=' '; i++; block=true; }
  }
  return { code: chars.join(''), structure: structure.join('') };
}
const functionCache = new Map();
export function functions(text) {
  if (functionCache.has(text)) return functionCache.get(text);
  const { code, structure }=lexical(text), found=[];
  const starts=/(?:\b(?:export\s+)?(?:async\s+)?function\s+[\w$]+\s*\([^)]*\)[^{]*|\b(?:const|let)\s+[\w$]+\s*=\s*(?:async\s*)?(?:\([^)]*\)|[\w$]+)\s*=>\s*|\b(?:app|router)\.(?:get|post|put|patch|delete)\s*\([^\n]*?=>\s*)\{/g;
  for(const m of code.matchAll(starts)) {
    const open=m.index+m[0].length-1; let depth=1,end=open+1;
    while(end<structure.length&&depth) { if(structure[end]==='{')depth++; else if(structure[end]==='}')depth--; end++; }
    if(depth===0) found.push({ text: code.slice(m.index,end), at:m.index, header:m[0] });
  }
  functionCache.set(text, found); return found;
}
const write = /\.(?:create|update|upsert|delete|insert|insertInto|updateMany|deleteMany)\s*\(/;
const route = b => /\b(?:GET|POST|PUT|PATCH|DELETE)\b|\b(?:app|router)\.(?:get|post|put|patch|delete)\s*\(/.test(b.header);
const mutation = b => route(b)&&/\b(?:POST|PUT|PATCH|DELETE)\b|\.(?:post|put|patch|delete)\s*\(/.test(b.header);
const guard = /\b(?:authorize|assertRole|requireRole|requireAdmin|checkPermission|requirePermission|assertOwner|verifyOwnership)\s*\(|(?:session|user)\.role\s*(?:!==|===|!=|==)|(?:ownerId|tenantId|userId)\s*:\s*(?:session|user|auth)\b/;
const bodyVars = t => [...t.matchAll(/(?:const|let)\s+([\w$]+)\s*=\s*(?:await\s+)?(?:req|request)\.(?:json\(\)|body\b)/g)].map(m=>m[1]);
const input = t => /(?:req|request)\.(?:json\(|body\b|query\b)|(?:params|searchParams)\./.test(t);
const authScope = /(?:tenantId|tenant_id|ownerId|owner_id|userId|user_id)\s*:\s*(?:session|user|auth)\b|\b(?:authorize|assertOwner|verifyOwnership)\s*\(/;
const perFunction = (file, predicate) => functions(file.text).filter(predicate).map(b=>b.at);
export const rules = {
 'js-ts-authz': f => perFunction(f,b=>mutation(b)&&/admin|\.user\.(?:update|delete)|\.account\.(?:update|delete)|\.tenant\.(?:update|delete)/i.test(f.rel+' '+b.text)&&write.test(localCode(b))&&!guard.test(localCode(b))),
 'js-ts-idor': f => perFunction(f,b=>route(b)&&input(localCode(b))&&/\.(?:order|invoice|account|customer|user|tenant)\.find(?:Unique|First)\s*\([\s\S]*?\bid\s*:\s*(?:params\.|\w+Id\b|id\b)/.test(b.text)&&!authScope.test(localCode(b))&&!guard.test(localCode(b))),
 'js-ts-mass-assignment': f => perFunction(f,b=>{ const vars=bodyVars(b.text); return write.test(localCode(b))&&vars.some(v=>new RegExp('(?:data\\s*:\\s*'+v+'\\b|\\.\\.\\.\\s*'+v+'\\b)').test(b.text)); }),
 'tenant-resolver-default': f => perFunction(f,b=>/resolve.*(?:Tenant|Store)|(?:tenant|store).*resolve/i.test(b.header)&&/(?:\?\?|\|\|)\s*(?:await\s+)?[\w$.]+\.(?:findFirst|first)\s*\(|(?:\?\?|\|\|)\s*(?:tenants|stores)\s*\[\s*0\s*\]/.test(localCode(b))),
 'session-cookie-flags': f => perFunction(f,b=>cookieCalls(b.text).some(call=>/(?:session|auth|token)/i.test(call)&&!(/httpOnly\s*:\s*true/.test(withoutLiteralText(call))&&/secure\s*:\s*true/.test(withoutLiteralText(call))&&/sameSite\s*:\s*['"](?:lax|strict|none)['"]/.test(call)))),
 'csrf': f => perFunction(f,b=>mutation(b)&&write.test(localCode(b))&&/(?:cookies|session|getServerSession|auth\s*\()/.test(localCode(b))&&!/(?:verifyCsrf|validateCsrf|assertOrigin|checkOrigin|sameOrigin)\s*\(|(?:origin|csrfToken)\s*(?:!==|===|!=|==)/.test(localCode(b))),
 'get-consumes-credential': f => perFunction(f,b=>route(b)&&/\bGET\b|\.get\s*\(/.test(b.header)&&/(?:consumeToken|consumeMagicLink|exchangeCodeForSession|createSession|signInWithOtp)\s*\(|(?:token|magicLink)\.(?:delete|update)\s*\(/.test(b.text)),
 'password-reset-flow': f => perFunction(f,b=>/resetPassword|passwordReset/i.test(b.header)&&/(?:password|passwordHash)\s*:/.test(localCode(b))&&!(/(?:expiresAt|expiry|expiration)\s*(?:<|<=|>|>=)|(?:expiresAt|expiry|expiration)\s*:\s*\{\s*(?:gt|gte)/.test(localCode(b))&&/(?:token|resetToken)\.(?:delete|deleteMany)\s*\(|usedAt\s*:\s*(?:new Date|Date\.now)/.test(localCode(b)))),
 'edge-input-validation': f => perFunction(f,b=>mutation(b)&&/(?:req|request)\.json\s*\(/.test(b.text)&&write.test(localCode(b))&&!validatesInput(b)),
 'webhook-signature': f => perFunction(f,b=>mutation(b)&&/webhook/i.test(f.rel+' '+b.header)&&input(localCode(b))&&!/(?:constructEvent|verifyWebhook|verifySignature|validateEvent|validateWebhook|verifyEvent)\s*\(/.test(localCode(b))),
 'idempotency': f => perFunction(f,b=>mutation(b)&&/webhook|payment/i.test(f.rel+' '+b.header)&&write.test(localCode(b))&&!/(?:deduplicate|claimEvent)\s*\(|(?:idempotencyKey|idempotency_key)\s*[:=]|\.(?:processedEvent|processedEvents)\.(?:create|upsert|findUnique)\s*\(|onConflictDoNothing\s*\(/.test(localCode(b))),
 'ssrf': f => perFunction(f,b=>{ const t=b.text, vars=bodyVars(t); const direct=/\bfetch\s*\(\s*(?:(?:req|request)\.(?:body|query)|(?:params|searchParams)\.)/.test(t); const aliases=[...t.matchAll(/(?:const|let)\s+([\w$]+)\s*=\s*(?:req|request)\.(?:body|query)\.[\w$]+/g)].map(m=>m[1]); return (direct||vars.some(v=>new RegExp('fetch\\s*\\(\\s*'+v+'\\.').test(t))||aliases.some(v=>new RegExp('fetch\\s*\\(\\s*'+v+'\\b').test(t)))&&!/(?:assertPublicUrl|validateOutboundUrl|assertAllowedHost|allowlistedFetch)\s*\(/.test(t); }),
 'queue-enqueue-fail-fast': f => perFunction(f,b=>/status\s*:\s*['"]queued['"]/.test(b.text)&&unhandledEnqueue(b.text)),
 'js-ts-sqli': f => perFunction(f,b=>/\$(?:queryRawUnsafe|executeRawUnsafe)\s*\(\s*(?:`[^`]*\$\{|[^\n;]*\+)|\.(?:query|execute)\s*\(\s*(?:`(?:SELECT|UPDATE|DELETE|INSERT)[^`]*\$\{|['"](?:SELECT|UPDATE|DELETE|INSERT)[^\n;]*\+)/i.test(b.text)),
 'fk-cascade': f => extname(f.rel)==='.sql'?[...f.text.matchAll(/(?:FOREIGN\s+KEY\s*\([^)]*\)\s*|\b[\w"]+\s+[\w()]+\s+)REFERENCES\s+[\w".]+(?:\s*\([^)]*\))?(?:\s+ON\s+DELETE\s+(?:NO\s+ACTION|RESTRICT))?(?=\s*[,;)\n])/gi)].filter(m=>! /ON\s+DELETE\s+(?:CASCADE|SET\s+NULL|SET\s+DEFAULT)/i.test(m[0])).map(m=>m.index):extname(f.rel)==='.prisma'?[...f.text.matchAll(/@relation\([^\n]*references\s*:[^\n]*\)/g)].filter(m=>! /onDelete\s*:\s*(?:Cascade|SetNull|SetDefault)/.test(m[0])).map(m=>m.index):[],
 'missing-index': (f,all) => extname(f.rel)==='.prisma'?prismaMissingIndexes(f.text):extname(f.rel)==='.sql'?sqlMissingIndexes(f.text,all):[],
 'unbounded-select': f => /\.[cm]?[jt]sx?$/.test(f.rel)? perFunction(f,b=>[...b.text.matchAll(/\.findMany\s*\(([^;]*?)\)\s*(?:;|\n|$)/g)].some(m=>! /\b(?:take|limit|cursor)\s*:/.test(m[1]))):extname(f.rel)==='.sql'?[...f.text.matchAll(/SELECT\s+\*[\s\S]*?(?:;|$)/gi)].filter(m=>! /\bLIMIT\b/i.test(m[0])).map(m=>m.index):[],
 'client-xss': f => /\.(?:tsx|jsx|js|ts|html|vue|svelte)$/.test(f.rel)?xssCandidates(f.text):[],
 'public-env-secret': f => [...lexical(f.text).code.matchAll(/(?:NEXT_PUBLIC_|VITE_)[A-Z0-9_]*(?:SECRET|PRIVATE_KEY|PASSWORD|ACCESS_TOKEN|API_KEY)[A-Z0-9_]*['"]?\s*[:=]\s*(?:(['"`])([\s\S]*?)\1|([^\s;'"`]+))/g)].filter(m=>{if(m[3]&&!/(?:^|\/)\.env(?:\.|$)/.test(f.rel))return false;const value=(m[2]??m[3]??'').trim();return value.length>=8&&!/^(?:example|placeholder|your_|test_|<|\$\{)/i.test(value);}).map(m=>m.index),
 'a11y-basics': f => /\.(?:tsx|jsx|html|vue|svelte)$/.test(f.rel)? a11yMissing(f.text):[],
 'i18n-parity': (f, all) => localeReferences(f, all),
 'pii-in-logs': f => /\.[cm]?[jt]sx?$/.test(f.rel)?[...withoutLiteralText(lexical(f.text).code).matchAll(/(?:console|logger|log)\.(?:log|info|debug|warn|error)\s*\([^;\n]*(?:\b(?:email|phone|password|accessToken|refreshToken|authorization)\b|(?:req|request)\.(?:body|headers))[^;\n]*\)/g)].filter(m=>! /(?:redact|maskPii|sanitizeLog)\s*\(/.test(m[0])).map(m=>m.index):[],
 'erasure-export-endpoints': (f,all)=>/schema\.prisma$/.test(f.rel)&&/\b(?:email|phone)\s+String/.test(f.text)&&!privacyEndpoints(all)?[f.text.search(/\b(?:email|phone)\s+String/)]:[],
 'consent-gate': f => perFunction(f,b=>/(?:analytics|posthog|mixpanel)\.(?:track|capture|identify|init)\s*\(|\bgtag\s*\(/.test(localCode(b))&&!/(?:hasConsent|analyticsConsent|consentGranted|canTrack|requireConsent)\s*\(|(?:consent|analyticsConsent)\s*(?:===|!==|==|!=)|if\s*\(\s*!?(?:consent|analyticsConsent)\s*\)/.test(localCode(b))),
 'cache-invalidation-coverage': (f,all)=>perFunction(f,b=>{if(!write.test(localCode(b))||/\b(?:invalidate|revalidateTag|revalidatePath|clearCache|delCache)\w*\s*\(/.test(localCode(b)))return false; const models=[...b.text.matchAll(/\b(?:prisma|db)\.([\w]+)\.(?:update|upsert|delete|create|updateMany|deleteMany)\s*\(/g)].map(m=>m[1]);return models.some(model=>all.some(other=>functions(other.text).some(read=>/unstable_cache\s*\(|cache\.get\s*\(|redis\.get\s*\(/.test(read.text)&&new RegExp('\\b(?:prisma|db)\\.'+model+'\\.(?:findUnique|findFirst|findMany)\\s*\\(').test(read.text)&&/price|inventory|permission|entitlement|accountStatus/i.test(read.text))));}),
};
function localCode(block){
 let t=block.text;
 // Nested function declarations/arrow assignments are not executed by declaring
 // them. Their guards cannot establish authorization for the enclosing route.
 const ranges=functions(t).filter(inner=>inner.at>0).sort((a,b)=>b.at-a.at);
 for(const inner of ranges)t=t.slice(0,inner.at)+inner.text.replace(/[^\n]/g,' ')+t.slice(inner.at+inner.text.length);
 return withoutLiteralText(t);
}
function balancedEnd(structure,start,open,close){let depth=1,i=start+1;for(;i<structure.length&&depth;i++){if(structure[i]===open)depth++;else if(structure[i]===close)depth--;}return depth?-1:i;}
function cookieCalls(text){const out=[],structure=lexical(text).structure;for(const m of text.matchAll(/(?:response\.cookies|cookies(?:\(\))?)\.set\s*\(|res\.cookie\s*\(/g)){const start=m.index+m[0].length-1,end=balancedEnd(structure,start,'(',')');if(end>0){const args=[],st=structure.slice(start+1,end-1),raw=text.slice(start+1,end-1);let depth=0,begin=0;for(let i=0;i<st.length;i++){if('({['.includes(st[i]))depth++;else if(')}]'.includes(st[i]))depth--;else if(st[i]===','&&depth===0){args.push(raw.slice(begin,i));begin=i+1;}}args.push(raw.slice(begin));out.push((args[0]??'')+'\n'+(args[2]??''));}}return out;}
function validatesInput(block){const t=localCode(block),vars=bodyVars(t);if(/\b(?!JSON\b)[\w$.]+\.(?:safeParse|parse|validate|validateSync)\s*\(\s*(?:await\s+)?(?:req|request)\.json\s*\(/.test(t))return true;return vars.some(v=>new RegExp('\\b(?!JSON\\b)[\\w$.]+\\.(?:safeParse|parse|validate|validateSync)\\s*\\(\\s*'+v+'\\b|\\b(?:validateBody|parseBody|assertValid)\\s*\\(\\s*'+v+'\\b').test(t));}
function unhandledEnqueue(text){const structure=lexical(text).structure;const enqueues=[...withoutLiteralText(text).matchAll(/await\s+[\w$.]+\.(?:send|enqueue|add)\s*\(/g)];return enqueues.some(call=>{for(const m of structure.matchAll(/\btry\s*\{/g)){const start=m.index+m[0].length-1,end=balancedEnd(structure,start,'{','}');if(end<0||call.index<start||call.index>=end)continue;const after=structure.slice(end),caught=after.match(/^\s*catch\s*(?:\([^)]*\))?\s*\{/);if(!caught)continue;const cs=end+caught[0].length-1,ce=balancedEnd(structure,cs,'{','}');if(ce>0){const caught=text.slice(cs,ce);if(write.test(withoutLiteralText(caught))&&[...caught.matchAll(/status\s*:\s*['"]failed['"]/g)].some(field=>withoutLiteralText(caught).slice(field.index,field.index+6).trim().startsWith('status')))return false;}}return true;});}
function withoutLiteralText(text){return text.replace(/(['"])(?:\\.|(?!\1).)*?\1/g,m=>m.replace(/[^\n]/g,' ')).replace(/`(?:\\.|[^`])*`/g,m=>{const result=m.replace(/[^\n]/g,' ').split('');for(const expr of m.matchAll(/\$\{([^}]+)\}/g))for(let i=0;i<expr[1].length;i++)result[expr.index+2+i]=expr[1][i];return result.join('');});}
function xssCandidates(text){const out=[];for(const m of lexical(text).code.matchAll(/dangerouslySetInnerHTML\s*=\s*\{\s*\{\s*__html\s*:\s*|\.innerHTML\s*=\s*/g)){
 if(!lexical(text).structure.slice(m.index,m.index+m[0].length).trim())continue;
 const expressionAt=m.index+m[0].length,tail=text.slice(expressionAt,expressionAt+350),expr=tail.match(/^[\w$.]+/)?.[0]??'';
 if(/^(?:DOMPurify\.sanitize|sanitizeHtml)\s*\(/.test(tail))continue;
 if(/^(['"])(?:\\.|(?!\1).)*?\1\s*(?:[};]|$)/.test(tail))continue;
 if(/^`(?:\\.|[^`])*`\s*(?:[};]|$)/.test(tail)&&!/^`[^`]*\$\{/.test(tail))continue;
 const escaped=tail.match(/^JSON\.stringify\([^\n]*\)\.replace\(\/<\/g?,\s*(['"])(.*?)\1\)/);if(escaped&&!/[<]|\$[&`']/.test(escaped[2]))continue;
 if(/^[^;\n?]+\?\s*(['"])(?:\\.|(?!\1).)*?\1\s*:\s*(['"])(?:\\.|(?!\2).)*?\2\s*(?:[};]|$)/.test(tail))continue;
 const owner=functions(text).filter(b=>b.at<=m.index&&b.at+b.text.length>=m.index).sort((a,b)=>b.at-a.at)[0];
 if(expr&&owner&&new RegExp('\\b(?:const|let)\\s+'+expr.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\s*=\\s*(?:await\\s+)?(?:DOMPurify\\.sanitize|sanitizeHtml|trustedHighlightHtml)\\s*\\(').test(owner.text))continue;
 out.push(m.index);
}return out;}
function sqlMissingIndexes(text,all){
 const catalog=all.filter(f=>extname(f.rel)==='.sql').map(f=>f.text).join('\n'),out=[];
 for(const query of text.matchAll(/SELECT\b[^;]*\bFROM\s+([\w]+)([^;]*)(?:;|$)/gi)){
  const table=query[1],schema=catalog.match(new RegExp('CREATE\\s+TABLE\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?'+table+'\\s*\\(([\\s\\S]*?)\\);','i'));
  if(!schema)continue;
  for(const filter of query[2].matchAll(/(?:WHERE|AND|ON)\s+(?:[\w]+\.)?([\w]+)\s*(?:=|>|<|IN\s*\()/gi)){
   const col=filter[1];
   if(!new RegExp('(?:^|,)\\s*'+col+'\\s+','i').test(schema[1]))continue;
   const inline=new RegExp('(?:^|,)\\s*'+col+'\\s+[^,]*?(?:PRIMARY\\s+KEY|UNIQUE)','i').test(schema[1]);
   const indexed=new RegExp('(?:INDEX[^;]*?ON\\s+'+table+'\\s*|(?:PRIMARY\\s+KEY|UNIQUE)\\s*)\\(\\s*'+col+'(?:\\s*[,\\)])','i').test(catalog);
   if(!inline&&!indexed)out.push(query.index+query[0].indexOf(filter[0]));
  }
 }
 return out;
}
function prismaMissingIndexes(text){ const out=[]; for(const m of text.matchAll(/model\s+\w+\s*\{([^}]+)\}/g)){ for(const fld of m[1].matchAll(/^\s*(\w+(?:Id|_id))\s+\w+[^\n]*/gm)){const name=fld[1];if(!/@(?:id|unique)\b/.test(fld[0])&&!new RegExp('@@(?:index|unique|id)\\s*\\(\\s*\\[\\s*'+name+'(?:\\s*[,\\]])').test(m[1]))out.push(m.index+m[0].indexOf(fld[0]));}}return out;}
function markupTags(text){const tags=[],code=lexical(text).code,structure=lexical(text).structure;for(const m of code.matchAll(/<\/?([A-Za-z][\w-]*)\b/g)){if(structure[m.index]!=='<')continue;let depth=0,end=m.index+m[0].length;for(;end<structure.length;end++){if(structure[end]==='{')depth++;else if(structure[end]==='}')depth--;else if(structure[end]==='>'&&depth===0){end++;break;}}tags.push({name:m[1].toLowerCase(),at:m.index,end,text:code.slice(m.index,end),closing:code[m.index+1]==='/'});}return tags;}
function a11yMissing(text){const out=[],code=lexical(text).code,stack=[];for(const m of markupTags(text)){
 if(m.closing){const idx=stack.map(t=>t.name).lastIndexOf(m.name);if(idx>=0)stack.splice(idx);continue;}
 const tag=m.text,hidden=[...stack,m].some(t=>/aria-hidden\s*=\s*['"]true['"]|\bhidden(?:\s|>|=)/.test(t.text));
 if(!hidden&&m.name==='img'&&!/\balt\s*=|\.\.\./.test(tag))out.push(m.at);
 if(!hidden&&m.name==='input'&&!/type\s*=\s*['"](?:hidden|submit|button)['"]|aria-label(?:ledby)?\s*=|\.\.\./.test(tag)){
  const id=tag.match(/\bid\s*=\s*['"]([^'"]+)['"]/),implicit=stack.some(t=>t.name==='label');
  if(!implicit&&(!id||!new RegExp('(?:htmlFor|for)\\s*=\\s*[\'"]'+id[1]+'[\'"]').test(code)))out.push(m.at);
 }
 if(!hidden&&m.name==='button'&&!/aria-label(?:ledby)?\s*=|\.\.\./.test(tag)){const rest=code.slice(m.end),close=rest.indexOf('</button>');if(close>=0&&!rest.slice(0,close).replace(/<[^>]*>/g,'').trim())out.push(m.at);}
 if(!/\/>$/.test(tag)&&!['input','img','br','hr','meta','link','area','base','embed','param','source','track','wbr'].includes(m.name))stack.push(m);
 }return out;}
function localeReferences(file, all) {
 if (!/\.[cm]?[jt]sx?$/.test(file.rel)) return [];
 const { code, structure } = lexical(file.text);
 // A binding applies only within its lexical brace scope, including nested callbacks.
 const scopes = [], stack = [];
 for (let i=0; i<structure.length; i++) {
  if (structure[i]==='{') { const scope={start:i,end:structure.length}; scopes.push(scope); stack.push(scope); }
  if (structure[i]==='}') { const scope=stack.pop(); if(scope) scope.end=i; }
 }
 const bindings=[...code.matchAll(/\b(?:const|let|var)\s+(t|translate)\s*=\s*([^;\n]+)/g)].map(m=>({
  name:m[1],at:m.index,value:m[2],scope:scopes.filter(s=>s.start<m.index&&s.end>m.index).at(-1),
 }));
 return [...code.matchAll(/(?<![\w$.])(t|translate)\s*\(\s*['"]([\w.-]+)['"]\s*\)/g)].filter(m=>{
  const binding=bindings.filter(b=>b.name===m[1]&&b.at<m.index&&(!b.scope||b.scope.end>m.index)).at(-1);
  const parameterScope=functions(file.text).filter(fn=>fn.at<m.index&&fn.at+fn.text.length>m.index&&new RegExp('(?:[(,]\\s*)'+m[1]+'\\s*(?=[:,)=])').test(fn.header)).at(-1);
  if(parameterScope&&(!binding||binding.at<parameterScope.at)) return false;
  let key=m[2];
  if(binding) {
   const hook=binding.value.match(/^(?:await\s+)?(?:useTranslations|useT|getTranslations)\s*\(\s*(['"])([\w.-]*)\1\s*\)/);
   if(hook) key=hook[2] ? hook[2]+'.'+key : key;
   else if(!/^(?:await\s+)?(?:useTranslations|useT|getTranslations)\s*\(\s*\)/.test(binding.value)) return false;
  }
  return missingLocaleKey(key,all);
 }).map(m=>m.index);
}
function localeObjects(all){return all.filter(f=>/(?:locales?|messages?|translations?)\/(?:en|ar)(?:\/|\.)|(?:^|\/)(?:en|ar)\.json$/.test(f.rel)&&extname(f.rel)==='.json');}
const localeCache=new WeakMap();function missingLocaleKey(key,all){let cached=localeCache.get(all);if(!cached){const locales=localeObjects(all);cached={both:locales.some(f=>/(?:^|\/)en(?:\/|\.)/.test(f.rel))&&locales.some(f=>/(?:^|\/)ar(?:\/|\.)/.test(f.rel)),values:locales.map(f=>{try{return {ok:true,value:JSON.parse(f.text)};}catch{return {ok:false};}}),keys:new Map()};localeCache.set(all,cached);}if(!cached.both)return false;if(!cached.keys.has(key))cached.keys.set(key,cached.values.every(item=>{if(!item.ok)return false;let value=item.value;for(const part of key.split('.'))value=value?.[part];return value===undefined;}));return cached.keys.get(key);}
function privacyEndpoints(all){const routes=all.filter(f=>/route\.[jt]s$|routes?\//.test(f.rel));return routes.some(f=>/eras|delete.*account|account.*delete|privacy.*delete/i.test(f.rel+' '+f.text))&&routes.some(f=>/export.*data|data.*export|privacy.*export/i.test(f.rel+' '+f.text));}
export function scan(lens,root,override){functionCache.clear();const {files,skipped}=sourceFiles(root);if(!rules[lens])throw Error('unknown software-layer lens');const findings=[], codeFiles=files.map(f=>({...f,text:lexical(f.text).code}));outer: for(const f of codeFiles){for(const at of (override??rules[lens])(f,codeFiles)){if(findings.length >= 500){skipped.push('coverage incomplete: finding output budget exceeded');break outer;}findings.push({rel:f.rel,line:f.text.slice(0,at).split('\n').length});}}return {findings,skipped,files:files.length};}
function safeEvidence(file,line){const root=realpathSync('.'),text=readBounded(resolve(file),root);if(text===null)return 'source not available';const safe=withoutLiteralText(lexical(text).code).replace(/^.*(?:NEXT_PUBLIC_|VITE_)[A-Z0-9_]*\s*[:=].*$/gm,'<public environment assignment redacted>');return safe.split('\n').slice(Math.max(0,line-5),line+12).map((s,i)=>`${Math.max(1,line-4)+i}: ${s}`).join('\n');}
function isMain(){try{return Boolean(process.argv[1])&&realpathSync(process.argv[1])===fileURLToPath(import.meta.url);}catch{return false;}}
if(isMain()){
 try{if(process.argv[2]==='--evidence'){console.log(safeEvidence(process.argv[3],Number(process.argv[4])));}else{const result=scan(process.argv[2],process.argv[3]);for(const f of result.findings)console.log(`${f.line}\t${Buffer.from(f.rel).toString('base64')}`);for(const reason of result.skipped)console.log(`SKIP\t${Buffer.from(reason).toString('base64')}`);if(!result.files)console.log(`SKIP\t${Buffer.from('no supported product source files').toString('base64')}`);}}
 catch{console.log(`SKIP\t${Buffer.from('software-layer scan failed; no clean claim is possible').toString('base64')}`);}
}
