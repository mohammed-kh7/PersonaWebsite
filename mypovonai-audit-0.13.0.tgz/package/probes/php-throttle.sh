#!/usr/bin/env bash
# php-throttle probe — evidence for rubric/php-throttle.md.
#
# The repo this pack was built against has a hard-coded admin password
# (php-secrets) AND zero rate limiting anywhere on the `web` middleware group:
# `app/Http/Kernel.php`'s `'api'` group carries `throttle:api`, its `'web'`
# group carries nothing, and every business route in the app runs through
# `web` — so that password, plus login, registration, and a team OTP with a
# 10-minute window, are all brute-forceable with no framework-level backoff.
# Two checks, because either alone misses half the picture: the KERNEL check
# (is throttling wired in at all) and the ROUTE check (does a specific
# sensitive endpoint actually inherit it, in its own chain or an enclosing
# group). A route wrapped in a group that already requires a shared admin
# password is left alone here — that surface is php-secrets' problem, and
# flagging every admin-CRUD POST behind the same gate would be exactly the
# noise this pack exists to avoid.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

is_laravel || { skipped "php-throttle" "not a Laravel application (no composer dependency, no routes/ + app/)"; exit 0; }

# --- Kernel check: is throttle wired into the group routes actually use? ----
kernel="$ROOT/app/Http/Kernel.php"
if [ ! -f "$kernel" ]; then
  skipped "php-throttle" "no app/Http/Kernel.php -- likely bootstrap/app.php-style middleware registration (Laravel 11+ new skeleton); this lens does not parse that form yet"
else
  krel="${kernel#"$ROOT"/}"
  # A group's span: its `'name' => [` line to the next line that is JUST a
  # closing `],` -- these groups are flat lists of ::class/string entries, so
  # the first such line ends it without needing a real brace-matcher.
  group_span() { # $1 = group key (e.g. web, api) -> prints "start end", or nothing
    local key="$1" start end
    start="$(grep -nE "^[[:space:]]*['\"]${key}['\"][[:space:]]*=>[[:space:]]*\[" "$kernel" | head -1 | cut -d: -f1)"
    [ -n "$start" ] || return
    end="$(awk -v s="$start" 'NR>s && $0 ~ /^[[:space:]]*\],?[[:space:]]*$/ {print NR; exit}' "$kernel")"
    [ -n "$end" ] || end="$start"
    printf '%s %s\n' "$start" "$end"
  }
  read -r web_start web_end <<<"$(group_span web)"
  if [ -n "${web_start:-}" ]; then
    web_body="$(sed -n "${web_start},${web_end}p" "$kernel")"
    if ! grep -qi 'throttle' <<<"$web_body"; then
      read -r api_start api_end <<<"$(group_span api)"
      if [ -n "${api_start:-}" ] && grep -qi 'throttle' <<<"$(sed -n "${api_start},${api_end}p" "$kernel")"; then
        loc="${krel}:$((web_end + 1))-$((api_end - 1))"
        msg="the 'web' middleware group carries no throttle: entry (lines ${web_start}-${web_end}), while the sibling 'api' group does ('throttle:api') -- and every route this app actually serves runs through 'web', so nothing on the site is rate-limited"
      else
        loc="${krel}:${web_start}-${web_end}"
        msg="the 'web' middleware group carries no throttle: entry, and no other group in this Kernel defines one either -- nothing on the site is rate-limited"
      fi
      finding "php-throttle" "high" "$loc" "$msg"
      evidence "sed -n '$(num "$web_start"),$(num "$web_end")p' $(qpath "$krel")"
    fi
  else
    skipped "php-throttle" "app/Http/Kernel.php has no \$middlewareGroups['web'] entry to check"
  fi
fi

# --- Route check: a sensitive POST route with no throttle anywhere in reach -
files="$(route_files)"
if [ -z "$files" ]; then
  skipped "php-throttle" "no route files found (routes/*.php, or a *.php file declaring Route::)"
  exit 0
fi

# Admin-moderation actions (publish/disable/mark-read/destroy/…) are gated by
# the admin password already and aren't "accepts public input" in the sense
# this lens cares about; matched on the route's OWN name, not the whole line,
# so a field literally named e.g. "public_comment" can't trip it by accident.
is_admin_verb() { # $1 = route name
  case "$1" in
    *.publish|*.disable|*.read|*.destroy|*'.set-leader'|*.update|*.edit|*.index|*.show) return 0 ;;
    *) return 1 ;;
  esac
}

# The nearest Route::group()/Route::middleware()->group() that still encloses
# line N, found by walking every group-start line before N and keeping the
# LAST one whose own `});` closes at or after N. Sets ENC_HDR (empty = none).
enclosing_group_header() { # $1 = N
  local n="$1" gs gclose
  ENC_HDR=""
  while IFS= read -r gs; do
    [ -n "$gs" ] || continue
    [ "$gs" -lt "$n" ] || continue
    gclose="$(awk -v s="$gs" 'NR>s && /^\}\);[[:space:]]*$/ {print NR; exit}' "$f")"
    [ -n "$gclose" ] || gclose=999999999
    if [ "$gclose" -ge "$n" ]; then
      ENC_HDR="$(sed -n "${gs},$((gs + 2))p" "$f")"
    fi
  done < <(grep -nE 'Route::(group|middleware)\(' "$f" 2>/dev/null | cut -d: -f1)
}

while IFS= read -r f; do
  [ -n "$f" ] || continue
  rel="${f#"$ROOT"/}"

  while IFS= read -r m; do
    ln="${m%%:*}"; text="${m#*:}"
    # Only routes that can receive a POST body: Route::post(...) / ::any(...)
    # / ::match([...,'post',...], ...). A match() listing only put/patch (an
    # UPDATE route) is not "accepts new public input" and is left alone.
    if grep -qE 'Route::match\(' <<<"$text"; then
      grep -qE "\[[^]]*['\"]post['\"]" <<<"$text" || continue
    fi

    name="$(grep -oE "\->name\(['\"][^'\"]+['\"]\)" <<<"$text" | head -1)"
    name_val="${name#*\'}"; [ "$name_val" = "$name" ] && name_val="${name#*\"}"
    name_val="${name_val%\'*}"; name_val="${name_val%\"*}"

    hay="$text $name_val"
    grep -qiE 'login|register|password|reset|contact|comment|subscribe|apply|application' <<<"$hay" || continue
    [ -n "$name_val" ] && is_admin_verb "$name_val" && continue

    # own chain: same line, plus a couple of continuation lines up to ';' --
    # this codebase's route chains are single-line, but a wrapped
    # ->middleware(...) on the next line should still count.
    chain="$(sed -n "${ln},$((ln + 3))p" "$f")"
    grep -qi 'throttle:' <<<"$chain" && continue

    enclosing_group_header "$ln"
    # Gated by the shared admin password already -- that surface belongs to
    # php-secrets, not here; flagging it too would be noise on every
    # admin-CRUD POST in the codebase for a risk that's already covered.
    grep -qi 'admin\.gate' <<<"$ENC_HDR" && continue
    grep -qi 'throttle:' <<<"$ENC_HDR" && continue

    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-160)"
    finding "php-throttle" "high" "$rel:$ln" \
      "a POST route that authenticates or accepts public input has no throttle: middleware in its own chain or any enclosing group: $safe"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <(grep -nE -- 'Route::(post|any|match)\(' "$f" 2>/dev/null)
done <<< "$files"
exit 0
