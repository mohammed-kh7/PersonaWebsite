#!/usr/bin/env bash
# cache-invalidation-coverage: bounded source candidates; see rubric/cache-invalidation-coverage.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "cache-invalidation-coverage" "$rel"; continue; fi
  finding "cache-invalidation-coverage" "high" "$rel:$line" "Writers to a model with visibly cached price/inventory/permission/entitlement/accountStatus reads require local invalidation."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "cache-invalidation-coverage" "$ROOT")
exit 0
