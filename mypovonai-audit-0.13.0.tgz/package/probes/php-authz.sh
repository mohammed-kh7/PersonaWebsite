#!/usr/bin/env bash
# php-authz probe — an admin/dashboard/manage route reachable with NO
# authentication or authorization middleware, in its own chain or any
# enclosing group.
#
# THIS IS THE FALSE-POSITIVE MINEFIELD (see rubric/php-authz.md). A previous
# attempt at this exact check emitted 110 findings on the calibration repo,
# none of them real, because it tracked route groups only by brace depth and
# never noticed that Laravel declares "this route/group has middleware" in
# FOUR different syntaxes:
#   Route::group(['prefix'=>'admin','middleware'=>['auth']], function () {});
#   Route::middleware(['auth'])->group(function () { ... });
#   Route::get('/x', ...)->middleware('auth');
#   Route::prefix('admin')->middleware('auth')->group(function () { ... });
# plus a controller whose __construct() calls $this->middleware(...), which
# covers every route on that controller regardless of what routes/web.php says.
#
# WHY A ROUTE-PARAMETER BRACE ({id}) DOES NOT BREAK THIS: `/company/{id}/jobs`
# contains one balanced `{`/`}` pair inside the URI STRING, not PHP syntax. The
# brace-counting below only cares about counts balancing back to zero, so a
# matched pair from a route parameter is invisible to it -- it neither opens
# nor leaves a level open. An inline closure ROUTE HANDLER (as opposed to a
# group callback) is told apart from a group by one thing only: whether the
# buffered statement contains "group(" at all. A handler closure's own braces
# are then just more opaque text to balance, never a group boundary, because
# the whole point of a handler closure is that it does not declare more routes.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_laravel; then
  skipped "php-authz" "not a Laravel application (no composer dependency, no routes/ + app/)"
  exit 0
fi

rfiles="$(route_files)"
[ -n "$rfiles" ] || { skipped "php-authz" "no route files found under routes/"; exit 0; }

# --- controller-level coverage: __construct() -> $this->middleware(...) ----
# A controller that gates itself in its constructor covers every route that
# points at it, no matter what routes/web.php says. Scoped to the text between
# `function __construct` and the NEXT `function ` in the same file -- good
# enough without a real PHP parser, and a miss here only makes the probe
# NOISIER, never quieter, so it fails toward the safe side of this check.
covered_ctrls="|"
while IFS= read -r f; do
  case "$f" in *Controller.php) ;; *) continue ;; esac
  ctor_line="$(grep -n 'function[[:space:]]*__construct' "$f" 2>/dev/null | head -1 | cut -d: -f1)"
  [ -n "$ctor_line" ] || continue
  next_line="$(awk -v s="$ctor_line" 'NR>s && /function[[:space:]]+[A-Za-z_]+[[:space:]]*\(/{print NR; exit}' "$f")"
  [ -n "$next_line" ] || next_line=999999
  if awk -v s="$ctor_line" -v e="$next_line" 'NR>s && NR<e && /\$this->middleware\(/{f=1} END{exit !f}' "$f"; then
    covered_ctrls="${covered_ctrls}$(basename "$f" .php)|"
  fi
done <<< "$(php_files)"

# --- the state machine over each route file -------------------------------
# One awk pass per file. It buffers whatever follows a `Route::` line until
# the statement is provably complete:
#   - a GROUP header (the buffer contains "Route::group(" or "->group(")
#     ends at its FIRST `{` -- that brace IS the group boundary, so the
#     header (everything before it) is all that is needed to decide whether
#     the group carries `middleware`.
#   - anything else (a plain route, including one with an inline closure
#     handler) is complete once every `{` it opened has a matching `}` AND a
#     `;` follows.
# Coverage is inherited down the group stack (OR'd, never reset), matching
# "in its own chain OR in any enclosing group." Written to a heredoc (quoted
# delimiter, so bash performs zero expansion on it) because the program is
# full of literal single quotes that would otherwise end a `awk '...'` string.
read -r -d '' AUTHZ_AWK <<'AWK_PROG'
function first_string(s,   r1s,r1l,r2s,r2l) {
  r1s = 0; r2s = 0
  if (match(s, /'[^']*'/)) { r1s = RSTART; r1l = RLENGTH }
  if (match(s, /"[^"]*"/)) { r2s = RSTART; r2l = RLENGTH }
  if (r1s > 0 && (r2s == 0 || r1s < r2s)) return substr(s, r1s+1, r1l-2)
  if (r2s > 0) return substr(s, r2s+1, r2l-2)
  return ""
}
function route_verb(b,   s) {
  if (match(b, /Route::[A-Za-z]+\(/)) {
    s = substr(b, RSTART, RLENGTH)
    sub(/^Route::/, "", s); sub(/\($/, "", s)
    return tolower(s)
  }
  return ""
}
function uri_from_buf(b, verb,   idx, rest) {
  if (verb == "match") {
    idx = index(b, "]")
    rest = (idx > 0) ? substr(b, idx+1) : b
    return first_string(rest)
  }
  idx = index(b, "(")
  rest = (idx > 0) ? substr(b, idx+1) : b
  return first_string(rest)
}
function controller_from_buf(b,   s, n, parts, n2, parts2) {
  if (match(b, /[A-Za-z_\\]+::class/)) {
    s = substr(b, RSTART, RLENGTH)
    sub(/::class$/, "", s)
    n = split(s, parts, "\\\\")
    return parts[n]
  }
  if (match(b, /'[A-Za-z0-9_\\]+@[A-Za-z0-9_]+'/)) {
    s = substr(b, RSTART+1, RLENGTH-2)
    n = split(s, parts, "@")
    n2 = split(parts[1], parts2, "\\\\")
    return parts2[n2]
  }
  return ""
}
function action_from_buf(b,   idx, s, arr) {
  idx = index(b, "::class")
  if (idx > 0) return first_string(substr(b, idx))
  if (match(b, /'[A-Za-z0-9_\\]+@[A-Za-z0-9_]+'/)) {
    s = substr(b, RSTART+1, RLENGTH-2)
    split(s, arr, "@")
    return arr[2]
  }
  return ""
}
function group_prefix(h,   s) {
  if (match(h, /'prefix'[ \t]*=>[ \t]*'[^']*'/)) {
    s = substr(h, RSTART, RLENGTH); match(s, /'[^']*'$/)
    return substr(s, RSTART+1, RLENGTH-2)
  }
  if (match(h, /->prefix\([ \t]*'[^']*'/)) {
    s = substr(h, RSTART, RLENGTH); match(s, /'[^']*'$/)
    return substr(s, RSTART+1, RLENGTH-2)
  }
  return ""
}
function is_priv(t) {
  t = tolower(t)
  return (t ~ /admin|dashboard|manage|moderat|settings|users|delete|destroy|approve|export|impersonate/)
}
function is_boundary(t) {
  t = tolower(t)
  return (t ~ /login|logout|register|sign-in|sign-up|signin|signup/)
}
function count_char(s, c,   n, i) {
  n = 0
  for (i = 1; i <= length(s); i++) if (substr(s, i, 1) == c) n++
  return n
}
function has_mw(h) {
  # Both the fluent-instance form (`->middleware(...)`) and the static-facade
  # form (`Route::middleware(...)->group(...)`) are canonical Laravel syntax
  # for the SAME thing -- missing the second dropped the fluent-group example
  # from the contract (`Route::middleware(['auth'])->group(function () {`)
  # and under-covered every route inside it.
  return (h ~ /(Route::|->)middleware\(/) || (h ~ /'middleware'[ \t]*=>/) || (h ~ /"middleware"[ \t]*=>/)
}
BEGIN { depth = 0; covstack[0] = 0; pkwstack[0] = 0; buffering = 0; buf = "" }
{
  line = $0
  trimmed = line
  sub(/^[ \t]+/, "", trimmed)
  if (buffering == 0) {
    if (trimmed ~ /^Route::/) {
      buf = line; buffering = 1; start_line = NR; end_line = NR
    } else if (trimmed ~ /^\}/) {
      if (depth > 0) depth--
    }
  } else {
    buf = buf "\n" line
    end_line = NR
  }
  if (buffering == 1) {
    has_grp = (buf ~ /Route::group\(/) || (buf ~ /->group\(/)
    n_open = count_char(buf, "{")
    n_close = count_char(buf, "}")
    if (has_grp) {
      if (n_open >= 1) {
        hidx = index(buf, "{")
        header = substr(buf, 1, hidx-1)
        mw = has_mw(header) ? 1 : 0
        pfx = group_prefix(header)
        pkw = is_priv(pfx) ? 1 : 0
        parent_cov = covstack[depth]; parent_pkw = pkwstack[depth]
        depth++
        covstack[depth] = (mw || parent_cov) ? 1 : 0
        pkwstack[depth] = (pkw || parent_pkw) ? 1 : 0
        buf = ""; buffering = 0
      }
    } else {
      if (n_open == n_close && index(buf, ";") > 0) {
        verb = route_verb(buf)
        if (verb ~ /^(get|post|put|patch|delete|any|match|resource|apiresource)$/) {
          uri = uri_from_buf(buf, verb)
          act = action_from_buf(buf)
          ctl = controller_from_buf(buf)
          own_mw = has_mw(buf) ? 1 : 0
          ctl_cov = (ctl != "" && index(ctrls, "|" ctl "|") > 0) ? 1 : 0
          covered = (own_mw || ctl_cov || covstack[depth]) ? 1 : 0
          priv = (is_priv(uri) || is_priv(act) || pkwstack[depth]) ? 1 : 0
          bnd = (is_boundary(uri) || is_boundary(act)) ? 1 : 0
          if (priv && !bnd && !covered) {
            loc = (start_line == end_line) ? start_line : (start_line "-" end_line)
            printf "%s\t%s\t%s\t%s\t%s\n", loc, start_line, verb, uri, act
          }
        }
        buf = ""; buffering = 0
      }
    }
  }
}
AWK_PROG

while IFS= read -r f; do
  [ -n "$f" ] || continue
  rel="${f#"$ROOT"/}"
  out="$(awk -v ctrls="$covered_ctrls" -- "$AUTHZ_AWK" "$f" 2>/dev/null)"
  [ -n "$out" ] || continue
  while IFS=$'\t' read -r loc sline verb uri act; do
    [ -n "$loc" ] || continue
    if [ -n "$act" ]; then
      msg="a privileged route is reachable with no authentication or authorization middleware in its own chain or any enclosing group: Route::${verb}('${uri}', ... '${act}')"
    else
      msg="a privileged route is reachable with no authentication or authorization middleware in its own chain or any enclosing group: Route::${verb}('${uri}', <closure>)"
    fi
    finding "php-authz" "critical" "$rel:$loc" "$msg"
    evidence "sed -n '$(num "$sline")p' $(qpath "$rel")"
    # Grade-0 shape: no `middleware` array key, no `->middleware(`, no
    # enclosing group carries one, and the controller (if any) has no
    # `$this->middleware(...)` in its constructor either. See rubric for the
    # deliberate calls this makes on session-flag gates and the login/logout/
    # register boundary.
  done <<< "$out"
done <<< "$rfiles"
exit 0
