#!/usr/bin/env bash
# agent-secrets-in-config probe — evidence for standard/security.md (secrets live in a
# 600 env file, never in a script/config an agent or a repo can read) as applied to an
# AGENT SETUP. N/A (skipped) on a product repo; gitleaks covers those.
#
# Over agent_files (backup files <glob>.bak*/.orig/.pre-* INCLUDED: a token in a backup is still on disk;
# backups/ dirs scanned unless >2000 files) '*.sh' '*.json' '*.md' '*.mjs' '*.py', one finding per line on the
# FIRST kind that matches (extended regex):
#   telegram   [0-9]{8,10}:AA[A-Za-z0-9_-]{30,}
#   anthropic  sk-ant-[A-Za-z0-9_-]{20,}
#   openai     sk-[A-Za-z0-9]{32,}
#   github     gh[pousr]_[A-Za-z0-9]{30,}
#   shell-default  (TOKEN|SECRET|API_KEY)[A-Z_]*:-[A-Za-z0-9_:-]{20,}   (${VAR:-literal})
# THE MATCH IS NEVER PRINTED: the finding carries kind + line number only, and the
# evidence command redacts every 20+ character token-shaped run.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_agent_setup; then
  skipped "agent-secrets-in-config" "not an agent setup (no CLAUDE.md, .claude/settings.json, settings.json+skills/, or agents/*.md) — product repos are covered by the secret scanner"
  exit 0
fi

KINDS=(
  "telegram|[0-9]{8,10}:AA[A-Za-z0-9_-]{30,}"
  "anthropic|sk-ant-[A-Za-z0-9_-]{20,}"
  "openai|sk-[A-Za-z0-9]{32,}"
  "github|gh[pousr]_[A-Za-z0-9]{30,}"
  "shell-default|(TOKEN|SECRET|API_KEY)[A-Z_]*:-[A-Za-z0-9_:-]{20,}"
)

# ONE grep pass over the (pruned) file list with the five patterns alternated; only files
# that hit are classified per kind. 5 greps x every file was 7 minutes on a real ~/.claude.
ALL=""
for k in "${KINDS[@]}"; do ALL="${ALL:+$ALL|}${k#*|}"; done

while IFS= read -r rel; do
  [ -n "$rel" ] || continue
  f="$ROOT/$rel"
  seen=" "
  for k in "${KINDS[@]}"; do
    kind="${k%%|*}"; pat="${k#*|}"
    # cut keeps ONLY the line number: the matched text never leaves this pipeline.
    for ln in $(grep -nE -e "$pat" "$f" 2>/dev/null | cut -d: -f1); do
      case "$seen" in *" $ln "*) continue ;; esac
      seen="$seen$ln "
      finding "agent-secrets-in-config" "high" "$rel:$ln" "literal secret in agent config: $kind at line $ln — move it to a 600 env file and rotate it"
      evidence "sed -n '$(num "$ln")p' $(qpath "$rel") | sed -E 's/[A-Za-z0-9_:-]{20,}/<redacted>/g'"
    done
  done
done < <(AGENT_FILES_BACKUPS=1 agent_files '*.sh' '*.json' '*.md' '*.mjs' '*.py' \
          | tr '\n' '\0' | (cd "${ROOT%/}" && xargs -0 grep -lE -e "$ALL" -- 2>/dev/null) | sort)

exit 0
