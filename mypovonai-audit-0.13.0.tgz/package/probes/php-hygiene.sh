#!/usr/bin/env bash
# php-hygiene probe — evidence for rubric/php-hygiene.md.
#
# The finding class: no git, so every hand-edit left a timestamped copy of the
# file it changed, sitting in the live webroot/app tree instead of in version
# control history. Calibrated against a real 269-file, ~10 MB instance of
# exactly this, 56 of them inside app/Http/Controllers/ alone — including
# `routes/web.php.bak_*` copies that carry the SAME hard-coded admin password
# php-secrets already flags in the live file (see fixtures/php-secrets). This
# probe reports a COUNT, never one finding per file — the contract is explicit
# that hundreds of individual findings would be as useless as zero.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_php; then
  skipped "php-hygiene" "no PHP source found"
  exit 0
fi

# --- 1. backup/archive files sitting in a deployable path (high) -----------
# Patterns from the contract: *.bak, *.bak2, *_bak_*, *.old, *.orig, *.save,
# *.sql, *.zip, *.tar.gz, backup/, *copy.php. `find -iname '*.tar.gz'` needs
# its own arm because -iname matches the whole basename, not a suffix, and
# .tar.gz is a compound extension.
#
# `*.bak` alone matches ZERO files on the calibration repo: every real
# timestamped backup there is shaped `AdminController.php.bak_20260725_
# applylock` — a suffix AFTER `.bak`, not `.bak` as the literal extension.
# `-iname '*.bak*'` (dot-bak-anything) is the pattern that actually matches
# the hand-edit-backup shape the contract's own ground truth describes;
# `*_bak_*` (underscore-delimited, no dot) is kept alongside it for the other
# naming convention the contract lists, which the calibration repo also has
# a handful of (`User.php.bak_np_20260706`-style names already covered by the
# dot form, plus a few genuinely underscore-only ones).
all_matches="$(find "$ROOT" -type f \
    \( -iname '*.bak*' -o -iname '*_bak_*' \
       -o -iname '*.old' -o -iname '*.orig' -o -iname '*.save' \
       -o -iname '*.sql' -o -iname '*.zip' -o -iname '*.tar.gz' \
       -o -iname '*copy.php' \) \
    -not -path '*/vendor/*' -not -path '*/node_modules/*' -not -path '*/.git/*' \
    2>/dev/null)"

deployable=""
if [ -n "$all_matches" ]; then
  while IFS= read -r f; do
    is_deployable_path "$f" && deployable="$deployable
$f"
  done <<< "$all_matches"
  deployable="${deployable#$'\n'}"
fi

# `backup/`-named directories under a deployable path — counted separately
# from the file-pattern scan above so a directory full of otherwise-ordinary
# filenames (e.g. `backup/2026-07-06/AdminController.php`) is not invisible.
backup_dirs="$(find "$ROOT" -type d -iname 'backup' \
    -not -path '*/vendor/*' -not -path '*/node_modules/*' -not -path '*/.git/*' \
    2>/dev/null)"
backup_dir_count=0
deployable_backup_dirs=""
if [ -n "$backup_dirs" ]; then
  while IFS= read -r d; do
    is_deployable_path "$d" || continue
    backup_dir_count=$((backup_dir_count + 1))
    deployable_backup_dirs="$deployable_backup_dirs
$d"
  done <<< "$backup_dirs"
fi

total=0
[ -n "$deployable" ] && total=$(printf '%s\n' "$deployable" | grep -c .)

if [ "$total" -gt 0 ] || [ "$backup_dir_count" -gt 0 ]; then
  controllers_count=0
  routes_bak_count=0
  examples="(none — only a backup/-named directory was found)"
  size_note=""
  location="$ROOT"
  if [ "$total" -gt 0 ]; then
    controllers_count=$(printf '%s\n' "$deployable" | grep -c '/app/Http/Controllers/' || true)
    routes_bak_count=$(printf '%s\n' "$deployable" | grep -cE '/routes/.*web\.php[._-]*bak' || true)
    # Worst examples: first three matches, relative to ROOT, for a stable,
    # reproducible message (sorting by size needs BSD/GNU-specific `stat`
    # flags this probe would rather not depend on).
    examples="$(printf '%s\n' "$deployable" | head -3 | while IFS= read -r f; do printf '%s\n' "${f#"$ROOT"/}"; done | tr '\n' ';' | sed 's/;/, /g;s/, $//')"
    location="$(printf '%s\n' "$deployable" | head -1 | while IFS= read -r f; do printf '%s\n' "${f#"$ROOT"/}"; done)"
    size_kb="$(printf '%s\n' "$deployable" | while IFS= read -r f; do du -k "$f" 2>/dev/null; done | awk '{s+=$1} END{print s+0}')"
    [ -n "$size_kb" ] && [ "$size_kb" -ge 1024 ] && size_note=" (~$((size_kb / 1024)) MB)"
  fi
  route_note=""
  [ "$routes_bak_count" -gt 0 ] && route_note=" $routes_bak_count of them are routes/web.php backups, which carry the same hard-coded credential as the live file — see php-secrets, and never print their contents."
  dir_note=""
  [ "$backup_dir_count" -gt 0 ] && dir_note=" Plus $backup_dir_count backup/-named director(ies) in a deployable path."
  finding "php-hygiene" "high" "$location" \
    "$total backup/archive file(s) sit in deployable paths$size_note — $controllers_count of them inside app/Http/Controllers/ alone. These are full source snapshots, not paperwork: anything that changed in one has a plaintext diff against the live file sitting next to it in the same deployable tree.$route_note$dir_note Worst examples: $examples"
  evidence "find $(qpath "$ROOT") -type f \\( -iname '*.bak*' -o -iname '*_bak_*' -o -iname '*.old' -o -iname '*.orig' -o -iname '*.save' -o -iname '*.sql' \\) -not -path '*/vendor/*' | wc -l"
fi

# --- 2. a migration physically inside app/Http/Controllers/ (high) ---------
# A migration's namespace/autoload path is database/migrations/ — one sitting
# in the Controllers directory is invisible to `php artisan migrate`, was
# almost certainly copy-pasted there by mistake, and is a landmine for the
# next grep-based refactor or IDE "go to definition".
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  finding "php-hygiene" "high" "$rel" \
    "a migration-shaped file sits inside app/Http/Controllers/ instead of database/migrations/ — it is invisible to 'php artisan migrate' from here and is dead weight in the controllers namespace"
  evidence "ls -la $(qpath "$rel")"
# `find -regex` is NOT portable: BSD find (macOS) reads basic regex, GNU find
# (Linux/CI) defaults to the emacs dialect, and this pattern matched on the
# development machine and NOT on CI -- the probe reported the fixture clean and
# the gate went dead on Linux only. `grep -E` is the same ERE on both.
done < <(find "$ROOT/app/Http/Controllers" -maxdepth 1 -type f -name '*.php' 2>/dev/null \
           | grep -E '/[0-9]{4}_[0-9]{2}_[0-9]{2}_[0-9]{6}_[^/]*\.php$')

# --- 3. a .blade.php template physically inside app/Http/Controllers/ (high)
# Blade views belong under resources/views/; one left in the Controllers
# directory is not autoloaded as a view path and, again, is dead weight most
# tooling (grep, IDE navigation, Composer's classmap) still has to wade
# through.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  finding "php-hygiene" "high" "$rel" \
    "a Blade template sits inside app/Http/Controllers/ instead of resources/views/ — it is not on Laravel's view path from here and is dead weight in the controllers namespace"
  evidence "ls -la $(qpath "$rel")"
done < <(find "$ROOT/app/Http/Controllers" -maxdepth 1 -type f -iname '*.blade.php' 2>/dev/null)

# --- 4. a *Controller.php file physically inside resources/views/ (high) ---
# The mirror case: a stale copy of a controller class sitting inside the
# views tree. It is not autoloaded from there (PSR-4 maps App\ to app/), so
# it is a second, silently-diverging copy of live code that nothing keeps
# in sync.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  finding "php-hygiene" "high" "$rel" \
    "a controller-shaped PHP file sits inside resources/views/ instead of app/Http/Controllers/ — it is not autoloaded from here, so it is a stale, silently-diverging copy of live code"
  evidence "ls -la $(qpath "$rel")"
done < <(find "$ROOT/resources/views" -type f -iname '*Controller.php' 2>/dev/null)

exit 0
