#!/usr/bin/env bash
# deploy-verify probe — evidence for standard/deploy-verify.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

# Find the deploy-target package.json: prefer a workspace app dir, else root.
PKG="$ROOT/package.json"
[ -f "$PKG" ] || PKG="$(product_find --first --maxdepth 3 -name package.json)"
if [ -z "$PKG" ] || [ ! -f "$PKG" ]; then
  skipped "deploy-verify" "no package.json found"
  exit 0
fi

# no-engines-node (high 2/8): without engines.node the lockfile can be
# regenerated against a Node/npm version the deploy target does not run,
# producing "Missing X from lock file" at deploy.
pkg="$(cat "$PKG" 2>/dev/null)"
if ! grep -qE '"engines"' <<<"$pkg" || ! grep -qE '"node"\s*:' <<<"$pkg"; then
  finding "deploy-verify" "high" "${PKG#"$ROOT"/}" "package.json declares no engines.node — the lockfile is not pinned to the deploy target's Node/npm, the classic source of a 'Missing X from lock file' deploy failure (deploy-verify 2/8)"
  evidence "grep -nE '\"engines\"|\"node\"' $(qpath "${PKG#"$ROOT"/}")"
fi

# no-prepush-mirror (medium 7): a pre-push hook should mirror a CI subset so a
# broken push is caught locally, not in CI. ANY real mechanism counts, each judged on its own
# body (a hook in name only is still a finding):
#   .husky/pre-push · .git/hooks/pre-push · a hooks dir (.githooks/, tools/hooks/, ...) that a
#   package.json script / README / docs / Makefile / .git/config points core.hooksPath at ·
#   simple-git-hooks "pre-push" · lefthook pre-push: · .pre-commit-config.yaml with a pre-push stage.
# A hooks dir that nothing installs is NOT a mechanism: it never runs.
PP_LOCS=(); PP_BODIES=()
_pp_add() { PP_LOCS+=("$1"); PP_BODIES+=("$2"); }

[ -f "$ROOT/.husky/pre-push" ] && _pp_add ".husky/pre-push" "$(cat "$ROOT/.husky/pre-push" 2>/dev/null)"
[ -f "$ROOT/.git/hooks/pre-push" ] && _pp_add ".git/hooks/pre-push" "$(cat "$ROOT/.git/hooks/pre-push" 2>/dev/null)"

# core.hooksPath, set by something the repo ships (or by its own .git/config).
hp_srcs=()
for f in "$ROOT/package.json" "$PKG" "$ROOT/Makefile" "$ROOT"/README* "$ROOT"/CONTRIBUTING* "$ROOT"/.github/*.md; do
  [ -f "$f" ] && hp_srcs+=("$f")
done
while IFS= read -r f; do [ -n "$f" ] && hp_srcs+=("$f"); done < <(find "$ROOT/docs" -maxdepth 3 -name '*.md' -type f 2>/dev/null)
hp_dirs=""
if [ "${#hp_srcs[@]}" -gt 0 ]; then
  hp_dirs="$(perl -ne 'while (/core\.hookspath\s*=?\s*["\x27`]?([A-Za-z0-9_.\/-]+)/ig) { print "$1\n" }' "${hp_srcs[@]}" 2>/dev/null)"
fi
[ -f "$ROOT/.git/config" ] && hp_dirs="${hp_dirs}"$'\n'"$(perl -ne 'print "$1\n" if /^\s*hookspath\s*=\s*(\S+)/i' "$ROOT/.git/config" 2>/dev/null)"
while IFS= read -r d; do
  d="${d#./}"; d="${d%/}"
  case "$d" in ''|/*|-*|..|../*|*/..|*/../*) continue ;; esac   # never follow a path out of the repo
  [ -f "$ROOT/$d/pre-push" ] && inside_root "$ROOT/$d/pre-push" || continue
  _pp_add "$d/pre-push" "$(cat "$ROOT/$d/pre-push" 2>/dev/null)"
done < <(printf '%s\n' "$hp_dirs" | sort -u)

# simple-git-hooks: package.json key, or its own config file.
for f in "$ROOT/package.json" "$PKG"; do
  [ -f "$f" ] || continue
  sgh="$(node -e 'try{const h=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"))["simple-git-hooks"];if(h&&typeof h["pre-push"]==="string")process.stdout.write(h["pre-push"])}catch{}' "$f" 2>/dev/null)"
  [ -n "$sgh" ] && _pp_add "${f#"$ROOT"/}" "$sgh"
done
for f in "$ROOT"/.simple-git-hooks.{json,js,cjs,mjs} "$ROOT"/simple-git-hooks.{json,js,cjs,mjs}; do
  [ -f "$f" ] && grep -q 'pre-push' "$f" 2>/dev/null && _pp_add "${f#"$ROOT"/}" "$(grep -h 'pre-push' "$f")"
done
# lefthook: only the pre-push: section.
for f in "$ROOT"/lefthook.yml "$ROOT"/lefthook.yaml "$ROOT"/.lefthook.yml "$ROOT"/.lefthook.yaml "$ROOT"/lefthook-local.yml; do
  [ -f "$f" ] || continue
  lh="$(awk '/^pre-push:/{f=1;print;next} /^[^[:space:]#]/{f=0} f' "$f" 2>/dev/null)"
  [ -n "$lh" ] && _pp_add "${f#"$ROOT"/}" "$lh"
done
# pre-commit framework: a config that declares a pre-push stage / install type. The whole file
# is the body (hook ids and entries), which is looser than the other mechanisms and accepted.
if [ -f "$ROOT/.pre-commit-config.yaml" ] && grep -q 'pre-push' "$ROOT/.pre-commit-config.yaml" 2>/dev/null; then
  _pp_add ".pre-commit-config.yaml" "$(cat "$ROOT/.pre-commit-config.yaml")"
fi

if [ "${#PP_LOCS[@]}" -eq 0 ]; then
  finding "deploy-verify" "medium" "$ROOT" "no pre-push hook (.husky/pre-push, a core.hooksPath hooks dir, simple-git-hooks, lefthook or a pre-commit pre-push stage) — a lockfile-drift / lint / typecheck / unit mirror does not run before the push, so drift is caught only in CI (deploy-verify 7)"
  evidence "ls $(qpath "$ROOT/.husky/pre-push") $(qpath "$ROOT/.git/hooks/pre-push") 2>&1; grep -rn 'core.hooksPath\|simple-git-hooks' $(qpath "$ROOT/package.json") 2>&1; ls $(qpath "$ROOT")/lefthook.y*ml $(qpath "$ROOT")/.pre-commit-config.yaml 2>&1"
else
  # present: does ANY mechanism actually mirror something meaningful?
  pp_ok=0
  for b in "${PP_BODIES[@]}"; do
    grep -qiE 'tsc|typecheck|lint|npm ci|lockfile|prisma generate|vitest|jest|test' <<<"$b" && { pp_ok=1; break; }
  done
  if [ "$pp_ok" = 0 ]; then
    finding "deploy-verify" "medium" "${PP_LOCS[0]}" "pre-push hook exists but runs no typecheck/lint/lockfile/test mirror — it is a hook in name only (deploy-verify 7)"
    evidence "cat $(qpath "${PP_LOCS[0]}")"
  fi
fi

# npm-toolchain-mismatch (high 8): the lockfile is written by one npm and CI's
# `npm ci` runs another. A lock written by a NEWER npm major than the Node the
# workflow installs is rejected with "Missing: X from lock file" (FWB #2524).
# Offline by design: it compares what the repo DECLARES (packageManager /
# engines) against what the workflows PIN (node-version), and runs no network.
WF_DIR="$ROOT/.github/workflows"
ci_majors=""
if [ -d "$WF_DIR" ]; then
  ci_majors="$(grep -hE '^[[:space:]-]*node-version:' "$WF_DIR"/*.yml "$WF_DIR"/*.yaml 2>/dev/null \
    | sed -E 's/.*node-version:[[:space:]]*//' | grep -oE '[0-9]+(\.[0-9x]+)*' | cut -d. -f1 | sort -n | uniq)"
fi
ci_min="$(printf '%s\n' "$ci_majors" | grep -m1 -E '^[0-9]+$' || true)"
if [ -n "$ci_min" ]; then
  # npm that each Node major ships (18 is read as 10: 18.20+; 18.19- ships 9)
  case "$ci_min" in 16) ci_npm=8 ;; 18|20|22) ci_npm=10 ;; 24|25|26) ci_npm=11 ;; *) ci_npm="" ;; esac
  decl_npm="$(grep -oE '"packageManager"[[:space:]]*:[[:space:]]*"npm@[0-9]+' <<<"$pkg" | grep -oE '[0-9]+$' | head -1)"
  [ -z "$decl_npm" ] && decl_npm="$(grep -oE '"npm"[[:space:]]*:[[:space:]]*"[^0-9]*[0-9]+' <<<"$pkg" | grep -oE '[0-9]+$' | head -1)"
  if [ -n "$ci_npm" ] && [ -n "$decl_npm" ] && [ "$decl_npm" -gt "$ci_npm" ]; then
    finding "deploy-verify" "high" "${PKG#"$ROOT"/}" "package.json declares npm $decl_npm but CI installs Node $ci_min, which ships npm $ci_npm — a lockfile written by the newer npm is rejected by CI's 'npm ci' with 'Missing: X from lock file'; pin the workflow to the same npm (setup-node node-version / 'npm i -g npm@$decl_npm') or regenerate the lock with npx npm@$ci_npm (deploy-verify 8)"
    evidence "grep -nE 'packageManager|\"npm\"' $(qpath "${PKG#"$ROOT"/}"); grep -rn node-version .github/workflows"
  fi
  eng_node="$(grep -oE '"node"[[:space:]]*:[[:space:]]*"[^0-9"]*[0-9]+' <<<"$pkg" | grep -oE '[0-9]+$' | head -1)"
  if [ -n "$eng_node" ] && [ "$eng_node" -gt "$ci_min" ]; then
    finding "deploy-verify" "high" "${PKG#"$ROOT"/}" "engines.node requires Node $eng_node but a workflow installs Node $ci_min — the lockfile is generated for one toolchain and installed by another; align the workflow node-version with engines.node (deploy-verify 8)"
    evidence "grep -n '\"node\"' $(qpath "${PKG#"$ROOT"/}"); grep -rn node-version .github/workflows"
  fi
fi

# verification-claim-unlabelled — a PR template with no verdict labels lets "tests pass"
# stand in for "verified in production" (standard/deploy-verify.md #15).
for t in "$ROOT/.github/pull_request_template.md" "$ROOT/.github/PULL_REQUEST_TEMPLATE.md" "$ROOT/docs/pull_request_template.md"; do
  [ -f "$t" ] || continue
  rel="${t#"$ROOT"/}"
  if ! grep -qE 'NOT VERIFIED|INCONCLUSIVE' "$t"; then
    finding "deploy-verify" "low" "$rel" "needs validation: PR template has no verification verdict (VERIFIED / NOT VERIFIED / INCONCLUSIVE) — a green suite is reported as proof about production"
    evidence "grep -nE 'VERIFIED|INCONCLUSIVE' $(qpath "$rel")"
  fi
done

exit 0
