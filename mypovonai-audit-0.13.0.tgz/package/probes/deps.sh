#!/usr/bin/env bash
# deps probe — evidence for standard/deps.md.
# Cheap static checks only: the CI-gate and override criteria read files. The
# live `npm audit` count is expensive and network-bound, so it is emitted as a
# TODO-evidence command for the interpreting agent to run, NOT executed here —
# a probe must stay fast and deterministic (a flaky network audit would make
# the whole engine non-reproducible).
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

PKG="$ROOT/package.json"
if [ ! -f "$PKG" ]; then
  skipped "deps" "no package.json at repo root — not an npm project"
  exit 0
fi

# --- ci-audit-gate: audit step must not be gated at --audit-level=critical ---
WF_DIR="$ROOT/.github/workflows"
if [ -d "$WF_DIR" ]; then
  if grep -rq "npm audit" "$WF_DIR" 2>/dev/null; then
    if grep -rq "audit-level=critical" "$WF_DIR" 2>/dev/null; then
      hit="$(grep -rl 'audit-level=critical' "$WF_DIR" | head -1)"
      finding "deps" "high" "$hit" "CI npm audit gated at --audit-level=critical — high-severity vulns pass the gate"
      evidence "grep -rn 'audit-level=critical' $(qpath "$WF_DIR")"
    fi
  else
    finding "deps" "high" "$WF_DIR" "no 'npm audit' step in any workflow — supply-chain vulns are ungated in CI"
    evidence "grep -rn 'npm audit' $(qpath "$WF_DIR")"
  fi
else
  finding "deps" "high" "$ROOT" "no .github/workflows — dependency audit cannot be CI-gated"
  evidence "ls $(qpath "$ROOT/.github/workflows")"
fi

# --- override-not-downgrade: heuristic for an accepted framework downgrade ----
# A next/react/express pinned BELOW its current major in overrides is the
# fingerprint of `npm audit fix --force` having been accepted.
if grep -q '"overrides"' "$PKG" 2>/dev/null; then
  for fw in next react react-dom express; do
    ov="$(grep -A40 '"overrides"' "$PKG" | grep "\"$fw\"" | head -1)"
    [ -z "$ov" ] && continue
    # flag only if the override pins an EXACT older major with a leading digit 0-9
    if grep -qE "\"$fw\"[[:space:]]*:[[:space:]]*\"[~^]?[0-9]" <<<"$ov"; then
      : # pinned — the agent inspects whether it is a downgrade vs the leaf pin
    fi
  done
fi

# --- audit-clean: the live count is the agent's to run (kept out of the probe)
evidence "cd $(qpath "$ROOT") && npm audit --json | jq '.metadata.vulnerabilities'  # must be all 0"

exit 0
