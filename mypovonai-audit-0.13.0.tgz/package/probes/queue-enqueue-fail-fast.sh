#!/usr/bin/env bash
# queue-enqueue-fail-fast: bounded source candidates; see rubric/queue-enqueue-fail-fast.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "queue-enqueue-fail-fast" "$rel"; continue; fi
  finding "queue-enqueue-fail-fast" "high" "$rel:$line" "Functions that persist queued status and enqueue work require a catch path that marks failed status."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "queue-enqueue-fail-fast" "$ROOT")
exit 0
