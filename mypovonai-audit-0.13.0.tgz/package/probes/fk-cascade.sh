#!/usr/bin/env bash
# fk-cascade: bounded source candidates; see rubric/fk-cascade.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "fk-cascade" "$rel"; continue; fi
  finding "fk-cascade" "high" "$rel:$line" "SQL/Prisma foreign keys require an explicit non-blocking delete action; restrictive actions require human review."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "fk-cascade" "$ROOT")
exit 0
