#!/usr/bin/env bash
# mutation-proof probe — evidence for standard/mutation-proof.md.
#
# "Green is the null result." A test proves a defence only after that defence
# was broken, THAT NAMED test went red, and the file was restored byte-identically.
# Two halves of the lens are mechanically visible:
#   §2/§6  a substring/prefix assertion on a security-relevant value — the
#          assertion is satisfied by the superstring that breaks you
#          (`Path=/course` satisfies toContain("Path=/") and kills __Host-)
#   §4/§5  defences in the mandatory set exist, with no mutation record anywhere
# Baseline regeneration and belt-and-braces layer isolation are interpreter work:
# a suppression file looks identical whether or not its fingerprints were diffed,
# and two layers enforcing one invariant look exactly like correct redundancy.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

TESTS=(--include='*.test.ts' --include='*.test.tsx' --include='*.spec.ts' --include='*.spec.tsx' --include='*.test.js' --include='*.test.mjs' --exclude-dir=node_modules "${BUILD_EXCL[@]}")

# A comment that QUOTES the bad pattern is not the bad pattern. Calibration
# precedent: a doc comment reading "NO dangerouslySetInnerHTML" was a security
# false positive, and three fixtures have already tripped a probe by naming the
# trigger word. grep -rn emits `path:line:text`, so anchor on the text field.
NOT_COMMENT='^[^:]*:[0-9]+:[[:space:]]*(//|#|\*|/\*)'

emit() { # severity pattern message   (grep -rn output on stdin)

  local sev="$1" pat="$2" msg="$3" line f rest n
  while IFS= read -r line; do
    [ -n "$line" ] || continue
    f="${line%%:*}"; rest="${line#*:}"; n="${rest%%:*}"
    finding "mutation-proof" "$sev" "${f#"$ROOT"/}:$n" "$msg"
    evidence "grep -nE '$pat' $(qpath "$f")"
  done
}

# --- whole-value-assert (critical, §2/§6) ---------------------------------
# Restricted to values where a superstring is a live vulnerability: cookie
# attributes, security headers, auth schemes. A substring assert elsewhere is
# style; here it is the defect that shipped `Path=/course` under a green check.
SEC_TOKEN='Path=|__Host-|__Secure-|HttpOnly|SameSite|Content-Security-Policy|Strict-Transport-Security|X-Frame-Options|Set-Cookie|Bearer |Authorization:'
P_SUBSTR="(toContain|toMatch|toHaveBeenCalledWith)\\([^)]*($SEC_TOKEN)"
grep -rnE "$P_SUBSTR" "${TESTS[@]}" "$ROOT" 2>/dev/null | grep -vE "$NOT_COMMENT" | head -25 \
  | emit "critical" "$P_SUBSTR" "a security-relevant value is asserted by SUBSTRING rather than whole — a substring assertion is satisfied by the superstring that breaks you: toContain(\"Path=/\") passes on \"Path=/course\", which breaks the __Host- prefix and kills login in production; assert the exact value (toBe) or an anchored regex (mutation-proof 2)"

P_INCLUDES="\\.includes\\([[:space:]]*[\"'\`][^\"'\`]*($SEC_TOKEN)"
grep -rnE "$P_INCLUDES" "${TESTS[@]}" "$ROOT" 2>/dev/null | grep -vE "$NOT_COMMENT" | head -25 \
  | emit "critical" "$P_INCLUDES" "a security-relevant value is asserted with .includes() rather than an exact/anchored match — the superstring that breaks the defence still satisfies the assertion (mutation-proof 2)"

# --- mutation-record (high, §4/§5) ----------------------------------------
# §5 names where the record is mandatory. Count those test files NUL-safely,
# then look for the §4 table anywhere a record could live.
# CALIBRATED (da-gusto, 2026-09-02): bare `export` matched a menu app's
# `feedback-export.test.ts`. 5 means GDPR erasure/export ENDPOINTS, not any
# CSV writer, so the token is narrowed to the data-subject forms.
MANDATORY='auth|session|entitl|paywall|rls|tenant|isolation|money|payment|checkout|refund|consent|eras(e|ure)|gdpr|data-export|secret|gitleaks|permission'
ntests=0
first_test=""
while IFS= read -r -d '' t; do
  rel="${t#"$ROOT"/}"
  if grep -qiE "$MANDATORY" <<<"$rel"; then
    ntests=$((ntests + 1))
    [ -n "$first_test" ] || first_test="$rel"
  fi
done < <(build_find --print0 -type f \( -name '*.test.ts' -o -name '*.test.tsx' -o -name '*.spec.ts' -o -name '*.test.js' -o -name '*.test.mjs' \))

if [ "$ntests" -eq 0 ]; then
  skipped "mutation-proof" "no test file matching the mandatory set (authn/session, entitlement/paywall, RLS/tenant, money, secret and dependency gates, consent, erasure/export — mutation-proof 5) — the record is mandatory only there; elsewhere the standard recommends but does not grade it"
else
  P_RECORD='[Mm]utation applied|mutation-verif|mutation verif|[Tt]est that went red|went red \(|[Nn]egative control'
  if ! grep -rqE "$P_RECORD" --include='*.md' --exclude-dir=node_modules "${BUILD_EXCL[@]}" "$ROOT" 2>/dev/null; then
    finding "mutation-proof" "high" "$first_test" "the repo has $ntests test file(s) covering defences where the mutation record is MANDATORY (mutation-proof 5) but carries no record anywhere: no mutation, no named test that went red, no restore checksum. 'N tests added, all passing' proves the outcome held, not which reason produced it — seven session tests once passed against UNFIXED code because a cookie rename made every case 401 (mutation-proof 1/4). NOTE: the 4 table is specified to ride in the PR BODY, which is not in the tree — this probe can only see an in-repo record, so the interpreter must check the PRs that shipped these defences before grading 0"
    evidence "grep -rlE '$P_RECORD' --include='*.md' $(qpath "$ROOT") ; echo '(no match = no record)'"
  fi
fi


exit 0
