#!/usr/bin/env bash
# observability probe — evidence for standard/observability.md.
#
# 0.12.4: recognises the Cloudflare Workers equivalents, evidence-based:
#   error monitoring = a monitoring SDK, OR Workers Logs enabled in wrangler AND an
#                      alert sender (fetch to Telegram/Slack/PagerDuty/ALERT webhook)
#                      reachable from an error-level log path;
#   structured logger = pino/winston, OR an in-repo module that emits JSON lines with
#                      a level field and is imported by server routes.
# A repo with neither keeps the original findings.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"
if [ -z "$files" ]; then
  skipped "observability" "no TS/TSX source found"
  exit 0
fi

# Product code only: fixtures, mocks, tests and .d.ts never count as evidence.
SRC=(--include='*.ts' --include='*.tsx' --exclude-dir=node_modules "${BUILD_EXCL[@]}"
     --exclude='*.test.ts' --exclude='*.test.tsx' --exclude='*.spec.ts' "${PRODUCT_EXCL[@]}")

# --- Workers Logs: an uncommented wrangler config that turns observability on ----
wrangler_logs=""
while IFS= read -r w; do
  [ -n "$w" ] || continue
  if grep -vE '^[[:space:]]*(//|#)' "$w" 2>/dev/null | tr -d '\n' \
       | grep -qiE '"?observability"?[[:space:]]*[:=]?[[:space:]]*[{[]*[^}]*"?enabled"?[[:space:]]*[:=][[:space:]]*true'; then
    wrangler_logs="$w"; break
  fi
done < <(cd "$ROOT" 2>/dev/null && find . \( -name 'wrangler.json' -o -name 'wrangler.jsonc' -o -name 'wrangler.toml' \) -type f \
           -not -path '*/node_modules/*' -not -path '*/fixtures/*' "${BUILD_NOTPATH[@]}" 2>/dev/null | while IFS= read -r w; do printf '%s\n' "${ROOT%/}/${w#./}"; done)

# --- Alert sender reachable from an error-level log path ---------------------------
# sender: product code that fetch()es an alerting channel
alert_sender=""; alert_path=""
senders="$(grep -rlE "api\.telegram\.org|hooks\.slack\.com|events\.pagerduty\.com|env\.[A-Z_]*ALERT[A-Z_]*(WEBHOOK|URL)|process\.env\.[A-Z_]*ALERT[A-Z_]*(WEBHOOK|URL)" "$ROOT" "${SRC[@]}" 2>/dev/null \
          | while IFS= read -r s; do grep -lE 'fetch\(' "$s" 2>/dev/null; done)"
while IFS= read -r s; do
  [ -n "$s" ] || continue
  base="$(basename "$s")"; base="${base%.*}"
  # reachable: the sender file itself branches on an error level, or a file that
  # branches on an error level imports the sender module
  if grep -qE "level[[:space:]]*===?[[:space:]]*[\"']error[\"']" "$s" 2>/dev/null; then
    alert_sender="$s"; alert_path="$s"; break
  fi
  while IFS= read -r caller; do
    [ -n "$caller" ] || continue
    if grep -qE "level[[:space:]]*===?[[:space:]]*[\"']error[\"']|[\"']error[\"'][[:space:]]*[,)]|error:[[:space:]]*\(" "$caller" 2>/dev/null; then
      alert_sender="$s"; alert_path="$caller"; break 2
    fi
  done < <(grep -rlE "from ['\"][^'\"]*/${base}['\"]" "$ROOT" "${SRC[@]}" 2>/dev/null)
done <<< "$senders"

# error-monitoring (crit): SDK wired in code, or Workers Logs + a reachable alert path
if grep -rqiE '@sentry/|Sentry\.init|datadog|bugsnag|rollbar' "$ROOT" "${SRC[@]}" 2>/dev/null; then
  :
elif [ -n "$wrangler_logs" ] && [ -n "$alert_sender" ]; then
  :
elif [ -n "$wrangler_logs" ]; then
  finding "observability" "medium" "$wrangler_logs" "Workers Logs enabled but no alerting — no error-level path reaches an alert sender (Telegram/Slack/PagerDuty/ALERT webhook); errors are recorded but nobody is told"
  evidence "grep -rnE 'api.telegram.org|hooks.slack.com|events.pagerduty.com|ALERT.*(WEBHOOK|URL)' $(qpath "$ROOT") --include='*.ts' | grep -vE '/($BUILD_ALT|node_modules)/'; grep -n observability $(qpath "$wrangler_logs")"
else
  finding "observability" "critical" "$ROOT" "no error-monitoring SDK wired in code (Sentry/Datadog/etc.) — production errors go unseen"
  evidence "grep -rniE '@sentry/|Sentry.init|datadog|bugsnag' $(qpath "$ROOT") --include='*.ts' | grep -vE '/($BUILD_ALT|node_modules)/'"
fi

# structured-logger (high): a logger library/module, used by server routes
has_logger=""
if grep -rqiE "from ['\"]pino|from ['\"]winston|createLogger|lib/logger" "$ROOT" "${SRC[@]}" 2>/dev/null; then
  has_logger=1
else
  # in-repo helper: JSON.stringify of an object with a level field + a console sink,
  # imported by a server-side file (routes/api/server/app)
  while IFS= read -r l; do
    grep -qE '\blevel\b' "$l" 2>/dev/null || continue
    grep -qE 'console(\[|\.(log|info|warn|error))' "$l" 2>/dev/null || continue
    base="$(basename "$l")"; base="${base%.*}"
    case "$base" in log|logger|logging) ;; *) continue ;; esac
    if grep -rlE "from ['\"][^'\"]*/${base}['\"]" "$ROOT" "${SRC[@]}" 2>/dev/null \
         | grep -qE '/(routes|api|server|app)/'; then
      has_logger=1; break
    fi
  done < <(grep -rlE 'JSON\.stringify\(' "$ROOT" "${SRC[@]}" 2>/dev/null)
fi
if [ -z "$has_logger" ]; then
  # only meaningful for a server app (has an api/server/routes dir)
  if product_find --first -type d \( -name routes -o -name api -o -name server \) | grep -q .; then
    finding "observability" "high" "$ROOT" "server app with no structured logger (pino/winston or a JSON-line logger module used by routes) — logs are unstructured console output"
    evidence "grep -rniE \"from 'pino'|createLogger|lib/logger|JSON.stringify\" $(qpath "$ROOT") --include='*.ts' | grep -vE '/($BUILD_ALT|node_modules)/'"
  fi
fi

exit 0
