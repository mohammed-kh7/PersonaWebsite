#!/usr/bin/env bash
# agent-context-budget probe — evidence for standard/skill-hygiene.md L2 (what is loaded
# every session is a standing cost; unbounded injection is a standing outage).
# N/A (skipped) on a product repo.
#
#   (1) bytes(CLAUDE.md) + bytes(AGENTS.md) + bytes(memory/MEMORY.md) > 40000
#         -> medium, "needs validation: always-loaded context is <n> bytes (~<n/4> tokens every session)"
#   (2) a script registered under settings.json hooks.SessionStart that
#         cat's a file AND mentions additionalContext AND has no head -c / head -n / cut -c
#         -> high, "SessionStart injects an uncapped file into every session"
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_agent_setup; then
  skipped "agent-context-budget" "not an agent setup (no CLAUDE.md, .claude/settings.json, settings.json+skills/, or agents/*.md) — there is no always-loaded agent context to budget"
  exit 0
fi

total=0; first=""
for f in CLAUDE.md AGENTS.md memory/MEMORY.md; do
  [ -f "$ROOT/$f" ] && inside_root "$ROOT/$f" || continue
  [ -n "$first" ] || first="$f"
  b="$(wc -c < "$ROOT/$f" | tr -d ' ')"
  total=$((total + b))
done
if [ "$total" -gt 40000 ]; then
  finding "agent-context-budget" "medium" "$first" "needs validation: always-loaded context is $total bytes (~$((total / 4)) tokens every session)"
  evidence "wc -c CLAUDE.md AGENTS.md memory/MEMORY.md"
fi

CMDS="$(
  for s in "$ROOT/settings.json" "$ROOT/.claude/settings.json"; do
    [ -f "$s" ] && inside_root "$s" || continue
    node -e '
      try {
        const h = JSON.parse(require("fs").readFileSync(process.argv[1], "utf8")).hooks?.SessionStart ?? [];
        for (const g of h) for (const x of g.hooks ?? []) if (x.command) console.log(x.command);
      } catch {}
    ' "$s" 2>/dev/null
  done
)"
while IFS= read -r cmd; do
  [ -n "$cmd" ] || continue
  read -ra toks <<<"$cmd"   # no glob expansion of config text
  for tok in "${toks[@]}"; do
    case "$tok" in *.sh|*.mjs|*.js|*.py) ;; *) continue ;; esac
    tok="${tok#\"}"; tok="${tok%\"}"
    cand="${tok#\~/}"; cand="${cand#\$HOME/}"; cand="${cand#.claude/}"
    script=""
    # Config-controlled path: accepted only if it RESOLVES inside $ROOT (no ../, no absolute
    # escape, no symlink out). Anything else is dropped without being read or named.
    for c in "$ROOT/$tok" "$ROOT/$cand" "$ROOT/.claude/$cand" "$tok"; do
      [ -f "$c" ] && inside_root "$c" && { script="$c"; break; }
    done
    [ -n "$script" ] || continue
    # The cat must FEED additionalContext: on one line / pipeline, or through a variable
    # assigned from a `cat` with no head/cut cap and later used on an additionalContext line.
    awk '
      /[^A-Za-z]cat[ \t]/ && /additionalContext/ && !/head[ \t]+-[cn]|cut[ \t]+-c/ { found = 1 }
      /^[ \t]*(local[ \t]+)?[A-Za-z_][A-Za-z0-9_]*=.*(\$\(|`)[ \t]*cat[ \t]/ && !/head[ \t]+-[cn]|cut[ \t]+-c/ {
        v = $0; sub(/^[ \t]*(local[ \t]+)?/, "", v); sub(/=.*/, "", v); uncapped[v] = 1
      }
      /additionalContext/ { for (v in uncapped) if (index($0, "$" v) || index($0, "${" v)) found = 1 }
      END { exit found ? 0 : 1 }
    ' "$script" 2>/dev/null || continue
    rel="${script#"$ROOT"/}"
    finding "agent-context-budget" "medium" "$rel" "needs validation: SessionStart injects an uncapped file into every session — cat feeds additionalContext with no head -c / size cap"
    evidence "grep -nE 'cat |additionalContext|head -c' $(qpath "$rel")"
  done
done <<<"$CMDS"

exit 0
