#!/usr/bin/env bash
# data-ui-coverage probe — evidence for standard/data-ui-coverage.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"

# csv-naive-split (medium 9): a CSV import that splits records on a raw newline.
# A quoted field with an embedded newline corrupts every downstream row. The
# record splitter must be quote-aware.
if [ -n "$files" ]; then
  while IFS= read -r f; do
    rel="${f#"$ROOT"/}"
    case "$rel" in *.test.*|*.spec.*|*.d.ts) continue ;; esac
    # only files that actually deal with CSV
    grep -qiE 'csv' "$f" 2>/dev/null || continue
    # match .split( ... \n ) — a raw-newline record split (single-quoted so bash
    # does not mangle the backslashes; \\n = a literal backslash-n in source).
    hit="$(grep -nE '\.split\(.{0,6}\\n' "$f" 2>/dev/null | head -1)"
    [ -z "$hit" ] && continue
    ln="${hit%%:*}"
    finding "data-ui-coverage" "medium" "$rel:$ln" "a CSV import splits records with a naive split(newline) — a quoted field containing a newline corrupts every row after it; use a quote-aware record splitter (data-ui-coverage 9)"
    evidence "grep -nE \"split\\('.n'\\)|csv\" $(qpath "$f")"
    break
  done <<<"$files"
fi

# The model↔UI coverage matrix (every table has a viewer, buttons map to real
# endpoints, no orphan pages, no split-brain editors) needs cross-referencing
# the schema against the frontend — not a single grep. Hand to the interpreter.

exit 0
