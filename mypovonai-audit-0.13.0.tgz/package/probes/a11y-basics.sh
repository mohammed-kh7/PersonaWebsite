#!/usr/bin/env bash
# a11y-basics: bounded source candidates; see rubric/a11y-basics.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "a11y-basics" "$rel"; continue; fi
  finding "a11y-basics" "medium" "$rel:$line" "Literal image/input/button markup requires alt text, associated labels or accessible names."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "a11y-basics" "$ROOT")
exit 0
