#!/usr/bin/env bash
# rls probe — evidence collector for standard/rls.md.
# Emits findings; the lens agent interprets them against the rubric.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! has_prisma; then
  skipped "rls" "no schema.prisma found — not a Prisma repo"
  exit 0
fi

# --- Ambient tenant context detection --------------------------------------
# FWB-style repos wrap ALL HTTP request handling in an AsyncLocalStorage tenant
# context (middleware/tenant-context), so route files never literally mention
# runInTenantContext — flagging them would flood the reference repo with false
# positives. When ambient context exists, only NON-HTTP writers (queue
# functions, crons, scripts, webhooks mounted before the middleware) must name
# their tenant handling explicitly.
AMBIENT=0
if grep -rqlE 'runInTenantContext|tenant-context' "$ROOT" \
     --include='*.ts' --exclude-dir=node_modules "${BUILD_EXCL[@]}" 2>/dev/null; then
  if product_find --first -path '*middleware*tenant-context*' -name '*.ts' | grep -q .; then
    AMBIENT=1
  fi
fi

is_non_http_writer_path() { # paths where ambient middleware does NOT apply
  case "$1" in
    */inngest/*|*/functions/*|*/jobs/*|*/workers/*|*/cron/*|*/scripts/*|*/webhooks/*) return 0 ;;
    *) return 1 ;;
  esac
}

WRITE_RE='prisma\.[a-z][A-Za-z]*\.(create|createMany|update|updateMany|delete|deleteMany|upsert)\('

# --- RLS-scoped model set (ground truth from migrations) --------------------
# Only writes to models whose TABLE is actually under RLS can violate writer
# coverage. Without this, global tables (FWB's `users` — deliberately no RLS)
# produce false positives: calibration flagged scripts/mfa-reset.ts on exactly
# that. Map table→model via schema.prisma @@map; fall back to "flag everything"
# only when there are no migrations to read (e.g. the known-bad fixture).
SCHEMA="$(product_find --first -name schema.prisma)"
MIG_DIR_EARLY="$(product_find --first -type d -name migrations -path '*prisma*')"
MIGS_EXIST=0; [ -n "$MIG_DIR_EARLY" ] && MIGS_EXIST=1
RLS_MODELS=""
if [ -n "$MIG_DIR_EARLY" ]; then
  # ONLY tables under FORCE are in scope for the critical writer-coverage
  # finding. Calibration on FWB (2026-08-13): bulk_ai_jobs is ENABLE-only, and
  # FWB connects as force_app which OWNS the table — under ENABLE (not FORCE)
  # the owner bypasses policy, so an owner-role write with manual `where`
  # scoping is safe by construction. Treating ENABLE == FORCE flagged 7 correct
  # FWB writes as critical. Postgres semantics, not a fudge: FORCE is what makes
  # the owner subject to policy, which is what makes a missing GUC exploitable.
  RLS_TABLES_RAW="$(grep -rhoiE 'ALTER TABLE "?[A-Za-z_]+"? +FORCE +ROW LEVEL SECURITY' "$MIG_DIR_EARLY" 2>/dev/null \
    | sed -E 's/ALTER TABLE "?([A-Za-z_]+)"?.*/\1/I' | sort -u)"
  # A FORCE table whose tenant policy has a HYBRID escape hatch —
  # `current_store_id() IS NULL` (unset GUC = unscoped system path) or a
  # `bypass_rls` clause — DELIBERATELY permits no-GUC async/system writes, which
  # then scope manually via `where: { storeId }`. Verified on FWB 2026-08-13
  # (rls_product_tags_tenant): writes to these tables from Inngest are safe by
  # policy design, NOT violations. Reading FORCE alone (without the predicate)
  # wrongly flagged 4 correct FWB writers — I had even called them REAL before
  # checking the USING clause. A finding is a claim until the predicate confirms
  # it. Only FORCE tables whose policy has NO such escape hatch are in scope.
  RLS_TABLES=""
  for t in $RLS_TABLES_RAW; do
    pol="$(grep -rhiA8 "CREATE POLICY [A-Za-z_]* ON $t\b" "$MIG_DIR_EARLY" 2>/dev/null)"
    if grep -qiE "current_store_id\(\) +IS +NULL|current_setting\('app\.bypass_rls'" <<<"$pol"; then
      continue  # hybrid policy permits system/no-GUC writes by design
    fi
    RLS_TABLES="$RLS_TABLES$t"$'\n'
  done
  RLS_TABLES="$(printf '%s' "$RLS_TABLES" | sed '/^$/d' | sort -u)"
  if [ -n "$RLS_TABLES" ] && [ -n "$SCHEMA" ]; then
    # model<TAB>table pairs: table = @@map value if present, else model name
    RLS_MODELS="$(awk '
      /^model /{model=$2; map=model}
      /@@map\(/{gsub(/.*@@map\("|"\).*/ ,""); map=$0}
      /^}/{if(model!=""){print model "\t" map; model=""}}
    ' "$SCHEMA" | while IFS=$'\t' read -r m t; do
      grep -qix "$t" <<<"$RLS_TABLES" && printf '%s\n' "$m"
    done)"
  fi
fi

# When migrations exist but define NO FORCE-RLS table, the repo has deliberately
# no row-level security. Writer-coverage is then N/A — a single-tenant app (e.g.
# a one-restaurant menu) is correct to have none. Do NOT flag every write: that
# fallback is only for the no-migrations case (fixture/greenfield). Emit a note
# so a MULTI-tenant repo with no RLS isn't silently passed — the interpreter
# judges tenancy. (Calibration: da-gusto, a single-restaurant menu with a schema
# but no RLS, got 7 false criticals from the flag-all fallback. 2026-08-13.)
if [ "$MIGS_EXIST" = "1" ] && [ -z "$RLS_MODELS" ] && [ -n "$SCHEMA" ]; then
  skipped "rls" "migrations exist but no FORCE ROW LEVEL SECURITY table is defined — this repo has no RLS. If it is MULTI-tenant that is a critical gap (no tenant isolation); if single-tenant it is N/A. Interpreter must judge tenancy."
fi

model_is_rls_scoped() { # $1 = client property name (camelCase, lowercase first)
  if [ -z "$RLS_MODELS" ]; then
    # migrations exist but no FORCE-RLS -> no RLS in this repo -> not in scope.
    [ "$MIGS_EXIST" = "1" ] && return 1
    # no migrations at all (fixture/greenfield) -> be conservative, in scope,
    # so the dead-gate fixture still fires.
    return 0
  fi
  local prop="$1"
  local pascal="$(printf '%s' "$prop" | awk '{print toupper(substr($0,1,1)) substr($0,2)}')"
  grep -qx "$pascal" <<<"$RLS_MODELS"
}

while IFS= read -r f; do
  [ -z "$f" ] && continue
  # Exclusions match the path RELATIVE to the target root. Matching the
  # absolute path silently skipped our own fixtures (whose absolute path
  # contains "fixtures/") — a dead gate the probe-fires test nearly missed
  # because a different criterion happened to fire.
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*spec*|*fixture*|*seed*) continue ;; esac
  grep -qE "$WRITE_RE" "$f" 2>/dev/null || continue
  grep -qE 'runInTenantContext|withRlsBypass|withMoneyTx' "$f" 2>/dev/null && continue
  if [ "$AMBIENT" = "1" ] && ! is_non_http_writer_path "$f"; then
    continue # HTTP path — covered by the ambient middleware
  fi
  # Only flag writes to models whose tables are actually under RLS.
  hit=""
  while IFS= read -r line; do
    ln="${line%%:*}"
    prop="$(printf '%s' "$line" | sed -E 's/.*prisma\.([a-z][A-Za-z]*)\..*/\1/')"
    if model_is_rls_scoped "$prop"; then hit="$ln:$prop"; break; fi
  done < <(grep -nE "$WRITE_RE" "$f")
  [ -z "$hit" ] && continue
  finding "rls" "critical" "$f:${hit%%:*}" "write to RLS-scoped model '${hit#*:}' with no runInTenantContext/withRlsBypass (writer class not covered by ambient middleware)"
  evidence "grep -nE 'prisma\\.[a-z][A-Za-z]*\\.(create|update|delete|upsert)\\(' $(qpath "$f")"
done < <(src_files)

# --- FORCE ROW LEVEL SECURITY in migrations --------------------------------
MIG_DIR="$(product_find --first -type d -name migrations -path '*prisma*')"
if [ -n "$MIG_DIR" ]; then
  if ! grep -rq "FORCE ROW LEVEL SECURITY" "$MIG_DIR" 2>/dev/null; then
    finding "rls" "critical" "$MIG_DIR" "no FORCE ROW LEVEL SECURITY in any migration — table owners bypass every policy"
    evidence "grep -r 'FORCE ROW LEVEL SECURITY' $(qpath "$MIG_DIR")"
  fi
else
  finding "rls" "high" "$ROOT" "prisma schema present but no migrations directory — RLS state cannot be verified from the repo"
  evidence "find $(qpath "$ROOT") -type d -name migrations -path '*prisma*' -not -path '*/node_modules/*'"
fi

exit 0
