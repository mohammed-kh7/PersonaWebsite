#!/usr/bin/env bash
# frontend-quality probe — evidence for standard/frontend-quality.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

# ar-mojibake (medium 3): a U+FFFD (EF BF BD) replacement char in an AR-locale
# source means a bad edit pipeline mangled the UTF-8. Matched by RAW BYTES under
# LC_ALL=C — grep -P '\x{FFFD}' is a unicode-codepoint match that depends on the
# ambient locale and flips inside a subprocess; byte matching is deterministic.
FFFD=$'\xef\xbf\xbd'
while IFS= read -r lf; do
  [ -e "$lf" ] || continue
  if LC_ALL=C grep -q "$FFFD" "$lf" 2>/dev/null; then
    finding "frontend-quality" "medium" "${lf#"$ROOT"/}" "AR-locale source contains U+FFFD replacement chars — a bad edit/codegen pipeline corrupted the UTF-8; the strings render as mojibake (frontend-quality 3)"
    evidence "LC_ALL=C grep -na $'\\xef\\xbf\\xbd' $(qpath "${lf#"$ROOT"/}")"
    break
  fi
done < <(build_find \( -name 'ar.json' -o -name 'ar.ts' \); build_find \( -name '*.json' -o -name '*.ts' \) -path '*/ar/*')

# no-axe-in-ci (high 4): an a11y floor should run in CI.
WF_DIR="$ROOT/.github/workflows"
has_next=0
product_find --first --maxdepth 4 -name 'next.config.*' | grep -q . && has_next=1
if [ "$has_next" = "1" ]; then
  if ! grep -rqiE 'axe-core|jest-axe|@axe-core|playwright.*axe' "$ROOT" --include='*.json' --include='*.ts' --exclude-dir=node_modules "${BUILD_EXCL[@]}" 2>/dev/null \
     && ! { [ -d "$WF_DIR" ] && grep -rqi 'axe' "$WF_DIR" 2>/dev/null; }; then
    finding "frontend-quality" "high" "$ROOT" "no a11y floor (axe-core/jest-axe/@axe-core/playwright) wired into the project or CI — accessibility regressions ship unseen (frontend-quality 4)"
    evidence "grep -rli 'axe' $(qpath "$ROOT") --include='*.json' | grep -vE '/($BUILD_ALT|node_modules)/'; grep -rli axe $(qpath "$WF_DIR")"
  fi

  # missing-sitemap-robots (medium 10): storefront needs sitemap + robots.
  has_sitemap=0; has_robots=0
  product_find --first \( -name 'sitemap.ts' -o -name 'sitemap.xml' -o -name 'sitemap.js' \) | grep -q . && has_sitemap=1
  product_find --first \( -name 'robots.ts' -o -name 'robots.txt' -o -name 'robots.js' \) | grep -q . && has_robots=1
  if [ "$has_sitemap" = "0" ] || [ "$has_robots" = "0" ]; then
    miss=""; [ "$has_sitemap" = "0" ] && miss="$miss sitemap"; [ "$has_robots" = "0" ] && miss="$miss robots"
    finding "frontend-quality" "medium" "$ROOT" "storefront missing:$miss — no sitemap/robots means the store is not properly crawlable (frontend-quality 10)"
    evidence "find $(qpath "$ROOT") \\( -name 'sitemap.*' -o -name 'robots.*' \\) -not -path '*/node_modules/*'"
  fi
fi

exit 0
