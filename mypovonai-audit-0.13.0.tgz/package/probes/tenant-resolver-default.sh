#!/usr/bin/env bash
# tenant-resolver-default: bounded source candidates; see rubric/tenant-resolver-default.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "tenant-resolver-default" "$rel"; continue; fi
  finding "tenant-resolver-default" "critical" "$rel:$line" "Tenant/store resolver functions must not fall back to the first row when resolution fails."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "tenant-resolver-default" "$ROOT")
exit 0
