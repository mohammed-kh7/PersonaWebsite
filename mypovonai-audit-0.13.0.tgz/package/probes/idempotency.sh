#!/usr/bin/env bash
# idempotency: bounded source candidates; see rubric/idempotency.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "idempotency" "$rel"; continue; fi
  finding "idempotency" "high" "$rel:$line" "Payment/webhook route writes require an explicit idempotency/deduplication claim in the handler."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "idempotency" "$ROOT")
exit 0
