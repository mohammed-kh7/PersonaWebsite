#!/usr/bin/env bash
# missing-index: bounded source candidates; see rubric/missing-index.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "missing-index" "$rel"; continue; fi
  finding "missing-index" "medium" "$rel:$line" "Prisma scalar Id/_id fields and SQL-filtered columns in known CREATE TABLE schemas require a leading index, unique index, or primary key."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "missing-index" "$ROOT")
exit 0
