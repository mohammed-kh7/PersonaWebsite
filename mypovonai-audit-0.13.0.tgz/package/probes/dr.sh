#!/usr/bin/env bash
# dr probe — evidence for standard/dr.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

# rollback-script (high): scripts/rollback.sh present
if [ ! -f "$ROOT/scripts/rollback.sh" ] && [ -z "$(product_find --first -name rollback.sh)" ]; then
  # only expected for a deployable app (has a schema or a deploy workflow)
  if has_prisma || grep -rqiE 'deploy' "$ROOT/.github/workflows" 2>/dev/null; then
    finding "dr" "high" "$ROOT" "no rollback.sh anywhere — a bad deploy has no scripted revert path"
    evidence "find $(qpath "$ROOT") -name rollback.sh -not -path '*/node_modules/*'"
  fi
fi

# additive-migrations (crit): a DROP in the NEWEST migration with no expand/contract note
MIG_DIR="$(product_find --first -type d -name migrations -path '*prisma*')"
if [ -n "$MIG_DIR" ]; then
  newest="$(ls -d "$MIG_DIR"/*/ 2>/dev/null | sort | tail -1)"
  if [ -n "$newest" ]; then
    sql="$(cat "$newest"migration.sql 2>/dev/null)"
    if grep -qiE 'DROP +COLUMN|DROP +TABLE' <<<"$sql"; then
      if ! grep -qiE 'expand|contract|phase|additive|-- safe' <<<"$sql"; then
        finding "dr" "critical" "${newest#"$ROOT"/}migration.sql" "newest migration DROPs a column/table with no expand/contract note — a destructive migration is a boot-time outage risk"
        evidence "grep -niE 'DROP +(COLUMN|TABLE)|expand|contract' $(qpath "${newest}migration.sql")"
      fi
    fi
  fi
fi

exit 0
