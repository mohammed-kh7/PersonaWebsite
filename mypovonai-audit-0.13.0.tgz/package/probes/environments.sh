#!/usr/bin/env bash
# environments probe — evidence for standard/environments.md.
# SECURITY: this probe reads .env files but NEVER emits their values — a
# DATABASE_URL can hold production credentials. It reports only booleans and
# grep COMMANDS, never the matched connection string.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

# owner-role-local (high 2): a local .env DATABASE_URL connects as the DB OWNER
# role (e.g. neondb_owner / *_owner), so RLS is bypassed locally and never
# exercised. The app should connect as a non-owner app role locally.
found_env=0
for envf in "$ROOT/.env" "$ROOT/.env.local" "$ROOT/.env.development"; do
  [ -f "$envf" ] || continue
  found_env=1
  # match an owner-role user in a postgres URL WITHOUT printing the line
  if grep -qiE 'postgres(ql)?://[a-z0-9_]*_owner[:@]|DATABASE_URL=.*_owner[:@]' "$envf" 2>/dev/null; then
    finding "environments" "high" "${envf#"$ROOT"/}" "local DATABASE_URL connects as a DB *owner* role — RLS is bypassed for the owner, so tenant isolation is never exercised in local dev; use the app role locally (environments 2)"
    evidence "grep -c '_owner' $(qpath "${envf#"$ROOT"/}")  # value withheld — DATABASE_URL may hold prod creds"
    break
  fi
done

# host-isolation (crit 1/3/5): whether local/preview/staging point at prod, and
# QUEUE_PREFIX on a shared broker, are runtime env values — not reliably in the
# repo. Hand to the interpreter explicitly rather than passing silently.
[ "$found_env" = "0" ] && skipped "environments" "no .env/.env.local in the checkout — owner-role check could not run"

exit 0
