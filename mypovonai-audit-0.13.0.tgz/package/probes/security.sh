#!/usr/bin/env bash
# security probe — evidence for standard/security.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"
if [ -z "$files" ]; then
  skipped "security" "no TS/TSX source found"
  exit 0
fi

# --- XSS sinks (crit) — but JSON-LD via an escaping helper is the sanctioned
# exception in FWB (jsonLdScriptContent already escapes </script). Flag only
# dangerouslySetInnerHTML NOT paired with a *json-ld/escape* helper on the line.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*spec*|*fixture*|*.d.ts) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    # A comment mentioning dangerouslySetInnerHTML is not a sink. Calibrated out
    # on FWB (BlogPostClient's "NO dangerouslySetInnerHTML" doc comment)
    # 2026-08-13.
    case "$(sed -E 's/^[[:space:]]*//' <<<"$text")" in '//'*|'*'*|'/*'*) continue ;; esac
    # A <style dangerouslySetInnerHTML> injects CSS, not an HTML body — it is not
    # an XSS body sink. Calibrated out on FWB (theme/style tags) 2026-08-13.
    grep -qiE '<style' <<<"$m" && continue
    # The __html value + its escape helper often sit on the NEXT line(s), not the
    # matched line, so inspect a small window. jsonLdScriptContent / escape /
    # sanitize / dompurify anywhere in the window is the sanctioned route.
    win="$(sed -n "${ln},$((ln+2))p" "$f" 2>/dev/null)"
    grep -qiE 'jsonld|escape|sanitize|dompurify' <<<"$win" && continue
    finding "security" "critical" "$rel:$ln" "dangerouslySetInnerHTML not routed through an escape/sanitize helper"
    evidence "sed -n '$(num "$ln"),$(( $(num "$ln") + 2 ))p' $(qpath "$f")"
  done < <(grep -nE 'dangerouslySetInnerHTML' "$f" 2>/dev/null)
done <<< "$files"

# --- gitleaks config presence (crit) ---------------------------------------
if [ ! -f "$ROOT/.gitleaks.toml" ] && [ ! -f "$ROOT/.gitleaksignore" ]; then
  has_gl_wf=0
  [ -d "$ROOT/.github/workflows" ] && grep -rqi "gitleaks" "$ROOT/.github/workflows" 2>/dev/null && has_gl_wf=1
  if [ "$has_gl_wf" = "0" ]; then
    finding "security" "critical" "$ROOT" "no gitleaks config or workflow — committed secrets are unscanned"
    evidence "ls $(qpath "$ROOT/.gitleaks.toml") $(qpath "$ROOT/.gitleaksignore"); grep -rli gitleaks $(qpath "$ROOT/.github/workflows")"
  fi
fi

# --- CSP / security headers in prod (high) ---------------------------------
if ! grep -rqiE 'content-security-policy|helmet\(|strict-transport-security' "$ROOT" \
     --include='*.ts' --exclude-dir=node_modules "${BUILD_EXCL[@]}" 2>/dev/null; then
  finding "security" "high" "$ROOT" "no CSP/HSTS/helmet reference anywhere — security headers likely unset"
  evidence "grep -rniE 'content-security-policy|helmet\\(|strict-transport-security' $(qpath "$ROOT") --include='*.ts'"
fi

# --- clickjacking / framing headers (crit 14) -------------------------------
# CSP alone (checked above) does not imply frame-ancestors is set — a repo can
# ship a CSP for XSS and still be embeddable in an attacker's iframe.
if ! grep -rqiE 'x-frame-options|frame-ancestors' "$ROOT" \
     --include='*.ts' --include='*.tsx' --exclude-dir=node_modules "${BUILD_EXCL[@]}" 2>/dev/null; then
  finding "security" "critical" "$ROOT" "no X-Frame-Options or Content-Security-Policy frame-ancestors anywhere in source — the app can be embedded in an attacker's iframe and driven with invisible clicks (security 14)"
  evidence "grep -rniE 'x-frame-options|frame-ancestors' $(qpath "$ROOT") --include='*.ts'"
fi

exit 0
