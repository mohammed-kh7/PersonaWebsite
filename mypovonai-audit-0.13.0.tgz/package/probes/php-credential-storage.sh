#!/usr/bin/env bash
# php-credential-storage probe — evidence for rubric/php-credential-storage.md.
#
# Distinct from php-secrets. That lens is about OUR credentials committed to the
# source. This one is about the USERS' credentials: a password the application
# keeps, moves or emits in a form it should never have had.
#
# The finding that made it exist came from the client-audit source, not from a
# person: the daily cycle read a hand-written report and proposed
# `plaintext-password-storage-normalpassword` as a class no lens graded. It was
# right. The repo stores every user's password twice — once hashed, and once in
# a `normalpassword` column written on the line above the hash:
#
#     $data['normalpassword'] = $data['password'];
#     $data['password'] = Hash::make($data['password']);
#
# NOTHING HERE EVER PRINTS A VALUE. Messages and evidence pass through
# redact_secrets: findings and excerpts are uploaded.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

is_laravel || { skipped "php-credential-storage" "not a Laravel application (no composer dependency, no routes/ + app/)"; exit 0; }
files="$(php_files)"
[ -n "$files" ] || { skipped "php-credential-storage" "no PHP source outside vendor/"; exit 0; }

# A column whose NAME says it holds what a hash exists to avoid storing.
PLAIN_COL='normal_?password|plain_?password|password_?plain|raw_?password|clear_?password|password_?text|text_?password|pwd_?plain|passwordclear'

# --- 1. a plaintext credential column (critical) ----------------------------
# ONE finding per column NAME, anchored at the migration that creates it.
# Reporting every mention gave 14 findings for a single column on the
# calibration repo -- the same noise failure that makes 276 backup files one
# finding in php-hygiene. The count and the files are in the message instead.
# Collected through a temp file, not `$(... case ... )`: a case pattern's
# closing `)` inside a command substitution ends the substitution early --
# "syntax error near unexpected token `newline'" -- and the probe emitted
# nothing at all while still exiting 0.
_plain_tmp="$(mktemp "${TMPDIR:-/tmp}/credstore-XXXXXX")"
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*) continue ;; esac
  grep -niE "$PLAIN_COL" "$f" 2>/dev/null | sed "s#^#$rel:#"
done <<< "$files" > "$_plain_tmp"
plain_hits="$(cat "$_plain_tmp")"
rm -f "$_plain_tmp"
if [ -n "$plain_hits" ]; then
  # The distinct column names actually seen, lower-cased.
  cols="$(printf '%s\n' "$plain_hits" | grep -oiE "$PLAIN_COL" | tr 'A-Z' 'a-z' | sort -u)"
  while IFS= read -r col; do
    [ -n "$col" ] || continue
    hits="$(printf '%s\n' "$plain_hits" | grep -i "$col")"
    count="$(printf '%s\n' "$hits" | grep -c .)"
    nfiles="$(printf '%s\n' "$hits" | cut -d: -f1 | sort -u | grep -c .)"
    # Anchor on the migration that CREATES it when there is one: that is the
    # line to delete, and it is where a reader should start.
    anchor="$(printf '%s\n' "$hits" | grep -i 'migration' | head -1 | cut -d: -f1,2)"
    [ -n "$anchor" ] || anchor="$(printf '%s\n' "$hits" | head -1 | cut -d: -f1,2)"
    finding "php-credential-storage" "critical" "$anchor" \
      "the column '$col' stores a PLAINTEXT credential — the one thing hashing exists to prevent. It survives every breach, backup and screen share, and no password reset can un-leak it; users reuse passwords, so the blast radius is other people's accounts. $count reference(s) across $nfiles file(s)."
    evidence "grep -rn -iE $(qpath "$col") --include='*.php' . | grep -v vendor/   # names only; this probe prints no values"
  done <<COLS
$cols
COLS
fi

# --- 2. a password stored without hashing (critical) ------------------------
# `$data['password'] = $request->input('password')` with no Hash::make anywhere
# in the same statement. Checked per LINE, because the hashed and unhashed
# writes sit next to each other and a per-method check would see the hash and
# call the whole method safe.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*|*/database/factories/*|*/database/seeders/*) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    grep -qiE -e 'Hash::make|bcrypt\(|password_hash\(|Hash::check|password_verify|->hash\(' <<<"$text" && continue
    # A validation rule or a form field name is not a write.
    grep -qiE "=>[[:space:]]*'(required|nullable|sometimes|string|confirmed|min|max)" <<<"$text" && continue
    # A LOG line is criterion 4's finding, not this one. Without this the probe
    # called `Log::info(..., ['password' => $data[...]])` a storage-without-
    # hashing defect: the right severity for the wrong reason, and it reported
    # the log line's number under a message about writing to the database.
    grep -qiE -e 'Log::|logger\(|error_log|->log\(' <<<"$text" && continue
    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-120)"
    finding "php-credential-storage" "critical" "$rel:$ln" \
      "a password taken from the request is stored without hashing — every row is readable by anyone who reaches the database, and users reuse passwords: $safe"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel") | sed -E \"s/(=>?[[:space:]]*)'[^']*'/\\1'<redacted>'/g\""
  done < <(grep -nE "\\['?password'?\\][[:space:]]*=[^=]|'password'[[:space:]]*=>" "$f" 2>/dev/null \
            | grep -E '\$request|\$_POST|\$_GET|\$data\[|\$input\[')
done <<< "$files"

# --- 3. a query builder read that bypasses the model's $hidden (high) -------
# `DB::table('users')->get()` returns stdClass rows, so Eloquent's
# $hidden = ['password', …] never applies. That only MATTERS where the rows are
# serialised out: a DB::table() used for an update or a where-clause leaks
# nothing. Requiring a json/serialise call within the next few lines took this
# from 16 findings to the 1 the hand audit named.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    # `-e`, because a pattern starting with `->` is parsed as OPTIONS:
    # `grep: invalid option -- >`, exit 2, and an exclusion that never excludes.
    # Same class as `grep -- PAT path --include=...`, where `--` ends option
    # parsing and every filter silently becomes a filename.
    grep -qE -e '->get\(\[|->select\(|->pluck\(|->value\(|->count\(|->exists\(|->update\(|->delete\(|->insert\(' <<<"$text" && continue
    grep -qE -e '->get\(\)|->first\(\)|->all\(\)' <<<"$text" || continue
    # Does anything nearby turn these rows into a response?
    window="$(sed -n "${ln},$((ln+12))p" "$f" 2>/dev/null)"
    grep -qE 'wantsJson|response\(\)->json|->toJson|json_encode|expectsJson' <<<"$window" || continue
    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-120)"
    finding "php-credential-storage" "high" "$rel:$ln" \
      "a credential table is read with no column list and serialised to JSON a few lines later, so the model's \$hidden never applies — the password hash, the remember token and any plaintext mirror all travel with the response: $safe"
    evidence "sed -n '$(num "$ln"),$(( $(num "$ln") + 12 ))p' $(qpath "$rel")"
  done < <(grep -nE "DB::table\\([[:space:]]*['\"](users|accounts|admins|customers|members|staff)['\"][[:space:]]*\\)" "$f" 2>/dev/null)
done <<< "$files"

# --- 4. a credential written to a log (high) --------------------------------
# Logs are shipped, retained and read by people who were never meant to hold
# the credential. A password in a log line outlives the request by months.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    grep -qiE '<redacted>|\*{3,}|mask|redact' <<<"$text" && continue
    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-120)"
    finding "php-credential-storage" "high" "$rel:$ln" \
      "a credential is written to the log — logs are shipped, retained and read by people who were never meant to hold it: $safe"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")   # value redacted by the probe"
  done < <(grep -nE "(Log::[a-z]+|error_log|logger\\(|->log\\()[^;]*(password|passwd|secret|token|api[_-]?key)" "$f" 2>/dev/null)
done <<< "$files"
exit 0
