#!/usr/bin/env bash
# js-ts-idor: bounded source candidates; see rubric/js-ts-idor.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "js-ts-idor" "$rel"; continue; fi
  finding "js-ts-idor" "high" "$rel:$line" "Private record reads from route input require a session-derived tenant/owner filter or local authorization."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "js-ts-idor" "$ROOT")
exit 0
