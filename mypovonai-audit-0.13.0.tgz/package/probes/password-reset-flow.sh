#!/usr/bin/env bash
# password-reset-flow: bounded source candidates; see rubric/password-reset-flow.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "password-reset-flow" "$rel"; continue; fi
  finding "password-reset-flow" "high" "$rel:$line" "Password-reset functions writing a password require a local expiry check and single-use token consumption."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "password-reset-flow" "$ROOT")
exit 0
