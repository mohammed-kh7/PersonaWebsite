#!/usr/bin/env bash
# event-log probe — evidence for standard/event-log.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! has_prisma; then
  skipped "event-log" "no prisma schema — no money entities to require an event log for"
  exit 0
fi
SCHEMA="$(product_find --first -name schema.prisma)"
schema_body="$(cat "$SCHEMA" 2>/dev/null)"

# money-entity-no-events (crit 1): a money/trust model exists but NO *Event /
# *_events model backs its history.
MONEY_MODELS="$(grep -oiE '^model +(Payment|Order|Subscription|Payout|Invoice|Refund|Transaction|Loyalty[A-Za-z]*)\b' <<<"$schema_body" | awk '{print $2}' | sort -u)"
if [ -n "$MONEY_MODELS" ]; then
  if ! grep -qiE '^model +[A-Za-z]*Event\b|@@map\("[a-z_]*_events"\)' <<<"$schema_body"; then
    first="$(head -1 <<<"$MONEY_MODELS")"
    finding "event-log" "critical" "${SCHEMA#"$ROOT"/}" "money/trust model '$first' exists but no *Event table backs its history — no append-only audit trail for money state (event-log 1)"
    evidence "grep -niE '^model (Payment|Order|Subscription|Payout|Invoice|Refund)|^model .*Event' $(qpath "$SCHEMA")"
  fi
fi

# event-mutated-in-place (crit 4): an event row is UPDATEd or DELETEd — the log
# must be insert-only.
files="$(src_files)"
if [ -n "$files" ]; then
  while IFS= read -r f; do
    rel="${f#"$ROOT"/}"
    # seed/demo/script files wipe-and-repopulate — that is not the prod money
    # path (FWB seed-demo-store re-seeds paymentEvent every run, by design).
    case "$rel" in *.test.*|*.spec.*|*.d.ts|*seed*|*demo*|*/scripts/*|*/prisma/*) continue ;; esac
    hit="$(grep -nE 'prisma\.[a-zA-Z]*[Ee]vent[s]?\.(update|updateMany|delete|deleteMany)\(|(UPDATE|DELETE +FROM) +"?[a-z_]*_events"?' "$f" 2>/dev/null | head -1)"
    [ -z "$hit" ] && continue
    ln="${hit%%:*}"
    finding "event-log" "critical" "$rel:$ln" "an event row is mutated in place (update/delete on an *Event table) — the event log must be append-only (event-log 4)"
    evidence "grep -nE 'Event[s]?\\.(update|delete)|UPDATE .*_events|DELETE FROM .*_events' $(qpath "$f")"
  done <<<"$files"
fi

exit 0
