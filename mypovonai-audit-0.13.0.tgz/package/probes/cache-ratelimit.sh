#!/usr/bin/env bash
# cache-ratelimit probe — evidence for standard/cache-ratelimit.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

GREP_INC=(--include='*.ts' --include='*.tsx' --exclude-dir=node_modules "${BUILD_EXCL[@]}")

# in-process-limiter (crit 1): a rate limiter is present but backed by no shared
# store — meaningless past one replica. Detect a limiter lib, then the absence
# of any Redis-backed store binding.
if grep -rqE "express-rate-limit|rateLimit\(|new RateLimiterMemory|@upstash/ratelimit" "${GREP_INC[@]}" "$ROOT" 2>/dev/null; then
  if ! grep -rqE "rate-limit-redis|RedisStore|RateLimiterRedis|@upstash/ratelimit|store:\s*new Redis|Ratelimit\.slidingWindow|sendCommand" "${GREP_INC[@]}" "$ROOT" 2>/dev/null; then
    hit=$(grep -rlE "express-rate-limit|new RateLimiterMemory" "${GREP_INC[@]}" "$ROOT" 2>/dev/null | head -1)
    finding "cache-ratelimit" "critical" "${hit#"$ROOT"/}" "a rate limiter is configured with no Redis-backed store — an in-process MemoryStore limit is not shared across replicas and is bypassed the moment you scale (cache-ratelimit 1)"
    evidence "grep -rnE 'express-rate-limit|rate-limit-redis|RedisStore|RateLimiterRedis' $(qpath "$ROOT") --include='*.ts'"
  fi
fi

# unbounded-map-cache (medium 6): a module-level Map used as a cache with no
# size bound. Only flag a Map that is clearly a cache (name contains cache) and
# is NOT a BoundedMap/LRU. Conservative to avoid flooding.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  # criterion 6 is about a long-running SERVER process. A Map in a client
  # component / hook (.tsx, */hooks/*, */components/*) lives in the browser tab
  # and is not the same memory-growth concern — exclude it (FWB: SearchAutocomplete
  # + useCurrentStore are client-side and were false positives here).
  case "$rel" in *.test.*|*.spec.*|*.d.ts|*.tsx|*/hooks/*|*/components/*) continue ;; esac
  hit="$(grep -niE 'const [a-z_]*[Cc]ache[a-z_]* *= *new Map' "$f" 2>/dev/null | head -1)"
  [ -z "$hit" ] && continue
  grep -qiE 'BoundedMap|LRU|lru-cache|maxSize|max:' "$f" 2>/dev/null && continue
  ln="${hit%%:*}"
  finding "cache-ratelimit" "medium" "$rel:$ln" "a module-level Map cache with no size bound (BoundedMap/LRU) — unbounded in-memory growth on a long-running process (cache-ratelimit 6)"
  evidence "grep -nE 'Cache *= *new Map|BoundedMap|LRU|maxSize' $(qpath "$f")"
done <<<"$(src_files)"

# redis-open-connection (crit 10): a Redis/Upstash connection string with no
# credentials (redis://host:port, no user:pass@). Infra ACL/network binding
# itself isn't visible in source — this locates the client; the read is
# against the actual instance settings (cache-ratelimit.md §4).
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*spec*|*fixture*|*.d.ts) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    finding "cache-ratelimit" "critical" "$rel:$ln" "a Redis/Upstash connection string with no credentials (redis://host:port, no user:pass@) — the cache holds sessions and tokens, and an open connection is a way to become any user without cracking a single password (cache-ratelimit 10)"
    evidence "sed -n '$(num "$ln")p' $(qpath "$f")"
  done < <(grep -nE "redis://[a-zA-Z0-9_.-]+:[0-9]+" "$f" 2>/dev/null | grep -vE "redis://[^/[:space:]]*:[^/@[:space:]]*@")
done <<<"$(src_files)"

exit 0
