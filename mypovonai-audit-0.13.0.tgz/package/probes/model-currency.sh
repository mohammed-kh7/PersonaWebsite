#!/usr/bin/env bash
# model-currency probe — evidence for standard/model-currency.md.
# Gated on the repo calling a hosted model at all.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

raw="$(grep -rnE '(claude|gpt|gemini|llama|mistral)-[a-z0-9][a-z0-9.-]*' "$ROOT" \
  --include='*.ts' --include='*.tsx' --include='*.js' --include='*.mjs' --include='*.py' \
  --exclude-dir=node_modules "${BUILD_EXCL[@]}" 2>/dev/null || true)"

# Filter on the path RELATIVE to the scanned root, never the absolute one: the
# absolute path carries whatever the staging directory happens to be called, so
# an exclusion written against it silently changes meaning depending on where
# the repo sits. A model id inside a test, a spec or a fixture is INPUT, not
# configuration, and grading it would report the negative controls as defects.
hits=""
while IFS= read -r line; do
  [ -z "$line" ] && continue
  f="${line%%:*}"
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*spec*|*fixture*|*.d.ts) continue ;; esac
  hits="${hits}${line}"$'\n'
done <<< "$raw"
hits="$(printf '%s' "$hits" | grep -c . >/dev/null 2>&1 && printf '%s' "$hits" || true)"

if [ -z "$(printf '%s' "$hits" | tr -d '[:space:]')" ]; then
  skipped "model-currency" "no hosted-model id in source — nothing to keep current"
  exit 0
fi

# model-id-scattered (high 1): one source per product. More than one file
# carrying an id means changing the model is a hunt, and one gets missed.
sources="$(printf '%s\n' "$hits" | grep -c . >/dev/null && printf '%s\n' "$hits" | cut -d: -f1 | sort -u | grep -c . || echo 0)"
if [ "$sources" -gt 1 ]; then
  first="$(printf '%s\n' "$hits" | cut -d: -f1 | sort -u | head -1)"
  finding "model-currency" "high" "${first#"$ROOT"/}" "model ids appear in $sources separate files — they must resolve from one constants module, or the next model change will miss one of them (model-currency 1)"
  evidence "grep -rnE '(claude|gpt|gemini)-[a-z0-9.-]+' . --include='*.ts' --include='*.mjs' | grep -vE '/($BUILD_ALT|node_modules)/' | cut -d: -f1 | sort -u"
fi

# dated-version-pin (medium 2): an id ending in a date stamp is pinned to the
# vendor's retirement schedule. Allowed WITH a stated reason; the bare pin is
# the gap, so the two lines above it are read before anything is recorded.
while IFS= read -r m; do
  [ -z "$m" ] && continue
  f="${m%%:*}"; rest="${m#*:}"; ln="${rest%%:*}"
  rel="${f#"$ROOT"/}"
  # A filename containing ':' shifts the split and makes ln repo-controlled text;
  # it reaches $(( )) below and an evidence command, so only digits proceed.
  case "$ln" in ''|*[!0-9]*) continue ;; esac
  ctx="$(sed -n "$(( ln > 2 ? ln - 2 : 1 )),${ln}p" "$f" 2>/dev/null)"
  grep -qiE 'pinned|deliberate|review|because|reason|keep' <<<"$ctx" && continue
  finding "model-currency" "medium" "$rel:$ln" "a dated model pin with no stated reason — a versioned id is deprecated or paywalled on the vendor's schedule, and the failure lands at runtime in a request someone is waiting for (model-currency 2)"
  evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  break
done < <(printf '%s\n' "$hits" | grep -E '(claude|gpt|gemini)-[a-z0-9.-]*-[0-9]{8}' || true)

exit 0
