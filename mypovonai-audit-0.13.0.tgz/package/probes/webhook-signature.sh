#!/usr/bin/env bash
# webhook-signature: bounded source candidates; see rubric/webhook-signature.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "webhook-signature" "$rel"; continue; fi
  finding "webhook-signature" "critical" "$rel:$line" "Webhook route body readers require a visible signature/event verification call in the handler."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "webhook-signature" "$ROOT")
exit 0
