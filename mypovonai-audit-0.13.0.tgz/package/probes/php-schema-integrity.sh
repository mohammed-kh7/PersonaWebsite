#!/usr/bin/env bash
# php-schema-integrity probe — evidence for rubric/php-schema-integrity.md.
#
# The finding class: the repository is not the source of truth for the
# database. A migration set is the only EXECUTABLE description of the schema;
# without one, nobody can rebuild an environment, stand up a test database, see
# a column being added in review, or tell which difference between staging and
# production is deliberate.
#
# Calibrated against a real snapshot: 55 migration files, 0 `->foreign(`/
# `->constrained(` calls anywhere, and 9 core tables the code reads and writes
# every day (companies, offers, applications, applicant_field_values,
# company_fields, contactus, about_us, settings, testimonials) that no
# migration creates. See backend.md findings 1 and 6.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

is_laravel || { skipped "php-schema-integrity" "not a Laravel application (no composer dependency, no routes/ + app/)"; exit 0; }
files="$(php_files)"
[ -n "$files" ] || { skipped "php-schema-integrity" "no PHP source outside vendor/"; exit 0; }

MIG_DIR="$ROOT/database/migrations"
mig_files=""
if [ -d "$MIG_DIR" ]; then
  mig_files="$(find "$MIG_DIR" -name '*.php' -type f 2>/dev/null)"
fi

# Tables Laravel's OWN scaffolding creates (queue, session, cache, auth
# housekeeping). These legitimately arrive from vendor-published migrations
# that a snapshot may or may not carry, and reporting them as "missing" or as
# proof of "no relational integrity" would be noise about the framework, not
# about the application. Documented in the rubric, not silently assumed.
FRAMEWORK_TABLES='^(migrations|sessions|cache|cache_locks|jobs|job_batches|failed_jobs|password_reset_tokens|personal_access_tokens)$'

# --- collect USED tables: Eloquent models + DB::table('x') calls -----------
# Pluralisation handles the common English cases only (consonant+y -> ies;
# s/x/z/ch/sh -> es; otherwise +s) — irregular plurals (person -> people) are
# NOT handled and are not guessed at; a model relying on one is invisible to
# this probe and that is a documented limitation, not a silent gap.
_pluralize() {
  case "$1" in
    *[bcdfghjklmnpqrstvwxyz]y) printf '%sies' "${1%y}" ;;
    *s|*x|*z|*ch|*sh) printf '%ses' "$1" ;;
    *) printf '%ss' "$1" ;;
  esac
}
_class_to_snake() {
  printf '%s' "$1" | sed -E 's/([a-z0-9])([A-Z])/\1_\2/g' | tr 'A-Z' 'a-z'
}

_used_tmp="$(mktemp "${TMPDIR:-/tmp}/schemaint-used-XXXXXX")"
# Model-declared tables: a class extending Model/Authenticatable/Pivot, using
# its own $table when set, else the conventional plural of the class name.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*) continue ;; esac
  grep -qE 'class[[:space:]]+[A-Za-z_]+[[:space:]]+extends[[:space:]]+(Model|Authenticatable|Pivot)\b' "$f" 2>/dev/null || continue
  cls="$(grep -oE 'class[[:space:]]+[A-Za-z_]+' "$f" | head -1 | awk '{print $2}')"
  [ -n "$cls" ] || continue
  tbl="$(grep -oE "protected[[:space:]]+\\\$table[[:space:]]*=[[:space:]]*['\"][a-zA-Z_]+['\"]" "$f" 2>/dev/null \
          | head -1 | grep -oE "['\"][a-zA-Z_]+['\"]" | tr -d "'\"")"
  if [ -z "$tbl" ]; then
    tbl="$(_pluralize "$(_class_to_snake "$cls")")"
  fi
  printf '%s\n' "$tbl"
done <<< "$files" >> "$_used_tmp"
# DB::table('x') calls anywhere in application code.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*) continue ;; esac
  grep -ohE "DB::table\\([[:space:]]*['\"][a-zA-Z_]+['\"]" "$f" 2>/dev/null
done <<< "$files" | grep -oE "['\"][a-zA-Z_]+['\"]" | tr -d "'\"" >> "$_used_tmp"
used="$(sort -u "$_used_tmp")"
rm -f "$_used_tmp"

# --- collect CREATED tables: Schema::create('x' across every migration -----
created=""
if [ -n "$mig_files" ]; then
  _created_tmp="$(mktemp "${TMPDIR:-/tmp}/schemaint-created-XXXXXX")"
  while IFS= read -r f; do
    grep -ohE "Schema::create\\([[:space:]]*['\"][a-zA-Z_]+['\"]" "$f" 2>/dev/null
  done <<< "$mig_files" | grep -oE "['\"][a-zA-Z_]+['\"]" | tr -d "'\"" >> "$_created_tmp"
  created="$(sort -u "$_created_tmp")"
  rm -f "$_created_tmp"
fi

if [ -z "$mig_files" ]; then
  # --- 3. no migrations directory at all (medium) — louder version of 1 ----
  # Reported ONCE, not once per model/table, for the same reason 276 backup
  # files are one php-hygiene finding: a finding per model would just be this
  # finding repeated.
  if [ -n "$used" ]; then
    n_used="$(printf '%s\n' "$used" | grep -c .)"
    finding "php-schema-integrity" "medium" "database/migrations" \
      "database/migrations/ does not exist at all, while the application reads and writes $n_used table(s) through Eloquent models and the query builder — NONE of the schema is reproducible from this repository; a new environment or test database cannot be created from source."
    evidence "test -d database/migrations; echo exit=\$?   # the application has models/DB::table() calls but no migrations/ directory"
  fi
else
  # --- 1. a table the code uses that no migration creates (critical) -------
  # ONE finding naming every missing table and the count, not one per table —
  # php-hygiene reports 276 backup files as a single finding for exactly this
  # reason: a finding per table would be as useless as zero findings.
  missing="$(comm -23 <(printf '%s\n' "$used") <(printf '%s\n' "$created") | grep -vE "$FRAMEWORK_TABLES")"
  if [ -n "$missing" ]; then
    n_missing="$(printf '%s\n' "$missing" | grep -c .)"
    table_list="$(printf '%s\n' "$missing" | tr '\n' ',' | sed 's/,/, /g; s/, $//')"
    finding "php-schema-integrity" "critical" "database/migrations" \
      "$n_missing table(s) the code reads or writes have NO migration anywhere: $table_list. The schema for these lives only in someone's production database — it cannot be rebuilt, reviewed, or stood up for a test, and nobody can tell which difference from production is deliberate."
    evidence "comm -23 <(grep -rhoE \"DB::table\\(['\\\"][a-zA-Z_]+\" app resources routes 2>/dev/null | sort -u) <(grep -rhoE \"Schema::create\\(['\\\"][a-zA-Z_]+\" database/migrations 2>/dev/null | sort -u)"
  fi

  # --- 2. zero foreign keys anywhere, with relational columns (high) -------
  # Repo-WIDE check, not per-column: the contract's ground truth is a schema
  # with 55 migrations, 0 `->foreign(`/`->constrained(` calls, and 8 files
  # declaring a *_id column regardless. `-e` on both patterns: a pattern
  # starting with `->` is parsed as OPTIONS otherwise (`grep: invalid option
  # -- >`), and the exclusion/check would silently never match.
  fk_hits=0
  rel_hits=0
  if [ -n "$mig_files" ]; then
    while IFS= read -r f; do
      grep -qE -e '->foreign\(' -e '->constrained\(' "$f" 2>/dev/null && fk_hits=$((fk_hits + 1))
      grep -qE "['\"][a-zA-Z_]+_id['\"]" "$f" 2>/dev/null && rel_hits=$((rel_hits + 1))
    done <<< "$mig_files"
  fi
  if [ "$fk_hits" -eq 0 ] && [ "$rel_hits" -gt 0 ]; then
    n_mig="$(printf '%s\n' "$mig_files" | grep -c .)"
    finding "php-schema-integrity" "high" "database/migrations" \
      "the schema declares ZERO foreign keys (no ->foreign( or ->constrained() call) across $n_mig migration file(s), while $rel_hits of them declare a relational (*_id) column — referential integrity exists only in application code, so a bug, an import or a manual query can orphan rows silently."
    evidence "grep -rc -e '->foreign(' -e '->constrained(' database/migrations | awk -F: '{s+=\$2} END{print s}'   # total FK calls across all migrations"
  fi
fi
exit 0
