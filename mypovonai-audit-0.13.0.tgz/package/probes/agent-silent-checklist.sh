#!/usr/bin/env bash
# agent-silent-checklist probe — the agent-setup twin of gate-integrity's
# checklist-silent-pass arm, so an agent-setup report is complete without the product
# lens. Detection is the SHARED silent_checklist_files in _lib.sh (affirmative
# "run/go through ... silently" or "silently ... check/rule/gate", negations ignored),
# called by both probes so the two cannot drift. N/A (skipped) on a product repo.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_agent_setup; then
  skipped "agent-silent-checklist" "not an agent setup (no CLAUDE.md, .claude/settings.json, settings.json+skills/, or agents/*.md) — there are no agent instructions to read"
  exit 0
fi

while IFS= read -r rel; do
  [ -n "$rel" ] || continue
  finding "agent-silent-checklist" "medium" "$rel" "needs validation: checklist runs silently: agent instructions say to run checks silently — record each item as done (evidence) or skip: <reason>"
  evidence "grep -niE 'silently' $(qpath "$rel")"
done < <(silent_checklist_files)

exit 0
