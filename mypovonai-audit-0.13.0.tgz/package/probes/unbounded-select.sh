#!/usr/bin/env bash
# unbounded-select: bounded source candidates; see rubric/unbounded-select.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "unbounded-select" "$rel"; continue; fi
  finding "unbounded-select" "medium" "$rel:$line" "ORM findMany and SQL SELECT * reads require a take/limit/cursor bound."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "unbounded-select" "$ROOT")
exit 0
