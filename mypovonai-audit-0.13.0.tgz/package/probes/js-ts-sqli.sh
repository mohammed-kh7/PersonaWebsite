#!/usr/bin/env bash
# js-ts-sqli: bounded source candidates; see rubric/js-ts-sqli.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "js-ts-sqli" "$rel"; continue; fi
  finding "js-ts-sqli" "critical" "$rel:$line" "Raw SQL calls must not concatenate or template-interpolate values into SQL text."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "js-ts-sqli" "$ROOT")
exit 0
