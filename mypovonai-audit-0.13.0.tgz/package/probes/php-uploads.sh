#!/usr/bin/env bash
# php-uploads probe — evidence for rubric/php-uploads.md.
#
# The finding that made this pack exist (php-secrets, see that probe's header)
# was a hard-coded admin password. The SAME repo's `/admin` panel — the only
# thing standing between the internet and that panel — also has exactly ONE
# file-upload handler with zero mime/size validation, in a codebase where
# EVERY OTHER upload handler validates `image`/`mimes:...`. A lens that flags
# "any file upload" would drown that one real bug in noise from the correctly
# validated handlers sitting one function away; a lens that flags nothing
# would miss remote code execution. So this probe scopes validation to the
# ENCLOSING METHOD, not the file or the repo: a `->validate()`/`Validator::make()`
# call ten lines above the write counts, one in a sibling method does not.
#
# NOTHING HERE EVER PRINTS A SECRET-SHAPED VALUE; redact_secrets still runs
# over every excerpt because upload code sometimes sits next to one.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

is_laravel || { skipped "php-uploads" "not a Laravel application (no composer dependency, no routes/ + app/)"; exit 0; }

files="$(php_files)"
[ -n "$files" ] || { skipped "php-uploads" "no PHP source outside vendor/"; exit 0; }

# Given the raw text of a line that persists an uploaded file, return the
# field name it came from — `hasFile('x')` / `->file('x')` first, falling back
# to `$request->x->store(...)` (Laravel's magic-property shorthand for
# accessing an uploaded file, used throughout this codebase's own known-bad
# site: `$request->image->store('uploads', 'public')` has no `->file(` call
# at all, so a probe that only looks for that literal misses its own target).
upload_field() { # $1 = source line
  local t="$1" m f
  m="$(grep -oE "(hasFile|->file)\(['\"][A-Za-z0-9_]+['\"]\)" <<<"$t" | head -1)"
  if [ -n "$m" ]; then
    f="${m#*\'}"; [ "$f" = "$m" ] && f="${m#*\"}"
    f="${f%\'*}"; f="${f%\"*}"
    printf '%s' "$f"
    return
  fi
  m="$(grep -oE '\$request->[A-Za-z0-9_]+->store(As)?\(' <<<"$t" | head -1)"
  if [ -n "$m" ]; then
    f="${m#\$request->}"
    f="${f%%->*}"
    printf '%s' "$f"
  fi
}

while IFS= read -r f; do
  [ -n "$f" ] || continue
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*|*/vendor/*) continue ;; esac

  # --- 3. write destination bypasses the disk abstraction (high) ------------
  # `->store('public', ...)` / `->storeAs('public', ...)` puts the PATH itself
  # at 'public' on the default disk, and `->move(public_path(...))` writes
  # straight into the document root — both land the file where the web server
  # serves it directly, skipping Laravel's disk config entirely. This is NOT
  # the ordinary `->store($path, 'public')` two-arg call (path, then DISK
  # NAME) that every validated handler in this codebase also uses -- that form
  # only matches here if 'public' is the FIRST argument, never the second.
  while IFS= read -r m; do
    ln="${m%%:*}"; text="${m#*:}"
    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-160)"
    finding "php-uploads" "high" "$rel:$ln" \
      "an upload is written straight to a web-servable destination, bypassing the disk abstraction: $safe"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <(grep -nE -- "->store\(\s*['\"]public['\"][,)]|->storeAs\(\s*['\"]public['\"]|->move\(\s*public_path\(" "$f" 2>/dev/null)

  # --- 4. stored filename built from the client-supplied name (high) --------
  # `getClientOriginalName()`/`getClientOriginalExtension()` hand the attacker
  # the extension (or the whole name) on the file that lands on disk. Laravel's
  # own `->store()`/`->storeAs()` random-name default is the safe path; this
  # is a handler that opted OUT of it.
  while IFS= read -r m; do
    ln="${m%%:*}"; text="${m#*:}"
    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-160)"
    finding "php-uploads" "high" "$rel:$ln" \
      "the stored filename is derived from the client-supplied original name/extension: $safe"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <(grep -nE "getClientOriginalName\(\)|getClientOriginalExtension\(\)" "$f" 2>/dev/null)

  # --- 1 & 2: validation quality, scoped to the ENCLOSING method -------------
  # Method boundaries: the nearest preceding/following named-method
  # declaration. Controllers don't nest methods, so "next declaration" is a
  # safe end marker without a real brace-matcher.
  func_lines="$(grep -nE '^[[:space:]]*(public|private|protected)[[:space:]]+(static[[:space:]]+)?function[[:space:]]+[A-Za-z_]' "$f" | cut -d: -f1)"
  total_lines="$(wc -l < "$f" | tr -d ' [:space:]')"

  while IFS= read -r m; do
    ln="${m%%:*}"; text="${m#*:}"

    s="$(printf '%s\n' "$func_lines" | awk -v n="$ln" '$1<=n{s=$1} END{print s+0}')"
    [ "$s" -gt 0 ] || s=1
    e="$(printf '%s\n' "$func_lines" | awk -v s="$s" -v last="$total_lines" '$1>s{print $1-1; f=1; exit} END{if(!f) print last}')"
    block="$(sed -n "${s},${e}p" "$f")"

    # --- 2. no validation call anywhere in the handler (high) --------------
    if ! grep -qE '[Vv]alidate[A-Za-z]*\(|Validator::make\(' <<<"$block"; then
      safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-160)"
      finding "php-uploads" "high" "$rel:$ln" \
        "an uploaded file is persisted with no validation call — no type, size or content check — anywhere in its handler: $safe"
      evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
      continue
    fi

    # --- 1. validated, but the rule has no mimes/mimetypes or no max: -------
    # Only judged when the field's OWN rule is a literal string right here in
    # this method (`'image' => 'nullable|image|mimes:...|max:...'`). A
    # dynamic, config-driven validator (`$this->validateCrudRequest(...)`)
    # proves a validate call happened but not what it checked -- guessing
    # would be exactly the noise this pack exists to avoid, so it is left
    # alone rather than flagged on a guess.
    field="$(upload_field "$text")"
    [ -n "$field" ] || continue
    # The field's own rule line: `'image' => 'nullable|image|mimes:...|max:...'`.
    # Checked as a whole line rather than isolating the quoted value -- the
    # key name itself can't accidentally contain "mimes:"/"max:", and this
    # sidesteps fragile multi-quote extraction for a check that only needs
    # presence, not the exact string.
    rule_line="$(grep -E "['\"]${field}['\"][[:space:]]*(=>|:)[[:space:]]*['\"][^'\"]*['\"]" <<<"$block" | head -1)"
    [ -n "$rule_line" ] || continue
    ok=1
    grep -qiE "mimes:|mimetypes:|\bimage\b" <<<"$rule_line" || ok=0
    grep -qiE "max:" <<<"$rule_line" || ok=0
    if [ "$ok" -eq 0 ]; then
      safe="$(printf '%s' "$rule_line" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-160)"
      finding "php-uploads" "high" "$rel:$ln" \
        "the '$field' upload is validated, but its rule has no mimes:/mimetypes: (or image) type check, or no max: size limit: $safe"
      evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
    fi
  done < <(grep -nE -- '->store\(|->storeAs\(' "$f" 2>/dev/null)
done <<< "$files"
exit 0
