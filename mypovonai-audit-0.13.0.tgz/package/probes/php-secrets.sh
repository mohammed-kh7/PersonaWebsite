#!/usr/bin/env bash
# php-secrets probe — evidence for rubric/php-secrets.md.
#
# The finding that made this pack exist: a Laravel app whose entire /admin panel
# was gated by ONE hard-coded password compared with === to a request value,
# inside a route closure. The fleet ran 34 probes over that repo and missed it,
# because every lens it owned was looking for TypeScript.
#
# NOTHING HERE EVER PRINTS THE SECRET. The message and the evidence command both
# pass through redact_secrets: findings and their excerpts are uploaded, so a
# probe that quotes the password turns an audit into a leak.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_php; then
  skipped "php-secrets" "no PHP source found"
  exit 0
fi

files="$(php_files)"
[ -n "$files" ] || { skipped "php-secrets" "no PHP source outside vendor/"; exit 0; }

# --- 1. a request value compared to a literal (critical) --------------------
# `$request->input('password') === 'literal'` — one shared password, in the
# source, for everyone who ever had it, and unrotatable without a deploy.
#
# TWO STAGES, not one dense regex: find any request value compared to a string
# literal, then keep only the CREDENTIAL-shaped fields. A single pattern doing
# both was unreadable and silently matched nothing; and the wide version flagged
# `$request->input('news_type') === 'x'`, which is ordinary application logic.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*|*/vendor/*) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    grep -qiE "(password|passwd|passcode|pass_?key|pin|secret|token|otp|access[_-]?code|admin[_-]?key|api[_-]?key)" <<<"$text" || continue
    grep -qiE "Hash::check|password_verify|Auth::attempt|bcrypt\(" <<<"$text" && continue
    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-120)"
    finding "php-secrets" "critical" "$rel:$ln" \
      "a credential from the request is compared with a hard-coded literal — a shared password living in the source: $safe"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel") | sed -E \"s/(===?[[:space:]]*)'[^']*'/\\1'<redacted>'/g\""
    # `$` inside an ERE alternation is the END-OF-LINE ANCHOR: `($request->|…)`
    # can never match, and the probe reported a clean repo for two runs. Two
    # greps instead — the second single-quoted, so `\$` reaches ERE intact.
  done < <(grep -nE "===?[[:space:]]*['\"][^'\"]{3,}['\"]" "$f" 2>/dev/null \
            | grep -E '\$request->|request\(|\$_POST|\$_GET')
done <<< "$files"

# --- 2. a hard-coded credential assigned in source (critical) ---------------
# `'api_key' => 'sk_live_...'`, `$secret = "..."` -- anything that belongs in .env.
# env(...) and config(...) reads are the sanctioned route and never match.
#
# EVERY filter here reads the VALUE, never the whole line. The first version
# tested the line, and the quoted KEY `'password'` matched its own placeholder
# word-list -- so `'password' => '<a real password>'` was DROPPED as a
# placeholder. It scored a clean repo for the right count and the wrong reason;
# a secrets lens that suppresses the secret is worse than no lens.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*|*.example*|*/database/factories/*|*/database/seeders/*) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    grep -qiE 'env\(|config\(|getenv|\$_ENV|\$_SERVER|Str::random|bcrypt|Hash::' <<<"$text" && continue
    val="$(printf '%s' "$text" \
      | grep -oiE "(api[_-]?key|secret|password|passwd|token|private[_-]?key)['\"]?[[:space:]]*(=>|=)[[:space:]]*['\"][^'\"]{8,}['\"]" \
      | head -1 | sed -E "s/.*['\"]([^'\"]{8,})['\"][[:space:]]*\$/\1/")"
    [ -n "$val" ] || continue
    # A Laravel VALIDATION RULE is the commonest lookalike: `'password' => 'required|min:8'`
    # sits under a credential-shaped key in every controller in the repo.
    grep -qE '^(required|nullable|sometimes|string|integer|numeric|email|confirmed|array|boolean|file|image|date|url|alpha|alpha_num|exists|unique|digits|between|same|regex|min|max|in|not_in|accepted|present|filled)([|:]|$)' <<<"$val" && continue
    # A TEMPLATE EXPRESSION is not a literal: `var token = '{{ csrf_token() }}'`
    # is the per-request CSRF token, rendered at response time. Four of the six
    # first findings on the calibration repo were this one line in two Blade files.
    grep -qE '\{\{|\}\}|\{!!|!!\}|<\?' <<<"$val" && continue
    # A credential has NO SPACES. `'password' => 'Incorrect password.'` is the
    # error message shown on a failed login, sitting under a credential key.
    grep -qE '[[:space:]]' <<<"$val" && continue
    # A fragment of a concatenation or a query string, not a value:
    # `body: '_token=' + token + '&_method=DELETE'`.
    grep -qE '^[-+.&=]|[-+.&=]$|^[_a-z]+=' <<<"$val" && continue
    # A note to the reader, not a credential.
    grep -qiE '^(null|changeme|change[-_]?me|your[-_]?(key|secret|token|password)|xxx+|placeholder|example|sample|dummy|test|secret|password|api[-_]?key|token|todo|none|unset)$' <<<"$val" && continue
    # CREDENTIAL-SHAPED, positively: a known key prefix, or enough entropy that it
    # cannot be a word. `required` (8 chars, no digit) is not; `key-9f2c8a71` is.
    shaped=0
    grep -qE '^(sk|pk|rk|ghp|gho|ghs|xox[bpsa]|AKIA|AIza|SG\.|eyJ|tok|key|api|Bearer)[-_.A-Za-z0-9]' <<<"$val" && shaped=1
    if [ "$shaped" -eq 0 ] && [ "${#val}" -ge 12 ]; then
      grep -qE '[0-9]' <<<"$val" && grep -qE '[A-Za-z]' <<<"$val" && shaped=1
      grep -qE '[a-z]' <<<"$val" && grep -qE '[A-Z]' <<<"$val" && shaped=1
      grep -qE '[^A-Za-z0-9]' <<<"$val" && shaped=1
    fi
    [ "${#val}" -ge 24 ] && shaped=1
    [ "$shaped" -eq 1 ] || continue
    safe="$(printf '%s' "$text" | redact_secrets | cut -c1-140)"
    finding "php-secrets" "critical" "$rel:$ln" \
      "a credential is hard-coded in source rather than read from the environment: ${safe#"${safe%%[![:space:]]*}"}"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")   # value redacted by the probe"
    # The key is usually QUOTED in a config array -- `'api_key' => '...'` -- and a
    # pattern without the optional closing quote matched nothing in config/.
  done < <(grep -niE "(api[_-]?key|secret|password|passwd|token|private[_-]?key)['\"]?[[:space:]]*(=>|=)[[:space:]]*['\"][^'\"]{8,}['\"]" "$f" 2>/dev/null)
done <<< "$files"

# --- 3. env() with a real-looking default (high) ----------------------------
# `env('STRIPE_KEY', 'sk_live_…')` ships the fallback the day the variable is
# missing — which is exactly the day nobody is watching.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    grep -qiE "env\([^,]+,[[:space:]]*(null|true|false|''|\"\"|[0-9]+|\[\])" <<<"$text" && continue
    grep -qiE "env\([^,]+,[[:space:]]*['\"](local|production|staging|testing|debug|sync|file|redis|database|mysql|pgsql|sqlite|smtp|log|array|daily|stack|single|public|private|utf8|utf8mb4|en|UTC)['\"]" <<<"$text" && continue
    # A NAME, not a secret: AUTH_PASSWORD_RESET_TOKEN_TABLE defaults to
    # `password_reset_tokens`. A credential is not lowercase snake_case, and a
    # variable ending TABLE/DRIVER/PROVIDER/COLUMN/FIELD names a thing.
    grep -qE "env\([[:space:]]*['\"][A-Z0-9_]*(TABLE|DRIVER|PROVIDER|COLUMN|FIELD|MODEL|CONNECTION|QUEUE|STORE)['\"]" <<<"$text" && continue
    # A NAME has no digits: `password_reset_tokens` is a table, `tok_live_4f9a2b7c`
    # is a credential. Excluding every lowercase-snake default swallowed the latter.
    grep -qE "env\([^,]+,[[:space:]]*['\"][a-z][a-z_]*['\"]" <<<"$text" && continue
    safe="$(printf '%s' "$text" | redact_secrets | cut -c1-140)"
    finding "php-secrets" "high" "$rel:$ln" \
      "env() falls back to a real-looking value — it ships the day the variable is missing: ${safe#"${safe%%[![:space:]]*}"}"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")   # default redacted by the probe"
    # CREDENTIAL-shaped variables only. Laravel's own config is full of honest
    # defaults — APP_URL http://localhost, MAIL_HOST 127.0.0.1, DB_DATABASE
    # forge — and flagging those produced 25 findings on one repo, none of them
    # real. A default is a finding when the NAME says credential.
  done < <(grep -nE "env\([[:space:]]*['\"][A-Z0-9_]*(KEY|SECRET|TOKEN|PASSWORD|PASSWD|CREDENTIAL|DSN|SALT|CERT)[A-Z0-9_]*['\"][[:space:]]*,[[:space:]]*['\"][^'\"]{8,}['\"]" "$f" 2>/dev/null)
done <<< "$files"
exit 0
