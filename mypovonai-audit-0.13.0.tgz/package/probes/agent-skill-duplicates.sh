#!/usr/bin/env bash
# agent-skill-duplicates probe — evidence for standard/skill-hygiene.md L6 (head-to-head:
# two copies of one capability are loaded, the losing one still costs context and can
# win the trigger). N/A (skipped) on a product repo.
#
# Surfaces: SKILL.md `name:` under skills/*/ and .claude/skills/*/ (find -L, so
# symlinked installs are followed), and the `enabledPlugins` keys of settings.json /
# .claude/settings.json. A dangling skill link is skipped-noted, never a crash.
#   same name twice            -> medium "duplicate skill"
#   same plugin name before @  -> medium "duplicate plugin" (two marketplaces)
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_agent_setup; then
  skipped "agent-skill-duplicates" "not an agent setup (no CLAUDE.md, .claude/settings.json, settings.json+skills/, or agents/*.md) — there are no installed skills or plugins to compare"
  exit 0
fi

NAMES=""
for d in "$ROOT"/skills/* "$ROOT"/.claude/skills/*; do
  [ -e "$d" ] || [ -L "$d" ] || continue
  if [ -L "$d" ] && [ ! -e "$d" ]; then
    skipped "agent-skill-duplicates" "dangling skill link ${d#"$ROOT"/} — target missing, so its name cannot be compared (a dangling skill is skill-hygiene L2's finding)"
    continue
  fi
  [ -f "$d/SKILL.md" ] && inside_root "$d/SKILL.md" || continue
  n="$(sed -n 's/^name:[[:space:]]*//p' "$d/SKILL.md" 2>/dev/null | head -1 | tr -d '\r"'"'"'')"
  [ -n "$n" ] || continue
  NAMES="${NAMES}${n}"$'\t'"${d#"$ROOT"/}"$'\n'
done

while IFS=$'\t' read -r name p1 p2; do
  [ -n "$name" ] || continue
  finding "agent-skill-duplicates" "medium" "$p1" "duplicate skill: $name loaded twice ($p1, $p2) — keep the head-to-head winner"
  evidence "grep -n '^name:' $(qpath "$p1/SKILL.md") $(qpath "$p2/SKILL.md")"
done < <(printf '%s' "$NAMES" | awk -F'\t' '{ c[$1]++; if (c[$1] == 1) a[$1] = $2; else if (c[$1] == 2) b[$1] = $2 } END { for (n in c) if (c[n] > 1) print n "\t" a[n] "\t" b[n] }' | sort)

PLUGINS="$(
  for s in "$ROOT/settings.json" "$ROOT/.claude/settings.json"; do
    [ -f "$s" ] && inside_root "$s" || continue
    node -e '
      try {
        const e = JSON.parse(require("fs").readFileSync(process.argv[1], "utf8")).enabledPlugins ?? {};
        for (const [k, v] of Object.entries(e)) if (v === true) console.log(k);
      } catch {}
    ' "$s" 2>/dev/null
  done
)"
while IFS= read -r pname; do
  [ -n "$pname" ] || continue
  finding "agent-skill-duplicates" "medium" "settings.json" "duplicate plugin: $pname enabled from two marketplaces"
  evidence "grep -n enabledPlugins settings.json .claude/settings.json"
done < <(printf '%s\n' "$PLUGINS" | grep . | sed 's/@.*//' | sort | uniq -d)

exit 0
