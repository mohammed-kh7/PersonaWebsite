#!/usr/bin/env bash
# enumeration-integrity probe — evidence for standard/enumeration-integrity.md.
#
# "A number describing a set is a measurement, not a fact." The failure class is
# invisible by construction: no error, no warning, a plausible total. Three of
# the five documented mechanisms leave a syntactic fingerprint and are probed:
#   §1/§2  `for x in $(find …)` — word-splits on spaces; measured 4 where the
#          NUL-safe census reported 2, and lost a 3,049-commit repo silently
#   §1/§2  a `.git` existence test that does not distinguish a WORKTREE (a file)
#          from a canonical repo (a directory) — 7 worktrees duplicated a third
#          of the corpus
#   §1/§2  a basename used as a unit id — collided across 24 directories
# The other two are structural, not syntactic, and go to the interpreter: a
# MISSING reconciliation assertion emits nothing to match on, and a first-match
# classifier is a control-flow shape rather than a token.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

SH_INC=(--include='*.sh' --include='*.bash' --exclude-dir=node_modules "${BUILD_EXCL[@]}")
JS_INC=(--include='*.js' --include='*.mjs' --include='*.cjs' --include='*.ts' --exclude-dir=node_modules "${BUILD_EXCL[@]}")

# A comment that QUOTES the bad pattern is not the bad pattern. Calibration
# precedent: a doc comment reading "NO dangerouslySetInnerHTML" was a security
# false positive, and three fixtures have already tripped a probe by naming the
# trigger word. grep -rn emits `path:line:text`, so anchor on the text field.
NOT_COMMENT='^[^:]*:[0-9]+:[[:space:]]*(//|#|\*|/\*)'

emit() { # severity pattern message   (grep -rn output on stdin)

  local sev="$1" pat="$2" msg="$3" line f rest n
  while IFS= read -r line; do
    [ -n "$line" ] || continue
    f="${line%%:*}"; rest="${line#*:}"; n="${rest%%:*}"
    finding "enumeration-integrity" "$sev" "${f#"$ROOT"/}:$n" "$msg"
    evidence "grep -nE '$pat' $(qpath "$f")"
  done
}

# --- nul-safe-iteration (high, §2) ----------------------------------------
P_WORDSPLIT='for[[:space:]]+[A-Za-z_][A-Za-z0-9_]*[[:space:]]+in[[:space:]]+[`$]\(?(find|ls)[[:space:]]'
grep -rnE "$P_WORDSPLIT" "${SH_INC[@]}" "$ROOT" 2>/dev/null | grep -vE "$NOT_COMMENT" | head -25 \
  | emit "high" "$P_WORDSPLIT" "paths are iterated by word-splitting a find/ls substitution — every path containing a space becomes two units and the enumeration is wrong with no error: measured, a directory whose name contained spaces made 'for d in \$(find …)' report 4 repos where the NUL-safe census reported 2, and a 3,049-commit repo vanished into a total that was then written into a plan; use find -print0 | while IFS= read -r -d '' p (enumeration-integrity 2)"

# A find|while pipeline that does not carry -print0/-d '' is the same class one
# step less severe: it survives spaces but not newlines, and it still cannot
# report what it skipped.
while IFS= read -r f; do
  [ -n "$f" ] || continue
  grep -qE -e "-print0" "$f" 2>/dev/null && continue
  n=$(grep -nE 'find[^|]*\|[[:space:]]*while' "$f" | head -1 | cut -d: -f1)
  finding "enumeration-integrity" "medium" "${f#"$ROOT"/}:$n" "a find|while path loop runs without -print0 / read -d '' — it survives spaces only by luck of IFS and breaks on a newline in a path; the standard's rule is to assume every path contains a space and may contain a quote or a newline (enumeration-integrity 2)"
  evidence "grep -nE 'find[^|]*\\|[[:space:]]*while' $(qpath "$f")"
done < <(grep -rlE 'find[^|]*\|[[:space:]]*while' "${SH_INC[@]}" "$ROOT" 2>/dev/null | head -20)

# --- worktree-vs-repo (high, §2) ------------------------------------------
# A worktree's .git is a FILE; a canonical repo's is a DIRECTORY. -e and
# existsSync() answer "has a .git entry", which is a different question.
P_SH_GIT='\[[[:space:]]+-e[[:space:]]+"?[^]"]*/\.git"?[[:space:]]*\]|\[\[[[:space:]]+-e[[:space:]]+"?[^]"]*/\.git"?[[:space:]]*\]\]'
grep -rnE "$P_SH_GIT" "${SH_INC[@]}" "$ROOT" 2>/dev/null | grep -vE "$NOT_COMMENT" | head -25 \
  | emit "high" "$P_SH_GIT" "a repo census tests '-e .../.git', which is true for a git WORKTREE as well as a canonical repo — a worktree's .git is a file, a repo's is a directory, and counting both duplicated 5,235 commits (a third of the corpus) with no error; use test -d, or resolve with git rev-parse --git-common-dir and de-duplicate on canonical identity (enumeration-integrity 2)"

P_JS_GIT="existsSync\\([^)]*['\"]\\.git['\"]|existsSync\\([^)]*\\.git['\"]\\)"
grep -rnE "$P_JS_GIT" "${JS_INC[@]}" "$ROOT" 2>/dev/null | grep -v 'isDirectory' | grep -vE "$NOT_COMMENT" | head -25 \
  | emit "high" "$P_JS_GIT" "existsSync(<dir>/.git) treats a git WORKTREE as a separate repo — a worktree's .git is a file, a canonical repo's is a directory; the measured run reported 41 repos for a 34-repo corpus and duplicated a third of its commits; statSync(...).isDirectory() or git rev-parse --git-common-dir (enumeration-integrity 2)"

# --- path-not-basename-id (medium, §2) ------------------------------------
P_BASENAME_JS='(const|let|var)[[:space:]]+[A-Za-z_$]*([Ii]d|[Kk]ey|[Ss]lug)[[:space:]]*=[[:space:]]*(path\.)?basename\(|[A-Za-z_$]*([Ii]d|[Kk]ey|[Ss]lug):[[:space:]]*(path\.)?basename\('
grep -rnE "$P_BASENAME_JS" "${JS_INC[@]}" "$ROOT" 2>/dev/null | grep -vE "$NOT_COMMENT" | head -25 \
  | emit "medium" "$P_BASENAME_JS" "a basename is used as a unit id — a basename is not unique: 'digital-card' existed at two paths and '<project>/project.md' collided on one id across 24 directories, silently collapsing units onto each other; identify a unit by its full relative path (or <namespace>:<relative-path>) and assert |unique ids| == |units| before emitting (enumeration-integrity 2)"

P_BASENAME_SH='^[[:space:]]*[A-Za-z_]*(id|key|slug)=\$\(basename'
grep -rnE "$P_BASENAME_SH" "${SH_INC[@]}" "$ROOT" 2>/dev/null | grep -vE "$NOT_COMMENT" | head -25 \
  | emit "medium" "$P_BASENAME_SH" "a basename is assigned as a unit id in a shell enumerator — basenames collide across directories and the collision is silent; use the full relative path and assert id uniqueness (sort ids | uniq -d must print nothing — print it, do not assume it) (enumeration-integrity 2)"


exit 0
