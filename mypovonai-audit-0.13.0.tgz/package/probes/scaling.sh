#!/usr/bin/env bash
# scaling probe — evidence for standard/scaling.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"
if [ -z "$files" ]; then
  skipped "scaling" "no TS/TSX source found"
  exit 0
fi

# leader-election (crit): a recurring setInterval whose callback does a SHARED
# side-effect (DB write / send / queue drain) with no leader lock. Calibrated
# on FWB (2026-08-13): flagging *every* setInterval floods the reference — a
# timer that only cleans a per-process in-memory Map (CSRF tokens, a debounce
# BoundedMap) MUST run on every replica and is correct as-is. The discriminator
# is a shared side-effect in the callback body, not the timer itself. Exempt
# also: a comment line, an Inngest cron, or a withLeaderLock/NX-guarded body.
# Only a DIRECT shared mutation in the callback window counts. Two calibration
# lessons from FWB (2026-08-13):
#  1. a bare `.delete(` also matches an in-memory Map.delete(key) (CSRF-token /
#     debounce cleanup) that MUST run per-replica — so scope DB writes to
#     `prisma.`-prefixed calls.
#  2. do NOT follow indirection (processQueue/dispatch/enqueue): FWB's queue
#     drainers call this.processQueue(), and one level down that is an atomic
#     `redis.rpop` — the standard EXEMPTS atomic-RPOP workers. Flagging the
#     indirection over-fires on a correct-by-design pattern. A timer that calls
#     a method is where atomicity may live; only flag an unmistakable inline
#     write/send. Precision over recall — the interpreter judges the rest.
SHARED='prisma\.[a-zA-Z]+\.(create|createMany|update|updateMany|delete|deleteMany|upsert)|prisma\.\$execute|sendMail|sendEmail|sendSms|\.sendRaw\('
GUARD='\bNX\b|redis[^\n]*\.set\(|acquireLock|leaderElection|withLeaderLock|LeaderLock|withLock|inngest\.createFunction'
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *.test.*|*.spec.*|*fixture*|*.d.ts) continue ;; esac
  case "$rel" in *components/*|*.tsx) continue ;; esac
  # inspect every setInterval call site individually
  while IFS= read -r m; do
    ln="${m%%:*}"
    line="${m#*:}"
    # skip a match inside a comment
    case "$(printf '%s' "$line" | sed -e 's/^[[:space:]]*//')" in \**|//*|/\**) continue ;; esac
    # the callback body: this line + the next 8
    win="$(sed -n "${ln},$((ln+8))p" "$f" 2>/dev/null)"
    grep -qiE "$GUARD" <<<"$win" && continue            # already leader-gated
    grep -qiE "$SHARED" <<<"$win" || continue           # no shared side-effect → per-instance, correct
    finding "scaling" "critical" "$rel:$ln" "recurring setInterval whose callback does a shared side-effect (DB write / queue drain) with no leader lock — every replica runs it, double-firing once you scale past one instance"
    evidence "grep -nE 'setInterval|withLeaderLock|prisma\\.|processQueue' $(qpath "$f")"
    break
  done < <(grep -nE 'setInterval *\(' "$f" 2>/dev/null)
done <<<"$files"

# socketio-adapter (crit): socket.io present but no redis-adapter wiring
GREP_INC=(--include='*.ts' --include='*.tsx' --exclude-dir=node_modules "${BUILD_EXCL[@]}")
if grep -rqE "from ['\"]socket\.io['\"]|require\(['\"]socket\.io['\"]\)" "${GREP_INC[@]}" "$ROOT" 2>/dev/null; then
  if ! grep -rqE "@socket\.io/redis-adapter|createAdapter" "${GREP_INC[@]}" "$ROOT" 2>/dev/null; then
    hit=$(grep -rlE "from ['\"]socket\.io['\"]" "${GREP_INC[@]}" "$ROOT" 2>/dev/null | head -1)
    finding "scaling" "critical" "${hit#"$ROOT"/}" "socket.io is used with no @socket.io/redis-adapter — realtime fan-out silently breaks the moment there is more than one replica"
    evidence "grep -rn 'socket.io|redis-adapter|createAdapter' $(qpath "$ROOT") --include='*.ts'"
  fi
fi

exit 0
