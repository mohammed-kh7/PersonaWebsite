#!/usr/bin/env bash
# auth-token-lifecycle probe — evidence for standard/auth-token-lifecycle.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"
if [ -z "$files" ]; then
  skipped "auth-token-lifecycle" "no TS/TSX source found"
  exit 0
fi

# --- session-not-regenerated (crit 1): a login handler writes session data ---
# with no session.regenerate() call anywhere in the same file.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*spec*|*fixture*|*.d.ts) continue ;; esac
  case "$rel" in *login*|*signin*|*sign-in*) : ;; *) continue ;; esac
  grep -qE 'req\.session\.[a-zA-Z]+ *=|session\.save\(|session\.user *=' "$f" 2>/dev/null || continue
  grep -qE '\.regenerate\(' "$f" 2>/dev/null && continue
  ln="$(grep -nE 'req\.session\.[a-zA-Z]+ *=|session\.save\(|session\.user *=' "$f" 2>/dev/null | head -1 | cut -d: -f1)"
  finding "auth-token-lifecycle" "critical" "$rel:$ln" "a login handler writes session data with no session.regenerate() call in the same file — a pre-authentication session id can be adopted by the attacker the moment this login succeeds (auth-token-lifecycle 1)"
  evidence "sed -n '$(num "$ln")p' $(qpath "$f")"
done <<< "$files"

# --- reset-token-no-expiry (crit 4): a reset-token reference with no ---------
# expiry/ttl check within the surrounding lines.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*spec*|*fixture*|*.d.ts) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    win="$(sed -n "${ln},$((ln+8))p" "$f" 2>/dev/null)"
    grep -qiE 'expir|ttl|exp:' <<<"$win" && continue
    finding "auth-token-lifecycle" "critical" "$rel:$ln" "a password-reset token is read/consumed with no expiry/ttl check in the surrounding lines — a reset link with no expiration keeps working indefinitely, months later (auth-token-lifecycle 4)"
    evidence "sed -n '$(num "$ln"),$(( $(num "$ln") + 8 ))p' $(qpath "$f")"
  done < <(grep -niE 'resetToken|reset_token|passwordResetToken' "$f" 2>/dev/null)
done <<< "$files"

exit 0
