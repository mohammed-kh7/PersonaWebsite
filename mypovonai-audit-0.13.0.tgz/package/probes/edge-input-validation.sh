#!/usr/bin/env bash
# edge-input-validation: bounded source candidates; see rubric/edge-input-validation.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "edge-input-validation" "$rel"; continue; fi
  finding "edge-input-validation" "high" "$rel:$line" "Route handlers sending JSON body data to database writes require visible schema parsing or validation."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "edge-input-validation" "$ROOT")
exit 0
