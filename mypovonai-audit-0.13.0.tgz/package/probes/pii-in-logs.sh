#!/usr/bin/env bash
# pii-in-logs: bounded source candidates; see rubric/pii-in-logs.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "pii-in-logs" "$rel"; continue; fi
  finding "pii-in-logs" "high" "$rel:$line" "Console/logger calls must not directly log PII/credential fields or whole request bodies/headers without redaction."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "pii-in-logs" "$ROOT")
exit 0
