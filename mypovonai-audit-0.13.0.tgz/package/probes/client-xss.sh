#!/usr/bin/env bash
# client-xss: bounded source candidates; see rubric/client-xss.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "client-xss" "$rel"; continue; fi
  finding "client-xss" "high" "$rel:$line" "Dynamic innerHTML/dangerouslySetInnerHTML expressions require a visible sanitizer at the sink."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "client-xss" "$ROOT")
exit 0
