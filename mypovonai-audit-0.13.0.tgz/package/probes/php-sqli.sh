#!/usr/bin/env bash
# php-sqli probe — evidence for rubric/php-sqli.md.
#
# Laravel's query builder parameter-binds everything by default. The hole is
# the *Raw family (DB::raw, whereRaw, havingRaw, selectRaw, orderByRaw) plus
# DB::select/DB::statement, which hand a literal SQL fragment straight to the
# driver: whatever the developer put inside the string runs verbatim. A raw
# call is fine when the string is a fixed literal (or uses `?`/`:name`
# placeholders with a bindings array) — it is only a finding when request or
# superglobal data reaches the SQL TEXT itself, by PHP double-quote
# interpolation or by `.` concatenation.
#
# NEVER flag on the bindings array. `whereRaw('name = ?', [$request->input('x')])`
# is the sanctioned, safe form — $request appears in the CALL but never inside
# the SQL string, so the probe only ever inspects the first (string) argument,
# not the whole call. That is the one exception the contract requires and the
# reason this is two stages, not one dense regex over the whole line.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_laravel; then
  skipped "php-sqli" "not a Laravel application (no composer dependency, no routes/ + app/)"
  exit 0
fi
files="$(php_files)"
[ -n "$files" ] || { skipped "php-sqli" "no PHP source outside vendor/"; exit 0; }

RAW_CALL='(DB::raw|DB::select|DB::statement|whereRaw|havingRaw|selectRaw|orderByRaw)\('

# --- 1. request/superglobal data reaches a raw SQL string (critical) --------
# Two-stage per file: find the call sites, then for EACH one pull out just the
# first argument (the SQL text) and test that in isolation. A single regex
# that also looked at the rest of the line matched `[$request->input('x')]`
# sitting safely in the bindings array two arguments later.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*|*/vendor/*) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    # Everything after the call's opening paren, on this line. Calls whose SQL
    # string starts on the NEXT line are not seen by a line-based probe — a
    # known limitation, not a silent pass: such a call still has to pass this
    # same test once its string is joined onto one line by hand.
    after="$(printf '%s' "$text" | sed -E "s/.*$RAW_CALL//")"
    trimmed="$(printf '%s' "$after" | sed -E 's/^[[:space:]]*//')"
    bad=0
    reason=""
    case "$trimmed" in
      '"'*|"'"*)
        # First argument is a string literal. Two independent injection
        # vectors, checked regardless of which quote style was used:
        #   (a) double-quoted only — PHP interpolates `$name` and `{$expr}`
        #       inside it, so a literal `$` followed by an identifier
        #       character IS live SQL injection, not just a stray dollar sign
        #       (`"Price: $5"` never interpolates — digits can't start a
        #       variable, so single-quoted text can never trigger this arm).
        #   (b) either quote style — `.` concatenation immediately after the
        #       string closes: 'SELECT ... WHERE id=' . $id, or the
        #       double-quoted equivalent "name = '" . $x . "'".
        if [ "${trimmed:0:1}" = '"' ]; then
          first_arg="$(printf '%s' "$trimmed" | grep -oE '^"([^"\\]|\\.)*"')"
        else
          first_arg="$(printf '%s' "$trimmed" | grep -oE "^'([^'\\\\]|\\\\.)*'")"
        fi
        if [ "${trimmed:0:1}" = '"' ] && grep -qE '\$[A-Za-z_{]' <<<"$first_arg"; then
          bad=1; reason="a variable is interpolated directly into the SQL string"
        fi
        if [ "$bad" -eq 0 ]; then
          rest="$(printf '%s' "${trimmed#"$first_arg"}" | sed -E 's/^[[:space:]]*//')"
          if grep -qE '^\.' <<<"$rest" && grep -qE '\$[A-Za-z_]' <<<"$rest"; then
            bad=1; reason="the SQL string is built by concatenating a variable onto it"
          fi
        fi
        ;;
      '$request'*|'request('*|'$_GET'*|'$_POST'*|'$_REQUEST'*)
        # No string literal at all: the SQL text itself is request-controlled.
        bad=1; reason="the query argument is request data, not a literal"
        ;;
      *)
        : # a bare variable holding a query built elsewhere is out of scope —
          # this probe reads text, not data flow across functions.
        ;;
    esac
    [ "$bad" -eq 1 ] || continue
    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-140)"
    finding "php-sqli" "critical" "$rel:$ln" \
      "raw SQL built with request-controlled data — $reason: $safe"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <(grep -nE "$RAW_CALL" "$f" 2>/dev/null)
done <<< "$files"

# --- 2. orderBy() column/direction taken straight from input (critical) -----
# Laravel does not parameter-bind a column or direction name — they are SQL
# identifiers, not values — so `orderBy($request->input('sort'))` lets a caller
# name any column (or, on some drivers, smuggle a second clause via direction).
# Two shapes: the request expression given directly to orderBy(), and a local
# variable assigned from the request a few lines earlier and handed to
# orderBy() by name — the window is 15 lines, wide enough for a controller
# method's setup block, narrow enough not to match an unrelated variable reuse.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*|*/vendor/*) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    arg="$(printf '%s' "$text" | sed -E 's/.*->orderBy\(//' | sed -E 's/^[[:space:]]*//')"
    bad=0
    case "$arg" in
      '$request'*|'request('*|'$_GET'*|'$_POST'*|'$_REQUEST'*)
        bad=1
        ;;
      '$'*)
        var="$(printf '%s' "$arg" | grep -oE '^\$[A-Za-z_][A-Za-z0-9_]*')"
        varname="${var#\$}"
        start=$((ln - 15)); [ "$start" -lt 1 ] && start=1
        window="$(sed -n "${start},${ln}p" "$f" 2>/dev/null)"
        # The LAST assignment to this exact variable name before the orderBy()
        # call, inside the window — not just any line mentioning the name.
        # "Taken STRAIGHT from input" means the whole right-hand side IS the
        # request read, nothing else: `$sort = $request->input('sort');`. A
        # right-hand side that runs the request value through an allow-list or
        # a ternary first (`in_array($request->input(...), $allowed) ? … : …`)
        # is validated before it reaches orderBy() and must not fire — anchor
        # the pattern to the FULL line so a validator wrapped around the read
        # cannot match it.
        assign_line="$(printf '%s' "$window" | grep -E "^[[:space:]]*\\\$${varname}[[:space:]]*=" | tail -1)"
        grep -qE "^[[:space:]]*\\\$${varname}[[:space:]]*=[[:space:]]*(\\\$request->[A-Za-z_]+\([^;]*\)|request\([^;]*\)|\\\$_GET\[[^]]*\]|\\\$_POST\[[^]]*\]|\\\$_REQUEST\[[^]]*\])[[:space:]]*;[[:space:]]*\$" <<<"$assign_line" \
          && bad=1
        ;;
    esac
    [ "$bad" -eq 1 ] || continue
    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-140)"
    finding "php-sqli" "critical" "$rel:$ln" \
      "orderBy() column/direction is taken straight from the request — a caller can name any column: $safe"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <(grep -nE '\->orderBy\(' "$f" 2>/dev/null)
done <<< "$files"

exit 0
