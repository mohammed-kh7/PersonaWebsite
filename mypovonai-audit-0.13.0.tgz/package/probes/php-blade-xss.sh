#!/usr/bin/env bash
# php-blade-xss probe — evidence for rubric/php-blade-xss.md.
#
# Blade's `{{ $x }}` escapes; `{!! $x !!}` prints raw HTML. The construct is
# legitimate for genuinely trusted, view-local content (a template constant, a
# translation string, `$loop`) and for output already run through a formatter
# that escapes internally (`nl2br(e($x))` is the standard Laravel idiom for
# "preserve newlines, still escape everything else"). It is a finding only
# when the raw echo carries request or model data straight through, because
# that is attacker-controlled and now runs as HTML/JS in every visitor's
# browser — stored or reflected XSS depending on where the data came from.
#
# TWO SIGNALS, not one dense regex: (a) is the expression REQUEST-shaped or
# MODEL-shaped (a `->` property/method chain), and (b) is it wrapped by a
# known-safe call. Checking both on the raw line conflated `{!! $loop->iteration !!}`
# (a `->` chain that is never attacker data) and `{!! nl2br(e($news->description)) !!}`
# (a `->` chain that IS escaped) with the real thing on the first pass.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

if ! is_laravel; then
  skipped "php-blade-xss" "not a Laravel application (no composer dependency, no routes/ + app/)"
  exit 0
fi
files="$(blade_files)"
[ -n "$files" ] || { skipped "php-blade-xss" "no .blade.php templates found"; exit 0; }

# A call that escapes its own output before this construct hands it to the raw
# echo. `e()` is Laravel's htmlspecialchars wrapper; the others are the common
# third-party equivalents. Matched as a SUBSTRING of the expression, so
# `nl2br(e($x))` (escape, then re-add newlines outside the escaped text) counts
# — the wrapping call does not have to be outermost, it has to be present.
SAFE_WRAP='\be\(|\bclean\(|Purifier::clean\(|\bstrip_tags\(|htmlspecialchars\('

while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*Test*|*/vendor/*) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    # The expression between the FIRST `{!!` and the LAST `!!}` on the line.
    # Blade attribute contexts (`css='{!! ... !!}'`) and plain raw echoes both
    # reach here; both are graded the same way.
    expr="$(printf '%s' "$text" | sed -E 's/^[^{]*\{!!//' | sed -E 's/!!\}[^!]*$//')"
    [ -n "$expr" ] || continue

    # $loop is Blade's own safe iteration object — never attacker data.
    grep -qE '\$loop\b' <<<"$expr" && continue
    # __() / trans() — translation strings, developer-authored.
    grep -qE '\b(__|trans|trans_choice)\(' <<<"$expr" && continue

    is_request=0
    grep -qE '\$request->|request\(|\$_GET|\$_POST|\$_REQUEST|\$_COOKIE' <<<"$expr" && is_request=1
    is_model=0
    grep -qE '\$[A-Za-z_][A-Za-z0-9_]*->' <<<"$expr" && is_model=1
    { [ "$is_request" -eq 1 ] || [ "$is_model" -eq 1 ]; } || continue

    # Escaped before the raw echo -> not a finding, regardless of source.
    grep -qE "$SAFE_WRAP" <<<"$expr" && continue

    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-140)"
    if [ "$is_request" -eq 1 ]; then
      finding "php-blade-xss" "critical" "$rel:$ln" \
        "unescaped raw echo of request data — reflected XSS the first time an attacker controls it: $safe"
    else
      finding "php-blade-xss" "critical" "$rel:$ln" \
        "unescaped raw echo of model/object data with no escaping helper — stored XSS if that field is ever user-supplied: $safe"
    fi
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <(grep -nE '\{!!.*!!\}' "$f" 2>/dev/null)
done <<< "$files"

exit 0
