#!/usr/bin/env bash
# erasure-export-endpoints: bounded source candidates; see rubric/erasure-export-endpoints.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "erasure-export-endpoints" "$rel"; continue; fi
  finding "erasure-export-endpoints" "high" "$rel:$line" "Prisma projects storing email/phone require discoverable erasure and data-export route declarations."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "erasure-export-endpoints" "$ROOT")
exit 0
