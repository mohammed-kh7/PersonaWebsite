#!/usr/bin/env bash
# agent-security probe — evidence for standard/agent-security.md.
#
# This lens exists because the buyers of this audit build AI products, and the
# defect class it looks for does not appear in any conventional security scan:
# an agent becomes an exfiltration vector the moment ONE runtime simultaneously
# holds private data, untrusted content, and a way out.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

# Vendored / third-party trees are not this project's code: a plugin cache or a pip
# site-packages holds hundreds of other people's files, and grading them reports their
# trifecta as the user's. Matched on the path RELATIVE to $ROOT (an absolute match would
# also hide a checkout that merely lives under .../vendor/...). plugins/ is only a
# third-party tree on an agent-setup root (~/.claude); in a product repo it is source.
not_vendored() {
  local f rel c r="${ROOT%/}"
  local clones=()
  while IFS= read -r c; do [ -n "$c" ] && clones+=("$c"); done < <(nested_clone_roots)
  while IFS= read -r f; do
    rel="${f#"$r"/}"
    for c in ${clones[@]+"${clones[@]}"}; do case "$f" in "$c"/*) continue 2 ;; esac; done
    case "$rel" in
      */site-packages/*|*/dist-packages/*|vendor/*|*/vendor/*|.venv/*|*/.venv/*|venv/*|*/venv/*) continue ;;
      plugins/*|removed-*/*|plugin-cache/*|*/plugin-cache/*) is_agent_setup && continue ;;
    esac
    printf '%s\n' "$f"
  done
}

TS_INC=(--include='*.ts' --include='*.tsx' --include='*.js' --include='*.mjs' --include='*.py'
        --exclude-dir=node_modules "${BUILD_EXCL[@]}" --exclude-dir=.git)

# Is this even an AI project? Everything below is N/A otherwise, and an N/A is a
# verdict rather than a skip.
USES_AI=0
[ -n "$(grep -rlE "@anthropic-ai/|openai|langchain|llamaindex|@ai-sdk/|generativelanguage|bedrock-runtime" \
  "${TS_INC[@]}" "${PRODUCT_EXCL[@]}" --include='package.json' --include='requirements.txt' --include='pyproject.toml' \
  "$ROOT" 2>/dev/null | not_vendored | head -1)" ] && USES_AI=1

if [ "$USES_AI" = "0" ]; then
  skipped "agent-security" "no AI/agent SDK found in the dependency manifests or the source — the lethal trifecta cannot apply to a runtime that has no model in it. N/A, which is a verdict, not a gap."
  exit 0
fi

# --- 1. the lethal trifecta ------------------------------------------------
# Three legs, each detected separately, and reported only when all three land in
# the SAME file. Two legs is a normal program; three in one runtime is the shape
# that turns a prompt into an exfiltration.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *.test.*|*.spec.*|*.d.ts|*/node_modules/*) continue ;; esac

  grep -qiE "@anthropic-ai/|openai|generateText|createMessage|messages\.create|chat\.completions" "$f" 2>/dev/null || continue

  # leg 1 — private data in reach
  priv=0
  grep -qiE "process\.env\.[A-Z_]*(SECRET|TOKEN|KEY|PASSWORD|CREDENTIAL)|readFileSync\(|prisma\.|\.env" "$f" 2>/dev/null && priv=1
  # leg 2 — untrusted content in reach
  untrusted=0
  grep -qiE "req\.body|request\.json|searchParams|webhook|\.message|email|comment|issue|pull_request|scrape|fetchPage" "$f" 2>/dev/null && untrusted=1
  # leg 3 — a way out
  egress=0
  grep -qiE "fetch\(|axios|https?\.request|sendMail|sendMessage|\.post\(|execSync|spawn\(|writeFileSync" "$f" 2>/dev/null && egress=1

  if [ "$priv" = "1" ] && [ "$untrusted" = "1" ] && [ "$egress" = "1" ]; then
    # An isolation gate breaks one leg deliberately. Look for one before firing.
    if ! grep -qiE "sanitiz|isolat|allowlist|allowList|denyList|requireHuman|confirm\(|approval|guard|fence" "$f" 2>/dev/null; then
      ln=$(grep -niE "@anthropic-ai/|openai|generateText|messages\.create" "$f" | head -1 | cut -d: -f1)
      finding "agent-security" "critical" "$rel:${ln:-1}" "one runtime holds private data, untrusted content AND a path out, with no isolation gate — this is the lethal trifecta, and it makes the agent an exfiltration vector the first time an attacker controls any input it reads (agent-security 1)"
      evidence "grep -nE 'process.env|req.body|fetch\\(|execSync' $(qpath "$rel") | head -20"
    fi
  fi
done < <(grep -rlE "." "${TS_INC[@]}" "$ROOT" 2>/dev/null | not_vendored | head -400)

# --- 2. a base-url override an attacker can set ----------------------------
# CVE-2026-21852: an env var the agent runtime honours, pointed at a host the
# attacker owns, turns every request into a credential handoff.
# The filter below must see the CODE, never the path.
#
# `grep -rn` emits `path:line:content`, and a filter applied to that whole
# string reads the path too. Measured: the staged fixture directory sat under a
# TMPDIR ending in "/", so the path contained "//", the "//" comment filter ate
# the match, and this criterion silently stopped firing. A customer whose
# checkout lives under a path containing "#" or "//" would have lost the finding
# the same way and never known.
while IFS= read -r f; do
  [ -n "$f" ] || continue
  # Per FILE, so the content filter only ever sees content.
  ln="$(grep -nE "(ANTHROPIC|OPENAI)_BASE_URL" "$f" 2>/dev/null \
        | awk -F: '{ line=$1; $1=""; sub(/^:/,""); if ($0 !~ /unset|delete |\/\/|#/) { print line; exit } }')"
  [ -n "$ln" ] || continue
  hit="present"
  break
done < <(grep -rlE "(ANTHROPIC|OPENAI)_BASE_URL" "${TS_INC[@]}" "$ROOT" 2>/dev/null | not_vendored)

if [ -n "${hit:-}" ]; then
  finding "agent-security" "high" "${f#"$ROOT"/}:$ln" "an agent base URL is read from the environment and used as-is — an attacker who can set that variable redirects every model call, and the API key travels with it (agent-security, CVE-2026-21852). Pin the host or allowlist it"
  evidence "grep -nE '(ANTHROPIC|OPENAI)_BASE_URL' $(qpath "$f")"
fi

# --- 3. model output reaching a shell --------------------------------------
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *.test.*|*.spec.*) continue ;; esac
  grep -qiE "\b(exec|spawn)[A-Za-z]*[[:space:]]*\(|eval\(|Function\(" "$f" 2>/dev/null || continue
  grep -qiE "completion|\.text|message\.content|choices\[0\]|generateText|response\.output" "$f" 2>/dev/null || continue
  grep -qiE "allowlist|allowList|schema\.parse|zod|validate|sanitiz" "$f" 2>/dev/null && continue
  ln=$(grep -niE "\b(exec|spawn)[A-Za-z]*[[:space:]]*\(|eval\(" "$f" | head -1 | cut -d: -f1)
  finding "agent-security" "critical" "$rel:${ln:-1}" "model output reaches a shell or an eval with no validation step between them — a prompt injection becomes code execution, which is the whole of CVE-2025-59536 (agent-security 3)"
  evidence "grep -nE 'exec|spawn|eval\\(|message.content|choices\\[0\\]' $(qpath "$rel") | head -20"
  break
done < <(grep -rlE "." "${TS_INC[@]}" "$ROOT" 2>/dev/null | not_vendored | head -400)

# What a deterministic probe cannot settle here.
exit 0
