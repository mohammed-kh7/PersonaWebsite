#!/usr/bin/env bash
# mobile probe — evidence for standard/mobile.md.
# Gated on a mobile app existing — a web-only project cleanly N/As.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

MOBILE_DIR="$(product_find --first --maxdepth 3 -type d -name mobile -path '*apps*')"
[ -z "$MOBILE_DIR" ] && [ -f "$ROOT/app.json" ] && grep -qiE 'expo' "$ROOT/app.json" 2>/dev/null && MOBILE_DIR="$ROOT"
if [ -z "$MOBILE_DIR" ]; then
  skipped "mobile" "no apps/mobile (or expo app.json) — the project ships no mobile app, standard N/A"
  exit 0
fi

# apple-signin-missing (crit 1): a social provider present but no Sign in with
# Apple (Apple Guideline 4.8 rejection).
HAS_SOCIAL=0
grep -rqiE 'expo-auth-session|GoogleSignin|@react-native-google-signin|react-native-fbsdk|FacebookAuth|signInWithGoogle' "$MOBILE_DIR" --exclude-dir=node_modules "${BUILD_EXCL[@]}" 2>/dev/null && HAS_SOCIAL=1
if [ "$HAS_SOCIAL" = "1" ]; then
  if ! grep -rqiE 'expo-apple-authentication|AppleAuthentication|appleAuth|SignInWithApple' "$MOBILE_DIR" --exclude-dir=node_modules "${BUILD_EXCL[@]}" 2>/dev/null; then
    finding "mobile" "critical" "${MOBILE_DIR#"$ROOT"/}" "a social sign-in provider is present but Sign in with Apple is not — App Store Guideline 4.8 rejection (mobile 1)"
    evidence "grep -rli 'expo-apple-authentication\\|AppleAuthentication' $(qpath "$MOBILE_DIR") | grep -vE '/($BUILD_ALT|node_modules)/'"
  fi
fi

# att-triggering-sdk (medium 8): an ATT-triggering attribution SDK in the MVP.
hit="$(grep -rliE 'react-native-fbsdk|(^|[^a-z])adjust|react-native-branch|singular-react-native' "$MOBILE_DIR" --include='package.json' --exclude-dir=node_modules "${BUILD_EXCL[@]}" 2>/dev/null | head -1)"
if [ -n "$hit" ]; then
  finding "mobile" "medium" "${hit#"$ROOT"/}" "an ATT-triggering attribution SDK (fbsdk/adjust/branch/singular) is present — it forces an App Tracking Transparency prompt and complicates review (mobile 8)"
  evidence "grep -nE 'fbsdk|adjust|branch|singular' $(qpath "${hit#"$ROOT"/}")"
fi

exit 0
