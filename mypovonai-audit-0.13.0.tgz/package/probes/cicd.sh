#!/usr/bin/env bash
# cicd probe — evidence for standard/cicd.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

WF_DIR="$ROOT/.github/workflows"
if [ ! -d "$WF_DIR" ]; then
  finding "cicd" "high" "$ROOT" "no .github/workflows directory — the project has no CI"
  evidence "ls $(qpath "$ROOT/.github/workflows")"
  exit 0
fi

# gitleaks-scan (crit): some workflow must run gitleaks
if ! grep -rqi "gitleaks" "$WF_DIR" 2>/dev/null; then
  finding "cicd" "critical" "$WF_DIR" "no gitleaks scan in any workflow — committed secrets are never caught in CI"
  evidence "grep -rli gitleaks $(qpath "$WF_DIR")"
fi

# job-timeouts (high): every workflow that defines jobs should set timeout-minutes
for wf in "$WF_DIR"/*.yml "$WF_DIR"/*.yaml; do
  [ -e "$wf" ] || continue
  grep -qE '^\s*jobs:' "$wf" 2>/dev/null || continue
  # NOTE: `grep -c` already prints a number and exits 1 on zero matches; a
  # `|| echo 0` fallback would append a SECOND line ("0\n0") and break the
  # integer test below. Let grep -c stand alone.
  njobs=$(grep -cE '^\s{2}[A-Za-z0-9_-]+:\s*$' "$wf" 2>/dev/null); njobs=${njobs:-0}
  ntimeouts=$(grep -cE 'timeout-minutes:' "$wf" 2>/dev/null); ntimeouts=${ntimeouts:-0}
  if [ "$njobs" -gt 0 ] && [ "$ntimeouts" -eq 0 ]; then
    finding "cicd" "high" "${wf#"$ROOT"/}" "workflow defines jobs but no timeout-minutes anywhere — a hung job burns the full runner budget"
    evidence "grep -nE 'timeout-minutes|^\\s{2}[A-Za-z0-9_-]+:' $(qpath "$wf")"
  fi
done

exit 0
