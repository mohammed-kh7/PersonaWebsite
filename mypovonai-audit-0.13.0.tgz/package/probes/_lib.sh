#!/usr/bin/env bash
# Shared probe helpers. Probes ALWAYS exit 0 — a probe crashing must not be
# indistinguishable from a probe finding nothing. Absence of findings is a
# claim; it needs the same reporting path as a finding.
#
# Contract (one JSON object per line on stdout):
#   finding <lens> <severity> <location> <message>   — a graded defect
#   evidence <cmd>                                    — command that reproduces
#                                                       the finding ABOVE it
#   skipped <lens> <reason>                           — lens is N/A; NEVER drop
#                                                       a lens silently
ROOT="${1:-.}"
[ "$ROOT" = / ] || ROOT="${ROOT%/}"

_json_escape() {
  # backslash and quote, then newline/tab/CR as escapes, then drop any other control char:
  # an unescaped control character (a filename with a newline) breaks the JSONL line.
  local s="$1"
  s="${s//\\/\\\\}"; s="${s//\"/\\\"}"
  s="${s//$'\n'/\\n}"; s="${s//$'\t'/\\t}"; s="${s//$'\r'/\\r}"
  printf '%s' "$s" | LC_ALL=C tr -d '\000-\010\013\014\016-\037'
}

finding() { # lens severity location message
  # `site` is the probe file:line this finding was emitted from. It exists so
  # the fleet can measure coverage of ITS OWN gates: tests/site-coverage.sh
  # compares the sites a probe DECLARES against the sites its known-bad fixture
  # actually reaches. A finding site no fixture exercises is a gate that has
  # never been proven alive -- it will report clean forever and nothing says so.
  printf '{"type":"finding","lens":"%s","severity":"%s","location":"%s","message":"%s","site":"%s"}\n' \
    "$(_json_escape "$1")" "$(_json_escape "$2")" "$(_json_escape "$3")" "$(_json_escape "$4")" \
    "$(basename "${BASH_SOURCE[1]}"):${BASH_LINENO[0]}"
}

evidence() { # command that reproduces the finding
  printf '{"type":"evidence","cmd":"%s"}\n' "$(_json_escape "$1")"
}

skipped() { # lens reason
  printf '{"type":"skipped","lens":"%s","reason":"%s"}\n' \
    "$(_json_escape "$1")" "$(_json_escape "$2")"
}

# --- "Does this repo use X?" triggers must look at the PRODUCT, not samples -----
# A trigger grep that also scans fixtures/ or generated *.d.ts turns "no AI SDK
# in src/" into "AI SDK present" (measured: a repo with none got a critical from
# ai-transparency because only fixtures/** and worker-configuration.d.ts matched).
# Keep this list identical to SAMPLE_DIRS in paths.mjs; paths.test.mjs asserts it.
PRODUCT_EXCL=(--exclude-dir=fixtures --exclude-dir=__fixtures__ --exclude-dir=test-fixtures
              --exclude-dir=testdata --exclude-dir=__snapshots__ --exclude-dir=__mocks__
              --exclude='*.d.ts' --exclude='*.d.mts' --exclude='*.d.cts')

# --- Generated build output is never "the product" -----------------------------------------
# A probe that greps `.open-next/middleware/handler.mjs` grades the bundler, not the repo
# (measured: model-currency "ids in 2 files" on an OpenNext bundle). ONE list, used by every
# probe's file enumeration and trigger, matched as RELATIVE directory segments. Keep identical
# to BUILD_OUTPUT_DIRS in paths.mjs; build-output.test.mjs asserts all three arrays below.
BUILD_DIRS=(.open-next .next .nuxt .svelte-kit .output .vercel .wrangler dist build out coverage .turbo .cache)
# grep -r: skip these directories while descending.
BUILD_EXCL=(--exclude-dir=.open-next --exclude-dir=.next --exclude-dir=.nuxt --exclude-dir=.svelte-kit --exclude-dir=.output --exclude-dir=.vercel --exclude-dir=.wrangler --exclude-dir=dist --exclude-dir=build --exclude-dir=out --exclude-dir=coverage --exclude-dir=.turbo --exclude-dir=.cache)
# find run from INSIDE $ROOT (relative start): `-not -path` is then relative-safe.
BUILD_NOTPATH=(-not -path '*/.open-next/*' -not -path '*/.next/*' -not -path '*/.nuxt/*' -not -path '*/.svelte-kit/*' -not -path '*/.output/*' -not -path '*/.vercel/*' -not -path '*/.wrangler/*' -not -path '*/dist/*' -not -path '*/build/*' -not -path '*/out/*' -not -path '*/coverage/*' -not -path '*/.turbo/*' -not -path '*/.cache/*')
# For evidence commands that reproduce a grep: `| grep -vE "/($BUILD_ALT|node_modules)/"`.
BUILD_ALT='\.open-next|\.next|\.nuxt|\.svelte-kit|\.output|\.vercel|\.wrangler|dist|build|out|coverage|\.turbo|\.cache'

# `grep --exclude-dir` (and find -name) also test the scan ROOT itself, so auditing a directory
# that is literally called build/ or dist/ would silently scan nothing -- and nothing found reads
# as clean. Refuse out loud instead.
_root_base="$(cd "$ROOT" 2>/dev/null && basename "$(pwd -P)")"
for _d in "${BUILD_DIRS[@]}"; do
  if [ "$_root_base" = "$_d" ]; then
    skipped "$(basename "${BASH_SOURCE[1]:-$0}" .sh)" "scan root is itself a directory named '$_d' (a build-output name) — its contents would be excluded as build output; point the audit at the repository root instead"
    exit 0
  fi
done

# is_build_rel <path relative to $ROOT>: 0 when a DIRECTORY segment is build output (the file
# name never counts). For loops that already walk a list and filter on the relative path.
is_build_rel() {
  local d
  for d in "${BUILD_DIRS[@]}"; do
    case "/$1" in */"$d"/*) return 0 ;; esac
  done
  return 1
}

# build_find <find-expression...>: `find` under $ROOT that never DESCENDS into build output,
# evaluated with -mindepth 1 so the root itself is never pruned. Prints ABSOLUTE paths.
# Options (first): --maxdepth N, --print0. node_modules is pruned too: nothing here is ever about
# a dependency's source.
build_find() {
  local names=() d md=() pr=-print
  while :; do
    case "${1:-}" in
      --maxdepth) md=(-maxdepth "$2"); shift 2 ;;
      --print0) pr=-print0; shift ;;
      *) break ;;
    esac
  done
  for d in "${BUILD_DIRS[@]}" node_modules; do names+=(-o -name "$d"); done
  find "$ROOT" "${md[@]+"${md[@]}"}" -mindepth 1 \( -type d \( -false "${names[@]}" \) -prune \) -o \( "$@" "$pr" \) 2>/dev/null
}

# product_find [--first] <find-expression...>: `find` under $ROOT that never DESCENDS into
# sample dirs (same list as PRODUCT_EXCL / SAMPLE_DIRS), node_modules, vendor or .git. Use it
# for every "does this repo have X?" find. A bare `find "$ROOT" -type d -name integration`
# treats fixtures/**/integration (a deliberately-broken probe sample) as the product's
# integration suite (measured: false critical "tests/integration exists but no workflow runs it").
# Pruning is by directory NAME, evaluated from inside $ROOT with a relative start (`.`), so it
# is relative-path matching: a $ROOT that itself lives under node_modules/ or fixtures/ is not
# pruned (see the is_php note). Prints ABSOLUTE paths ($ROOT-prefixed). --first stops at the
# first hit; --maxdepth N (after --first) limits depth. PF_KEEP_VENDOR=1 keeps vendor/ in scope (the vendored-code probe looks FOR it).
product_find() {
  local first=0 p md=()
  [ "${1:-}" = "--first" ] && { first=1; shift; }
  [ "${1:-}" = "--maxdepth" ] && { md=(-maxdepth "$2"); shift 2; }
  local prune=(-name fixtures -o -name __fixtures__ -o -name test-fixtures -o -name testdata
               -o -name __snapshots__ -o -name __mocks__ -o -name node_modules -o -name .git)
  local bd; for bd in "${BUILD_DIRS[@]}"; do prune+=(-o -name "$bd"); done
  [ "${PF_KEEP_VENDOR:-0}" = 1 ] || prune+=(-o -name vendor)
  local tail=(-print); [ "$first" = 1 ] && tail=(-print -quit)
  ( cd "$ROOT" 2>/dev/null && find . "${md[@]+"${md[@]}"}" -mindepth 1 \( -type d \( "${prune[@]}" \) -prune \) -o \( "$@" \) "${tail[@]}" 2>/dev/null ) \
    | while IFS= read -r p; do printf '%s\n' "${ROOT%/}/${p#./}"; done
  return 0
}

# Legacy probes consume newline-delimited path lists. Refuse unsupported names
# explicitly rather than silently dropping files. New NUL-safe scanner wrappers
# are identified from their trusted installed source and retain full coverage.
_legacy_probe="${BASH_SOURCE[1]:-$0}"
if ! grep -q '_software-layer.mjs' "$_legacy_probe" 2>/dev/null; then
  _legacy_path_check="$(node - "$ROOT" <<'NODE'
const fs = require('node:fs');
const path = require('node:path');
const ignored = new Set(['.git','node_modules','vendor','fixtures','__fixtures__','test-fixtures','testdata','__snapshots__','__mocks__','.open-next','.next','.nuxt','.svelte-kit','.output','.vercel','.wrangler','dist','build','out','coverage','.turbo','.cache']);
let seen = 0;
const deadline = Date.now() + 2000;
function walk(dir) {
  for (const entry of fs.readdirSync(dir, {withFileTypes:true})) {
    if (++seen > 10000 || Date.now() > deadline) throw Error('pathname preflight exceeded bounds');
    if (entry.name.includes('\n') || entry.name.includes('\r')) throw Error('newline pathname unsupported by legacy probe');
    if (entry.isDirectory() && !ignored.has(entry.name)) walk(path.join(dir, entry.name));
  }
}
try {
  if (process.argv[2].includes('\n') || process.argv[2].includes('\r')) throw Error('newline scan root unsupported by legacy probe');
  walk(process.argv[2]);
} catch { process.stdout.write('pathname preflight incomplete or unsupported pathname'); }
NODE
)" || _legacy_path_check='pathname preflight unavailable'
  if [ -n "$_legacy_path_check" ]; then
    skipped "$(basename "$_legacy_probe" .sh)" "coverage incomplete: $_legacy_path_check"
    exit 0
  fi
fi

# --- Repo shape detection — drives N/A decisions ---------------------------
# (e.g. `mobile` on a web-only repo per standard/00-index.md: reported N/A,
# never silently dropped.)
has_mobile() { [ -d "$ROOT/ios" ] || [ -d "$ROOT/android" ] || ls "$ROOT"/*.xcodeproj >/dev/null 2>&1; }
has_prisma() { [ -n "$(product_find --first -name schema.prisma)" ]; }

# --- PHP / Laravel ----------------------------------------------------------
# Added 2026-09-23. Before this the fleet ran 34 probes against a Laravel 11 repo
# and 28 lenses answered "no TS/TSX source found": it scored a codebase whose
# whole /admin panel sat behind one hard-coded password as three generic findings.
# Is there PHP source in the tree being scanned?
#
# The exclusions are matched against the path RELATIVE to $ROOT, never the
# absolute one. `find -not -path '*/node_modules/*'` matches anywhere in the
# absolute path, so once this package is installed as a dependency -- fixtures
# living at node_modules/mypovonai-audit/fixtures/php-hygiene -- the probe
# excludes its OWN known-bad input and reports a clean repo. That failure mode
# already cost 17 of 29 gates once; tests/probe-fires.sh works around it by
# staging to a temp dir, and fleet.test.mjs asserts it directly.
#
# The exclusion itself is needed: is_php once accepted `vendor/` only, and ONE
# stray .php file inside a single npm dependency -- the only .php in the whole
# tree -- made a Next.js repository answer yes.
is_php() {
  local f rel
  while IFS= read -r f; do
    rel="${f#"$ROOT"/}"
    case "$rel" in
      node_modules/*|*/node_modules/*|vendor/*|*/vendor/*) continue ;;
      storage/*|*/storage/*|bootstrap/cache/*|*/bootstrap/cache/*) continue ;;
    esac
    return 0
  done < <(find "$ROOT" -name '*.php' -type f 2>/dev/null)
  return 1
}
# Laravel by EVIDENCE, not by one filename: a source snapshot (the shape a client
# actually sends) has composer.json, app/ and routes/ but no artisan, and a
# strict artisan check called a Laravel 11 repo "not Laravel".
is_laravel() {
  [ -f "$ROOT/artisan" ] && return 0
  [ -f "$ROOT/composer.json" ] && grep -q 'laravel/framework' "$ROOT/composer.json" 2>/dev/null && return 0
  { [ -f "$ROOT/routes/web.php" ] || [ -f "$ROOT/routes/api.php" ]; } && [ -d "$ROOT/app" ] && return 0
  return 1
}
is_wordpress() { [ -f "$ROOT/wp-config.php" ] || [ -d "$ROOT/wp-content" ]; }

# PHP sources worth auditing: never vendor/ (someone else's code), never
# storage/ or bootstrap/cache (generated), never node_modules.
php_files() {
  # Relative-path filtering, for the same reason as is_php above: an absolute
  # `-not -path '*/node_modules/*'` hides the fixtures from the probe that owns
  # them the moment this package is installed as a dependency.
  local f rel
  while IFS= read -r f; do
    rel="${f#"$ROOT"/}"
    case "$rel" in
      node_modules/*|*/node_modules/*|vendor/*|*/vendor/*) continue ;;
      storage/*|*/storage/*|bootstrap/cache/*|*/bootstrap/cache/*) continue ;;
    esac
    printf '%s\n' "$f"
  done < <(find "$ROOT" -name '*.php' -type f 2>/dev/null)
}

blade_files() {
  find "$ROOT" -name '*.blade.php' -type f \
    -not -path '*/vendor/*' -not -path '*/node_modules/*' -not -path '*/storage/*' \
    2>/dev/null
}

# Route declarations live in routes/ in Laravel, but a legacy app scatters them;
# fall back to any PHP file that declares a Route:: call.
route_files() {
  if [ -d "$ROOT/routes" ]; then
    find "$ROOT/routes" -name '*.php' -type f 2>/dev/null
  else
    grep -rl --include='*.php' -E '^[[:space:]]*Route::' "$ROOT" 2>/dev/null | grep -v '/vendor/'
  fi
}

# A deployable path is one that ships: public web roots and the app tree.
# Backups parked there are served, not ignored.
is_deployable_path() {
  # Judged on the path RELATIVE to $ROOT, like is_php and php_files. An absolute
  # match reads directories that belong to the machine, not to the repository: a
  # checkout living under any .../public/... or .../app/... parent would call
  # EVERY file deployable, and a repo staged under node_modules would call none
  # of them deployable. Same defect as the is_php node_modules bug, one helper over.
  local rel="${1#"$ROOT"/}"
  case "$rel" in
    vendor/*|*/vendor/*|node_modules/*|*/node_modules/*) return 1 ;;
    tests/*|*/tests/*|.git/*|*/.git/*) return 1 ;;
    public/*|*/public/*|app/*|*/app/*|routes/*|*/routes/*) return 0 ;;
    config/*|*/config/*|resources/*|*/resources/*) return 0 ;;
    *) return 1 ;;
  esac
}

# Mask a credential inside a source line before it is printed.
#
# Findings AND their evidence excerpts are uploaded, so a secrets probe that
# quotes the secret turns an audit into a leak. This FAILS CLOSED: the last arm
# masks any quoted literal that merely LOOKS like a credential, even under a key
# this function has never heard of. Over-redacting costs a little context; the
# location and the rubric still say where to look. Under-redacting costs the
# secret. Proven by tests/no-leak.sh, which greps the probe output for every
# literal in the fixtures -- the check that caught two rules printing the value
# verbatim, because the name-matching arms below required the key to be
# UNQUOTED and every real config array writes it as `'api_key' => '...'`.
redact_secrets() {
  sed -E \
    -e "s/(===?[[:space:]]*)'[^']*'/\1'<redacted>'/g" \
    -e "s/(===?[[:space:]]*)\"[^\"]*\"/\1\"<redacted>\"/g" \
    -e "s/((password|passwd|secret|token|api[_-]?key|key|hash|credential|salt|dsn)['\"]?[[:space:]]*(=>|=|:)[[:space:]]*)'[^']*'/\1'<redacted>'/Ig" \
    -e "s/((password|passwd|secret|token|api[_-]?key|key|hash|credential|salt|dsn)['\"]?[[:space:]]*(=>|=|:)[[:space:]]*)\"[^\"]*\"/\1\"<redacted>\"/Ig" \
    -e "s/(env\([[:space:]]*'[^']*'[[:space:]]*,[[:space:]]*)'[^']*'/\1'<redacted>'/g" \
    -e "s/(env\([[:space:]]*\"[^\"]*\"[[:space:]]*,[[:space:]]*)\"[^\"]*\"/\1\"<redacted>\"/g" \
    -e "s/'[A-Za-z0-9_.+\/-]*[0-9][A-Za-z0-9_.+\/-]*[A-Za-z][A-Za-z0-9_.+\/-]{10,}'/'<redacted>'/g" \
    -e "s/'[A-Za-z0-9_.+\/-]*[A-Za-z][A-Za-z0-9_.+\/-]*[0-9][A-Za-z0-9_.+\/-]{10,}'/'<redacted>'/g"
}


# All TS/TSX source files, excluding deps and build output.
src_files() {
  # build_find is relative-safe (a scan root under a dist/ PARENT is still scanned); the old
  # absolute `-not -path '*/dist/*'` was not.
  build_find \( -name '*.ts' -o -name '*.tsx' \) -type f
}

# --- Silent-checklist detection ---------------------------------------------
# Prints (relative to $ROOT) each agent-instruction file that tells the agent to
# run a checklist "silently". A silent checklist cannot fail: a skipped rule and
# a passed rule look identical (standard/gate-integrity.md, visible-skip).
# Shared by gate-integrity and any lens that grades the same instruction text.
silent_checklist_files() {
  local f rel
  while IFS= read -r f; do
    rel="${f#"$ROOT"/}"
    case "$rel" in node_modules/*|*/node_modules/*) continue ;; esac
    # Affirmative instructions only, judged PER CLAUSE (split on ; . , and the em dash): a
    # negation only counts when it directly precedes `silently` ("never silently skip") or the
    # verb phrase ("do not run through ... silently") in the SAME clause. A line-level filter
    # let "Run through all 15 rules silently; never silently skip" through as a non-defect.
    perl -CSD -ne 'for my $c (split /[;.,\x{2014}]/) {
        next unless $c =~ /(run|go) through .{0,40}silently|silently .{0,30}(check|rule|gate)/i;
        next if $c =~ /(?:\b(?:never|do not|not|no|without)|n\x27t)\s+(?:ever\s+)?silently/i;
        next if $c =~ /(?:\b(?:never|do not|not|no|without)|n\x27t)\s+(?:ever\s+)?(?:run|go) through/i;
        $h = 1 }
      END { exit($h ? 0 : 1) }' "$f" 2>/dev/null && printf '%s\n' "$rel"
  done < <(find "$ROOT" -maxdepth 3 \( -name 'CLAUDE.md' -o -name 'AGENTS.md' -o -name '.cursorrules' -o -name 'GEMINI.md' \) -type f 2>/dev/null)
  return 0
}

# Quote a repo-derived value for embedding in an evidence command. run.mjs runs
# evidence with `bash -c` on the auditors machine, so an unquoted or \"-quoted
# path such as a$(touch X).md would execute. Every repo-derived value goes through here.
# A leading dash would make a path an OPTION (a dir named --version, a file named
# -e.md); paths are relative to $ROOT, so ./ is equivalent and defuses it.
qpath() { case "$1" in -*) printf '%q' "./$1" ;; *) printf '%q' "$1" ;; esac; }

# Non-path values parsed out of repo content (line numbers, counts) can carry text
# when a filename contains ':' and shifts a split. Anything numeric that reaches an
# evidence command goes through num(): digits pass through, everything else becomes 0.
num() { case "$1" in ''|*[!0-9]*) printf 0 ;; *) printf '%s' "$1" ;; esac; }

# --- agent-setup target (a Claude Code / agent configuration, not a product repo) ---
# is_agent_setup: $ROOT holds CLAUDE.md, .claude/settings.json, settings.json next to a
# skills/ dir (a ~/.claude), or agents/*.md. The seven agent-* lenses answer `skipped`
# on anything else, so a product repo is never graded as if it were an agent setup.
is_agent_setup() {
  [ -f "$ROOT/CLAUDE.md" ] || [ -f "$ROOT/.claude/settings.json" ] \
    || { [ -f "$ROOT/settings.json" ] && [ -d "$ROOT/skills" ]; } \
    || [ -n "$(find "$ROOT/agents" -maxdepth 1 -name '*.md' -print -quit 2>/dev/null)" ]
}

# agent_files <glob...>: files under $ROOT whose basename matches any glob, as paths
# RELATIVE to $ROOT. A ~/.claude holds hundreds of thousands of transcript files, so
# the transcript/cache dirs are PRUNED (never descended into), not filtered afterwards.
# nested_clone_roots: on an agent-setup root, the directories BELOW $ROOT (never $ROOT itself)
# that carry their own .git - a vendored clone such as skills/_some-repo is someone else's code.
# Printed as absolute paths, one per line.
nested_clone_roots() {
  is_agent_setup || return 0
  local r="${ROOT%/}" g
  find "$r" \( -type d \( -name node_modules -o -name projects -o -name plugins -o -name 'removed-*' -o -name plugin-cache \) -prune \) \
    -o -name .git -not -path "$r/.git" -print 2>/dev/null | while IFS= read -r g; do dirname "$g"; done
}

agent_files() {
  local args=() g first=1 r="${ROOT%/}" d n
  local clones=()
  while IFS= read -r d; do [ -n "$d" ] && clones+=(-o -path "$d"); done < <(nested_clone_roots)
  local bk_prune=(-name backups) bk_not=(-not -name '*.bak*')
  # AGENT_FILES_BACKUPS=1 (agent-secrets-in-config): a token in settings.json.bak-2026... is
  # still a token on disk, so backup FILES (<glob>.bak*, <glob>.orig, <glob>.pre-*) are
  # scanned at any depth outside the still-pruned trees, and a backups/ dir is scanned too
  # unless it is huge (> AGENT_BACKUPS_MAX files, default 2000), where it is pruned by path.
  if [ "${AGENT_FILES_BACKUPS:-0}" = 1 ]; then
    bk_prune=(-path /nonexistent-backups-prune); bk_not=()
    while IFS= read -r d; do
      n="$(find "$d" -type f 2>/dev/null | head -n "$(( ${AGENT_BACKUPS_MAX:-2000} + 1 ))" | wc -l | tr -d ' ')"
      [ "$n" -gt "${AGENT_BACKUPS_MAX:-2000}" ] && bk_prune+=(-o -path "$d")
    done < <(find "$r" \( -type d \( -name node_modules -o -name .git -o -name plugins -o -name projects \) -prune \) -o -type d -name backups -print 2>/dev/null)
  fi
  for g in "$@"; do
    [ "$first" -eq 1 ] || args+=(-o)
    args+=(-name "$g"); first=0
    if [ "${AGENT_FILES_BACKUPS:-0}" = 1 ]; then
      args+=(-o -name "$g.bak*" -o -name "$g.orig" -o -name "$g.pre-*")
    fi
  done
  # plugins/ registers its own hooks (hooks.json) and holds most of a real ~/.claude's files;
  # removed-*/, backups and vendored trees are not this setup's live configuration either.
  find "$r" \( -type d \( -name projects -o -name file-history -o -name shell-snapshots \
      -o -name debug -o -name todos -o -name telemetry -o -name statsig -o -name node_modules -o -name .git \
      -o -name plugins -o -name 'removed-*' -o -name plugin-cache -o \( "${bk_prune[@]}" \) -o -name 'tcc-backup-*' \
      -o -name vendor -o -name downloads -o -name worktrees ${clones[@]+"${clones[@]}"} \) -prune \) \
    -o -type f -not -name '*.jsonl' ${bk_not[@]+"${bk_not[@]}"} \( "${args[@]}" \) -print 2>/dev/null \
    | while IFS= read -r f; do printf '%s\n' "${f#"$r"/}"; done | sort
}

# inside_root <path>: 0 only when <path> RESOLVES (symlinks and ../ followed) to a location
# inside the resolved $ROOT. Every agent-setup probe that follows a path read from config
# (a settings.json hook command, a skills/ entry, an .mcp.json link) must pass it first:
# those paths are repo- or user-controlled, and anything read outside $ROOT could surface in
# a finding or an evidence command that is uploaded or run. Files that fail are ignored
# silently - never named, never read.
_realpath() {
  realpath "$1" 2>/dev/null || node -e 'try{console.log(require("fs").realpathSync(process.argv[1]))}catch{process.exit(1)}' "$1" 2>/dev/null
}
inside_root() {
  local rp rr
  rp="$(_realpath "$1")" || return 1
  rr="$(_realpath "$ROOT")" || return 1
  case "$rp" in "$rr"|"$rr"/*) return 0 ;; esac
  return 1
}
