#!/usr/bin/env bash
# get-consumes-credential: bounded source candidates; see rubric/get-consumes-credential.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "get-consumes-credential" "$rel"; continue; fi
  finding "get-consumes-credential" "high" "$rel:$line" "GET handlers must not consume magic-link/reset credentials or establish sessions."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "get-consumes-credential" "$ROOT")
exit 0
