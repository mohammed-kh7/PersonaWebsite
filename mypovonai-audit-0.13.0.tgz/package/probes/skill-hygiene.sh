#!/usr/bin/env bash
# skill-hygiene probe — evidence for standard/skill-hygiene.md.
#
# This lens grades the AGENT's configuration, not the code it produced, so the
# probe reads two surfaces the other lenses never touch: the installed-skill
# tree (L2 apply/verify/dispose) and the CI review step's vendor (L5 the builder
# must not be the reviewer).
#
# Deliberately mechanical only where a grep can defend the claim:
#   - a SKILL.md that cannot be read, or carries no date anywhere → provenance
#   - a SKILL.md naming a dated/pinned model id → expired, not merely old
#   - every AI-invoking review/audit workflow naming ONE vendor → same-vendor review
# Review CADENCE and role ROTATION are handed to the interpreter: "when was this
# last read" and "would you install it again today" leave no trace in the tree.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

WF_DIR="$ROOT/.github/workflows"
SKILL_DIRS=""
for d in "$ROOT/.claude/skills" "$ROOT/.agents/skills" "$ROOT/skills"; do
  [ -d "$d" ] && SKILL_DIRS="${SKILL_DIRS}${d}"$'\n'
done

if [ -z "$SKILL_DIRS" ] && [ ! -d "$WF_DIR" ]; then
  skipped "skill-hygiene" "no installed-skill directory (.claude/skills, .agents/skills, skills/) and no .github/workflows — neither the skill-expiry (L2) nor the reviewer-rotation (L5) gate has a surface in this repo"
  exit 0
fi

# --- L2: apply / verify / dispose -----------------------------------------
# A dated model id is the expiry marker the standard names: a skill pinned to
# `claude-3-5-sonnet-20241022` or `gpt-4-0613` encodes a model generation, and
# every such workaround outlives the behaviour it was written for.
MODEL_PIN='claude-[0-9][.0-9]*-[a-z]+(-[0-9]{8})?|claude-3[.-]|gpt-4(o|-turbo|-[0-9]{4})|gpt-3\.5|text-davinci|gemini-1\.5|gemini-[0-9.]+-(pro|flash)-[0-9]{3}|llama-?[23][.-]|mistral-(tiny|small|medium)-[0-9]{4}'

while IFS= read -r root; do
  [ -n "$root" ] || continue
  total=0; unreadable=0; undated=0
  while IFS= read -r -d '' entry; do
    total=$((total + 1))
    sf="$entry/SKILL.md"
    if [ ! -r "$sf" ]; then
      # A dangling symlink or a dir with no manifest. The install is present in
      # the count and absent from every review — the accumulation the standard
      # warns about, in its purest form.
      unreadable=$((unreadable + 1))
      continue
    fi
    # A skill symlinked to a tree outside $ROOT is not read: its content must never reach a
    # finding or an evidence command (inside_root resolves symlinks and ../).
    inside_root "$sf" || continue
    grep -qE '[0-9]{4}-[0-9]{2}-[0-9]{2}' "$sf" || undated=$((undated + 1))
    if grep -qEi "$MODEL_PIN" "$sf"; then
      finding "skill-hygiene" "high" "${sf#"$ROOT"/}" "installed skill pins a specific model id / dated model release — it is EXPIRED, not merely old: it encodes workarounds for behaviour the model no longer has and competes for attention with the live instruction (skill-hygiene L2)"
      evidence "grep -niE '$MODEL_PIN' $(qpath "$sf")"
    fi
  done < <(find "$root" -mindepth 1 -maxdepth 1 \( -type d -o -type l \) -print0 2>/dev/null)

  [ "$total" -eq 0 ] && continue

  if [ "$unreadable" -gt 0 ]; then
    finding "skill-hygiene" "medium" "${root#"$ROOT"/}" "$unreadable of $total installed skills have no readable SKILL.md (dangling symlink or empty directory) — an install that cannot be read cannot be re-read or disposed on a cadence, only accumulated; skill count is a cost, not a capability score (skill-hygiene L2)"
    evidence "for d in $(qpath "$root")/*; do [ -r \"\$d/SKILL.md\" ] || echo \"UNREADABLE: \$d\"; done"
  fi
  if [ "$undated" -gt 0 ]; then
    finding "skill-hygiene" "medium" "${root#"$ROOT"/}" "$undated of $total installed skills record no date anywhere in SKILL.md — every install must record WHEN and WHY, or it can never be evaluated later (skill-hygiene L2); bulk installs are the highest risk because they arrive as a set and are never revisited individually"
    evidence "for d in $(qpath "$root")/*; do [ -r \"\$d/SKILL.md\" ] && ! grep -qE '[0-9]{4}-[0-9]{2}-[0-9]{2}' \"\$d/SKILL.md\" && echo \"UNDATED: \$d\"; done"
  fi
done <<<"$SKILL_DIRS"

# --- L5: the builder must not be the reviewer ------------------------------
# "AI-invoking" is judged on credential/action/CLI names, not the word "claude"
# in a comment — a vendor marker must be something that actually calls a model.
if [ -d "$WF_DIR" ]; then
  VENDORS=""
  REVIEW_WFS=""
  for wf in "$WF_DIR"/*.yml "$WF_DIR"/*.yaml; do
    [ -e "$wf" ] && inside_root "$wf" || continue
    body="$(cat "$wf" 2>/dev/null)"
    # Must be a review/audit gate, not any AI job (an eval or a codegen bot is
    # not the reviewer L5 is about).
    grep -qiE 'review|audit|critique' <<<"$body" || continue
    v=""
    grep -qE 'ANTHROPIC_API_KEY|CLAUDE_CODE_OAUTH_TOKEN|anthropics/claude|claude-code|@anthropic-ai' <<<"$body" && v="${v}anthropic"$'\n'
    grep -qE 'OPENAI_API_KEY|openai|AZURE_OPENAI|codex' <<<"$body" && v="${v}openai"$'\n'
    grep -qE 'GEMINI_API_KEY|GOOGLE_API_KEY|google-genai|gemini-cli|vertexai' <<<"$body" && v="${v}google"$'\n'
    grep -qE 'MISTRAL_API_KEY|DEEPSEEK_API_KEY|XAI_API_KEY|COHERE_API_KEY' <<<"$body" && v="${v}other-vendor"$'\n'
    [ -n "$v" ] || continue
    VENDORS="${VENDORS}${v}"
    REVIEW_WFS="${REVIEW_WFS}${wf#"$ROOT"/} "
  done

  if [ -z "$VENDORS" ]; then
    skipped "skill-hygiene" "no AI-invoking review/audit workflow found in .github/workflows — L5 (reviewer vendor differs from author vendor) cannot be graded from the tree; the interpreter must establish whether the diffs are AI-authored and, if so, what reviews them"
  else
    nv=$(sort -u <<<"$VENDORS" | grep -c .)
    if [ "$nv" -le 1 ]; then
      only=$(sort -u <<<"$VENDORS" | grep . | head -1)
      finding "skill-hygiene" "high" "${REVIEW_WFS% }" "every AI-invoking review/audit workflow calls the SAME vendor ($only) — if the diff is AI-authored by that vendor the review is same-vendor, and one vendor's blind spots are correlated across both roles, so the gate measures style adherence rather than correctness (skill-hygiene L5)"
      evidence "grep -rlE 'ANTHROPIC_API_KEY|CLAUDE_CODE_OAUTH_TOKEN|OPENAI_API_KEY|GEMINI_API_KEY' $(qpath "$WF_DIR")"
    fi
  fi
fi


exit 0
