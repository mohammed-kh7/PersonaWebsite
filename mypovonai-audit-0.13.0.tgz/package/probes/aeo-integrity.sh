#!/usr/bin/env bash
# aeo-integrity probe — evidence for standard/aeo-integrity.md.
# Statically-checkable subset only: the live-crawl/entity-consolidation criteria
# in the standard (canonical hreflang reciprocity, AI-crawler policy, entity
# fragmentation, substance floor) need a deployed URL and are a manual/live step
# in a full audit, not a repo grep — see standard/aeo-integrity.md §6.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

pages="$(product_find -type f -name 'page.tsx' -not -path '*/.next/*')"
if [ -z "$pages" ]; then
  skipped "aeo-integrity" "no Next.js app-router page.tsx found"
  exit 0
fi

# --- homepage-canonical-missing (high 4) ------------------------------------
# The homepage route (shallowest page.tsx under app/) vs. a deeper page route
# that DOES set canonical. Canonical coverage on product pages says nothing
# about the homepage, which is exactly the gap this was measured against.
homepage=""
deep_with_canonical=""
while IFS= read -r p; do
  rel="${p#"$ROOT"/}"
  after="${rel#*app/}"
  depth="$(tr -cd '/' <<<"$after" | wc -c | tr -d ' ')"
  if [ "$depth" -le 1 ] && [ -z "$homepage" ]; then
    homepage="$p"
  elif [ "$depth" -ge 2 ] && grep -qE 'canonical' "$p" 2>/dev/null; then
    deep_with_canonical="$p"
  fi
done <<< "$pages"

# canonical_via_helper <page>: 0 when the page's metadata DELEGATES to a local helper that sets the
# canonical. One level only: a relative or `@/` (-> src/, else the repo root) import whose imported
# name the page CALLS (`buildMetadata({...})`, `...seoFor(...)`), and whose module sets a
# `canonical:` key / `alternates.canonical` outside a comment. Imports that resolve outside $ROOT
# are never read. Absent in both page and helper = still a finding.
canonical_via_helper() {
  local page="$1" dir names spec base c f
  dir="$(dirname "$page")"
  while IFS='|' read -r names spec; do
    [ -n "$spec" ] || continue
    case "$spec" in
      @/*) base="$ROOT/src/${spec#@/}"; [ -d "$ROOT/src" ] || base="$ROOT/${spec#@/}" ;;
      ./*|../*) base="$dir/$spec" ;;
      *) continue ;;
    esac
    # at least one imported name must be CALLED by the page
    c=0
    for n in $names; do grep -qE "(^|[^A-Za-z0-9_.])${n}[[:space:]]*\(" "$page" 2>/dev/null && { c=1; break; }; done
    [ "$c" = 1 ] || continue
    for f in "$base.ts" "$base.tsx" "$base.js" "$base.mjs" "$base/index.ts" "$base/index.tsx"; do
      [ -f "$f" ] && inside_root "$f" || continue
      grep -vE '^[[:space:]]*(//|\*|/\*)' "$f" 2>/dev/null | grep -qE 'canonical[[:space:]]*:|alternates\.canonical' && return 0
    done
  done < <(perl -0777 -ne 'while (/import\s+(?:type\s+)?([\w\$]+)?\s*,?\s*(?:\{([^}]*)\})?\s*from\s*["\x27]([^"\x27]+)["\x27]/g) { my ($d, $b, $s) = ($1, $2, $3); my @n = (); push @n, $d if defined $d; for my $x (split /,/, (defined $b ? $b : "")) { $x =~ s/^\s*type\s+//; $x =~ s/.*\bas\s+//; $x =~ s/\s+//g; push @n, $x if length $x } print join(" ", @n) . "|" . $s . "\n" }' "$page" 2>/dev/null)
  return 1
}

if [ -n "$homepage" ] && [ -n "$deep_with_canonical" ] && ! grep -qE 'canonical' "$homepage" 2>/dev/null && ! canonical_via_helper "$homepage"; then
  rel="${homepage#"$ROOT"/}"
  deep_rel="${deep_with_canonical#"$ROOT"/}"
  finding "aeo-integrity" "high" "$rel" "the homepage route sets no canonical while a deeper route ($deep_rel) does — canonical coverage on product pages does not mean the homepage has one (aeo-integrity 4)"
  evidence "grep -n canonical $(qpath "$rel") $(qpath "$deep_rel")"
fi

# --- meta-description-not-locale-branched (high 1) --------------------------
# A page under an app/[locale]/ tree sets a literal description with no
# locale/lang interpolation in the surrounding lines.
while IFS= read -r p; do
  rel="${p#"$ROOT"/}"
  case "$rel" in *"[locale]"*) : ;; *) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    win="$(sed -n "$((ln>3?ln-3:1)),$((ln+3))p" "$p" 2>/dev/null)"
    grep -qE 'description:.*\$\{(locale|lang)\}|description:.*(locale|lang) *===' <<<"$win" && continue
    finding "aeo-integrity" "high" "$rel:$ln" "a locale-routed page sets a literal meta description with no reference to the locale/lang param — the same copy likely ships under every locale's lang attribute (aeo-integrity 1)"
    evidence "sed -n '$(num "$ln")p' $(qpath "$p")"
  done < <(grep -nE "description: *[\"']" "$p" 2>/dev/null)
done <<< "$pages"

exit 0
