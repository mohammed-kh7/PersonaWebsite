#!/usr/bin/env bash
# php-deps probe — evidence for rubric/php-deps.md.
#
# Ground rule for this lens (contract, `docs/plans/php-lens-contract.md`): do
# not guess CVEs, do not invent version numbers. Every check below is a fact
# that can be verified from the composer.json/composer.lock schema itself or
# from a public, dated, non-controversial end-of-life date — never a
# CVE database this probe has no way to query. Sources are cited inline.
# Calibrated to be SILENT on the work-wise repo (PHP ^8.2, Laravel v11.44.1,
# composer.lock present, minimum-stability stable + prefer-stable true — every
# one of the four checks below is clean there on purpose).
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

# This lens reads composer.json/composer.lock directly — it applies to any
# Composer-managed PHP project, not only a Laravel one, so it gates on the
# manifest rather than on is_laravel/is_php.
cj="$ROOT/composer.json"
if [ ! -f "$cj" ]; then
  skipped "php-deps" "no composer.json — not a Composer-managed PHP project"
  exit 0
fi

cl="$ROOT/composer.lock"

# --- 1. composer.lock absent → dependencies are unpinned (medium) ----------
# Without a lock file, `composer install` resolves whatever versions satisfy
# composer.json's ranges AT INSTALL TIME — two installs a week apart can pull
# different code. This is a structural fact readable from the filesystem, not
# a guess about any specific package.
if [ ! -f "$cl" ]; then
  finding "php-deps" "medium" "composer.json:1" \
    "composer.lock is absent — dependency versions are unpinned; two installs of this repo, even minutes apart, can resolve different package versions"
  evidence "test -f $(qpath "$ROOT/composer.lock") || echo 'composer.lock missing'"
fi

# --- 2. PHP constraint requires an end-of-life PHP (high) -------------------
# PHP 8.0 (EOL 2023-11-26) and earlier are past the PHP project's own security
# support window (php.net/supported-versions.php, dated policy, not a CVE
# lookup). A `"php": "^8.2"`-style constraint is read for its FLOOR version.
php_constraint="$(grep -oE '"php"[[:space:]]*:[[:space:]]*"[^"]+"' "$cj" 2>/dev/null | head -1 | sed -E 's/.*"([^"]+)"$/\1/')"
if [ -n "$php_constraint" ]; then
  floor="$(printf '%s' "$php_constraint" | grep -oE '[0-9]+\.[0-9]+' | head -1)"
  major="${floor%%.*}"
  minor="${floor#*.}"
  if [ -n "$major" ] && [ -n "$minor" ]; then
    # 8.1 is the EOL cutoff named in the contract: PHP < 8.1 is past support.
    if [ "$major" -lt 8 ] || { [ "$major" -eq 8 ] && [ "$minor" -lt 1 ]; }; then
      ln="$(grep -n '"php"[[:space:]]*:' "$cj" | head -1 | cut -d: -f1)"
      finding "php-deps" "high" "composer.json:$ln" \
        "the declared PHP constraint ($php_constraint) allows a PHP version below 8.1, which is past php.net's own security-support window"
      evidence "grep -n '\"php\"' $(qpath "$ROOT/composer.json")"
    fi
  fi
fi

# --- 3. Laravel major version is abandoned/EOL (high) -----------------------
# Laravel < 9 is past the framework's own published security-support window
# (laravel.com/docs/releases — a dated policy table, not a CVE lookup).
# Prefer the LOCKED version (what actually installs) over the composer.json
# range (what is merely allowed); fall back to the range only when there is
# no lock file to read.
laravel_version=""
if [ -f "$cl" ]; then
  # `-A5` after the name line is enough to reach "version" in composer.lock's
  # per-package block without a JSON parser.
  laravel_version="$(grep -A5 '"name": *"laravel/framework"' "$cl" 2>/dev/null | grep -m1 '"version"' | sed -E 's/.*"version": *"v?([0-9]+\.[0-9]+\.[0-9]+)".*/\1/')"
fi
laravel_source="composer.lock (locked version)"
if [ -z "$laravel_version" ]; then
  laravel_source="composer.json (declared range — no lock file to confirm the resolved version)"
  laravel_range="$(grep -oE '"laravel/framework"[[:space:]]*:[[:space:]]*"[^"]+"' "$cj" 2>/dev/null | head -1 | sed -E 's/.*"([^"]+)"$/\1/')"
  laravel_version="$(printf '%s' "${laravel_range:-}" | grep -oE '[0-9]+\.[0-9]+' | head -1)"
fi
if [ -n "$laravel_version" ]; then
  lmajor="${laravel_version%%.*}"
  if [ "$lmajor" -lt 9 ] 2>/dev/null; then
    ln="$(grep -n '"laravel/framework"' "$cj" | head -1 | cut -d: -f1)"
    [ -n "$ln" ] || ln=1
    finding "php-deps" "high" "composer.json:$ln" \
      "laravel/framework resolves to major version $lmajor (per $laravel_source), past Laravel's own published security-support window (Laravel < 9 is EOL)"
    evidence "grep -n '\"laravel/framework\"' $(qpath "$ROOT/composer.json")"
  fi
fi

# --- 4. minimum-stability: dev without prefer-stable (medium) --------------
# `"minimum-stability": "dev"` allows Composer to resolve ANY dev/alpha/beta
# release that satisfies a constraint's range, not just tagged stable
# releases — unless `"prefer-stable": true` tells it to prefer a stable
# release when one exists. Both keys are read directly off composer.json; no
# guessing which package would actually resolve unstable.
if grep -qE '"minimum-stability"[[:space:]]*:[[:space:]]*"dev"' "$cj" 2>/dev/null; then
  if ! grep -qE '"prefer-stable"[[:space:]]*:[[:space:]]*true' "$cj" 2>/dev/null; then
    ln="$(grep -n '"minimum-stability"' "$cj" | head -1 | cut -d: -f1)"
    finding "php-deps" "medium" "composer.json:$ln" \
      "minimum-stability is 'dev' with no prefer-stable — Composer can resolve an unstable (dev/alpha/beta) release of any dependency whose constraint allows one"
    evidence "grep -n 'minimum-stability\|prefer-stable' $(qpath "$ROOT/composer.json")"
  fi
fi


# --- 5. a locked dependency matches a PUBLISHED advisory (severity varies) ---
# The reason this lens shipped with only four STRUCTURAL facts was that it had
# no way to know a real vulnerability and would not guess one. It now has one:
# `data/advisories.json`, generated from GitHub's Security Advisory database by
# `tools/audit/build-advisory-table.mjs`, carrying the affected package and the
# vulnerable version range exactly as GitHub publishes them.
#
# WHAT THIS TABLE IS NOT, and the finding says so too: it is the most recent N
# advisories per ecosystem, NOT a complete vulnerability database. A package
# absent from it has NOT been cleared. Silence here is "not found in a partial
# table", never "clean" -- a false all-clear is the failure this fleet exists
# to avoid, and it would be a worse one than reporting nothing at all.
#
# Matching is CONSERVATIVE by construction. A version that is not plain dotted
# numerals (dev-main, a pre-release like 2.0.0-beta1, a branch alias) is skipped
# rather than guessed at, because a wrong match sends someone to patch software
# that was never affected. Skips are counted and reported, so the gap is visible
# rather than silent.
ADV_TABLE="$(dirname "$0")/../data/advisories.json"
if [ -f "$cl" ] && [ -f "$ADV_TABLE" ]; then

  # Compare two plain dotted-numeric versions. Echoes -1, 0 or 1.
  # Pure bash: `sort -V` is not dependable across BSD and GNU, and this pack has
  # already been bitten once by a BSD/GNU difference (`find -regex`) that passed
  # on macOS and died on CI.
  _ver_cmp() {
    local a="$1" b="$2" i x y
    IFS='.' read -r -a _va <<< "$a"
    IFS='.' read -r -a _vb <<< "$b"
    for i in 0 1 2 3; do
      x="${_va[$i]:-0}"; y="${_vb[$i]:-0}"
      x="${x##+(0)}"; y="${y##+(0)}"
      [ -z "$x" ] && x=0; [ -z "$y" ] && y=0
      if [ "$x" -gt "$y" ] 2>/dev/null; then echo 1; return; fi
      if [ "$x" -lt "$y" ] 2>/dev/null; then echo -1; return; fi
    done
    echo 0
  }
  _is_plain_version() { case "$1" in ''|*[!0-9.]*) return 1 ;; *) return 0 ;; esac; }

  gen_at="$(python3 -c "import json,sys;print(json.load(open(sys.argv[1])).get('generated_at',''))" "$ADV_TABLE" 2>/dev/null)"
  # Installed packages, one `name<TAB>version` per line, leading v stripped.
  installed="$(python3 - "$cl" <<'PY' 2>/dev/null
import json, sys
try:
    lock = json.load(open(sys.argv[1]))
except Exception:
    sys.exit(0)
for section in ("packages", "packages-dev"):
    for p in lock.get(section) or []:
        name, ver = p.get("name"), (p.get("version") or "").lstrip("vV")
        if name and ver:
            print(f"{name}\t{ver}")
PY
)"
  matched_any=0
  skipped_versions=0
  unbounded_flat=0
  if [ -n "$installed" ]; then
    while IFS="$(printf '\t')" read -r pkg ver; do
      [ -n "$pkg" ] || continue
      if ! _is_plain_version "$ver"; then skipped_versions=$((skipped_versions + 1)); continue; fi
      # Every advisory row for this exact package name.
      rows="$(python3 - "$ADV_TABLE" "$pkg" <<'PY' 2>/dev/null
import json, sys
table = json.load(open(sys.argv[1]))
for a in table.get("advisories", []):
    if a.get("ecosystem") == "composer" and a.get("package", "").lower() == sys.argv[2].lower():
        print("\t".join([a["id"], a.get("severity", "unknown"), a["range"], a.get("patched") or "", (a.get("summary") or "")[:90]]))
PY
)"
      [ -n "$rows" ] || continue
      hits=""; worst="low"
      while IFS="$(printf '\t')" read -r gid sev range patched summary; do
        [ -n "$gid" ] || continue
        # Every comma-separated constraint must hold for the range to match.
        in_range=1
        oldifs="$IFS"; IFS=','
        for c in $range; do
          c="$(printf '%s' "$c" | tr -d ' ')"
          op="$(printf '%s' "$c" | grep -oE '^(>=|<=|>|<|=)')"
          cv="${c#"$op"}"
          if ! _is_plain_version "$cv"; then in_range=0; break; fi
          cmp="$(_ver_cmp "$ver" "$cv")"
          case "$op" in
            '>=') [ "$cmp" -ge 0 ] || in_range=0 ;;
            '>')  [ "$cmp" -gt 0 ] || in_range=0 ;;
            '<=') [ "$cmp" -le 0 ] || in_range=0 ;;
            '<')  [ "$cmp" -lt 0 ] || in_range=0 ;;
            '=')  [ "$cmp" -eq 0 ] || in_range=0 ;;
            *)    in_range=0 ;;
          esac
          [ "$in_range" -eq 0 ] && break
        done
        IFS="$oldifs"
        [ "$in_range" -eq 1 ] || continue
        # THE BACKPORT TRAP, reported rather than suppressed.
        # Many advisories are filed as ONE FLAT range with no lower bound --
        # `<= 5.0.7` -- which by semver ordering swallows every earlier major
        # line. brace-expansion 1.1.18 and 2.1.4 ARE the fix and were still
        # reported vulnerable for exactly this reason
        # ([[advisory-flat-range-false-positive]], measured across two repos).
        # 49% of the composer rows in data/advisories.json are this shape.
        #
        # The first fix here SUPPRESSED these. That was wrong, and testing it
        # showed why: a package at 0.9.9 against `< 1.4.0` is almost certainly a
        # GENUINE hit, not a backport. The signal that made brace-expansion a
        # false positive was the RELEASE DATE of the patched line, which this
        # probe cannot read offline. Trading a false positive for a false
        # negative in a security lens is the worse direction.
        #
        # So the finding is reported, downgraded to medium, and carries the
        # 60-second check the reader needs to settle it themselves.
        flat_note=""; sev_cap=""
        if ! grep -qE -e '>=|>' <<<"$range"; then
          ceil="$(printf '%s' "$range" | grep -oE '[0-9][0-9.]*' | tail -1)"
          inst_major="${ver%%.*}"; ceil_major="${ceil%%.*}"
          if [ -n "$ceil_major" ] && [ "${inst_major:-0}" -lt "${ceil_major:-0}" ] 2>/dev/null; then
            unbounded_flat=$((unbounded_flat + 1))
            sev_cap="medium"
            flat_note=" [FLAT RANGE, VERIFY: this advisory names no lower bound, so it covers every earlier major line including yours. If $ver is a BACKPORTED fix released after the advisory, this is a false positive. Settle it with: gh api /advisories/$gid --jq .published_at  and compare against this version's release date.]"
          fi
        fi
        hits="$hits $gid($sev${patched:+, fixed in $patched})$flat_note"
        if [ -n "$sev_cap" ]; then
          case "$worst" in critical|high) ;; *) worst="medium" ;; esac
          continue
        fi
        case "$sev" in
          critical) worst="critical" ;;
          high) [ "$worst" = critical ] || worst="high" ;;
          moderate|medium) case "$worst" in critical|high) ;; *) worst="medium" ;; esac ;;
        esac
      done <<ADVROWS
$rows
ADVROWS
      [ -n "$hits" ] || continue
      matched_any=1
      case "$worst" in medium) sev_out="medium" ;; critical) sev_out="critical" ;; high) sev_out="high" ;; *) sev_out="low" ;; esac
      finding "php-deps" "$sev_out" "composer.lock:1" \
        "$pkg is locked at $ver, which falls inside the vulnerable range of published advisory/ies:$hits. Matched against data/advisories.json generated $gen_at — the most recent advisories per ecosystem, NOT a complete database, so absence from it is not a clean bill of health."
      evidence "grep -n $(qpath "\"name\": $pkg") -A2 composer.lock"
    done <<INSTALLED
$installed
INSTALLED
  fi
  if [ "$skipped_versions" -gt 0 ] && [ "$matched_any" -eq 0 ]; then
    skipped "php-deps" "$skipped_versions locked package(s) carry a non-numeric version (dev-*, pre-release) and were not matched against the advisory table rather than guessed at"
  fi
fi
exit 0
