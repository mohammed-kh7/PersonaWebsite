// Conservative PHP delegate recognition, never executes scanned source.
// Only an unconditional same-controller call on the routed request, preceding
// persistence, to a helper whose sole top-level return validates that parameter.
import { readFileSync, statSync } from 'node:fs';
function mask(source) {
  return source.replace(/\/\*[\s\S]*?\*\/|\/\/[^\n]*|#[^\n]*|'(?:\\[\s\S]|[^'\\])*'|"(?:\\[\s\S]|[^"\\])*"/g, value => value.replace(/[^\n]/g, ' '));
}
function close(text, start, left, right) {
  let depth = 0;
  for (let i = start; i < text.length; i++) {
    if (text[i] === left) depth++;
    else if (text[i] === right) {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}
function depthAt(body, end) {
  let depth = 0;
  for (const char of body.slice(0, end)) depth += char === '{' ? 1 : char === '}' ? -1 : 0;
  return depth;
}
try {
  const file = process.argv[2];
  if (statSync(file).size > 2_000_000) process.exit(0);
  const raw = readFileSync(file, 'utf8');
  if (raw.includes('<<<')) process.exit(0); // unsupported heredoc: retain finding
  const source = mask(raw);
  if ([...source.matchAll(/\bclass\s+[A-Za-z_]\w*/g)].length !== 1) process.exit(0);
  const methods = new Map();
  for (const match of source.matchAll(/\b(?:public|protected|private)\s+function\s+(\w+)\s*\(/g)) {
    const opening = match.index + match[0].lastIndexOf('(');
    const paramsEnd = close(source, opening, '(', ')');
    const bodyStart = source.indexOf('{', paramsEnd);
    if (paramsEnd < 0 || bodyStart < 0 || source.slice(paramsEnd, bodyStart).includes(';')) continue;
    const bodyEnd = close(source, bodyStart, '{', '}');
    if (bodyEnd < 0 || methods.has(match[1])) process.exit(0);
    methods.set(match[1], { params: source.slice(opening + 1, paramsEnd).split(','), body: source.slice(bodyStart + 1, bodyEnd) });
  }
  for (const [name, method] of methods) {
    const request = method.params.map(p => /\bRequest\s+(\$\w+)/.exec(p)?.[1]).find(Boolean);
    if (!request) continue;
    const write = /(?:::|->)(?:create|update|fill|forceFill|save|insert|insertGetId|updateOrCreate|firstOrCreate)\s*\(/.exec(method.body);
    if (!write) continue;
    for (const call of method.body.matchAll(/\$this->(\w+)\s*\(/g)) {
      if (call.index >= write.index || depthAt(method.body, call.index) !== 0) continue;
      // Reject unbraced conditional/loop calls as well as braced ones.
      const statement = method.body.slice(Math.max(method.body.lastIndexOf(';', call.index), method.body.lastIndexOf('}', call.index)) + 1, call.index);
      if (/\b(?:if|else|for|foreach|while|switch|function|fn|and|or|xor)\b|\?|&&|\|\|/.test(statement)) continue;
      const helper = methods.get(call[1]);
      if (!helper) continue;
      const argStart = call.index + call[0].lastIndexOf('(');
      const argEnd = close(method.body, argStart, '(', ')');
      if (argEnd < 0) continue;
      const args = method.body.slice(argStart + 1, argEnd).split(',').map(arg => arg.trim());
      const index = args.indexOf(request);
      const parameter = index < 0 ? null : /\bRequest\s+(\$\w+)/.exec(helper.params[index] ?? '')?.[1];
      if (!parameter) continue;
      const returns = [...helper.body.matchAll(/\breturn\b/g)];
      if (returns.length !== 1 || depthAt(helper.body, returns[0].index) !== 0) continue;
      const returnPrefix = helper.body.slice(Math.max(helper.body.lastIndexOf(';', returns[0].index), helper.body.lastIndexOf('}', returns[0].index)) + 1, returns[0].index);
      if (/\b(?:if|else|for|foreach|while|switch|function|fn|and|or|xor)\b|\?|&&|\|\|/.test(returnPrefix)) continue;
      const tail = helper.body.slice(returns[0].index);
      const escaped = parameter.replaceAll('$', '\\$');
      if (!new RegExp(`^return\\s+${escaped}->validate\\s*\\(`).test(tail)) continue;
      const validationStart = tail.indexOf('(');
      const validationEnd = close(tail, validationStart, '(', ')');
      if (validationEnd < 0 || !/^\s*;\s*$/.test(tail.slice(validationEnd + 1))) continue;
      console.log(name);
      break;
    }
  }
} catch { /* Failure retains the existing finding; never suppress on uncertainty. */ }
