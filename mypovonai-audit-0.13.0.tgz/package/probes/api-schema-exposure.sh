#!/usr/bin/env bash
# api-schema-exposure probe — evidence for standard/api-schema-exposure.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

files="$(src_files)"
if [ -z "$files" ]; then
  skipped "api-schema-exposure" "no TS/TSX source found"
  exit 0
fi

GREP_INC=(--include='*.ts' --include='*.tsx' --exclude-dir=node_modules "${BUILD_EXCL[@]}")

# --- introspection-not-disabled (crit 1): a GraphQL server with no explicit --
# introspection:false anywhere in the repo.
if grep -rlqE "apollo-server|ApolloServer|graphql-yoga|new Yoga\(|makeExecutableSchema" "${GREP_INC[@]}" "$ROOT" 2>/dev/null; then
  if ! grep -rqE "introspection *: *false" "${GREP_INC[@]}" "$ROOT" 2>/dev/null; then
    hit="$(grep -rlE "apollo-server|ApolloServer|graphql-yoga|new Yoga\(" "${GREP_INC[@]}" "$ROOT" 2>/dev/null | head -1)"
    ln="$(grep -nE "apollo-server|ApolloServer|graphql-yoga|new Yoga\(" "$hit" 2>/dev/null | head -1 | cut -d: -f1)"
    finding "api-schema-exposure" "critical" "${hit#"$ROOT"/}:$ln" "a GraphQL server is configured with no explicit introspection:false anywhere in the repo — one unauthenticated request returns the complete schema (api-schema-exposure 1)"
    evidence "grep -n 'ApolloServer\|introspection' $(qpath "$hit")"
  fi
fi

# --- public-swagger-ui (high 4): a Swagger/OpenAPI UI wired in with no visible
# production gate near the registration line.
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in *test*|*spec*|*fixture*) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    win="$(sed -n "$((ln>5?ln-5:1)),$((ln+5))p" "$f" 2>/dev/null)"
    grep -qiE "NODE_ENV *[!=]==? *['\"]production['\"]|isDev|isDevelopment" <<<"$win" && continue
    finding "api-schema-exposure" "high" "$rel:$ln" "a Swagger/OpenAPI UI route is registered with no visible production gate nearby — a public schema/documentation endpoint likely ships live (api-schema-exposure 4)"
    evidence "sed -n '$(num "$ln")p' $(qpath "$f")"
  done < <(grep -niE "swagger-ui|SwaggerModule\.setup|new Redoc\(" "$f" 2>/dev/null)
done <<< "$files"

exit 0
