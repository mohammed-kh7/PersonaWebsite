#!/usr/bin/env bash
# ssrf: bounded source candidates; see rubric/ssrf.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "ssrf" "$rel"; continue; fi
  finding "ssrf" "high" "$rel:$line" "Functions fetching a URL from request input require an explicit outbound URL/host validation call."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "ssrf" "$ROOT")
exit 0
