#!/usr/bin/env bash
# php-runtime-ddl probe — evidence for rubric/php-runtime-ddl.md.
#
# Schema changes executed at REQUEST time instead of by a migration.
#
# The finding that made this lens exist (ground truth SEC-013): a controller
# with `ensureNewsSchema()` and `newsSetup()` that call `Schema::table('blogs',…)`
# and `Schema::create('news_comments',…)` whenever an HTTP endpoint is hit. The
# code's own comment said it could be removed once run. It was not removed.
#
# A migration is reviewed, ordered, versioned and reversible. The same
# `Schema::table()` behind a web request is none of those: it runs with whatever
# privileges the app's database user holds, it runs again on every hit, it races
# with itself under concurrency, and it makes the schema of production a
# function of traffic.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

is_laravel || { skipped "php-runtime-ddl" "not a Laravel application (no composer dependency, no routes/ + app/)"; exit 0; }
files="$(php_files)"
[ -n "$files" ] || { skipped "php-runtime-ddl" "no PHP source outside vendor/"; exit 0; }

DDL_FACADE='Schema::(create|table|drop|dropIfExists|dropColumns|rename|disableForeignKeyConstraints|enableForeignKeyConstraints)\('
DDL_SQL='CREATE[[:space:]]+TABLE|ALTER[[:space:]]+TABLE|DROP[[:space:]]+TABLE|TRUNCATE[[:space:]]+TABLE|CREATE[[:space:]]+INDEX|ADD[[:space:]]+COLUMN|DROP[[:space:]]+COLUMN'

# A migration is a file under database/migrations/. A migration-SHAPED file
# living somewhere else is not treated as runtime DDL here: it is a class nobody
# calls, so it changes no schema at request time, and php-hygiene already reports
# it as a file in the wrong place. Reporting it twice, under two different
# accusations, would be noise.
_is_migration() {
  case "$1" in
    database/migrations/*) return 0 ;;
    *) ;;
  esac
  # a timestamped migration filename, wherever it has been copied to
  case "$(basename "$1")" in
    [0-9][0-9][0-9][0-9]_[0-9][0-9]_[0-9][0-9]_*.php) return 0 ;;
    *) return 1 ;;
  esac
}

VULN="$(mktemp "${TMPDIR:-/tmp}/runtimeddl-XXXXXX")"
trap 'rm -f "$VULN"' EXIT

# --- 1. schema builder called outside a migration (critical) ----------------
# Reported per METHOD, not per call: on the reference repo two methods hold most
# of 23 `Schema::` call sites, and 23 findings for one defect is the noise this
# pack exists to avoid (php-hygiene reports 276 backup files as ONE finding).
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  _is_migration "$rel" && continue
  case "$rel" in *test*|*Test*|*/vendor/*) continue ;; esac
  hits="$(grep -nE "$DDL_FACADE" "$f" 2>/dev/null)"
  [ -n "$hits" ] || continue
  # Attribute each hit to the function that encloses it: the nearest preceding
  # `function name(` line. That is the unit a reader has to go and delete.
  methods="$(printf '%s\n' "$hits" | while IFS= read -r h; do
    ln="${h%%:*}"
    m="$(head -n "$ln" "$f" | grep -nE '^[[:space:]]*(public|protected|private|static| )*[[:space:]]*function[[:space:]]+[A-Za-z_]' | tail -1)"
    if [ -n "$m" ]; then
      printf '%s\t%s\n' "${m%%:*}" "$(printf '%s' "${m#*:}" | grep -oE 'function[[:space:]]+[A-Za-z_][A-Za-z0-9_]*' | awk '{print $2}')"
    else
      printf '%s\t%s\n' "$ln" "(file scope)"
    fi
  done | sort -u)"
  while IFS="$(printf '\t')" read -r mline mname; do
    [ -n "$mline" ] || continue
    n="$(printf '%s\n' "$hits" | wc -l | tr -d ' ')"
    printf '%s\n' "$mname" >> "$VULN"
    finding "php-runtime-ddl" "critical" "$rel:$mline" \
      "$mname() changes the database SCHEMA at request time — it calls Laravel's schema builder outside any migration, so the shape of production is decided by traffic rather than by a reviewed, ordered, reversible migration. $n schema-builder call(s) in this file."
    evidence "grep -nE '$DDL_FACADE' $(qpath "$rel")"
  done <<METHODS
$methods
METHODS
done <<< "$files"

# --- 2. raw DDL through the query builder or PDO (critical) -----------------
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  _is_migration "$rel" && continue
  case "$rel" in *test*|*Test*) continue ;; esac
  while IFS= read -r m; do
    ln="${m%%:*}"
    text="${m#*:}"
    grep -qiE -e "$DDL_SQL" <<<"$text" || continue
    safe="$(printf '%s' "$text" | redact_secrets | sed 's/^[[:space:]]*//' | cut -c1-110)"
    finding "php-runtime-ddl" "critical" "$rel:$ln" \
      "raw DDL is executed at request time, outside any migration — the statement alters the schema with whatever privileges the application's database user holds: $safe"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <(grep -nE 'DB::statement\(|DB::unprepared\(|->unprepared\(' "$f" 2>/dev/null)
done <<< "$files"

# --- 3. the DDL is reachable over HTTP (high) -------------------------------
# Gated on criterion 1/2 having found something, the way php-idor's route
# criterion is gated on its method criterion.
#
# Resolves ONE HOP of indirection, because the routed method is rarely the one
# holding the DDL: on the reference repo `newsSetup()` is the public entry point
# and it calls the private `ensureNewsSchema()`, which does the schema change.
# Matching only the DDL method's own name found nothing and would have reported
# the defect as unreachable over HTTP — the opposite of what a reader needs.
#
# Built through a temp file, never `$( … <<HEREDOC … )`: a heredoc inside a
# command substitution inside another loop is the construct that has already
# silently produced an empty result once in this pack.
if [ -s "$VULN" ]; then
  REACH="$(mktemp "${TMPDIR:-/tmp}/ddlreach-XXXXXX")"
  sort -u "$VULN" | grep -v '^(file scope)$' > "$REACH"
  # one hop: any method whose body calls a flagged method
  while IFS= read -r v; do
    [ -n "$v" ] || continue
    while IFS= read -r f; do
      # NO `$` inside the alternation. `"(\$this->|self::)"` in a double-quoted
      # string becomes `($this->|self::)`, and ERE then reads that `$` as the
      # end-of-line anchor: the pattern matches NOTHING and exits 1, so the whole
      # caller lookup returned empty while every gate stayed green. Measured
      # here, after the same trap was already written into the pack's contract.
      grep -nE "this->${v}\(|self::${v}\(|static::${v}\(" "$f" 2>/dev/null | while IFS= read -r ch; do
        head -n "${ch%%:*}" "$f" 2>/dev/null \
          | grep -oE 'function[[:space:]]+[A-Za-z_][A-Za-z0-9_]*' | tail -1 | awk '{print $2}'
      done
    done <<DDLFILES
$files
DDLFILES
  done < <(sort -u "$VULN" | grep -v '^(file scope)$') >> "$REACH"
  sort -u "$REACH" -o "$REACH"

  route_list="$(route_files)"
  if [ -n "$route_list" ]; then
    while IFS= read -r rf; do
      [ -n "$rf" ] || continue
      rrel="${rf#"$ROOT"/}"
      while IFS= read -r mname; do
        [ -n "$mname" ] || continue
        hit="$(grep -nE "['\"]${mname}['\"]|@${mname}\b" "$rf" 2>/dev/null | head -1)"
        [ -n "$hit" ] || continue
        finding "php-runtime-ddl" "high" "$rrel:${hit%%:*}" \
          "a route reaches $mname(), which changes the schema (directly or one call away) — the DDL above is triggerable over HTTP rather than only by a deploy step or an artisan command"
        evidence "grep -n $(qpath "$mname") $(qpath "$rrel")"
        break
      done < "$REACH"
    done <<DDLROUTES
$route_list
DDLROUTES
  fi
  rm -f "$REACH"
fi
exit 0
