#!/usr/bin/env bash
# agent-containment probe — evidence for standard/agent-containment.md.
# Only the two repo-visible, grep-detectable checks are mechanical; hook
# REGISTRATION (criteria 5-7), config-weakening guards (3-4) and sandboxing
# (9-12) live in ~/.claude/settings.json and the host, so they go to the interpreter.
#
# Agent runtime = a `.claude/` directory at the root, OR source/manifest naming an
# agent SDK (claude-agent-sdk | @anthropic-ai/sdk | @openai/agents). None -> skipped.
#
# Check 1 — criterion 1, "Hook bypass is blocked, not discouraged":
#   runtime has a `.claude/` dir WITH hook wiring (.claude/settings*.json or .claude/hooks/ —
#   a skills/commands-only .claude/ registers hooks in ~/.claude/settings.json, out of view)
#   and  grep -rliE 'no-verify|core\.hooksPath' .claude  matches NOTHING
#   ->  no PreToolUse blocker for `git commit --no-verify`.
# Check 2 — criterion 8, "Credentials never reach a child process":
#   a .ts/.tsx/.js/.mjs line matching
#     env:[[:space:]]*(\{[[:space:]]*\.\.\.)?process\.env([[:space:]]*[,}]|$)
#   that also matches (spawn|exec|execFile|fork)[A-Za-z]*\( within 3 lines, where the
#   ENCLOSING function (nearest preceding function/arrow/method-signature line up to the
#   next one) has no  (KEY|PASSWORD|SECRET|TOKEN|CREDENTIAL)  scrub. EVERY such line in a
#   file is examined, not just the first, and a constant named API_KEY in another function
#   is not a scrub of this spawn.
# Both are heuristics: severity medium, "needs validation:".
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"

SRC_FILES=()
while IFS= read -r f; do
  rel="${f#"$ROOT"/}"
  case "$rel" in node_modules/*|*/node_modules/*|*.d.ts|dist/*|*/dist/*|.next/*|*/.next/*) continue ;; esac
  SRC_FILES+=("$f")
done < <(build_find \( -name '*.ts' -o -name '*.tsx' -o -name '*.js' -o -name '*.mjs' \) -type f)

runtime=0
[ -d "$ROOT/.claude" ] && runtime=1
if [ "$runtime" -eq 0 ] && [ -f "$ROOT/package.json" ] && grep -qE 'claude-agent-sdk|@anthropic-ai/sdk|@openai/agents' "$ROOT/package.json" 2>/dev/null; then runtime=1; fi
if [ "$runtime" -eq 0 ] && [ "${#SRC_FILES[@]}" -gt 0 ] && grep -lE 'claude-agent-sdk|@openai/agents' "${SRC_FILES[@]}" >/dev/null 2>&1; then runtime=1; fi

if [ "$runtime" -eq 0 ]; then
  skipped "agent-containment" "no agent runtime (.claude/ directory, or an agent SDK in package.json/source) — there is no unattended agent whose containment could be examined"
  exit 0
fi

# --- check 1: hook bypass is blocked (criterion 1) -------------------------
if [ -d "$ROOT/.claude" ] \
   && { [ -d "$ROOT/.claude/hooks" ] || [ -n "$(find "$ROOT/.claude" -maxdepth 1 -name 'settings*.json' -print -quit 2>/dev/null)" ]; } \
   && ! grep -rqiE 'no-verify|core\.hooksPath' "$ROOT/.claude" 2>/dev/null; then
  finding "agent-containment" "medium" ".claude" "needs validation: no hook that blocks --no-verify — nothing under .claude/ mentions --no-verify or core.hooksPath, so the bypass is discouraged by prose and enforced by no PreToolUse hook (agent-containment 1)"
  evidence "grep -rniE 'no-verify|core\\.hooksPath' .claude  # (none found)"
fi

# --- check 2: credentials reach child processes (criterion 8) --------------
P_ENV='env:[[:space:]]*(\{[[:space:]]*\.\.\.)?process\.env([[:space:]]*[,}]|$)'
for f in ${SRC_FILES[@]+"${SRC_FILES[@]}"}; do
  rel="${f#"$ROOT"/}"
  grep -qE "$P_ENV" "$f" 2>/dev/null || continue
  # one awk pass per file: every env-passthrough line next to a spawn, unless the enclosing
  # function (signature line .. next signature line) contains a scrub token.
  while IFS= read -r ln; do
    [ -n "$ln" ] || continue
    finding "agent-containment" "medium" "$rel:$ln" "needs validation: child process inherits the full environment — a spawn passes process.env whole with no KEY/PASSWORD/SECRET/TOKEN/CREDENTIAL scrub in the enclosing function, so every secret in the parent reaches every tool the agent runs (agent-containment 8)"
    evidence "sed -n '$(num "$ln")p' $(qpath "$rel")"
  done < <(awk -v pat="$P_ENV" '
    function sig(l) {
      if (l ~ /^[ \t]*(if|for|while|switch|catch|return)[ \t]*\(/) return 0
      if (l ~ /function[ \t]*[A-Za-z0-9_$]*[ \t]*\(/ || l ~ /=>/) return 1
      return (l ~ /^[ \t]*((public|private|protected|static|async|export)[ \t]+)*[A-Za-z_$][A-Za-z0-9_$]*[ \t]*\(.*\)[ \t]*(:[^{]*)?\{[ \t]*$/)
    }
    { L[NR] = $0; if (sig($0)) { S[NR] = 1 } }
    END {
      for (n = 1; n <= NR; n++) {
        if (L[n] !~ pat) continue
        sp = 0; lo = (n > 3 ? n - 3 : 1)
        for (i = lo; i <= n; i++) if (L[i] ~ /(spawn|exec|execFile|fork)[A-Za-z]*[ \t]*\(/) sp = 1
        if (!sp) continue
        a = n; while (a > 1 && !S[a]) a--
        e = n + 1; while (e <= NR && !S[e]) e++
        sc = 0
        for (i = a; i < e; i++) if (L[i] ~ /(KEY|PASSWORD|SECRET|TOKEN|CREDENTIAL)/) sc = 1
        if (!sc) print n
      }
    }' "$f" 2>/dev/null)
done

exit 0
