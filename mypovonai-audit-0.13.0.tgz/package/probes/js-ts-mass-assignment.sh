#!/usr/bin/env bash
# js-ts-mass-assignment: bounded source candidates; see rubric/js-ts-mass-assignment.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "js-ts-mass-assignment" "$rel"; continue; fi
  finding "js-ts-mass-assignment" "high" "$rel:$line" "A raw request-body binding must not be passed or spread directly into an ORM write."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "js-ts-mass-assignment" "$ROOT")
exit 0
