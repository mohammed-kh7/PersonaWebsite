#!/usr/bin/env bash
# consent-gate: bounded source candidates; see rubric/consent-gate.md.
set -uo pipefail
ROOT="${1:-.}"
. "$(dirname "$0")/_lib.sh" "$ROOT"
SCANNER="$(cd "$(dirname "$0")" && pwd)/_software-layer.mjs"
while IFS=$'\t' read -r line encoded; do
  [ -n "$line" ] || continue
  rel="$(printf '%s' "$encoded" | base64 -d)"
  if [ "$line" = SKIP ]; then skipped "consent-gate" "$rel"; continue; fi
  finding "consent-gate" "high" "$rel:$line" "Functions emitting analytics events or initialization require a visible consent gate, including admin source paths."
  evidence "node $(qpath "$SCANNER") --evidence $(qpath "$rel") $(num "$line")"
done < <(node "$SCANNER" "consent-gate" "$ROOT")
exit 0
