/** Source literals are private. Unknown output is withheld rather than guessed safe. */
export function privateEvidence(input) {
  let output = "", quote = "", block = false, line = false;
  const text = String(input);
  for (let i = 0; i < text.length; i++) {
    const c = text[i], next = text[i + 1];
    if (c === "\n") { output += c; line = false; continue; }
    if (line) continue;
    if (block) { if (c === "*" && next === "/") { block = false; i++; } continue; }
    if (quote) { if (c === "\\") { i++; continue; } if (c === quote) { output += quote; quote = ""; } continue; }
    if (c === "/" && next === "*") { block = true; i++; continue; }
    if ((c === "/" && next === "/") || c === "#") { line = true; i += c === "/" ? 1 : 0; continue; }
    if (["'", '"', "`"].includes(c)) { quote = c; output += c + "<literal withheld>"; continue; }
    output += c;
  }
  return output.split("\n").map(row => {
    if (!row.trim()) return "";
    // Plain env, YAML and assignment values may be unquoted credentials.
    if (/^\s*(?:\d+[: -]\s*)?[\w.-]+\s*[:=]/.test(row)) return "(assignment withheld)";
    // Only structural source lines survive; prose, diagnostics and opaque output do not.
    if (!/[{}();]/.test(row) || !/\b(?:const|let|var|return|if|function|class|import|export|await|throw|try|catch)\b|[.][A-Za-z_$][\w$]*\s*\(/.test(row)) return "(source excerpt withheld; inspect locally)";
    return row;
  }).join("\n");
}
