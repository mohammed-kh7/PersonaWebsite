# mypovonai-audit

A source audit that runs **on your machine** — one lens per concern in the Force AI production rubric.

```sh
npx -y mypovonai-audit@latest              # FREE local score + severity counts; uploads nothing
npx -y mypovonai-audit@latest score --share-dir ./audit-score  # optional local summary SVGs
npx -y mypovonai-audit@latest login <key>   # get one at https://mypovonai.com/en/audit/cli
npx -y mypovonai-audit@latest run           # probe locally, upload findings, get the report
npx -y mypovonai-audit@latest fix           # verified mechanical fixes, written as a patch
git apply mypovonai-fix/patch.diff
npx -y mypovonai-audit@latest rerun         # the proof: what cleared, what did not
```

## Interactive start

Run the command without arguments in a terminal to see the guided Score → Report → Fix flow. It checks for updates, asks for a project folder when needed, and runs the free local score first. Every scan command (including scripted score, run, rerun and fix) refuses home, filesystem root and their symlink aliases. A project must have .git or package.json. Invalid scripted targets exit 2 with one message and no score, scan or charge. A stored key never charges for this first score: the full report requires confirmation. Explicit commands, flags and piped output never open prompts. Use --repo /path/to/project to select a project, and --version to print the installed version.

## Supported stacks

| Stack | Detected by | Lenses |
|---|---|---|
| TypeScript / Next.js | `.ts`/`.tsx` source | the original pack |
| PHP / Laravel | `composer.json` naming `laravel/framework`, or `routes/` + `app/` | `php-*` lenses |

A lens that cannot apply to your repository says so by name and reason — it is
never counted as a pass. Laravel is detected by EVIDENCE rather than by one
filename: a source snapshot, which is the shape a client actually sends, has
`composer.json`, `app/` and `routes/` but no `artisan`, and a strict `artisan`
check called a real Laravel 11 repository "not Laravel".

## Free score and paid details

Bare invocation and `score` always run free, even with a stored key. `run` and `rerun` require a key; missing keys stop with login instructions. Explicit `run --free` remains a free-score compatibility option. They show an unjudged probe score, severity counts and coverage; no model, evidence commands, upload, token charge or saved scan. Actual findings and verified fix flow require a key and tokens: audit 200, fix 100, rerun 50. $25 buys 250 tokens; $100 buys 1000. A full audit/fix/rerun costs 350 tokens ($35). Existing paid flows are unchanged.

Local SVGs contain only score/counts. Paid scan reports link to public PNG score cards and README SVG badges; never publish findings or code. A score is a probe summary, not a security certification.

## Audit your agent setup

```bash
npx -y mypovonai-audit@latest run --repo /path/to/project
```

Run from a marked project that contains the agent configuration you want to audit (.git or package.json is required). A standalone configuration directory without either marker is refused.

The `agent-*` lenses grade the configuration you hand an agent:
hooks that are installed but never registered, literal secrets in scripts and configs,
the same skill or plugin loaded twice, always-loaded context that has grown past its
budget (or a SessionStart hook injecting an uncapped file), MCP servers whose credential
nothing provides, checklists that run "silently", and binding rules that live only in
prose. Transcripts, `plugins/`, caches and vendored trees are never read. Backup files
(`*.bak*`, `*.orig`, `*.pre-*`) ARE scanned for literal secrets - a token in
`settings.json.bak-2026...` is still a token on disk - as are `backups/` directories unless
they hold more than 2,000 files.

What the report upload excludes: file contents and source excerpts. A secret finding carries the
kind of secret, the file and the line number - never the value, in the finding or in the
evidence. On a product repo these lenses answer `skipped` by name.

## Source and model privacy

The probes run here. Uploads contain lens IDs, locations, finding messages and judge rulings. Source evidence excerpts are omitted. Optional judging sends masked structural context through your own model provider. Judge context masks literals, comments and unrecognized output before use; values needed to settle a finding require local inspection. The repository is never cloned by us and we never ask for access to it.

A credential embedded in your `origin` remote is stripped before the repository
name travels.

## It refuses to run on a broken gate

Before a single line of your code is measured, every probe is run against its
known-bad fixture, and every clean twin is run to prove the probe can also stay
quiet. If any probe fails to fire, the run stops: nothing is
uploaded and nothing is charged. A zero from a broken check cannot be told apart
from a clean repository, and we will not sell you one.

## Judging

Findings are located by deterministic probes and graded against the rubric.
`--judge local` additionally judges on this machine through your signed-in
`claude` CLI — no API key, nothing metered.

## Environment

- `MYPOVONAI_KEY` — override the stored key
- `MYPOVONAI_ENDPOINT` — override the endpoint
- `FLEET_CLAUDE_BIN` — path to the `claude` binary for `--judge local`

The terminal score card always prints the numeric score as `0/100` through `100/100`, alongside decorative digits in Unicode terminals. “Unjudged” means local probe findings have not been reviewed by a model.

### Score methodology (0.13.0 and later)

The score is the average across completed lenses. Each lens starts at 100; its worst finding deducts 100 for critical, 60 for high, 25 for medium or 10 for low. Repeated findings in that lens do not deduct again; severity counts still show all findings. The score describes probe signals, not a security probability or certification. An aggregate score can coexist with critical findings: review those first. Unavailable lenses are excluded and make coverage partial; no completed lenses means no score. JSON identifies this method as `lens-severity-v1`. Scores from earlier versions use a different formula and should not be compared directly. Historical published results retain their recorded values.

The locale-key probe resolves literal `useTranslations`, `useT` and `getTranslations` namespaces within lexical scopes. Dynamic/custom translator bindings are outside this lexical check; it does not prove complete bilingual parity. Output/traversal limits report incomplete coverage rather than claiming a process crash.
