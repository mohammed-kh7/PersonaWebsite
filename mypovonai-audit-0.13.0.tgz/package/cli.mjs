#!/usr/bin/env node
/**
 * `mypovonai-audit` — the no-trust tier (R-6).
 *
 * Probes run on the customer's machine. Report uploads contain findings and
 * rulings, never source excerpts. Optional judging uses the operator's own
 * model provider with masked structural context; free scoring calls no model.
 *
 * That is the whole point of this tier. The objection that loses the account is
 * "you want access to my source", and the answer to it cannot be a promise in a
 * privacy policy; it has to be an architecture where we could not take the
 * source if we wanted to.
 *
 *   mypovonai-audit login <key>          store the key in ~/.mypovonai/config.json
 *   mypovonai-audit run [--repo .]       probe locally, upload findings, print the report
 *   mypovonai-audit fix                  apply the verified mechanical fixes as a patch
 *   mypovonai-audit rerun                the proof: run again and diff against last time
 *   mypovonai-audit whoami               show the endpoint and whether a key is present
 */
import { chmodSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join, resolve } from "node:path";

import { projectFolder, runWizard, shouldRunWizard } from "./wizard.mjs";
import { isMain } from "./is-main.mjs";
import { scoreFromFindings, countSeverities, badgeSvg, SCORE_METHOD } from "./score.mjs";

import { loadLenses, proveGatesAlive, runFleet } from "./run.mjs";
import { sampleNotice } from "./paths.mjs";
import { commitOf, remoteUrlOf } from "./repo-read.mjs";
import { claudeCodeAvailable, resolveLocalSeat } from "./transports.mjs";
import { createUi, detectCaps, makeStyle, renderCard, renderFindings, renderBanner, safeText, sanitize, wrapText } from "./ui.mjs";

const VERSION = JSON.parse(
  readFileSync(new URL("./package.json", import.meta.url), "utf8"),
).version;

const CONFIG_DIR = join(homedir(), ".mypovonai");
const CONFIG_FILE = join(CONFIG_DIR, "config.json");
const DEFAULT_ENDPOINT = "https://mypovonai.com";

const say = (...a) => console.error(...a);

// Counted, not typed: the fleet grows and a number in a usage string has no
// way to find out.
const LENS_COUNT = loadLenses().length;

const USAGE = `mypovonai-audit — a ${LENS_COUNT}-lens source audit with source-free report uploads

  score [--repo .]   free local score, even if a key is stored (default command)
  login <key>        store the key in ~/.mypovonai/config.json (mode 600)
  run [--repo .]     requires a key and audit tokens; use score for free counts.
                     --share-dir DIR writes summary-only SVGs locally.
                     With a key: prove the gates, probe locally, use your model provider, upload the
                     findings, print the report
                     --name <id>    pin how this repo is identified across runs
                                    (default: the git origin URL, else the
                                    directory name — a rerun MUST match it)
                     --judge none   skip judging (findings keep their false
                                    positives)

  --json             also print the report as JSON on stdout (with a key: every
                     finding, every severity, full messages; free: score and
                     counts only); the human report stays on stderr
  --include-samples  also score findings under fixtures/, __fixtures__/, testdata/,
                     __snapshots__/, __mocks__/ (default: listed, not scored;
                     secret-class findings there are always scored)

  fix [--out DIR]    apply the verified mechanical fixes and write a patch you
                     apply — the middle of the loop, and a priced step
                     --scan <id>    which audit to fix (default: your last)
  rerun [--repo .]   run again; the server diffs it against your last audit
  whoami             show the endpoint and whether a key is present

The probes run on this machine, and so does the judge — on whatever seat you
already have: your \`ANTHROPIC_API_KEY\` if one is set, otherwise your signed-in
\`claude\` CLI. Judging uses your model provider with masked structural context. Free scoring
makes no model call.

Report uploads contain lens IDs, paths, messages and rulings. Source excerpts
are omitted. The repository is never cloned by us.

  MYPOVONAI_KEY       override the stored key
  MYPOVONAI_ENDPOINT  override the endpoint (default https://mypovonai.com)`;

export function readConfig() {
  try {
    return JSON.parse(readFileSync(CONFIG_FILE, "utf8"));
  } catch {
    return {};
  }
}

export function writeConfig(next) {
  mkdirSync(CONFIG_DIR, { recursive: true, mode: 0o700 });
  writeFileSync(CONFIG_FILE, `${JSON.stringify(next, null, 2)}\n`, {
    mode: 0o600,
  });
  // A credential file the rest of the machine can read is not a stored
  // credential, it is a published one. Set it explicitly: the mode argument to
  // writeFileSync does not apply to a file that already exists.
  chmodSync(CONFIG_FILE, 0o600);
}

const endpointOf = (config) =>
  process.env.MYPOVONAI_ENDPOINT?.trim() || config.endpoint?.trim() || DEFAULT_ENDPOINT;
const keyOf = (config) => process.env.MYPOVONAI_KEY?.trim() || config.key?.trim() || null;

/** HEAD's commit, read from .git (never by running git), or null when it cannot be read plainly. */
export { commitOf };

/**
 * What identifies the repository across runs. Never its contents.
 *
 * This string is hashed into `target_hash`, and the server finds a rerun's
 * baseline by that hash — so anything that changes it silently starts a NEW
 * audit at full price. Measured: a baseline taken in a directory with no
 * remote identified as `proofrepo`, the patched clone identified by its origin
 * URL, and a rerun that cleared seven findings was billed as a first audit with
 * no diff at all.
 *
 * The fallback to a directory name is kept, because a repository with no remote
 * still has to be auditable — but it is now REPORTED, and `--name` lets a
 * caller pin an identity that outlives the checkout.
 */
export function repoNameOf(repoPath) {
  try {
    // Same here: a repository with no `origin` is ordinary, and the fallback
    // below handles it. Measured on a fresh `git init`, git's own
    // "error: No such remote 'origin'" reached the customer's terminal on the
    // very first run and read as the tool breaking.
    const url = (remoteUrlOf(repoPath) ?? "").trim();
    if (!url) throw new Error("no origin");
    // Strip any credential a remote URL may carry; it is not ours and it must
    // not travel in a field whose purpose is naming a repository.
    return url.replace(/\/\/[^@/]*@/, "//");
  } catch {
    return resolve(repoPath).split("/").pop() ?? "repo";
  }
}

/** The upload body. Everything not in this shape stays on the machine. */
export function buildSubmission(report, { repo, commit }) {
  const findings = [];
  const byIdentity = new Map();
  const ran = [];
  const unavailable = [];
  // Lenses whose interpreter ERRORED. The probe ran and was charged for, but
  // the lens was never settled — so the customer paid for a verdict they did
  // not get. Reported so the server can refund that share rather than leaving
  // it to a support request nobody will make.
  const uninterpreted = [];
  for (const lens of report.lenses ?? []) {
    const rows = [
      ...(Array.isArray(lens.candidates) ? lens.candidates : []),
      ...(lens.interpreter?.findings ?? []),
    ];
    if (lens.status === "probe-crashed") unavailable.push(lens.id);
    else ran.push(lens.id);
    if (lens.interpreter?.ruling === "errored") uninterpreted.push(lens.id);
    for (const row of rows) {
      if (row.verdict?.ruling === "false-positive") continue;
      // Collapse repeats of the SAME finding.
      //
      // Identity deliberately drops the `:line` suffix, because a patch shifts
      // line numbers and a rerun must still recognise the finding. The
      // consequence is that one lens reporting the same message for seven
      // different lines of one file produces seven rows with ONE identity --
      // and `audit_findings` is keyed on (identity, scan_id), so the upload
      // used to fail the whole batch with a constraint violation and answer
      // 503. Measured on this repository: 68 rows, 47 identities.
      //
      // One file carrying one defect is ONE finding. The other line numbers are
      // evidence of how widespread it is, so they are counted, not discarded.
      const seen = byIdentity.get(row.identity);
      if (seen) {
        seen.occurrences += 1;
        continue;
      }
      const finding = {
        lens: lens.id,
        severity: row.severity ?? "medium",
        location: String(row.location ?? "").slice(0, 1024),
        message: String(row.message ?? "").slice(0, 4000),
        identity: row.identity,
        occurrences: 1,
        // The judge's ruling travels with the finding. Dropping a false
        // positive locally is only half of judging: without the ruling the
        // server cannot tell a CONFIRMED finding from one nothing ever looked
        // at, and the reason -- the part a customer argues with -- is lost.
        ...(row.verdict?.ruling
          ? {
              ruling: row.verdict.ruling,
              ...(row.verdict.why
                ? { why: String(row.verdict.why).slice(0, 1000) }
                : {}),
            }
          : {}),
      };
      byIdentity.set(row.identity, finding);
      findings.push(finding);
    }
  }
  return {
    repo,
    commit,
    lensesProven: report.lensesProven ?? 0,
    coverage: {
      ran,
      unavailable,
      ...(uninterpreted.length ? { uninterpreted } : {}),
    },
    findings,
    // Which seat judged, so the report can say so instead of guessing. Null
    // when nothing judged -- and that is reported as unjudged, never as clean.
    ...(report.judgedBy
      ? { judgedBy: String(report.judgedBy).slice(0, 32) }
      : {}),
  };
}

async function post(endpoint, key, body, path = "/api/audit/source") {
  const response = await fetch(`${endpoint}${path}`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${key}`,
    },
    body: JSON.stringify(body),
  });
  const text = await response.text();
  let payload;
  try {
    payload = JSON.parse(text);
  } catch {
    payload = {
      ok: false,
      error: "unreadable_response",
      status: response.status,
      body: text.slice(0, 300),
    };
  }
  return { status: response.status, payload };
}

/** The rich (TTY) layout of the same report: card, run facts, grouped findings, then rerun diff and report URL. */
function printRichReport(ui, submission, payload, repoSource, endpoint, samples) {
  const { caps } = ui;
  const s = makeStyle(caps.color);
  const counts = countSeverities(submission.findings);
  const rows = (pairs) =>
    pairs.flatMap(([k, v]) =>
      wrapText(sanitize(v), caps.width - 14, { indent: "", hang: "" }).map(
        (line, i) => `  ${s.dim((i === 0 ? k : "").padEnd(10))}  ${line}`,
      ),
    );
  ui.out(
    renderCard(
      {
        score: scoreFromFindings(submission.findings, submission.coverage),
        counts,
        coverage: payload.coverage,
        samples,
        judged: payload.judged === false ? false : submission.judgedBy ? true : null,
        label: "audit score",
        note: ["Lens-weighted score; counts show all findings.", payload.judged === false ? payload.note : null].filter(Boolean).join(" "),
      },
      caps,
    ),
  );
  const meta = [
    ["repo", `${submission.repo}${repoSource ? `  (${repoSource})` : ""}`],
    ["scan", String(payload.scanId)],
    ["charged", `${payload.charged} token(s), balance ${payload.balance}`],
  ];
  if (payload.refunded > 0) {
    const missed = Array.isArray(payload.uninterpreted) ? payload.uninterpreted.join(", ") : "";
    meta.push([
      "refunded",
      `${payload.refunded} token(s) — ${payload.uninterpreted?.length ?? 0} lens(es) could not be settled${missed ? `: ${missed}` : ""}`,
    ]);
  }
  ui.out(rows(meta).join("\n"));
  ui.out("");
  ui.out(renderFindings(submission.findings, caps));
  const tail = [];
  if (payload.rerun) {
    tail.push([
      "rerun",
      `${payload.rerun.cleared} cleared · ${payload.rerun.stillPresent} still present · ${payload.rerun.introduced} introduced (against ${payload.parentScanId})`,
    ]);
  } else {
    tail.push([
      "rerun",
      `none — this is the FIRST audit recorded for "${submission.repo}". A later run must report the same name (--name) to be diffed against this one`,
    ]);
  }
  tail.push(["report", `${endpoint}/en/audit/reports/${payload.scanId}`]);
  ui.out(rows(tail).join("\n"));
  ui.out("");
}

function printReport(submission, payload, repoSource, endpoint, ui, samples = []) {
  if (ui?.rich) return printRichReport(ui, submission, payload, repoSource, endpoint, samples);
  // The repo name comes from the git origin of the audited checkout.
  submission = { ...submission, repo: safeText(submission.repo) };
  const bySeverity = { critical: 0, high: 0, medium: 0, low: 0 };
  for (const f of submission.findings)
    bySeverity[f.severity] = (bySeverity[f.severity] ?? 0) + 1;
  say("");
  say(
    `  repo        ${submission.repo}${repoSource ? `  (${repoSource})` : ""}`,
  );
  say(`  scan        ${payload.scanId}`);
  say(
    `  findings    ${payload.total}  (critical ${bySeverity.critical}, high ${bySeverity.high}, medium ${bySeverity.medium}, low ${bySeverity.low})`,
  );
  say(
    `  lenses      ${payload.coverage.ran.length} ran, ${payload.coverage.unavailable.length} unavailable`,
  );
  say(`  charged     ${payload.charged} token(s), balance ${payload.balance}`);
  // Refunded when interpreters errored: the customer paid for lenses that were
  // never settled, and the credit is automatic rather than on request.
  if (payload.refunded > 0) {
    const missed = Array.isArray(payload.uninterpreted)
      ? payload.uninterpreted.join(", ")
      : "";
    say(
      `  refunded    ${payload.refunded} token(s) — ${payload.uninterpreted?.length ?? 0} lens(es) could not be settled${missed ? `: ${missed}` : ""}`,
    );
  }
  // The report is KEPT. Without this line the findings live only in this
  // scrollback, which is where every audit before today went to die.
  say(`  report      ${endpoint}/en/audit/reports/${payload.scanId}`);
  // Always say which this was. Printing the diff only when a parent happened to
  // be found meant a run that LOST its baseline looked exactly like a first
  // audit -- and the only visible difference was the charge.
  if (payload.rerun) {
    say(
      `  rerun       ${payload.rerun.cleared} cleared, ${payload.rerun.stillPresent} still present, ${payload.rerun.introduced} introduced`,
    );
    say(`              (against ${payload.parentScanId})`);
  } else {
    say(
      `  rerun       none — this is the FIRST audit recorded for "${submission.repo}"`,
    );
    say(
      `              a later run must report the same name to be diffed against this one`,
    );
  }
  if (payload.judged === false) say(`  note        ${safeText(payload.note)}`);
  say("");
  printFindings(submission.findings);
}

const SEVERITY_ORDER = ["critical", "high", "medium", "low"];

/**
 * EVERY finding, every severity, full message. This used to print critical and
 * high only, cut at 150 characters: on a 47-finding run 21 medium/low rows (and
 * the tail of every message) never reached the operator's terminal.
 */
export function printFindings(findings) {
  const rank = (f) => {
    const i = SEVERITY_ORDER.indexOf(f.severity);
    return i === -1 ? SEVERITY_ORDER.length : i;
  };
  const sorted = [...findings].sort((a, b) => rank(a) - rank(b));
  for (const f of sorted) {
    say(safeText(`  ${String(f.severity).padEnd(8)} ${String(f.lens).padEnd(22)} ${f.location}`));
    say(safeText(`           ${f.message}`));
  }
}

export async function cmdRun({
  repoPath,
  config,
  prefer,
  pinnedName,
  shareDir,
  forceFree = false,
  includeSamples = false,
  json = false,
  showNextStep = true,
  ui = createUi(detectCaps({ json })),
}) {
  const key = forceFree ? null : keyOf(config);
  ui.banner(VERSION);
  if (!key) {
    const report = await runFleet({
      repoPath,
      transport: null,
      interpret: false,
      includeSamples,
      onProgress: ui.rich ? ui.note : () => {},
      onStage: ui.stage,
    });
    ui.settle();
    if (report.aborted) {
      ui.abort();
      say(
        `REFUSED: ${report.deadGates?.length ?? 0} dead gate(s). No score can be trusted.`,
      );
      say("nothing was uploaded and nothing was charged.");
      return 1;
    }
    const submission = buildSubmission(report, { repo: "local", commit: null });
    const counts = countSeverities(submission.findings);
    if (submission.coverage.ran.length === 0) {
      say("inconclusive: no probes ran. No score can be trusted.");
      return 1;
    }
    const score = scoreFromFindings(submission.findings, submission.coverage);
    if (ui.rich) {
      ui.out(
        renderCard(
          {
            score,
            counts,
            coverage: submission.coverage,
            samples: report.samples ?? [],
            judged: false,
            note: "Lens-weighted score; counts show all findings. A probe signal, not a security certification.",
          },
          ui.caps,
        ),
      );
    } else {
      say(`probe score: ${score}/100 (unjudged; not a security certification)`);
      say(
        `${counts.critical} critical · ${counts.high} high · ${counts.medium} medium · ${counts.low} low`,
      );
      say(
        `${submission.coverage.ran.length} probes ran · ${submission.coverage.unavailable.length} unavailable`,
      );
      if (report.samples?.length) for (const l of sampleNotice(report.samples)) say(safeText(l));
    }
    ui.info("nothing uploaded · nothing charged · no model called");
    if (json) {
      // The free score deliberately withholds finding detail (the paid report
      // has it), so the JSON matches what the terminal shows: score + counts.
      // stdout carries ONLY the JSON; everything above went to stderr.
      console.log(JSON.stringify({ mode: "free", score, scoring: SCORE_METHOD, counts, coverage: submission.coverage, samples: report.samples ?? [] }, null, 2));
    }
    if (shareDir) {
      mkdirSync(shareDir, { recursive: true });
      writeFileSync(join(shareDir, "badge.svg"), badgeSvg(score, counts));
      writeFileSync(
        join(shareDir, "score-card.svg"),
        `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" role="img"><rect width="1200" height="630" fill="#090909"/><g font-family="Arial,sans-serif" fill="#fff"><text x="70" y="100" font-size="30">mypovonai · local probe score</text><text x="70" y="330" font-size="160">${score}/100</text><text x="70" y="440" font-size="32">${counts.critical} critical · ${counts.high} high · ${counts.medium} medium · ${counts.low} low</text><text x="70" y="540" font-size="24">Unjudged. A probe signal, not a security certification.</text></g></svg>`,
      );
      say(`share files: ${shareDir} (score/counts only; upload them yourself)`);
    }
    const cta = `see the findings and fixes: ${endpointOf(config).replace(/\/$/, "")}/en/pricing`;
    if (showNextStep) {
      if (ui.rich) ui.out(`  ${makeStyle(ui.caps.color).bold(cta)}\n`);
      else say(cta);
    }
    ui.farewell();
    return 0;
  }
  ui.plain("proving the gates are alive before measuring anything...");
  ui.begin("gates");
  const gates = proveGatesAlive();
  if (!gates.ok) {
    // Refusing is the correct outcome. A run past a dead gate produces zeros
    // that read as clean, and the customer would be charged for them.
    ui.abort();
    say(`REFUSED: ${gates.dead.length} dead gate(s): ${gates.dead.join(", ")}`);
    say("nothing was uploaded and nothing was charged.");
    return 1;
  }
  ui.end("gates", `${gates.alive.length} gates proven`);
  ui.plain(`  ${gates.alive.length} gates proven`);

  const commit = commitOf(repoPath);
  if (!commit) {
    say(
      `${repoPath} is not a git checkout — a finding with no commit cannot be rerun against anything.`,
    );
    return 2;
  }
  if (prefer === "local" && !claudeCodeAvailable()) {
    say("--judge local needs the `claude` CLI on your PATH and signed in.");
    say(
      "without it the findings would be probe-located but unjudged, so this stops here.",
    );
    return 2;
  }

  // The judge runs HERE, on whatever seat this machine already has.
  //
  // The operator chooses a model seat. Its provider receives masked structural
  // context; our report endpoint receives findings/rulings without source excerpts.
  const { seat, why } =
    prefer === "none"
      ? { seat: null, why: "--judge none" }
      : resolveLocalSeat();
  if (seat) {
    ui.info(`judging on this machine: ${why}`);
    // Say how long BEFORE the wait, not after. Measured on a 13-finding repo:
    // nine lenses needed judging and took about four and a half minutes on an
    // unmetered local seat, one lens at a time. Someone who expects seconds
    // reaches for ctrl-C at ninety of them.
    ui.info("this takes a few minutes — the probes are instant, the judge is not.");
    ui.info("  `--judge none` skips it, and leaves the false positives in.");
  } else {
    ui.info(`NOT judging: ${why}`);
  }

  const report = await runFleet({
    repoPath,
    transport: seat,
    interpret: Boolean(seat),
    includeSamples,
    onProgress: ui.rich
      ? ui.note
      : (id, note) => say(safeText(`  ${String(id).padEnd(22)} ${note}`)),
    onStage: ui.stage,
  });
  ui.settle();
  if (report.aborted) {
    ui.abort();
    say("REFUSED: a gate stopped firing. Nothing was uploaded or charged.");
    return 1;
  }
  if (report.samples?.length && !ui.rich) for (const l of sampleNotice(report.samples)) say(safeText(l));
  const repo = pinnedName ?? repoNameOf(repoPath);
  const submission = buildSubmission(report, { repo, commit });
  // Kept OUT of the submission. The server's schema is `.strict()`, so a display
  // field attached to the uploaded object is a 400 — and more to the point, the
  // upload is a list of exactly what may leave this machine, not a place to put
  // things the terminal wants to say.
  const repoSource = pinnedName
    ? "pinned with --name"
    : "from git origin, or the directory name";
  ui.plain(
    `uploading ${submission.findings.length} finding(s) — the repository is not uploaded`,
  );
  ui.begin("upload");

  const { status, payload } = await post(endpointOf(config), key, submission);
  if (payload.ok) {
    ui.end(
      "upload",
      `uploaded ${submission.findings.length} finding(s) — the repository is not uploaded`,
    );
  } else {
    ui.abort();
    if (status === 402)
      say(
        `out of tokens: this run needs ${payload.need}, balance is ${payload.have}`,
      );
    else if (status === 401)
      say(
        "the key was refused. it may be revoked — reissue and `login` again.",
      );
    else say(`upload failed (${status}): ${payload.error ?? "unknown"}`);
    return 1;
  }
  printReport(submission, payload, repoSource, endpointOf(config), ui, report.samples ?? []);
  ui.farewell();
  if (json) {
    console.log(JSON.stringify({ mode: "uploaded", ...submission, samples: report.samples ?? [], report: payload }, null, 2));
  }
  writeConfig({
    ...config,
    lastScanId: payload.scanId,
    lastRepo: submission.repo,
  });
  return 0;
}

async function main() {
  const args = process.argv.slice(2);
  if (args[0] === "--version") { console.log(VERSION); return 0; }
  if (args.includes("--help") || args[0] === "help") { say(USAGE); return 0; }
  const explicitCommand = args[0] && !args[0].startsWith("--");
  const command = explicitCommand ? args[0] : "score";
  const rest = explicitCommand ? args.slice(1) : args;
  const config = readConfig();
  if (shouldRunWizard({ args: process.argv.slice(2), stdin: process.stdin, stdout: process.stdout })) {
    const caps = detectCaps();
    // The supplied closing art is wider than the report's 100-column cap.
    // Bare onboarding may use the real terminal width; scripted output stays unchanged.
    const ui = createUi({ ...caps, width: Math.min(160, Math.max(40, process.stderr.columns || caps.width)) });
    return runWizard({
      version: VERSION, lensCount: LENS_COUNT, hasKey: Boolean(keyOf(config)), endpoint: endpointOf(config),
      showBanner: () => ui.rich ? ui.banner(VERSION) : say(renderBanner(caps, VERSION)),
      runScore: (repoPath) => cmdRun({ repoPath, config, forceFree: true, showNextStep: false, ui: { ...ui, banner: () => {} } }),
      runReport: (repoPath) => cmdRun({ repoPath, config, prefer: "api" }),
    });
  }
  const flag = (name, fallback) => {
    const i = rest.indexOf(name);
    return i === -1 ? fallback : rest[i + 1];
  };
  let repoPath;
  if (["score", "run", "rerun", "fix"].includes(command)) {
    const target = flag("--repo", ".");
    repoPath = target && !target.startsWith("--") ? projectFolder(target) : null;
    // One boundary for every scan entry point, before probes, model calls or billing.
    if (!repoPath) {
      say("Choose a project with .git or package.json; home and filesystem root cannot be scanned.");
      return 2;
    }
  }

  switch (command) {
    case "login": {
      const key = rest[0];
      if (!key || key.startsWith("--")) {
        say("usage: mypovonai-audit login <key>");
        return 2;
      }
      writeConfig({ ...config, key, endpoint: endpointOf(config) });
      say(`key stored in ${CONFIG_FILE} (mode 600)`);
      return 0;
    }
    case "whoami": {
      say(`endpoint  ${endpointOf(config)}`);
      say(
        `key       ${keyOf(config) ? "present" : "MISSING — run: mypovonai-audit login <key>"}`,
      );
      say(`config    ${CONFIG_FILE}`);
      return 0;
    }
    case "score":
    case "run":
    case "rerun": {
      const prefer = rest.includes("--judge")
        ? String(flag("--judge", "api"))
        : "api";
      if (!["api", "local", "none"].includes(prefer)) {
        say(`--judge takes api|local|none, not ${prefer}`);
        return 2;
      }
      if (command !== "score" && !rest.includes("--free") && !keyOf(config)) {
        say("a full report needs a key and audit tokens. Run: mypovonai-audit login <key>; use score for a free local score.");
        return 2;
      }
      // They are the same call. The server decides whether this is a rerun by
      // looking for a previous complete source scan of the same repository --
      // a client that could declare its own baseline could declare an empty one.
      return cmdRun({
        repoPath,
        config,
        prefer,
        pinnedName: flag("--name", undefined),
        shareDir: flag("--share-dir", undefined),
        forceFree: command === "score" || rest.includes("--free"),
        includeSamples: rest.includes("--include-samples"),
        json: rest.includes("--json"),
      });
    }
    case "fix": {
      const out = resolve(flag("--out", "./mypovonai-fix"));
      const key = keyOf(config);
      const scanId = flag("--scan", config.lastScanId);
      if (!key) {
        say("no key. run:  mypovonai-audit login <key>");
        return 2;
      }
      if (!scanId) {
        say(
          "no scan to fix. run `mypovonai-audit run` first, or pass --scan <id>.",
        );
        return 2;
      }

      // Pay BEFORE the work, and stop if it is refused. `fix` is the middle of
      // the loop -- identify, RESOLVE, verify -- and it was being given away.
      // Charging after would mean a customer with no balance still walks away
      // with the patch.
      const charge = await post(
        endpointOf(config),
        key,
        { scanId },
        "/api/audit/fix",
      );
      if (!charge.payload.ok) {
        if (charge.status === 402) {
          say(
            `out of tokens: a fix costs ${charge.payload.need}, balance is ${charge.payload.have}`,
          );
        } else if (charge.status === 404) {
          say(`scan ${scanId} is not one of yours, or does not exist.`);
        } else if (charge.status === 401) {
          say(
            "the key was refused. it may be revoked — reissue and `login` again.",
          );
        } else {
          say(
            `could not start the fix (${charge.status}): ${charge.payload.error ?? "unknown"}`,
          );
        }
        return 1;
      }
      say(
        charge.payload.alreadyPaid
          ? `this audit's fix is already paid for — re-running it is free (balance ${charge.payload.balance})`
          : `charged ${charge.payload.charged} token(s) for the fix, balance ${charge.payload.balance}`,
      );

      say(`probing ${repoPath} and writing verified fixes to ${out}`);
      const { runFix } = await import("./fix/run-fix.mjs");
      const { readStandardFor } = await import("./run.mjs");
      // The same seat that judges. A finding the templates cannot touch gets a
      // patch written by a model reading the actual code — on this machine, on
      // a seat you already have, so it costs nothing per fix and the source
      // never moves.
      const { seat: fixSeat, why: seatWhy } = resolveLocalSeat();
      say(
        fixSeat
          ? `deep findings will be attempted by an agent on this machine: ${seatWhy}`
          : `no model seat — only the mechanical fixes will be applied (${seatWhy})`,
      );
      const report = await runFleet({
        repoPath,
        apiKey: null,
        onProgress: () => {},
      });
      const result = await runFix({
        repoPath,
        report,
        outDir: out,
        seat: fixSeat,
        rubricFor: readStandardFor,
        onProgress: (id, note) => say(`  ${id}: ${note}`),
      });
      say("");
      const mech = result.applied.filter(
        (a) => a.action !== "agent-patch",
      ).length;
      const byAgent = result.applied.length - mech;
      say(
        `  applied   ${result.applied.length} fix(es), each verified by re-running its own probe`,
      );
      say(
        `            ${mech} mechanical, ${byAgent} written by the agent (of ${result.agentAttempted} attempted)`,
      );
      say(
        `  reverted  ${result.reverted.length} (the finding survived the edit, or the gate stopped firing)`,
      );
      say(`  specs     ${result.specs.length} written to ${out}/specs`);
      say(`  patch     ${result.patchBytes} bytes at ${out}/patch.diff`);
      say("");
      say(
        "  the patch is yours to read and apply:  git apply mypovonai-fix/patch.diff",
      );
      say("  then prove it landed:                  mypovonai-audit rerun");
      return 0;
    }
    default:
      say(USAGE);
      return command ? 2 : 0;
  }
}

if (isMain(import.meta.url)) {
  process.exit(await main());
}
