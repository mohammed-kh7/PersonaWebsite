/** Severity-weighted average of completed lenses; repeated locations do not multiply risk. */
export const SCORE_METHOD = "lens-severity-v1";
export function scoreFromFindings(findings, coverage) {
  const unavailable = new Set(coverage.unavailable ?? []);
  const penalties = new Map(coverage.ran.filter(id => !unavailable.has(id)).map(id => [id, 0]));
  if (!penalties.size) return null;
  const weights = { critical: 100, high: 60, medium: 25, low: 10 };
  for (const finding of findings) {
    if (!penalties.has(finding.lens)) continue;
    penalties.set(finding.lens, Math.max(penalties.get(finding.lens), weights[finding.severity] ?? 25));
  }
  return Math.round(100 - [...penalties.values()].reduce((sum, value) => sum + value, 0) / penalties.size);
}
/** Legacy count-based scoring, retained only for historical results without coverage. */
export function scoreFromCounts(counts) {
  return Math.max(
    0,
    100 -
      counts.critical * 20 -
      counts.high * 10 -
      counts.medium * 3 -
      counts.low,
  );
}
export function countSeverities(findings) {
  const counts = { critical: 0, high: 0, medium: 0, low: 0 };
  for (const finding of findings) {
    if (Object.hasOwn(counts, finding.severity)) counts[finding.severity]++;
  }
  return counts;
}
export function badgeSvg(score, counts, partial = false) {
  const label = `mypovonai ${partial ? "partial " : ""}${score}/100 · ${counts.critical} critical · ${counts.high} high · ${counts.medium} medium · ${counts.low} low`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="540" height="28" role="img" aria-label="${label}"><title>${label}</title><rect width="540" height="28" rx="5" fill="#171717"/><text x="270" y="19" text-anchor="middle" font-family="Arial,sans-serif" font-size="12" fill="#fff">${label}</text></svg>`;
}
