import { createHash } from "node:crypto";
import { isAbsolute, relative } from "node:path";

/**
 * A finding's locator, normalized so the SAME defect keeps the SAME id across a
 * fix and its rerun.
 *
 * Two things are stripped, each for a reason the loop depends on:
 *
 *  - the repo path prefix, because the audit runs against a fresh clone at a
 *    different temp path every time. `/tmp/a1b2/src/x.ts` and `/tmp/c3d4/src/x.ts`
 *    are the same file.
 *  - the `:line` suffix, because a patch SHIFTS line numbers. Keeping the line
 *    in the identity is the failure mode this whole module exists to avoid: the
 *    rerun would report every surviving finding as "introduced" and every
 *    original as "cleared", so a patch that fixed nothing would grade as a
 *    complete success.
 *
 * The message stays in, because one file routinely carries several distinct
 * findings from one lens (three unsanitized sinks in one component). Dropping
 * it would collapse them into one id and the rerun would call the pair closed
 * when one was fixed.
 */
export function normalizeLocator(location, repoPath = "") {
  let loc = String(location ?? "").trim();
  if (repoPath) {
    const root = String(repoPath).replace(/\/+$/, "");
    // Probes emit both absolute paths and paths already relative to the root.
    if (loc === root) loc = ".";
    else if (loc.startsWith(`${root}/`)) loc = loc.slice(root.length + 1);
    else if (isAbsolute(loc) && isAbsolute(root)) {
      const rel = relative(root, loc.replace(/:\d+(?:-\d+)?$/, ""));
      if (rel && !rel.startsWith("..")) loc = rel + (loc.match(/:\d+(?:-\d+)?$/)?.[0] ?? "");
    }
  }
  return loc.replace(/:\d+(?:-\d+)?$/, "").replace(/^\.\//, "");
}

/**
 * `sha256(lens_id + ' ' + normalized_locator)` as `db/audit-schema.sql` specifies,
 * where the normalized locator carries the message so sibling findings in one
 * file stay distinct.
 */
export function findingIdentity({ lens, location, message }, repoPath = "") {
  const locator = `${normalizeLocator(location, repoPath)}|${String(message ?? "").trim()}`;
  return createHash("sha256").update(`${lens} ${locator}`).digest("hex");
}
