import { realpathSync } from "node:fs";
import { pathToFileURL } from "node:url";

/**
 * Is this module the process entry point?
 *
 * ## The bug this exists to kill
 *
 * Every script here used to ask:
 *
 *   if (import.meta.url === `file://${process.argv[1]}`)
 *
 * which is true when you run `node fleet/cli.mjs` and FALSE for every customer
 * who installed the package. npm links a bin as a symlink — `/opt/homebrew/bin/
 * mypovonai-audit` -> `../lib/node_modules/mypovonai-audit/cli.mjs` — and Node
 * sets `import.meta.url` from the RESOLVED path while `process.argv[1]` keeps
 * the symlink. The two never match, `main()` never runs, and the command exits
 * 0 having printed nothing.
 *
 * Silent success is the worst possible failure here: `npx mypovonai-audit run`
 * looked like a no-op rather than an error, so there was nothing to search for
 * and nothing to report. It shipped in 0.1.0 through 0.6.0 and was invisible to
 * every test, because the tests invoke these files by their real path — the one
 * way a customer never does.
 *
 * ## Two fixes in one line
 *
 * `realpathSync` collapses the symlink so both sides describe the same file.
 * `pathToFileURL` replaces the string-concatenated `file://`, which produced a
 * malformed URL for any path containing a space or a `#` — the same class of
 * bug waiting for the first customer with a space in their project path.
 */
export function isMain(moduleUrl) {
  const entry = process.argv[1];
  if (!entry) return false;
  try {
    return moduleUrl === pathToFileURL(realpathSync(entry)).href;
  } catch {
    // The entry point vanished or is unreadable. Fall back to the unresolved
    // form rather than refusing to run at all.
    return moduleUrl === pathToFileURL(entry).href;
  }
}
