# php-throttle — missing rate limiting (PHP)

**Grade 2** — `app/Http/Kernel.php`'s `'web'` middleware group carries a `throttle:` entry (or every
sensitive route/group provides its own), and every login, registration, password-reset, application,
contact, comment and subscribe endpoint throttles in its own chain or an enclosing group.

**Grade 1** — the Kernel is fine, but at least one sensitive endpoint relies on a group that turns out
not to carry `throttle:` after all (a near-miss, not a blanket gap).

**Grade 0** — the `web` group has no `throttle:` entry at all and the app's real routes run through it,
or a specific sensitive endpoint (login, admin-login, register, password/reset, apply, contact,
comment, subscribe) has no `throttle:` anywhere in reach.

## Why this lens exists

A Laravel 11 app's `app/Http/Kernel.php` gives `'api'` the standard `throttle:api` entry but leaves
`'web'` with none — textbook Laravel scaffolding, except this app has no `routes/api.php` at all, so
every route it serves, including the admin password gate (see `php-secrets`), `/login`,
`/admin/register`, and a 6-digit team OTP with a 10-minute window and zero attempt limit, runs through
`web` with no rate limiting whatsoever. `throttle:api` existing is what makes this easy to miss: the
framework mechanism is right there, wired to the one group nothing uses.

## What the probe checks

1. **Kernel-level**: does `$middlewareGroups['web']` contain a `throttle:` entry? If not, and `'api'`
   has one, the finding cites both spans as contrast (mirroring how this exact gap reads in a report:
   "`web` has none; `api` does, but nothing runs through `api`"). If neither group has one, the finding
   says so more starkly — no throttle is configured anywhere in the Kernel.
2. **Route-level**: for a `Route::post()`/`Route::any()`/`Route::match([...,'post',...])` whose name or
   URI signals it authenticates or accepts public input (`login`, `register`, `password`, `reset`,
   `contact`, `comment`, `subscribe`, `apply`/`application`), does `throttle:` appear in its own
   middleware chain, or in any `Route::group()`/`Route::middleware()->group()` still enclosing it at
   that line? Both forms of Laravel middleware declaration are honoured: an inline `->middleware(...)`
   chain and a `['middleware' => [...]]` group array.

Two exclusions keep this from becoming noise: an admin-moderation action (`.publish`, `.disable`,
`.read`, `.destroy`, `.update`, `.edit`, `.index`, `.show` route names) isn't "accepts new public
input" in the sense this lens cares about, and a route already wrapped in an `admin.gate`-style shared
group is `php-secrets`' surface, not this one — flagging every admin-CRUD POST behind the same password
gate would drown the routes that actually have no protection at all.

## What it cannot see

A helper method whose *name* gives no hint (`storeCompanyForm` for a job application, `company-services`
for a lead form) won't match the keyword list — this is a text-pattern lens, not a semantic one. A
multi-line `->middleware(...)` chain beyond a few lines of wrapping, or middleware assigned entirely
outside `routes/`/`app/Http/Kernel.php` (e.g. Laravel 11's `bootstrap/app.php`-style registration), is
also out of reach; the probe reports `skipped` rather than guessing when it cannot find a Kernel at all.
