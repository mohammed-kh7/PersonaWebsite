# php-blade-xss — unescaped raw echo in Blade templates

**Grade 2** — every `{!! ... !!}` in the codebase is either translation copy (`__()`/`trans()`),
Blade's own `$loop` object, literal template-authored HTML, or output that has already passed through
an escaping helper (`e()`, `clean()`, `Purifier::clean()`, `strip_tags()`, `htmlspecialchars()`).

**Grade 1** — a raw echo of model or request data exists but the field is provably never user-editable
(e.g. a hard-coded enum rendered as HTML) — worth a human read, not an automatic critical, but still
worth removing the raw echo since the next edit to that field won't know the assumption exists.

**Grade 0** — `{!! ... !!}` prints request data (`{!! request(...) !!}`, `$_GET`/`$_POST`/`$_REQUEST`)
or a model/object property or method chain (`{!! $model->field !!}`) with no escaping call in between.
Blade's `{{ }}` exists specifically to auto-escape this; `{!! !!}` opts back out, and the moment the
value is attacker-controlled it is stored or reflected XSS.

## Why this lens exists

`{!! !!}` is legitimate and common in Laravel — the standard idiom for "preserve line breaks, still
escape everything else" is `{!! nl2br(e($x)) !!}`. A lens that flagged every `{!! !!}` would be noise;
a lens that ignored the construct entirely would miss the one line in a view that skipped the `e()`
call on the same field a sibling view escaped correctly.

## What the probe checks

For every `{!! ... !!}` in a `.blade.php` file, the probe reads the expression between the markers and:

1. Skips it if it references `$loop` or calls `__()`/`trans()`/`trans_choice()` — never attacker data.
2. Classifies it as request-shaped (`$request->`, `request(`, `$_GET`/`$_POST`/`$_REQUEST`/`$_COOKIE`)
   or model-shaped (any `$var->` property/method chain). Anything that is neither — a plain view-local
   variable, a literal ternary, a string built entirely in the template — is out of scope by design;
   the contract's own safe example (`{!! isset($css) ? $css : "" !!}`, a template-authored constant)
   is exactly this shape.
3. Drops it if it is wrapped by a known escaping call (`e(`, `clean(`, `Purifier::clean(`,
   `strip_tags(`, `htmlspecialchars(`) anywhere in the expression — `nl2br(e($x))` matches on the
   inner `e(`, not just an outermost call.
4. What survives both filters is a finding: request-shaped is graded as reflected, model-shaped as
   stored.
