# php-uploads — unsafe file uploads (PHP)

**Grade 2** — every upload handler validates type (`mimes:`/`mimetypes:`/`image`) and size (`max:`)
before the write, files land on a disk chosen by name (never a literal `'public'` path or
`public_path()`), and the stored filename is never derived from the client-supplied name.

**Grade 1** — uploads are validated, but at least one field's rule is missing a type or size bound.

**Grade 0** — a file is persisted with no validation call anywhere in its handler, the write lands
directly in a web-servable path, or the filename on disk is attacker-chosen.

## Why this lens exists

A Laravel 11 app had one upload handler — `HomeController::offersStore()` — with zero validation on
its `image` field, while every other upload handler in the same codebase (`newsStore`, `storeResource`,
`updateSetting`, `languagesStore`, …) validated `image`/`mimes:...`/`max:...`. `Storage::disk('public')`
preserves the client's extension when no filename is given, and the `public/storage` symlink serves it
straight from the webroot: uploading `shell.php` as a job-offer image is remote code execution the
moment PHP execution is enabled anywhere under the document root. The bug was invisible to any lens
that either flags every upload (drowned in the validated ones) or flags none.

## What the probe checks

1. **No validation at all** — the ENCLOSING METHOD of a `->store()`/`->storeAs()` call contains no
   `->validate()`, `Validator::make()`, or `$this->validate*()` call anywhere. A validate call in a
   *different* method proves nothing about this one.
2. **Incomplete validation** — a validate call exists in the method, and the field's own rule string
   is present, but it has neither `mimes:`/`mimetypes:`/`image` nor `max:`.
3. **Web-reachable destination** — `->store('public', …)` / `->storeAs('public', …)` (the literal
   `'public'` as the PATH, not the disk) or `->move(public_path(...))`, both of which land the file
   where the web server serves it directly, bypassing Laravel's disk config. The ordinary
   `->store($path, 'public')` two-argument form — choosing the `public` DISK — is normal Laravel and
   is never flagged by itself; it only matters when validation (1) or (2) is also missing.
4. **Attacker-chosen filename** — `getClientOriginalName()`/`getClientOriginalExtension()` used to
   build the path written to disk, instead of Laravel's random-name default.

A validate call routed through a config-driven helper (`$this->validateCrudRequest(...)`) is treated
as validation having happened, even though the probe cannot see what it checked — guessing at a rule
it cannot read would be exactly the noise this pack exists to avoid.
