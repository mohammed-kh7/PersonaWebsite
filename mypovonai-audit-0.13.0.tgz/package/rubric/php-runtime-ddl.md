# php-runtime-ddl — schema changes executed by traffic (PHP/Laravel)

**Grade 2** — every schema change lives in `database/migrations/`. The running application reads the
schema; it never reshapes it.

**Grade 1** — the application calls the schema builder outside a migration, but only from code no
route can reach (a console command, a one-off script). The change is unreviewed and unordered, but
it is not a function of traffic.

**Grade 0** — a route reaches code that changes the schema.

## Why this lens exists

A migration is reviewed in a diff, ordered against its siblings, recorded as run, and reversible.
The same `Schema::table()` call behind a web request is none of those things:

- it runs with whatever privileges the application's database user holds, which is why that user
  usually should not hold `ALTER`;
- it runs **again on every hit**, so its safety depends on a guard someone remembered to write;
- it races with itself under concurrency — two simultaneous requests, two `CREATE TABLE`s;
- and the schema of production becomes a function of who visited which URL, in what order.

Ground truth SEC-013 on the reference repository: a controller with `ensureNewsSchema()` adding ~35
columns and creating a table, called from `newsSetup()`. The code's own comment said it could be
removed once run. It had not been removed.

## What the probe checks

1. `Schema::create|table|drop|dropIfExists|rename|…` in any file that is not a migration. Reported
   **per method**, not per call — the reference repo holds 23 schema-builder call sites in two
   methods, and 23 findings for one defect is the noise this pack exists to avoid.
2. `DB::statement` / `DB::unprepared` whose SQL contains CREATE/ALTER/DROP/TRUNCATE/ADD COLUMN,
   outside a migration.
3. A route naming a method from 1 or 2, resolving **one hop** of indirection — because the routed
   method is rarely the one holding the DDL. Gated on 1/2 having found something.

## Deliberately not flagged

- **Migrations themselves.** `Schema::create` inside `database/migrations/` is the correct use; a
  probe that flagged it would flag every Laravel application.
- **A migration-shaped file in the wrong directory.** The reference repo has two timestamped
  migration files sitting inside `app/Http/Controllers/`. They are classes nobody calls, so they
  change no schema at request time — and `php-hygiene` already reports them as misplaced. Accusing
  the same two files twice, under two different headings, is how an audit loses a reader's trust.
- **`Schema::hasTable` / `hasColumn`.** Asking is not changing.

## Calibrated

One finding on the reference repository: `ensureNewsSchema()` at `AdminController.php:610`, critical.

**A documented disagreement with the hand audit.** SEC-013 describes this as an *"HTTP-reachable
admin endpoint"*. In this snapshot it is not: `newsSetup()` is one of only 3 public methods out of
98 in that controller with no route referencing it, and the route file names every method
explicitly — there is no dynamic dispatch that could reach it. So criterion 3 is silent here, on
purpose. The DDL finding stands; the reachability claim does not, in this snapshot. If a route for
it exists in an environment this snapshot does not include, criterion 3 will fire there.
