# php-schema-integrity — is the repository the source of truth for the database? (PHP)

**Grade 2** — every table the code touches is created by a migration, and every relational column
declares the constraint that makes the relationship real.

**Grade 1** — the migration set is complete, but the schema declares no foreign keys: referential
integrity exists only in application code, so a bug, an import or a manual query can orphan rows and
nothing will object.

**Grade 0** — tables the application reads and writes are created by no migration at all. The schema
lives only in someone's production database.

## Why this lens exists

A migration set is the only executable description of a schema. Without it:

- a new environment cannot be created, and a test database cannot be built at all;
- a review never sees a column being added, because adding one leaves no diff;
- nobody can say which of the differences between staging and production is deliberate;
- and the one copy that defines the system is the one nobody can roll back.

Measured on the reference Laravel 11 repository: **9 tables** the code reads or writes have no
migration anywhere — `about_us`, `applicant_field_values`, `applications`, `companies`,
`company_fields`, `contactus`, `offers`, `settings`, `testimonials` — alongside **55** migration
files that create other things. The hand audit reached the same number independently.

## What the probe checks

1. Tables used by the code (an Eloquent `$table`, the conventional plural of a model class, or a
   `DB::table('x')` call) that appear in no `Schema::create` under `database/migrations/`. Reported
   as **one** finding naming every missing table — a finding per table would be as useless as zero,
   the same reasoning that makes 276 backup files one `php-hygiene` finding.
2. Zero `->foreign(` / `->constrained()` calls across the whole migration set, while at least one
   migration declares a relational `*_id` column. The second half matters: a schema with no
   relationships legitimately has no foreign keys, and flagging it would be noise.
3. No `database/migrations/` directory at all — the louder version of 1, reported once.

## Deliberately not flagged

Laravel's own framework tables — `migrations`, `sessions`, `cache`, `jobs`, `failed_jobs`,
`password_reset_tokens`, `personal_access_tokens` — are excluded. They are commonly created by
vendor or stub migrations that a source snapshot may not carry, and reporting them would blame the
application for the framework's own furniture.

Pluralisation is handled for the common English cases (`Company` → `companies`, `Offer` → `offers`).
An irregular plural a model does not declare with `$table` may be missed; that is a false negative,
which is the safer direction for a lens whose findings accuse a repository of losing its schema.
