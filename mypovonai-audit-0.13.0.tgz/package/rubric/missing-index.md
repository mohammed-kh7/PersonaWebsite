# Foreign-key lookup indexes

## Source candidate
Prisma scalar Id/_id fields and SQL-filtered columns in known CREATE TABLE schemas require a leading index, unique index, or primary key.

The probe is a bounded lexical source check. It reports candidates with file/line evidence and deliberately does not claim that local guard names prove the guard is effective. A judge must inspect reachability, middleware, imports and framework semantics before grading. Runtime configuration and database state are not inferred.

Score 0: verified reachable unsafe behavior. Score 1: candidate exists but reachability/mitigation is unresolved. Score 2: inspected path has effective protection. N/A: no applicable source.
