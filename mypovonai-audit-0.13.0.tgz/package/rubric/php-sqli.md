# php-sqli — SQL injection via raw query builders (PHP/Laravel)

**Grade 2** — every raw SQL call (`DB::raw`, `DB::select`, `DB::statement`, `whereRaw`, `havingRaw`,
`selectRaw`, `orderByRaw`) uses a fixed literal or `?`/`:name` placeholders with values passed through
the bindings array, and every `orderBy()` takes a fixed or allow-listed column.

**Grade 1** — one raw call or `orderBy()` takes its value from a local variable that is *usually*
validated, but the validation is not visible on the same line the probe can prove (e.g. a shared
helper method elsewhere in the class) — worth a human read, not an automatic critical.

**Grade 0** — a raw SQL call's TEXT contains a request or superglobal value (double-quote
interpolation or `.` concatenation), or `orderBy()`/an `orderBy()`-bound variable is taken straight
from the request. Either lets a caller run arbitrary SQL fragments or name arbitrary columns.

## Why this lens exists

Laravel's query builder parameter-binds everything by default — that is the whole reason `whereRaw`,
`DB::raw` and friends exist as an *escape hatch*: they hand a literal string straight to the SQL
driver. The escape hatch is safe when the string is fixed or uses placeholders; it is a critical
finding the moment request data reaches the string itself, because the driver runs whatever is there
verbatim — there is no bind step left to protect it.

## What the probe checks

1. For every `DB::raw`/`DB::select`/`DB::statement`/`whereRaw`/`havingRaw`/`selectRaw`/`orderByRaw`
   call, the probe reads ONLY the first (SQL-text) argument, in isolation from the rest of the call —
   never the bindings array. It flags:
   - a double-quoted string containing `$name` or `{$expr}` interpolation, or
   - a string immediately followed by `.` concatenation with a variable.
2. For every `->orderBy(...)`, the probe flags a call whose argument is request/superglobal data
   directly, or a local variable whose most recent assignment (within 15 lines) is *exactly* a
   request/superglobal read with nothing else on the right-hand side — an allow-list check, a
   ternary, or any other validation wrapped around that read makes the assignment line no longer
   match, and the probe stays silent.

## The exception that keeps this lens quiet on a normal Laravel app

`whereRaw('email = ?', [$request->input('email')])` is the *correct* form — `$request` appears in the
call, but never inside the SQL string. The probe is deliberately two-stage (find the call, then judge
only its first argument) so this sanctioned pattern never fires. See `fixtures/CALIBRATION-work-wise.md`
for the count of real-repo raw calls and orderBy() calls this excluded.
