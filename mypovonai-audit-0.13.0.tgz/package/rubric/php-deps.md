# php-deps — Composer dependency currency and pinning (PHP)

**Grade 2** — `composer.lock` is present, the declared PHP constraint's floor is ≥ 8.1, `laravel/
framework` resolves to major version ≥ 9, and stability is `"stable"` (or `"prefer-stable": true`
accompanies any looser `minimum-stability`).

**Grade 1** — `composer.lock` is missing (dependencies are unpinned, but nothing else below fires),
or `minimum-stability` is `"dev"` without `"prefer-stable": true`.

**Grade 0** — the declared PHP constraint or the resolved Laravel major version is past its own
project's published end-of-security-support date.

## Why this lens exists — and why it does NOT guess CVEs

The contract this pack was built against is explicit: **do not guess CVEs, do not invent version
numbers.** A probe that fabricates a CVE ID or claims a specific vulnerable version it cannot verify
is worse than a probe that says nothing — it produces a finding nobody can check and everybody has to
either blindly trust or manually re-derive. Every check below is instead a **structural fact**,
readable directly from `composer.json`/`composer.lock`'s own schema, or a **dated, public,
non-controversial policy** (a framework's own security-support table), never a live CVE database
this probe has no way to query from a static source tree.

## What the probe checks, and how it knows

1. **`composer.lock` absent** (medium) — `[ -f composer.lock ]`. A structural fact: without a lock
   file, `composer install` re-resolves the newest version satisfying each range at install time, so
   two installs of the same commit can pull different code. No version claim involved.
2. **PHP constraint below 8.1** (high) — reads `"php": "^X.Y"` from `composer.json`, extracts the
   floor version, compares against 8.1. **Source:** php.net/supported-versions.php publishes PHP's
   own security-support end dates; 8.0 reached end-of-life 2023-11-26. This is a *declared
   constraint* check, not a confirmed-installed-version check — the rubric and the finding message
   both say so, since the actual interpreter running in production is outside a static source tree's
   visibility.
3. **`laravel/framework` major version below 9** (high) — prefers the **locked** version from
   `composer.lock` (`"name": "laravel/framework"` block's `"version"` field) over the composer.json
   range, since the lock file states what actually installs; falls back to the range only when no
   lock file exists to confirm it, and the finding message says which source it used. **Source:**
   laravel.com/docs/releases publishes Laravel's own release/support table; major versions below 9
   are past it as of this pack's authoring date.
4. **`"minimum-stability": "dev"` without `"prefer-stable": true`** (medium) — both are literal keys
   read directly off `composer.json`. `minimum-stability: dev` allows Composer to resolve **any**
   dev/alpha/beta release that satisfies a constraint's range; `prefer-stable: true` tells it to
   prefer a tagged stable release when one exists. No package-specific guess is involved — this is a
   composer.json-schema fact.

**Deliberately not checked:** any specific package name against any specific CVE, `composer audit`
output, or Packagist's advisory feed. This probe has no network access from inside a static-source
audit and would either fabricate the check or silently go stale the day a new CVE is published — both
worse than a lens that stays inside what it can actually verify. Calibrated to be **silent** on the
work-wise-audit repo (PHP ^8.2, Laravel v11.44.1 locked, `composer.lock` present, `"minimum-stability":
"stable"`, `"prefer-stable": true`) — matching that audit's own conclusion: "Overall dependency risk:
Low / Unverified... no CVE could be confidently confirmed from the lock file alone."

## 5. A locked dependency with a published advisory (added 0.10.0)

For four releases this lens could assert only STRUCTURAL facts — no lockfile, a PHP floor below
8.1, a framework major past end of support, `minimum-stability: dev` — because it would not guess a
CVE, and a guessed advisory is worse than none: it sends someone to patch software that was never
affected.

It now matches `composer.lock` against `data/advisories.json`, generated from GitHub's Security
Advisory database by `tools/audit/build-advisory-table.mjs`, carrying the affected package and the
vulnerable version range exactly as GitHub publishes them.

**What this table is not.** It is the most recent N advisories per ecosystem, not a complete
vulnerability database. **A package absent from it has not been cleared.** The finding text says so,
and it is repeated here because the failure mode this fleet exists to prevent is a false all-clear —
silence that reads as safety. Anyone wanting completeness should run `composer audit` as well; this
lens is a floor, not a ceiling.

**Matching is deliberately conservative.** A version that is not plain dotted numerals — `dev-main`,
a pre-release like `2.0.0-beta1`, a branch alias — is skipped rather than guessed at, and the count
of skipped packages is reported so the gap is visible instead of silent. Version comparison is
implemented in pure bash rather than `sort -V`, which is not dependable across BSD and GNU; this
pack has already lost a gate on Linux to exactly that class of difference (`find -regex`).

**The gate cannot rot.** `tools/audit/build-advisory-table.mjs` fetches an ANCHOR package by name on
every regeneration, so the advisory the `php-deps.b` fixture pins cannot scroll off the end of a
recency-capped table and leave the check quietly proving nothing. The generator throws if the anchor
returns no rows.

### The flat-range trap (0.10.1)

**49% of the composer advisories in the shipped table name no lower bound** — `<= 5.0.7`, `< 1.4.0`.
By semver ordering such a range swallows every earlier major line, so a version that is itself the
**backported fix** is reported vulnerable. That is not hypothetical: `brace-expansion` 1.1.18 and
2.1.4 were flagged by GHSA-mh99-v99m-4gvg (`<= 5.0.7`) across two repositories, and the "obvious"
remedy — forcing the patched major — broke ESLint repo-wide because `minimatch@3` cannot consume it.

The first attempt at handling this SUPPRESSED those matches. That was wrong, and testing it showed
why: a package at `0.9.9` against `< 1.4.0` is almost certainly a genuine hit, not a backport. The
signal that made brace-expansion a false positive was the **release date** of the patched line,
which this probe cannot read offline. Trading a false positive for a false negative is the worse
direction in a security lens.

So a flat-range match is **reported, capped at medium, and carries the check that settles it**:

    gh api /advisories/<GHSA> --jq .published_at    # then compare the installed version's release date

A version published *after* the advisory is a backport, and the finding is a false positive.

