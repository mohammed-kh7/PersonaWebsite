# php-unvalidated-write — routed writes that validate nothing (PHP/Laravel)

**Grade 2** — every routed write validates its input, and the rules live in FormRequest classes
where they can be reviewed in one place, reused, and covered by a single test.

**Grade 1** — every routed write validates, but the rules are inlined per method: nothing is
reusable, and a rule can be tightened in one endpoint and missed in the four beside it.

**Grade 0** — a method reachable from a route writes request data to the database and validates
none of it.

## Why this lens exists

Validation is not a formatting nicety. An unvalidated write is where a string of unbounded length
reaches a column, where a client-supplied foreign id selects a row belonging to someone else, and
where a field nobody meant to expose gets set because it happened to be in the payload.

Ground truth SEC-008 and backend #4 on the reference repository: `storeCompanyForm()` — the **public
apply-for-a-job endpoint**, the most business-critical write in the application — has no
`$request->validate()` at all, and inserts every non-excluded input key straight into
`applicant_field_values` keyed by a client-supplied `field_id`.

## How the count is kept defensible

That repository has **98 public methods in one controller, 30 validate call-sites and zero
FormRequest classes**. A finding per unvalidated method would produce a list nobody reads — the same
outcome as finding nothing, and the failure an earlier route-authorization attempt hit with 110
findings, none of them real. Three narrowings:

1. **Only methods that WRITE.** A read using request data is ordinary and is deliberately ignored.
2. **Only methods a ROUTE can reach.** A helper nobody can call over HTTP is a different risk, and
   one this lens would be guessing about.
3. **A cap of 20 reported individually**, with the remainder collapsed into a counted finding that
   says how many were not listed.

The cap is 20 rather than 5 for a reason worth recording: at 5 it suppressed `storeCompanyForm()`
itself — the finding the hand audit led with. **A cap that hides the headline is worse than no cap.**

Result on the reference repository: **8 findings** — 7 routed writes without recognized validation (including
`storeCompanyForm` at `AdminController.php:1757`, matching backend #4's cited range exactly) and one
for the absent FormRequest layer.

## What the probe checks

1. Per METHOD BODY, found by brace matching from `function name(`: a persistence call
   (`::create`, `->update`, `->fill`, `->save`, `->insert`, `->updateOrCreate`, …) together with
   request data, and no `->validate(`, `Validator::make`, `->validated()` or injected FormRequest
   anywhere in that body or its signature.
2. `app/Http/Requests/` absent or empty while at least one unvalidated routed write exists.
   Reported once.

## Delegated validation and limits

The source-only replay initially misclassified generic `storeResource` and `updateResource`: both pass the actual routed request to `validateCrudRequest`, whose return directly validates it before persistence. The probe now recognizes this bounded same-controller pattern. The helper must receive the corresponding Request parameter, have one unconditional top-level return of that parameter’s `validate(...)`, and be called unconditionally before the first write. Unused helpers, name-only matches, different arguments, conditional calls/returns, early returns and validation after persistence do not suppress findings. More complex delegation remains a candidate for manual review. Presence of some validation does not prove every persisted field has an adequate rule.

Absence of FormRequest classes means only that this specific class layer is absent; shared controller helpers can still centralize rules. See `fleet/WORKWISE-COMPARISON.md` for historical versus current replay and explicit residual scope.
