# php-authz — route-level authorization (PHP / Laravel)

**Grade 2** — every privileged route (admin/dashboard/manage panels, settings, user
management, destructive or exporting actions) carries authorization middleware in its own
chain, in an enclosing group, or via a controller that gates itself in `__construct()`.

**Grade 1** — not used by this lens; a route either has an authorization checkpoint declared
somewhere in its reachable chain, or it does not. There is no partial-credit shape for this
specific check (a WEAK checkpoint, e.g. a hardcoded password compared with `===`, is a real
defect but is `php-secrets`' finding, not this lens's — see "What this lens deliberately does
NOT check" below).

**Grade 0** — a privileged route is reachable with no `middleware` anywhere in its chain: not
on the route itself, not in any `Route::group()` / `->group()` wrapping it, and not in a
`$this->middleware(...)` call in its controller's constructor.

## Why this lens exists

A prior attempt at this exact check emitted **110 findings** on the calibration repo (a real
Laravel 11 job-board app), none of them real, because it tracked route groups by brace depth
alone. Laravel expresses "this route/group has middleware" in at least five distinct
syntaxes — a bare route, an array-form group, a fluent `Route::middleware([...])->group()`, a
per-route `->middleware()`, and a chained `Route::prefix()->middleware()->group()` — and a
lens that does not parse all five treats every route inside the ones it doesn't recognize as
uncovered, which is exactly backwards: it is loudest on the routes least likely to be wrong,
because well-structured Laravel apps group their admin routes.

## What the probe checks

For each `Route::(get|post|put|patch|delete|any|match|resource|apiResource)(...)` call in
`routes/*.php`:

1. Does its URI or resolved controller-method name contain a privileged keyword (`admin`,
   `dashboard`, `manage`, `moderat`, `settings`, `users`, `delete`, `destroy`, `approve`,
   `export`, `impersonate`)? If not, it is out of scope — the lens never flags an ordinary
   public page.
2. If privileged, does `middleware` appear in its own chain (`->middleware(...)`), in ANY
   enclosing group (array key `'middleware' => [...]`, or `Route::middleware(...)->group()`,
   or `->prefix(...)->middleware(...)->group()`), or does the target controller's
   `__construct()` call `$this->middleware(...)`? If any of these is true, the route is
   covered and is never flagged, regardless of which of the five syntaxes was used.
3. A group's own `prefix` value is also keyword-checked (`'prefix' => 'admin'` counts as
   "privileged context" for everything inside it) — so an uncovered group named `admin` still
   fires even if none of its own routes individually repeat the word "admin" in their URI.

Nesting is tracked with a real stack: coverage is inherited down through enclosing groups
(OR'd, never reset), so a group nested inside an already-covered group stays covered even if
it declares no middleware of its own — and an uncovered group nested inside a covered one is
still fine, because the outer coverage still applies to everything inside.

## Two deliberate rulings (read before extending this lens)

**1. A middleware string being present is "coverage," even if the middleware itself is weak.**
The calibration repo's entire `/admin` panel is wrapped in
`Route::group(['prefix' => 'admin', 'middleware' => ['admin.gate', ...]], ...)`, and
`admin.gate` (`app/Http/Middleware/AdminGate.php`) does nothing more than check a session flag
set by a route closure that compares a hardcoded 6-digit password with `===`
(`routes/web.php:106`, already `php-secrets`' SEC-001 finding). This lens still treats every
route in that group as **covered**, on purpose: `php-authz` answers "is an authorization
checkpoint declared in this route's reachable chain," a purely structural question, not "is
that checkpoint any good." The QUALITY of a declared gate — a hardcoded literal compare, a
predictable session flag name, no per-admin identity — is a semantically different defect
class, already owned by `php-secrets`. Collapsing the two would either (a) duplicate the same
finding under two lens IDs, or (b) require `php-authz` to read every custom middleware class's
implementation, which is a different and much larger analysis than route-chain reachability.
**If this ruling changes, `php-secrets`' SEC-001-shaped fixture must be re-checked so the two
lenses don't silently start double-counting the same defect.**

**2. The login/logout/registration boundary of a gate is not itself a privileged target,**
even when its URI contains a privileged keyword. `/admin-login` (GET, the form),
`/admin-login` (POST, the submit handler) and `/admin-logout` all contain `admin` and carry no
middleware — by design: you cannot log in to a gate you are already required to be behind. The
calibration repo also has `GET/POST /admin/register`, explicitly commented in
`routes/web.php:372` as "must stay OUTSIDE admin.gate so visitors can sign up" — a public
candidate-registration form that happens to live under an `/admin` URL prefix used purely as a
namespace, not as a privilege boundary. The probe excludes any route whose URI or action
contains `login`, `logout`, `register`, `sign-in`/`signin`, or `sign-up`/`signup`, regardless
of what other keyword it also matches. **Trade-off, accepted:** a genuinely privileged action
named around one of those words (e.g. `/admin/users/purge-registration-log`) would be missed.
Given the false-positive cost this pack exists to avoid, under-flagging five specific,
well-known words is preferable to re-introducing noise on every gate's own front door.

## What this lens deliberately does NOT check

- **The strength of a declared middleware** (hardcoded comparisons, predictable session flags,
  missing per-user identity) — `php-secrets`.
- **IDOR / missing per-tenant scoping on a route that has no auth concept at all** (e.g. the
  calibration repo's `/company/{company_id}/commission`, which is public "by design" because
  there is no company-login system to gate it with) — `php-idor`. Those routes carry no
  privileged keyword from this lens's list either, so they would not be caught here even
  incidentally.
- **Laravel 11's newer static `public static function middleware(): array` controller method**
  (an alternative to `$this->middleware()` in `__construct()`) — not implemented, because the
  calibration repo uses neither form. A controller using only the static form would be
  (incorrectly) treated as uncovered if none of its routes/groups declare middleware
  elsewhere; documented here rather than silently.
- **Policy/Gate-based authorization** (`Gate::authorize(...)`, `$this->authorize(...)` inside a
  route closure or controller method body) is not recognized as coverage — only `middleware`
  is. A route relying solely on an in-body policy check would be a false positive under this
  lens; not observed in the calibration repo, but a known scope boundary.
- **Prefix concatenation across nested groups.** A route's own URI/action and its group's own
  `prefix` are each keyword-checked independently; a two-level-deep prefix split across two
  groups (`prefix=>'admin'` then `prefix=>'panel'`) is not concatenated into `/admin/panel`
  before matching. Both levels are still individually checked, so this only matters if
  *neither* level's own prefix string contains a keyword and neither does the leaf route.
- **A group-closing `}` sharing a line with other code.** The stack pop assumes Laravel/PSR-12
  convention: the closing brace of a `Route::group()`/`->group()` callback starts its own line
  (`});`). This holds throughout the calibration repo and every fixture here.

## Calibration result

Run against `~/Desktop/projects/_clients/work-wise-audit/src`: **0 findings.** See
`fixtures/CALIBRATION-work-wise.md` under `## php-authz` for the route-by-route reasoning —
every genuinely uncovered privileged route in that repo either does not exist (the admin panel
is entirely wrapped in `admin.gate`-carrying groups) or is the gate's own front door (Ruling 2
above).
