# observability — Observability & Alerting Rubric

tags: [BOTH]
sources: PLAYBOOK §8, CLAUDE.md (Production Reality gates 6/7/11/12), reference-iceberg-audit.md (terms 23–26: Logging/Alerting/Incident response/Instrumentation), reference-force-ai-production-grade-standard.md (layer 7: observability)

## What "solid" looks like
Sentry wired day 1 on every job failure, webhook, and money mutation; an external uptime monitor with a P0 notification channel before any customer goes live; a log drain with verified ≥30-day retention documented in `docs/DEPLOYMENT.md`; the external-alert bridge token set in prod with a boot-time warning if missing; a defined SLO (p95 latency + error rate) with a queue-depth watch on async jobs.

## Criteria
| # | Criterion | Solid (grade 2) | Gap detection | Severity |
|---|---|---|---|---|
| 1 | Error monitoring wired day 1 | Sentry initialized and capturing on every job failure, webhook, and money mutation | grep for `Sentry.init`/`@sentry/` import in app bootstrap; grep money/webhook/job handlers for a capture call (`captureException`/`Sentry.`). Cloudflare Workers equivalent (probe 0.12.4): wrangler `observability` enabled (Workers Logs) AND an alert sender (fetch to api.telegram.org / hooks.slack.com / events.pagerduty.com / an ALERT webhook env) reachable from an error-level log path; logs on without an alert path is reported Medium ("logs enabled but no alerting") | Critical |
| 2 | Uptime monitor + P0 channel | External uptime monitor (UptimeRobot/BetterStack) + a P0 notification channel (Telegram/PagerDuty) live before any customer | check `docs/DEPLOYMENT.md` for a named uptime monitor; grep for the P0 channel config (`TELEGRAM_*`/PagerDuty webhook); confirm not in-code-only ping | High |
| 3 | Log drain with ≥30-day retention | Log drain (Axiom/equivalent) configured; retention window ≥30 days verified, not assumed | grep `docs/DEPLOYMENT.md` for a stated retention figure ≥30 days; confirm a drain config key (`AXIOM_*`/drain token) exists, not just console logging | High |
| 4 | Retention window documented | The ≥30-day retention is written down in `docs/DEPLOYMENT.md` (verified) | file-exists `docs/DEPLOYMENT.md` + grep it for an explicit retention statement (e.g. `retention`/`30-day`/`30 days`) | Medium |
| 5 | External-alert bridge token in prod | Alert bridge token set in production; boot-time warning logged if missing | grep boot/startup for an `ALERTS_WEBHOOK_TOKEN`/alert-bridge env check that warns when unset; confirm the var name exists in prod env list | High |
| 6 | SLO defined (p95 + error rate) | p95 latency target and error-rate target codified, not informal | grep `docs/`/`*.md` for a stated p95 latency + error-rate SLO; confirm a number, not prose intent | Medium |
| 7 | Queue-depth watch on async jobs | Async/queue jobs have a queue-depth watch that alerts on backlog | grep worker/queue code for a depth/backlog metric or alert (`queue.getJobCounts`/depth gauge); confirm an alert threshold exists | Medium |
| 8 | Correctness probe on the critical path | Every product has a synthetic probe of its critical path (auth login→/me, checkout, order-create) that FAILS on a wrong-but-200/401 — not just a `/health` ping — plus a deploy-drift check (running commit vs main HEAD) | grep monitor scripts for an authed/critical-path probe asserting 200 + expected role/body; flag health-only monitors | High |

## Evidence (filled during audit, per repo)
- FWB: …
- WBS: …
