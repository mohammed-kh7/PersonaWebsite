# php-credential-storage — how the application holds its users' credentials (PHP)

**Grade 2** — a password exists in exactly one form at rest: a hash. It is never mirrored into a
second column, never written as it arrived, never serialised into a response, never logged.

**Grade 1** — every password is hashed, but a credential table is read through the query builder
with no column list, so the hash and the remember token travel wherever those rows go.

**Grade 0** — the application stores, or emits, a credential in a form a reader can use: a
plaintext column, an unhashed write, a credential in a log line.

## Why this lens exists, and why it is not php-secrets

`php-secrets` is about **our** credentials committed to the source — an API key, a shared admin
password. This lens is about the **users'** credentials: a password the application was trusted
with and then kept in a form it should never have had.

It also exists as proof that the audit pack's daily cycle works. No person proposed it. The
`client-audit` source read a hand-written report, reduced a finding to the class
`plaintext-password-storage-normalpassword`, checked it against 48 existing lenses, and reported
that nothing graded it. That was correct, and this is the lens.

The repository it came from stores every user's password twice — once hashed, and once in a
`normalpassword` column written on the line *above* the hash:

```php
$data['normalpassword'] = $data['password'];
$data['password'] = Hash::make($data['password']);
```

A hash exists so that losing the database does not mean losing the passwords. A plaintext mirror
undoes that completely, and no password reset can un-leak it: people reuse passwords, so the blast
radius is accounts on systems that have nothing to do with this one.

## What the probe checks

1. **A plaintext credential column** (`normalpassword`, `plain_password`, `raw_password`,
   `clear_password`, …) in a migration, a `$fillable` list, or an assignment. Reported **once per
   column name**, anchored at the migration that creates it — that is the line to delete. Reporting
   every mention gave 14 findings for one column on the calibration repo.
2. **A password written without hashing.** Checked per LINE, not per method: the mirrored and
   hashed writes sit next to each other, so a method-level check sees the `Hash::make` and calls
   the whole method safe.
3. **A query-builder read with no column list, serialised to JSON.** `DB::table('users')->get()`
   returns `stdClass` rows, so Eloquent's `$hidden` never applies. This only *matters* where the
   rows are serialised out — a `DB::table()` used for an update or a where-clause leaks nothing.
   Requiring a `json`/`wantsJson` call within the next few lines took this from 16 findings to the
   1 the hand audit named.
4. **A credential in a log line.** Logs are shipped, retained, and read by people who were never
   meant to hold the credential; a password in a log outlives the request by months.

## The probe never prints a value

Every message and every `evidence` command passes through `redact_secrets`. Criterion 1's evidence
greps for the column **name** only. Findings and their excerpts are uploaded — a probe that quotes
a user's password turns an audit into a breach.

## Calibrated

On the reference Laravel 11 repository: **3 findings** — the `normalpassword` column (critical, 14
references across 5 files), and two query-builder reads that serialise to JSON, one of which is the
live `allusers()` endpoint. Criteria 2 and 4 are correctly silent there: that repository does hash,
and does not log credentials. Both are proven alive by the known-bad fixture instead.
