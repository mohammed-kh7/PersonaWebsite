# php-secrets — secrets and auth gates (PHP)

**Grade 2** — no credential appears in source. Every secret is read from the environment, and
authentication compares a hash (`Hash::check`, `Auth::attempt`), never a literal.

**Grade 1** — secrets come from the environment, but a credential-shaped `env()` call carries a
real-looking default that would ship silently the day the variable is missing.

**Grade 0** — a request value is compared with a hard-coded literal, or a credential is assigned in
source. A shared password in the repository is known to everyone who ever had access to it — every
contractor, every backup copy, every screen share — and rotating it requires a deploy.

## Why this lens exists

A Laravel app was audited with 34 probes and scored three generic findings. Its entire `/admin`
panel was gated by one hard-coded numeric password compared with `===` to `$request->input('password')`
inside a route closure, and a session flag set on success. Nothing in the fleet was looking at PHP.

## What the probe checks

1. A credential-shaped request field (`password`, `pin`, `secret`, `token`, `otp`, …) compared with
   `==`/`===` to a string literal, outside `Hash::check` / `Auth::attempt` / `password_verify`.
2. A credential assigned to a literal in source, excluding `env()`/`config()` reads, test data and
   obvious placeholders.
3. `env('…KEY'|'…SECRET'|'…TOKEN'|…, '<real-looking default>')`. Laravel's own honest defaults
   (`APP_URL`, `MAIL_HOST`, table names) are excluded by name and by shape — flagging those produced
   25 findings on one repo, none of them real.

## The probe never prints the secret

Findings and their excerpts are uploaded. Every message and every `evidence` command passes through
`redact_secrets`, and the calibration run asserts the literal does not appear anywhere in the output.
A probe that quotes the password turns an audit into a leak.
