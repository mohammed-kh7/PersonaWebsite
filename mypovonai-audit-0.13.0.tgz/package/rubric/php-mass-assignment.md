# php-mass-assignment — mass assignment (PHP)

**Grade 2** — every `create()`/`update()`/`fill()`/`forceFill()` call site passes a named,
validated array, and every model declares an explicit `$fillable` allowlist (or a non-empty
`$guarded`).

**Grade 1** — models declare a real `$fillable`/`$guarded`, but at least one write call still
passes `$request->all()`/`->except(...)` straight through — safe only because the model's own
allowlist happens to cover every column that matters today, and silently unsafe the day a new
sensitive column is added without also being excluded.

**Grade 0** — a model declares `protected $guarded = [];`, or unfiltered request input reaches a
write call with no allowlist anywhere in the path. Every column — `id`, `role`, `is_admin`,
whatever gets added next — is writable by anyone who can reach the endpoint.

## Why this lens exists

`$guarded = []` is Eloquent's own documented way of saying "nothing is guarded" — it is not a
typo or an oversight the framework will catch, it is the literal opt-out of mass-assignment
protection. Paired with `Model::create($request->all())`, a client can set `is_admin`, `role`,
or the row's own `id` in the same request that was supposed to just update their name. Neither
half needs the other to be dangerous — either one alone removes the fillable allowlist that
`$fillable` exists to provide.

## What the probe checks

1. `$request->all()`/`->except(...)` (or the `request()` helper form) reaching
   `create(`/`update(`/`->fill(`/`->forceFill(` — either as the call's own argument, or one
   variable-assignment hop away in the same method (`$data = $request->all(); ...
   Model::create($data);`). This is a one-hop check, not full data-flow: a value threaded through
   a second helper function or handed to a different method is invisible to it.
2. A model declaring `protected $guarded = [];` (or `['']`) — checked independently of (1),
   because the column list it exposes is model-wide, not tied to any one controller action.

Calibrated on a Laravel 11 repo where every `::create()` call site builds its array from named
literals against an explicit `$fillable`: the probe is silent there (see
`fixtures/CALIBRATION-work-wise.md`) — the repo's real mass-assignment-adjacent finding
(`$request->except(...)` reaching a raw `DB::table()->insert()`, not `create()`/`update()`) is a
different code shape than this lens targets and is out of scope for it.

## Known limitations (documented, not silently accepted)

- Comment lines merely mentioning the pattern (a docblock warning "never declare `$guarded = []`
  here") are excluded from criterion 2 by checking the matched line doesn't start with
  `//`/`*`/`#` — but a multi-line `/* ... */` block comment is not tracked, so a declaration
  buried inside one would still be flagged.
- Criterion 1 does not resolve what a called **helper function** or **FormRequest** does with a
  variable it receives — a project that funnels `$request->all()` through a sanitizing helper
  before `create()` will read as vulnerable even if the helper is actually safe.
