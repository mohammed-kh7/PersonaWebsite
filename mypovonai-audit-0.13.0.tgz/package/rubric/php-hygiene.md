# php-hygiene — backup files and misplaced source in the deployable tree (PHP)

**Grade 2** — no backup/archive file (`*.bak*`, `*_bak_*`, `*.old`, `*.orig`, `*.save`, `*.sql`,
`*.zip`, `*.tar.gz`, a `backup/`-named directory, `*copy.php`) sits anywhere in a deployable path, and
every migration/Blade/controller file lives in its own directory.

**Grade 0** — either category fires. There is no partial-credit middle grade for this lens: a single
misplaced migration is as cheap to fix and as easy to have prevented as 269 of them, and a repository
either has hand-edit backups sitting in its deployable tree or it does not.

## Why this lens exists

A Laravel app with **no git repository** had every hand-edit leave a timestamped copy of the file it
changed, in place, forever — because there was no version control to make the copy unnecessary.
Calibrated against exactly that repository: **276 backup/archive files (~10 MB)**, 57 of them inside
`app/Http/Controllers/` alone (53 are `AdminController.php.bak_*` — 53 historical snapshots of one
file), plus 4 files sitting in the wrong directory entirely (two migrations and a Blade template
physically inside `app/Http/Controllers/`, and a stale copy of the whole `AdminController.php` class
inside `resources/views/pages/`).

This is not tidiness. Two concrete consequences, both confirmed on the calibration repo:

- **The `.bak` copies ARE the only version history.** With no git, diffing "what changed and why"
  between any two `AdminController.php.bak_*` snapshots means opening both files by hand — which is
  exactly what made this audit itself slower (`grep` passes had to explicitly exclude `.bak` to avoid
  reviewing dead code as live).
- **`routes/web.php.bak_*` copies carry the same hard-coded admin password as the live file** — the
  exact credential `php-secrets` already flags in `routes/web.php` itself. Every one of those 15+
  backup copies is a second place that same shared secret sits in cleartext, in the deployable tree,
  outside whatever review or rotation process ever touches the live route file. **This lens never
  prints the credential** — it names the file count and points at `php-secrets` for the finding
  itself, consistent with the no-leak rule this whole pack is built around.

## What the probe checks

1. **Backup/archive files in a deployable path** (`is_deployable_path`: under `public/`, `app/`,
   `routes/`, `config/` or `resources/`, never `vendor/`, `node_modules/`, `tests/` or `.git/`) —
   reported as **one finding with a total count**, never one finding per file. The message states the
   total, the count specifically inside `app/Http/Controllers/`, whether any are `routes/web.php`
   backups (and why that specifically matters), the approximate total size, and up to three example
   paths. `*.bak*` (dot-bak-anything) is the pattern that actually matches the calibration repo's real
   naming shape (`AdminController.php.bak_20260725_applylock`) — a literal `*.bak` suffix alone
   matches zero files there, because the timestamp suffix comes *after* `.bak`, not instead of it.
2. A migration-shaped filename (`YYYY_MM_DD_HHMMSS_*.php`) physically inside `app/Http/Controllers/`
   — invisible to `php artisan migrate` from there.
3. A `.blade.php` file physically inside `app/Http/Controllers/` — not on Laravel's view resolution
   path from there.
4. A `*Controller.php` file physically inside `resources/views/` — not autoloaded from there (PSR-4
   maps `App\` to `app/`), so it is a second, silently-diverging copy of live code.

Both (2)–(4) are cheap, individually-reportable findings (there are only ever a handful) — the
"report a count, not one-per-file" rule in this lens applies specifically to the backup-file check,
where the calibration repo's 276 instances make individual findings noise rather than signal.
