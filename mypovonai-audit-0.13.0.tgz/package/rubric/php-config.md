# php-config — debug, CSRF and session config (PHP)

**Grade 2** — no committed `.env`/`.env.production`, `config/app.php` reads `debug` from the
environment with a safe default, `VerifyCsrfToken`'s exemption list is empty, and every session
cookie flag (`secure`, `http_only`, `same_site`) either has a safe default or is explicitly
hardened.

**Grade 1** — every value above is safe, but a session cookie flag (most often `SESSION_SECURE_
COOKIE`) is read with `env(...)` and **no second argument**, so it silently resolves to `null`
(falsy) the day the environment variable is missing, rather than failing safe.

**Grade 0** — a real `.env`/`.env.production` file is committed, `'debug' => true` is hard-coded in
`config/app.php`, or `VerifyCsrfToken::$except` carries a route pattern. Any one of these is a direct
production exposure: a debug page renders the stack trace (and often values interpolated from
`.env`) on every unhandled exception; a committed `.env` ships whatever it holds — including
`APP_KEY` and DB credentials — to every clone, CI runner and contractor who ever pulled the repo; and
a CSRF exemption is a named list of routes that accept a write with no token check at all.

## Why this lens exists

Laravel's own scaffold is safe by default: `'debug' => (bool) env('APP_DEBUG', false)`, an empty
`$except = []`, and cookie flags read from the environment. Every finding this lens looks for is a
place where a real deploy **overrode** that safe default — not a framework weakness. Calibrated
against a real Laravel 11 snapshot (`work-wise-audit`) where every check the framework already
guards against is clean, and the **one** real finding is `config/session.php`'s `'secure' =>
env('SESSION_SECURE_COOKIE'),` — no second argument, so it is `null` unless the production `.env`
(out of scope for that audit) happens to set it. That single finding matches the audit's own SEC-011
exactly.

## What the probe checks

1. `.env`/`.env.production` committed to the repo, with `APP_DEBUG=true` or `APP_ENV=local` inside it
   — `.env.example` is the expected, sanctioned template and is never checked.
2. A committed `.env`/`.env.production` at all, regardless of its contents — the file itself is the
   finding; whatever else it carries shipped into version control the moment it was added.
3. `'debug' => true` hard-coded in `config/app.php` (not `env(...)`-wrapped).
4. A non-empty `$except` array in `app/Http/Middleware/VerifyCsrfToken.php`, single-line or
   multi-line form.
5. `config/session.php`: `'secure'` read via `env('SESSION_SECURE_COOKIE')` with no default, or
   hard-set/defaulted to `false`; `'same_site'` hard-set to `'none'` (the one value that is always
   permissive); `'http_only'` hard-set/defaulted to `false`.

## The probe never prints a committed .env's contents

The excerpt for a committed-env finding is limited to the single matched `APP_DEBUG=`/`APP_ENV=`
line, and that line passes through `redact_secrets` before it is ever printed — a `.env` is exactly
the place a `DB_PASSWORD` or `APP_KEY` line lives, even though this lens only greps for two
boolean-ish keys.
