# php-idor — insecure direct object reference (PHP)

**Grade 2** — every controller lookup by a client-supplied id is scoped to the caller's own
records: a second where() on an ownership column (user_id/company_id/tenant_id/owner_id), a
policy check (`$this->authorize(...)`, `Gate::`, `->can(`), or a relationship traversal through
the authenticated user (`auth()->user()->orders()->find(...)`).

**Grade 1** — most lookups are scoped, but a handful of low-risk admin-only mutations (behind an
existing auth gate) load a record by raw id with no ownership check. Not exploitable by an
anonymous visitor, but the code has no boundary to fall back on if that gate is ever weakened.

**Grade 0** — a **public** route (no auth/gate middleware) forwards to a method that loads a
record by client-supplied id with no scope at all. Anyone can walk the id space and read or write
records that were never meant to be theirs.

## Why this lens exists

`CompanyController::offers($company_id)` / `commission($company_id)` fetch a company with
`DB::table('companies')->where('company_id', $company_id)->first()` and nothing else. The
where() clause LOOKS like an ownership check — its column name is `company_id` — but it is
comparing the id to itself: there is no session, no second column, nothing stopping a visitor
from reading every company's confidential commission data by walking `company_id` from 1..N
(`routes/web.php:403-404`, both outside any middleware group). A lens that treats "a where()
naming a tenant-ish column" as proof of scoping calls this repo clean.

## What the probe checks

1. Per **method body** (not per line): find every client-supplied-id lookup
   (`::find($var)`, `->find($var)`, `findOrFail(...)`, `->where('id'|'<x>_id', VALUE)` where
   VALUE traces back to this method's own parameters, `$request->`, or `request(...)`). A method
   is scoped only if, ALONGSIDE that lookup, the body also has a second, DIFFERENT where()
   column that is ownership-shaped, a policy call, or an authenticated-relationship traversal.
   One where() clause whose only column happens to be named `company_id`/`user_id` does **not**
   count — that is the exact CompanyController shape.
2. A route with no enclosing `Route::middleware()/group()` and no `->middleware()` of its own
   that forwards to a method criterion 1 already flagged. Gated on criterion 1's own findings so
   it does not fire on the many intentionally-public `{id}` routes in a typical job board (job
   listings, offer/news detail pages) that carry no per-owner data.

## Known limitations (documented, not silently accepted)

- A value derived from a **prior query result** (`$firstRow = ...->first(); ->where('id',
  $firstRow->id)`) is correctly excluded (not client-supplied) — but a value captured under a
  **second** local alias two hops away (`$x = $firstRow->id; ... ->where('id', $x)`) is not
  followed; this is a one-hop check, not a full data-flow analysis.
- Column-name matching cannot tell "this table's data is meant to be public" (a job posting,
  a news article) from "this table's data is meant to be private" (a company's commission rate)
  — both are literally the same code shape. The route-level check (2) narrows this to routes
  reachable with zero auth, but a public **and** confidential resource with a lookup behind
  `auth` middleware only will still be flagged at the method level and needs a human verdict.
- A generic CRUD engine that resolves its lookup column through a **variable**
  (`->where($config['pk'], $id)`) is invisible to this probe — the column name isn't a string
  literal — so a hand-rolled admin resource framework can hide the same bug from this lens.
