# self-healing — the OS medic (auto-remediation, not just alerting)

The observability fleet (`services-watch`, `wbs-monitor`, `checkout-monitor`, `cf-workers-watch`, `anomaly-watch`) **detects + alerts** — it never mutates. This layer **acts**: when a hosted service is confirmed down, it runs a bounded, compute-only recovery and reports the outcome. So a service that falls at 3am is *fixed by 3:03am*, and Ahmad wakes to "🔧 I fixed it," not "🚨 it's broken."

**Strategy (Ahmad, 2026-07-05): heal-immediately-then-notify.** On confirmed-down, recover right away, then Telegram the result. Escalate only if healing fails.

## Components (`ops/`)
- **`heal-watch.sh`** — launchd heartbeat (`com.forceai.heal-watch`, every 180s). Probes each registered service's health; on DOWN, hands off to `self-heal.sh`.
- **`self-heal.sh <id> [reason]`** — the medic. Confirm-still-down (anti-flap) → cooldown/attempt check → platform recovery → re-verify → `🔧 self-healed` / `🚨 auto-heal failed` via `notify.sh`. `DRY_RUN=1` simulates with no mutation; `HEAL_REG=<path>` overrides the registry for tests.
- **`lib/heal-registry.json`** — the service registry. Add a service = add an entry.
- **`heal-review.sh [status|log|test|registry]`** — inspect: live probe, audit log, dry-run all, dump registry.

## Recovery playbooks (compute only — NEVER data)
| platform | recovery | action |
|---|---|---|
| railway | `railway-redeploy` | `railway redeploy --from-source` (proven; also the fix for a crash-loop or the Neon-creds-drift outage) |
| vercel  | `vercel-rollback`  | `vercel rollback` to the last-good production deploy |
| cloudflare | `wrangler-rollback` | `wrangler rollback` |
| any | `escalate-only` | no auto-action — alert only (safe default for unmapped/ambiguous services) |

## Guardrails (why it can't make things worse)
- **Anti-flap**: re-probes N times before acting — a transient blip is ignored.
- **Cooldown** (600s) + **max attempts** (3): no redeploy loops; exhaustion → escalate to a human.
- **Compute-only**: redeploy/rollback/restart. Never touches data, migrations, or ambiguous states.
- **Full audit log** (`~/.whisky-os-state/heal.log`) + Telegram on every heal/escalation.
- Complements (does not replace) the detect+alert monitors — they stay as an independent signal.

## Registered services (2026-07-05)
`wbs-api` (Railway, redeploy) · `wbs-web` (Cloudflare Worker, wrangler rollback) · `fwb-web` (Cloudflare Worker, wrangler rollback) · `fwb-api` (Railway, redeploy). To add: append to `heal-registry.json` with `health`, `expect`, `recovery`, and the platform's service identifiers.
