# Force AI Foundation — Standard Index

The canonical, **gradeable** Force AI production standard: one file per concern, merged from the 6 scattered sources. Used as the rubric for BOTH building (`/force-build`) and auditing (`/force-audit`) every Force AI SaaS.

> **🔭 `unified-audit.md` is THE entry point for "audit this repo" / `/force-audit`.** It blends ALL audit types (layers + blast-radius + feature×feature interaction + security + RLS-writer-coverage + iceberg-38 + scaling/money + reliability/observability + save-integrity S1–S6 + data→UI + UI/UX consistency + CI/testing + deps + docs-parity + mobile) into ONE report: what's broken, WHERE exactly (file:line / page / field), and the **blast radius** that must be fixed in lockstep so the whole system reaches one level of maturity. The 41 lenses below are its rubric. It is steps 1–3 of the self-improving loop (`~/.claude/.../memory/feedback-os-self-improving-audit-loop`).

## Concern taxonomy (the rubric)

The 41 lenses below each become one file `standard/<id>.md`. `mobile` is N/A for web-only repos (FWB/WBS) and is authored but not graded in Phase 1.

| # | id | Concern | Primary source |
|---|---|---|---|
| 1 | `architecture` | Monorepo shape, stack decisions, money-as-integer | Playbook §2 |
| 2 | `auth` | authn/authz middleware chain, ownership guard, auth rate limit | Playbook §3.1 |
| 3 | `rls` | Multi-tenant RLS, non-owner role, GUC, bypass vs tenant-context, cutover sweep | Playbook §3.2 |
| 4 | `money` | Integer minor units, tx maxWait, SAVEPOINT idempotency, deterministic orderBy | Playbook §2/§3.3 |
| 5 | `event-log` | Append-only `<entity>_events` with raw payloads for money/trust | Playbook §3.4 |
| 6 | `cache-ratelimit` | Redis rate-limit, two-tier cache, TTL floor, replica-safe | Playbook §3.5 |
| 7 | `feature-flags` | 4-layer enforcement, plan-baseline + override resolution | Playbook §3.6 |
| 8 | `scaling` | Vertical sliders, replica prereqs (socket adapter, cron leader-election) | Playbook §4 |
| 9 | `testing` | 5 layers, CI gating, teardown discipline | Playbook §5; Rule 14 |
| 10 | `cicd` | Canonical workflow shape, timeouts, audit split, notify-failure, runner routing | Playbook §6; Rule 15 |
| 11 | `deploy-verify` | Simulate target commands, lockfile 4-dimensions | Playbook §7 |
| 12 | `observability` | Sentry, uptime, ≥30-day logs, SLO, queue-depth, alert bridge | Playbook §8 |
| 13 | `security` | XSS, injection, secrets 0/0/0/0, PII mask, CSV-formula, consent, erasure, headers | Playbook §9; Rules 1,2 |
| 14 | `dr` | Snapshot/backup, rollback, additive-only migrations, restore re-verify RLS | Playbook §10 |
| 15 | `environments` | Local/staging never prod, queue prefix, CI-enforced isolation | Playbook §11 |
| 16 | `docs-parity` | All docs updated same session (local + pushed) | Playbook §12 |
| 17 | `data-ui-coverage` | Every meaningful table has a viewer; admin-endpoint connection; redundancy | Playbook §3.7/§14 |
| 18 | `deps` | Registry-exists, <12mo, license-compat, `npm audit` 0/0/0/0, override-the-leaf | Rule 1 |
| 19 | `frontend-quality` | i18n/RTL parity, a11y/WCAG, perf/CWV, SEO | iceberg + grading matrix |
| 20 | `mobile` | Store compliance, MASVS, push, OTA staged rollout (N/A for FWB/WBS) | reference-mobile-* methodology |
| 21 | `migration-safety` | Expand/contract, rollback-with-migration, staging mirror, constraint pre-checks, boot-time migration risk | Reel fleet 2026-08-08 + FWB sku/index incidents |
| 22 | `error-surface` | Public vs private error layers, every boundary, correlation ids, redacted log pipeline | Reel fleet 2026-08-08 |
| 23 | `ai-transparency` | EU AI Act SGI labelling, consent gate, immutable generation log, jurisdictional reach | Reel fleet 2026-08-08 (Act live 2026-08-02) |
| 24 | `edge-protection` | WAF in front of the whole stack, adaptive rate limiting, abuse playbook | Reel fleet 2026-08-08 |
| 25 | `unit-economics` | Cost per feature AND per tenant, revenue:cost ratio, margin alerting | Reel fleet 2026-08-08 |
| 26 | `skill-hygiene` | Installed-skill expiry (apply/verify/dispose), reviewer-vendor rotation — grades the AGENT's config, not its output | Reel fleet 2026-08-31 |
| 27 | `gate-integrity` | A gate's PASS must be reachable only by reading the artifact: receipt-bound verdicts, empty-input fails, exit codes are not evidence, `=== true` at injected seams | Corpus-pipeline session 2026-09-02 |
| 28 | `mutation-proof` | Every defence carries a recorded mutation that made its named test go red, plus a byte-identical restore | Session 2026-09-02 (4 false-green defences) |
| 30 | `absent-filter-matches-everything` | A query filter built from an optional value must be proven present before the query runs — a dropped condition widens the result set, it does not narrow it | Reel lens pack 2026-09 L6 + `force-website-builder` P0 2026-09-03 |
| 29 | `enumeration-integrity` | Counts reconcile against an independent total, NUL-safe iteration, path-not-basename ids, score-not-first-match classification | Corpus-census session 2026-09-02 |
| 31 | `supply-chain` | Action refs pinned to SHAs, no branch refs, consumers pin our reusable workflows, `npm audit signatures`, vendored-source provenance | Harness extraction 2026-09-04 (223/229 refs mutable) |
| 32 | `agent-containment` | Hook-bypass and gate-config-weakening blocked in code, every declared hook registered, credentials scrubbed before spawn | Harness extraction 2026-09-04 (a shipped hook that had never fired) |
| 33 | `rsc-payload-exposure` | Server→client props serialise in full: explicit `select`, a DTO at every boundary, sensitive fields never on the wire | Reel lens pack 2026-09 L16 |
| 34 | `psp-account-survival` | Policy pages, support contact, statement descriptor, dispute-ratio alerting, ToS as dispute evidence — the account, not the payment path | Reel lens pack 2026-09 L17 |
| 35 | `model-currency` | One source per product, vendor alias over a versioned pin, verified against the vendor's list, loud failure on an unknown id | Reel lens pack 2026-09 L18 + CLAUDE.md model-routing rule |
| 36 | `auth-token-lifecycle` | Session id regenerated on login/privilege change, reset token expires ≤15min + single-use + invalidated on any password change + rate-limited issuance | Reel lens pack 2026-09 L21, L23 |
| 37 | `api-schema-exposure` | Introspection/Swagger/Playground disabled in prod, query depth limited, no exposed source maps — the self-describing-endpoint sibling of `rsc-payload-exposure` | Reel lens pack 2026-09 L24 |
| 38 | `aeo-integrity` | Locale-matched meta content per URL (not just present), canonical on every page, single canonical brand entity, deliberate+documented AI-crawler policy, rendered-text substance floor | Reel lens pack 2026-09 A1-A5 (live measurement, `pecannbee.com.kw`, 2026-09-19/22) |
| 39 | `navigation-integrity` | Native-stack dismiss vetoed only via `usePreventRemove`, never a raw `beforeRemove`+`preventDefault` (ignored by iOS swipe-dismiss → ghost route, dead navigation); explicit close on every blocked screen | gcc-horse-market device audit 2026-10-07 (memory `feedback-native-stack-beforeremove-swipe-dismiss`) |
| 40 | `state-transition-integrity` | Approve/review/revoke/publish/restore/grant/suspend are conditional on the current state (`updateMany where status = expected`), a repeat is a no-op/409 with one audit row, resubmission blocked while settled, undo derives its target, UI shows per-entity status | gcc-horse-market sense audit 2026-10-07 (PRs #205, #209) |
| 41 | `real-world-sense` | Location pairing, gate order (guest → signed-in → verified → owner), money + lifecycle (no 0-for-unknown, no live-when-ended, Range/206 video), identity reuse — "nothing is logical until it makes sense" | gcc-horse-market sense audit 2026-10-07 (memory `feedback-sense-audit-real-world-logic`) |

## Source lens packs

The rubric above is the graded form. The **source packs** the lenses were derived from —
original claims, verbatim, with the concrete scenario attached — live in
[`audit/lenses/`](../audit/lenses/00-index.md), along with per-repo fleet status so a pack
re-runs against repos it has not been applied to yet. Lenses 21–25 came from the
2026-08-08 reel fleet; lens 26 from 2026-08-31. Lenses 27–29 came from a single
engineering session on 2026-09-02 and are sourced from memory files rather than a lens pack.
Lenses 33–35 came from three reels watched 2026-09-19 (pack L16–L18); L18's source claim was
false on verification, and the lens is the first-party rule that survived it. Lenses 36–38 came
from a second `@mattmurphyai` batch watched 2026-09-22 (pack L21/L23, L24) plus five live AEO
findings (pack A1–A5) measured the same day against a real FWB merchant store; three other
claims in that batch (L19 clickjacking, L20 Redis-as-a-database, L22 open redirect) extended
existing docs (`security.md` crit 14, `cache-ratelimit.md` crit 10, `auth.md` crit 11) instead
of becoming new lenses, and two (L25 compliance docs, L26 vendor sovereignty) were ruled
process-only and are recorded in the pack without a graded doc.
Lenses 39–41 came from the gcc-horse-market launch-readiness day, 2026-10-07 (pack `audit/lenses/gcc-horse-market-2026-10.md`: device test + four-lens sense audit, PRs #197–#209); the fourth lesson of that day, the lockfile written by a different npm major than CI, extended `deploy-verify.md` criterion 8 instead of becoming a lens.

## Grade scale

- `0` = absent · `1` = partial · `2` = solid (matches the FWB/WBS reference).
- Layer grade = rounded mean of its criteria; any **Critical-severity FAIL caps the layer at 0**.

## Cross-cutting standard docs

Beyond the 29 per-concern lenses above, twelve docs describe HOW the standard is applied rather than a single concern:

- `unified-audit.md` — THE entry point for "audit this repo" (`/force-audit`); blends all lenses + blast-radius into one report (see the 🔭 callout above).
- `lens-calibration.md` — a new audit lens is not done until it has been wrong on a real repo: five artifacts (probe, manifest, rubric, known-bad fixture, CLEAN TWIN), a per-finding REAL/FALSE-POSITIVE verdict against a real repository, and a mutation proof. Severity follows reachability; zero is a claim that needs a measurement.
- `audit-gating.md` — per-PR scoped (blast-radius) audit vs full nightly/on-demand fleet; what blocks a merge (P0/P1) vs what's tracked (P2/P3).
- `closed-loop-audit.md` — a finding without a rerun is half an audit: identify → fix →
  verify by RERUN. Every finding names the check that would prove it fixed; prefer a
  gate in the target repo to a one-time result; the rerun runs against the CHANGED
  commit; declined findings close via a ruling, not silence.
- `dreaming-cycle.md` — the daily autonomous LEARN→SCAN→ACT loop (CVE/dep research → scan all repos → auto-fix safe tier / propose the rest).
- `worktree-lifecycle.md` — per-task worktree birth→merge→teardown; delete the local worktree+branch right after a merge, behind 4 safety gates (`ops/post-merge-cleanup.sh`), so zombie branches / root-owned leftovers never pile up.
- `agent-security.md` — agent-RUNTIME security (lethal trifecta, prompt-injection→tool-exec, MCP Top-10) applied to WBS/Zero/dream-fix; the code-security gates live in `security.md`.
- `self-healing.md` — the OS medic: auto-remediation (railway redeploy / vercel rollback) on confirmed-down, heal-immediately-then-notify, with anti-flap + cooldown + escalation. The action layer atop the detect+alert monitors.
- `verify-before-assert.md` — check ground truth before calling anything stale/unused/violating; an instruction describes the world, it is not evidence about it. The 60-second checks (curl the `server:` header, `gh api` every repo, `git ls-remote` not push output, confirm a gate's binary exists). Born from 4 false assertions in one session, 2026-07-20.
- `coding-hygiene.md` — Karpathy universal LLM-coding-pitfall guardrails (think-before-coding, simplicity, surgical changes, goal-driven); the always-on hygiene layer in the operator CLAUDE.md.
- `session-handoff.md` — lossless session continuity: a **per-session** handoff (`<repo>/.handoff/<session-id>.md`, else `~/.claude/handoff/<session-id>.md`) with Goal/State/Done/In-progress/Left, surfaced on SessionStart + flushed before compaction, with a `⚑HANDOFF` statusline badge at 40% context remaining so clearing the chat stays cheap. Per-session since 2026-08-26: one shared path let two parallel sessions silently destroy each other's state. (`ops/handoff.sh` + `ops/lib/handoff-paths.sh` + hooks.)
- `rules/` — per-language/framework rule packs (typescript, react-nextjs, node-express, prisma-postgres, bash-ops) auto-relevant by file type; distilled from real incidents.
- `rulings.md` — the dispatch record: every decision that overrides a plan, rejects a finding or accepts a residual is written down with its evidence and **what it costs if it is wrong**, at decision time, in a tracked ledger. Stops re-litigation and makes a declined finding traceable. From the course-platform build's 32 rulings (2026-09-04).
- `common-test-files.md` — the shared test-infra (prod-guards + setup) every repo and every worktree must always keep + propagate; the registry teardown gate 4 confirms.

## Memory lessons folded into this standard

Cross-reference so `dream-standard-drift.sh` (which matches the memory-file slug verbatim) sees each cross-cutting lesson as covered, and a human can trace lesson → standard doc. The **concept** was already in the standard for the first group; the last two were newly folded into `deps.md` (crit 10–11) on 2026-07-01.

| memory lesson (slug) | lives in |
|---|---|
| `feedback-blast-radius-sweep-on-every-change` | `audit-gating.md`, `unified-audit.md`, `dreaming-cycle.md` (+ `ops/blast-radius.sh`) |
| `feedback-migrate-before-deploy-and-force-dynamic` | `deploy-verify.md`, `cicd.md` |
| `feedback-workers-no-module-env-secrets` | `security.md`, `environments.md` |
| `feedback-cf-workers-builds-autonomous-cicd` | `cicd.md`, `deploy-verify.md` |
| `feedback-cf-migration-platform-host-drift` | `deploy-verify.md`, `environments.md` |
| `feedback-audit-severity-by-deployment-scope` | `audit-gating.md` |
| `reference-php-laravel-lens-pack` | `lens-calibration.md` |
| `feedback-parallel-test-shared-db-truncate-race` | `testing.md`, `common-test-files.md` |
| `feedback-react19-form-action-resets-uncontrolled-inputs` | `frontend-quality.md` |
| `feedback-subagent-pnpm-pollution-dual-react` | `deps.md` (crit 10) — **new 2026-07-01** |
| `feedback-pnpm-react18-19-types-coexistence` | `deps.md` (crit 11) — **new 2026-07-01** |
| `feedback-session-handoff-and-context-hygiene` | `session-handoff.md` — **new 2026-07-14** |
| `feedback-jsonparse-any-poisoning` | `rules/typescript.md` (Must Always + Traps) — **new 2026-07-14** |
| `feedback-gate-that-cannot-fail-reports-success` | `gate-integrity.md` (lens 27) — **new 2026-09-02** |
| `feedback-test-that-passes-for-the-wrong-reason` | `mutation-proof.md` (lens 28) — **new 2026-09-02** |
| `feedback-enumeration-is-a-measurement` | `enumeration-integrity.md` (lens 29) — **new 2026-09-02** |
| `feedback-a-record-of-proof-can-be-false` | `mutation-proof.md` (§2) — **new 2026-09-04** |
| `feedback-fake-that-reimplements-what-it-verifies` | `testing.md` (crit 14–16) — **new 2026-09-04** |
| `feedback-gate-ships-a-different-build` | `cicd.md` (gate↔artifact section) + `gate-integrity.md` (§2) — **new 2026-09-04** |
| `feedback-ruling-form-cost-if-wrong` | `rulings.md` — **new 2026-09-04** |
| `feedback-security-fix-claims-about-who-it-does-not-affect` | `auth.md` (crit 8-10) — **new 2026-09-05** |
| `feedback-csrf-guard-method-aware` | `auth.md` (crit 7) — **new 2026-09-04** |
| `feedback-never-run-gate-is-the-deadest-gate` | `gate-integrity.md` + `common-test-files.md` (crit 6) — **new 2026-09-04** |
| `feedback-monitor-alert-measures-the-monitor` | `observability.md` + `common-test-files.md` (shape-aware gate 4) — **new 2026-09-04** |
| `feedback-test-truncate-wiped-prod-db` | `common-test-files.md` (crit 1-3; it is that doc's `sources:` line) — **new 2026-09-04** |

> The drift detector's exact-slug match is why concepts already covered (e.g. blast-radius) still flagged as "gaps" — this mapping is the canonical fix; add a row here whenever a new cross-cutting lesson lands so the detector stays accurate.

## Tag legend

- `[BUILD]` — used when scaffolding/guiding a new product.
- `[AUDIT]` — used as a grading criterion against an existing repo.
- `[BOTH]` — both (most items).

## Sources merged into this standard

- `~/.claude/CLAUDE.md` — the 15 code-quality rules
- `~/.claude/PRODUCTION-SAAS-BUILD-PLAYBOOK.md` — 16-section playbook
- `~/.claude/projects/-Users-ahmadsharaf/memory/reference-iceberg-audit.md` — 38-term audit
- `~/.claude/projects/-Users-ahmadsharaf/memory/reference-audit-fleet-and-build-playbook.md`
- `~/.claude/projects/-Users-ahmadsharaf/memory/reference-force-ai-production-grade-standard.md` — 15-layer grading matrix
