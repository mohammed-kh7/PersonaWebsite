/** Bare-interactive onboarding. Explicit commands never enter this module's flow. */
import { existsSync, realpathSync, statSync } from "node:fs";
import { homedir } from "node:os";
import { join, parse, resolve } from "node:path";
import { spawn } from "node:child_process";
import { createInterface } from "node:readline/promises";
import { safeText } from "./ui.mjs";

const stableVersion = (value) => typeof value === "string" && /^(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})$/.test(value);
const newer = (latest, current) => {
  if (!stableVersion(latest) || !stableVersion(current)) return false;
  const a = latest.split(".").map(Number), b = current.split(".").map(Number);
  for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] > b[i];
  return false;
};
export const shouldRunWizard = ({ args, stdin, stdout }) => args.length === 0 && stdin.isTTY === true && stdout.isTTY === true;

/** Follow aliases before deciding: a symlink to home must never become a project. */
export function projectFolder(input, { cwd = process.cwd(), home = homedir() } = {}) {
  try {
    const value = String(input).trim();
    if (!value || /[\x00-\x1f\x7f]/.test(value)) return null;
    const expanded = value === "~" ? home : value.startsWith("~/") ? join(home, value.slice(2)) : value;
    const path = realpathSync(resolve(cwd, expanded));
    if (!statSync(path).isDirectory() || path === parse(path).root || path === realpathSync(home)) return null;
    if (!existsSync(join(path, ".git")) && !existsSync(join(path, "package.json"))) return null;
    return path;
  } catch { return null; }
}

/** Timeout covers headers AND the response body. Offline/invalid metadata is silent. */
export async function checkLatest(fetcher = globalThis.fetch) {
  try {
    const response = await fetcher("https://registry.npmjs.org/mypovonai-audit/latest", { signal: AbortSignal.timeout(1500) });
    if (!response.ok) return null;
    const { version } = await response.json();
    return stableVersion(version) ? version : null;
  } catch { return null; }
}

/** Never interpolate registry data into a shell command. */
export function reexecLatest(version, args, spawnChild = spawn) {
  if (!stableVersion(version)) return Promise.resolve(1);
  return new Promise((done) => {
    try {
      const child = spawnChild(process.platform === "win32" ? "npx.cmd" : "npx", ["-y", `mypovonai-audit@${version}`, ...args], { stdio: "inherit", shell: false });
      child.once("error", () => done(1));
      child.once("exit", (code, signal) => done(code ?? (signal === "SIGINT" ? 130 : 1)));
    } catch { done(1); }
  });
}

export async function runWizard({ version, args = [], cwd = process.cwd(), home = homedir(), lensCount,
  fetchLatest = checkLatest, reexec = reexecLatest, ask, write = console.error,
  showBanner, runScore, runReport, hasKey, endpoint = "https://mypovonai.com" }) {
  let rl;
  // Keep readline out of the way of the inherited child and the scanner.
  const question = ask ?? (async (prompt) => {
    rl ??= createInterface({ input: process.stdin, output: process.stderr });
    const controller = new AbortController();
    const cancel = () => controller.abort();
    rl.once("SIGINT", cancel); rl.once("close", cancel);
    try { return await rl.question(prompt, { signal: controller.signal }); }
    finally { rl.off("SIGINT", cancel); rl.off("close", cancel); }
  });
  const confirm = async (prompt) => {
    for (;;) {
      const answer = (await question(prompt)).trim();
      if (/^(?:y(?:es)?)?$/i.test(answer)) return true;
      if (/^n(?:o)?$/i.test(answer)) return false;
      write("Please answer Y or n.");
    }
  };
  const closePrompt = () => { rl?.close(); rl = undefined; };
  try {
    showBanner();
    const latest = await fetchLatest();
    if (newer(latest, version) && await confirm(`You're on ${version}, latest is ${latest}. Update now? (Y/n) `)) {
      closePrompt();
      return await reexec(latest, args);
    }
    let repo = projectFolder(cwd, { cwd, home });
    while (!repo) {
      write("Choose a project with .git or package.json; home and filesystem root cannot be scanned.");
      repo = projectFolder(await question("Which project folder? (path) "), { cwd, home });
    }
    closePrompt();
    write(`Step 1 of 3 · Score (free, local) → Step 2 · Full report (needs a key) → Step 3 · Fix (patch)\n${lensCount} lenses · ${safeText(repo)}`);
    const scoreCode = await runScore(repo);
    if (scoreCode !== 0) return scoreCode;
    write("┌─ Next step ─────────────────────────────────────");
    if (!hasKey) {
      write(`│ Get a key: ${safeText(endpoint.replace(/\/$/, ""))}/en/audit/cli\n│ mypovonai-audit login <key>\n│ Then: mypovonai-audit run → mypovonai-audit fix`);
      write("└────────────────────────────────────────────────");
      return 0;
    }
    write("│ Full report uses your key and audit tokens; fix writes a patch.");
    write("└────────────────────────────────────────────────");
    if (!await confirm("Run the full report now? (Y/n) ")) return 0;
    closePrompt();
    return await runReport(repo);
  } catch (error) {
    if (["ABORT_ERR", "ERR_USE_AFTER_CLOSE"].includes(error.code) || error.name === "AbortError") return 130;
    throw error;
  } finally { closePrompt(); }
}
