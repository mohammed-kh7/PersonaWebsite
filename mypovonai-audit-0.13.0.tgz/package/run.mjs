#!/usr/bin/env node
/**
 * The audit fleet runner — the Force AI force-audit skill, carried over whole.
 *
 *   node fleet/run.mjs --repo <path> [--out findings.json]
 *
 * ## The order matters, and step 0 is the whole reason this is trustworthy
 *
 *   0. prove the gates are ALIVE   tests/probe-fires.sh, 29 known-bad fixtures
 *   1. probes LOCATE               deterministic bash, no model cost
 *   2. an agent JUDGES             only the candidates, never the repo
 *   3. grade against standard/
 *
 * Step 0 is not ceremony. From the skill's own rule: "Never report a lens as
 * passing because its probe was silent. A silent probe can be a dead gate."
 * A zero from a broken probe is indistinguishable from a clean repo, so this
 * runner ABORTS rather than audit with an unproven gate — an audit that cannot
 * tell those apart is worth less than no audit, because it is believed.
 *
 * ## Why the model never sees the repo
 *
 * The first version of this file sent selected source files to the model and
 * asked it to find problems. That was wrong twice over: it costs a fortune on a
 * 357k-line repo, and it lets the model INVENT findings. The skill's rule is
 * the opposite — "an agent may DOWNGRADE a probe finding to a false positive,
 * with a written reason tied to the code it read, but may never invent a
 * finding the probes did not surface."
 *
 * So the model is handed candidates and their evidence windows, and its only
 * powers are to confirm, to downgrade with a reason, and to say what it could
 * not tell. Findings come from probes. Judgment comes from the model. Neither
 * does the other's job.
 */
import { execFileSync } from "node:child_process";
import { readFileSync, readdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

import { privateEvidence } from "./evidence.mjs";
import { dirname } from "node:path";
import { isMain } from "./is-main.mjs";
import { safeText } from "./ui.mjs";
import { diffRuns } from "./diff.mjs";
import { findingIdentity } from "./identity.mjs";
import { partitionSamples, sampleNotice } from "./paths.mjs";
import { buildInterpreterPrompt, collectRepoEvidence, parseInterpreterResult } from "./interpret.mjs";
import { resolveTransport } from "./transports.mjs";

const FLEET_DIR = fileURLToPath(new URL(".", import.meta.url));

export function loadLenses() {
  return readdirSync(join(FLEET_DIR, "lenses"))
    .filter((f) => f.endsWith(".json"))
    .map((f) => JSON.parse(readFileSync(join(FLEET_DIR, "lenses", f), "utf8")))
    .sort((a, b) => a.id.localeCompare(b.id));
}

/**
 * Step 0. Returns the list of probes proven to fire on their known-bad fixture.
 *
 * A non-zero exit means at least one gate is dead, and the caller must refuse
 * to audit rather than produce zeros nobody can trust.
 */
export function proveGatesAlive() {
  try {
    const out = execFileSync("bash", [join(FLEET_DIR, "tests", "probe-fires.sh")], {
      encoding: "utf8",
      timeout: 300_000,
      cwd: FLEET_DIR,
    });
    const alive = [...out.matchAll(/^ok: (\S+)/gm)].map((m) => m[1]);
    return { ok: true, alive, dead: [] };
  } catch (error) {
    const text = String(error?.stdout ?? "") + String(error?.stderr ?? "");
    const dead = [...text.matchAll(/DEAD GATE:?\s*(\S+)/g)].map((m) => m[1]);
    return { ok: false, alive: [...text.matchAll(/^ok: (\S+)/gm)].map((m) => m[1]), dead };
  }
}

/** Runs one probe. Probes always exit 0 and emit newline-delimited JSON. */
export function runProbe(lensId, repoPath) {
  let raw = "";
  try {
    raw = execFileSync("bash", [join(FLEET_DIR, "probes", `${lensId}.sh`), repoPath], {
      encoding: "utf8",
      timeout: 180_000,
      maxBuffer: 32 * 1024 * 1024,
    });
  } catch (error) {
    // A probe that crashed has NOT reported a clean lens.
    return { findings: [], skipped: [], crashed: String(error?.message ?? error).slice(0, 200) };
  }
  const findings = [];
  const skipped = [];
  let lastFinding = null;
  for (const line of raw.split("\n")) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch {
      continue;
    }
    if (row.type === "finding") {
      lastFinding = { ...row, evidence: [] };
      findings.push(lastFinding);
    } else if (row.type === "evidence" && lastFinding) {
      lastFinding.evidence.push(row.cmd);
    } else if (row.type === "skipped") {
      skipped.push(row);
    }
  }
  return { findings, skipped, crashed: skipped.some(row => String(row.reason ?? "").startsWith("coverage incomplete:")) ? "coverage incomplete: probe could not enumerate the repository safely" : null };
}

/** Runs the evidence command so the judge sees the code, not just the claim. */
export function collectEvidence(cmd, repoPath) {
  // Fleet evidence is local inspection. Network/registry checks need separate
  // operator execution and must not inherit permission from source judging.
  if (/(?:^|[;&|])\s*(?:npm|npx|pnpm|yarn|curl|wget|git)\b/.test(cmd)) {
    return "(evidence requires a network-capable command; not executed; inspect locally)";
  }
  // stdout, stderr AND the exit code, because for roughly half the lenses the
  // finding is that something is ABSENT and the command that proves it FAILS.
  // `ls .gitleaks.toml` exiting 1 with "No such file" is the whole proof; the
  // earlier version caught the throw and returned "", so the judge was handed
  // nothing and correctly answered "cannot tell" to every absence finding.
  const run = (args) =>
    execFileSync("bash", args, {
      encoding: "utf8",
      cwd: repoPath,
      env: { PATH: `${dirname(process.execPath)}:/usr/bin:/bin:/usr/sbin:/sbin`, LANG: "C", LC_ALL: "C" },
      timeout: 20_000,
      maxBuffer: 1024 * 1024,
      stdio: ["ignore", "pipe", "pipe"],
    });
  try {
    const out = run(["-c", cmd]);
    return out.trim() ? privateEvidence(out).slice(0, 4000) : "(command succeeded and printed nothing)";
  } catch (error) {
    const stdout = String(error?.stdout ?? "");
    const stderr = String(error?.stderr ?? "");
    const code = error?.status ?? "?";
    const body = /No such file|cannot access/i.test(stderr) ? "(cannot access requested path)" : privateEvidence(`${stdout}${stderr}`).trim();
    return `(command exited ${code})\n${body}`.slice(0, 4000);
  }
}

export function buildJudgePrompt(lens, standardText, candidates) {
  const rows = candidates
    .map(
      (c, i) =>
        `## candidate ${i + 1}\nseverity: ${c.severity}\nlocation: ${c.location}\nmessage: ${c.message}\n` +
        `evidence:\n${c.evidenceText || "(no evidence command was recorded for this candidate)"}`,
    )
    .join("\n\n");

  return `You are judging candidate findings for ONE lens: ${lens.title} (${lens.id}).

These candidates came from a deterministic probe. Probes deliberately over-report:
they locate candidates, they do not judge.

YOUR POWERS ARE EXACTLY THREE, and the third is as important as the others:
1. CONFIRM a candidate — the evidence shows the defect is real.
2. DOWNGRADE it to a false positive — you MUST give a reason tied to the code you
   were shown. "Looks fine" is not a reason.
3. Say you CANNOT TELL from the evidence shown, and what would settle it.

You may NOT invent a finding the probe did not surface. A finding is a hypothesis
until a probe reproduces it; you are grading hypotheses, not hunting.

## How to read the evidence when the finding is that something is ABSENT

Many criteria are about a missing control, and for those the reproducing command
is a SEARCH. A search that finds nothing is the confirmation, not a failure to
produce evidence:

- "(command exited N)" followed by "No such file or directory" (or "cannot
  access") for a file the message says is missing CONFIRMS the finding. That is
  what absence looks like from a shell. The exit code itself varies by platform
  and carries no meaning beyond "this failed".
- "(command succeeded and printed nothing)" for a grep whose message says the
  pattern is nowhere in the tree CONFIRMS the finding, for the same reason.
- Never rule that a path, file or directory does not exist, is missing or is absent
  unless the evidence command shown for that candidate proved it. The evidence is a
  bounded excerpt, not the whole repository: a path you cannot see is not thereby
  absent, and "I was not shown it" is "cannot-tell", never a verdict on the repo.
- Reserve "cannot-tell" for a candidate whose evidence is genuinely ambiguous —
  a command that errored for an unrelated reason, or output that neither shows
  the defect nor rules it out. Do not use it merely because a search came back
  empty when empty was the point.

<rubric>
${standardText}
</rubric>

<criteria>
${(lens.criteria ?? []).map((c) => `- ${c.id} (${c.severity}): ${c.description}`).join("\n")}
</criteria>

${rows}

Reply with ONLY JSON:
{"verdicts":[{"candidate":1,"ruling":"confirmed|false-positive|cannot-tell","severity":"critical|high|medium|low","why":"tied to the code shown","scenario":"specific state -> specific wrong outcome"}]}`;
}

export function parseVerdicts(text, expected) {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("judge reply contained no JSON");
  const parsed = JSON.parse(text.slice(start, end + 1));
  if (!Array.isArray(parsed.verdicts)) throw new Error("judge reply has no verdicts array");
  for (const v of parsed.verdicts) {
    if (!["confirmed", "false-positive", "cannot-tell"].includes(v.ruling)) {
      throw new Error(`unknown ruling: ${v.ruling}`);
    }
    // A downgrade without a reason is how a real finding gets quietly dropped.
    if (v.ruling === "false-positive" && !String(v.why ?? "").trim()) {
      throw new Error("a false-positive verdict carries no reason");
    }
  }
  if (parsed.verdicts.length > expected) throw new Error("judge returned more verdicts than candidates");
  return parsed.verdicts;
}


/** The rubric text for a lens id — what the fix agent grades its patch against. */
export function readStandardFor(lensId) {
  const lens = loadLenses().find((l) => l.id === lensId);
  return lens ? readStandard(lens) : "";
}

function readStandard(lens) {
  const name = (lens.standard ?? "").split("/").pop();
  try {
    return readFileSync(join(FLEET_DIR, "rubric", name), "utf8");
  } catch {
    return `(rubric ${name} not vendored)`;
  }
}

export async function runFleet({
  repoPath,
  apiKey = null,
  /**
   * Where the judging model comes from. The default is `api`, which means "use
   * the key you were given and nothing else" -- so a caller that passes no key
   * gets no judging, exactly as before.
   *
   * `local` is opt-in ON PURPOSE. Falling back to the signed-in `claude` CLI
   * whenever a key was absent would turn every free probe run into a judged one
   * without the caller asking: measured here, it took a 2-second test to 224
   * seconds. Spending someone's seat is a decision, not a default.
   *
   * A run with no transport reports `unjudged` -- never that it judged and
   * found nothing.
   */
  transport = undefined,
  prefer = "api",
  baseline = null,
  interpret = false,
  /** Score findings at fixture/sample paths too (see paths.mjs). Default: set them aside, reported. */
  includeSamples = false,
  onProgress = () => {},
  /** Presentation hook only: `{phase, state?, done?, total?, lens?, count?}`. Never affects the report. */
  onStage = () => {},
}) {
  onStage({ phase: "gates", state: "start" });
  const gates = proveGatesAlive();
  onStage({ phase: "gates", state: "done", count: gates.alive.length });
  if (!gates.ok) {
    // Refusing is the correct outcome. Auditing past a dead gate produces zeros
    // that read as clean and cannot be distinguished from a working probe.
    return { aborted: "dead_gate", deadGates: gates.dead, lensesProven: gates.alive.length };
  }

  const seat = transport === undefined ? resolveTransport({ apiKey, prefer }) : transport;
  const lenses = loadLenses();
  const results = [];
  let inputTokens = 0;
  let outputTokens = 0;

  // Probe every lens first. Probing is deterministic bash over a working tree —
  // cheap, and it has to finish before anything can be judged anyway.
  const toJudge = [];
  const sampleFindings = [];
  onStage({ phase: "probe", done: 0, total: lenses.length });
  let probedCount = 0;
  for (const lens of lenses) {
    const probed = runProbe(lens.id, repoPath);
    probedCount += 1;
    onStage({ phase: "probe", done: probedCount, total: lenses.length, lens: lens.id });
    const { skipped, crashed } = probed;
    // After the probe, before the judge: sample-path findings neither score nor
    // cost a judge call, but they are listed in `report.samples`.
    const { kept: findings, samples } = partitionSamples(probed.findings, repoPath, { includeSamples });
    for (const f of samples) {
      sampleFindings.push({
        lens: lens.id,
        severity: f.severity,
        location: f.location,
        message: f.message,
        identity: findingIdentity(f, repoPath),
      });
    }
    if (crashed) {
      results.push({ id: lens.id, status: "probe-crashed", detail: crashed });
      onProgress(lens.id, crashed.startsWith("coverage incomplete:") ? "coverage incomplete (output/traversal limit)" : "probe failed (timeout or process error)");
      continue;
    }
    if (findings.length === 0) {
      // The probe is proven alive by step 0, so a silent probe here is a real
      // clean — but any `skipped` note travels with it, because a lens that
      // could not examine something has not cleared it.
      results.push({ id: lens.id, status: skipped.length ? "partial" : "clean", skipped });
      onProgress(lens.id, skipped.length ? `clean, ${skipped.length} skipped` : "clean");
      continue;
    }

    const candidates = findings.map((f) => ({
      ...f,
      // The stable id that makes a rerun a rerun. Computed here, once, so the
      // probe output, the report, the patch and the diff all name the same
      // finding by the same string.
      identity: findingIdentity(f, repoPath),
      evidenceText: seat ? f.evidence.map((cmd) => collectEvidence(cmd, repoPath)).join("\n").slice(0, 6000) : undefined,
    }));

    if (!seat) {
      // Emit the ROWS, not just a count. An unjudged run is still a real
      // measurement -- it is what the free tier and the post-patch rerun
      // produce -- and a count cannot be diffed against a later run.
      results.push({
        id: lens.id,
        status: "unjudged",
        candidates: candidates.map((c) => ({ ...c, evidenceText: undefined })),
        skipped,
      });
      onProgress(lens.id, `${candidates.length} candidate(s), UNJUDGED (no judging seat)`);
      continue;
    }

    // Queue it. Each lens's judge call is independent of every other, and a
    // local seat pays a process start per call: measured, nine lenses judged
    // one after another took 276 seconds, almost all of it spent starting the
    // CLI again.
    toJudge.push({ lens, candidates, skipped });
  }

  // Concurrency, chosen by MEASUREMENT rather than by instinct.
  //
  // The instinct was that a local seat pays a process start per call, so running
  // four at once would collapse the wall clock. It did the opposite: nine lenses
  // took 276s one at a time and 326s at four-way concurrency on the same
  // machine and repo. The cost is the model, not the process start, and four
  // local CLIs contend rather than overlap.
  //
  // So: one at a time for an unmetered local seat. A metered API seat is
  // network-bound rather than process-bound and should parallelise — that is
  // reasoning, NOT a measurement, because there was no key to test it with, so
  // it stays conservative at two and is tunable.
  const JUDGE_CONCURRENCY = Number(
    process.env.FLEET_JUDGE_CONCURRENCY ?? (seat?.metered ? 2 : 1),
  );
  const queue = [...toJudge];
  let settled = 0;
  if (toJudge.length) onStage({ phase: "judge", done: 0, total: toJudge.length });
  const judgeOne = async ({ lens, candidates, skipped }) => {
    try {
      return await judgeLens({ lens, candidates, skipped });
    } finally {
      settled += 1;
      onStage({ phase: "judge", done: settled, total: toJudge.length, lens: lens.id });
    }
  };
  const judgeLens = async ({ lens, candidates, skipped }) => {
    try {
      const { text, usage } = await seat.ask(buildJudgePrompt(lens, readStandard(lens), candidates));
      const verdicts = parseVerdicts(text, candidates.length);
      inputTokens += usage.input_tokens ?? 0;
      outputTokens += usage.output_tokens ?? 0;
      const confirmed = verdicts.filter((v) => v.ruling === "confirmed");
      results.push({
        id: lens.id,
        status: "judged",
        candidates: candidates.map((c, i) => ({ ...c, evidenceText: undefined, verdict: verdicts[i] ?? null })),
        confirmed: confirmed.length,
        skipped,
      });
      onProgress(lens.id, `${confirmed.length}/${candidates.length} confirmed`);
    } catch (error) {
      // Same reason: a judge failure must not erase the probe's measurement.
      results.push({
        id: lens.id,
        status: "judge-errored",
        candidates: candidates.map((c) => ({ ...c, evidenceText: undefined })),
        error: String(error?.message ?? error),
      });
      onProgress(lens.id, "judge errored");
    }
  };
  await Promise.all(
    Array.from({ length: Math.min(JUDGE_CONCURRENCY, queue.length) }, async () => {
      for (let next = queue.shift(); next; next = queue.shift()) await judgeOne(next);
    }),
  );

  // Results arrive in completion order under concurrency; a report whose lens
  // order changed between two runs would make an eyeball diff useless.
  const order = new Map(lenses.map((l, i) => [l.id, i]));
  results.sort((a, b) => (order.get(a.id) ?? 0) - (order.get(b.id) ?? 0));

  // ---- interpreter seats -------------------------------------------------
  // Eight lenses end in a `skipped` note rather than a verdict. Before this,
  // that note rode along and nobody acted on it: the lens read "partial" and
  // the customer had no route to the rest. Opt-in, because unlike the probes
  // this seat READS the repository. On a metered key that is the cost line; on
  // the signed-in `claude` CLI it is a seat the operator already pays for. The
  // base audit stays at zero either way.
  let repoEvidence = null;
  if (interpret && seat) {
    const interpretTotal = results.filter((r) => (r.skipped ?? []).length > 0).length;
    let interpreted = 0;
    if (interpretTotal) onStage({ phase: "interpret", done: 0, total: interpretTotal });
    for (const result of results) {
      const reasons = (result.skipped ?? []).map((s) => s.reason ?? String(s)).filter(Boolean);
      if (reasons.length === 0) continue;
      interpreted += 1;
      const lens = lenses.find((l) => l.id === result.id);
      if (!lens) continue;
      repoEvidence ??= collectRepoEvidence(repoPath);
      try {
        const { text, usage } = await seat.ask(
          buildInterpreterPrompt(lens, readStandard(lens), reasons, repoEvidence),
        );
        inputTokens += usage.input_tokens ?? 0;
        outputTokens += usage.output_tokens ?? 0;
        const verdict = parseInterpreterResult(text, repoPath);
        result.interpreter = {
          ruling: verdict.ruling,
          why: verdict.why,
          refused: verdict.refused,
          findings: verdict.findings.map((f) => ({
            ...f,
            lens: lens.id,
            identity: findingIdentity({ ...f, lens: lens.id }, repoPath),
          })),
        };
        onProgress(lens.id, `interpreter: ${verdict.ruling}, ${verdict.findings.length} finding(s)` +
          (verdict.refused.length ? `, ${verdict.refused.length} refused` : ""));
      } catch (error) {
        // A failed interpreter leaves the lens exactly as the probe left it:
        // skipped. It never becomes clean.
        const reason = String(error?.message ?? error).slice(0, 200);
        result.interpreter = { ruling: "errored", error: reason };
        // Print the reason, not just the fact. "interpreter errored" was a
        // shrug: it told a customer something failed and gave them nothing to
        // report, and it told us nothing either — the string was captured here
        // and then dropped on the floor. Two lenses failed this way on a real
        // run and the cause had to be reproduced from first principles because
        // the one machine that knew it never said.
        onProgress(lens.id, `interpreter errored — ${reason}`);
      }
      onStage({ phase: "interpret", done: interpreted, total: interpretTotal, lens: lens.id });
    }
  } else if (interpret && !seat) {
    onProgress("interpreter", "requested but no api key — every skipped lens stays skipped");
  }

  const report = {
    lensesProven: gates.alive.length,
    lenses: results,
    // Which seat judged, so a reader can tell a run that cost nothing from one
    // that cost money -- and a run that judged from one that could not.
    // Findings at test-fixture/sample paths: not scored, not judged, not
    // uploaded, but never hidden. `--include-samples` puts them back.
    samples: sampleFindings,
    includeSamples,
    judgedBy: seat?.name ?? null,
    metered: seat?.metered ?? false,
    usage: { inputTokens, outputTokens },
  };
  // A rerun without its parent is just a second unrelated opinion. With one, it
  // is the only evidence a patch actually landed -- which is what the customer
  // is paying the rerun price for.
  if (baseline) report.rerun = diffRuns(baseline, report, repoPath);
  return report;
}

const say_samples = (samples) => console.error(sampleNotice(samples).map(safeText).join("\n"));

if (isMain(import.meta.url)) {
  const arg = (flag) => {
    const i = process.argv.indexOf(flag);
    return i === -1 ? undefined : process.argv[i + 1];
  };
  const repoPath = arg("--repo");
  if (!repoPath) {
    console.error("usage: node fleet/run.mjs --repo <path> [--out file.json] [--baseline prev.json] [--interpret] [--include-samples]");
    process.exit(2);
  }
  const baselinePath = arg("--baseline");
  const report = await runFleet({
    repoPath,
    apiKey: process.env.ANTHROPIC_API_KEY,
    baseline: baselinePath ? JSON.parse(readFileSync(baselinePath, "utf8")) : null,
    interpret: process.argv.includes("--interpret"),
    includeSamples: process.argv.includes("--include-samples"),
    onProgress: (id, note) => console.error(`  ${id.padEnd(22)} ${note}`),
  });
  if (report.samples?.length) say_samples(report.samples);
  if (report.rerun) {
    const r = report.rerun;
    console.error(
      `  rerun: ${r.cleared.length} cleared, ${r.stillPresent.length} still present, ` +
      `${r.introduced.length} introduced, ${r.unknown.length} unknown -> held=${r.held}`,
    );
  }
  const out = arg("--out");
  const json = JSON.stringify(report, null, 2);
  if (out) writeFileSync(out, json);
  else console.log(json);
}
