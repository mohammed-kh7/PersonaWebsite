export async function checkout(prisma, data) { return prisma.$transaction(tx => tx.order.create({data}), {maxWait:5000,timeout:10000}); }
