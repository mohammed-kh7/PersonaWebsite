<?php
// The SAME shape as the known-bad twin, written correctly: every lookup by a
// client-supplied id is scoped to the caller's own records, one of three ways.
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function show($order_id)
    {
        // SAFE: two DISTINCT columns -- the record's own id AND a separate
        // ownership column tied to the current session.
        $order = DB::table('orders')
            ->where('order_id', $order_id)
            ->where('user_id', Auth::id())
            ->first();
        if (!$order) {
            abort(404, 'Order not found');
        }
        return view('orders.show', compact('order'));
    }

    public function invoice($id)
    {
        // SAFE: relationship traversal through the authenticated user -- the
        // query can only ever return an invoice that already belongs to them.
        $invoice = Auth::user()->invoices()->find($id);
        return view('orders.invoice', compact('invoice'));
    }

    public function destroy($id)
    {
        $order = \App\Models\Order::find($id);
        // SAFE: an explicit policy check before touching the record.
        $this->authorize('delete', $order);
        $order->delete();
        return redirect()->route('orders.index');
    }
}
