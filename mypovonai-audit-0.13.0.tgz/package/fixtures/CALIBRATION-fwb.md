# FWB calibration — `rls` lens (2026-08-13)

FWB is the reference. A finding here is either a REAL FWB gap or a probe false
positive — both are recorded, neither is tuned away silently.

## Iteration log

| run | findings | change |
|---|---|---|
| 1 | 9 critical | initial probe: flagged every `prisma.<model>.write` outside `runInTenantContext` |
| 2 | 7 | added ambient-middleware detection (HTTP routes covered by tenant-context) + RLS-scoped-model filter (dropped 2 `users` writes — `users` is deliberately NOT under RLS) |
| 3 | 4 | **restrict to FORCE tables only.** `bulk_ai_jobs` is `ENABLE`-only; FWB connects as `force_app` which owns it, and under ENABLE (not FORCE) the owner bypasses policy → owner-role write with manual `where` scoping is safe. Postgres semantics, not a fudge. Dropped the 5 `bulkAiJob` writes and 0 others incorrectly. |

## CORRECTION (2026-08-13) — the "remaining 4" were FALSE POSITIVES

I called the 4 below REAL. **They are not.** Verifying the policy predicate — the
step I skipped — proved FWB correct. `rls_product_tags_tenant` (and its siblings)
is a HYBRID policy:

```sql
USING ( current_store_id() IS NULL                          -- unset GUC = system path, ALLOW
        OR current_setting('app.bypass_rls', true) = 'true'
        OR store_id = current_store_id() )
```

The `current_store_id() IS NULL → allow` clause means an async/system writer with
no tenant GUC is **permitted by design**; it scopes manually via `where:
{ storeId }`. So the Inngest bulk-ai writers are SAFE. My probe read FORCE-vs-
ENABLE but not the USING clause — a finding is a claim until the predicate
confirms it. The probe now skips FORCE tables whose policy has the NULL-allow /
bypass_rls escape hatch, and FWB rls scores **0**. The 4 below are struck.

## ~~Remaining 4 — verdict: REAL (needs runtime/policy confirmation)~~ STRUCK — false positives

All four are async/script writers to **FORCE-RLS** tables with **zero**
`runInTenantContext`/`withRlsBypass` in the file:

| location | model | table FORCE? | file sets ctx? |
|---|---|---|---|
| `apps/api/scripts/submit-all-templates.ts:60` | whatsAppTemplate | yes | no |
| `apps/api/src/lib/inngest/functions/bulk-ai-image-alt.ts:210` | productImage | yes | no |
| `apps/api/src/lib/inngest/functions/bulk-ai-tags.ts:238` | productTag | yes | no |
| `apps/api/src/lib/inngest/functions/bulk-ai-categorize.ts:219` | productCategory | yes | no |

Under FORCE RLS the table owner is subject to policy, so these writes must
either (a) carry a permissive policy that admits them without the tenant GUC,
or (b) they fail at runtime. This is the exact class FWB's own memory records as
`feedback-rls-force-coverage-breaks-async-writers` (async writers silently
breaking under the FORCE cutover). The static probe cannot see which — that is
the interpretation agent's job with a read-only prod check. **Not tuned away:
surfaced to Ahmad as a genuine question about the reference repo.**

## Probe status: CALIBRATED

The `rls` writer-coverage probe distinguishes ENABLE vs FORCE, honours ambient
middleware, and scopes to models whose tables are actually FORCE-RLS. It fires
on its known-bad fixture (dead-gate test green) and does not flood FWB. It ships.

---

# FWB calibration — deps / security / auth / money (2026-08-13)

Four more lenses, same discipline: refine until FWB shows only real findings.

## deps → 0 findings (clean)
FWB has an npm audit CI step not gated at `--audit-level=critical`. Probe leaves
the live 0/0/0/0 count as an evidence command for the agent (network-bound, kept
out of the probe for reproducibility).

## money → 0 findings (clean, after two calibration fixes)
- `percentageFee Decimal(5,2)` is a RATE ("2.5 for 2.5%"), not minor-units money
  — excluded percent/rate/ratio/pct columns.
- `discount.test.ts` exists but was reported missing: **a real bash trap** —
  `printf | grep -q` under `set -o pipefail` SIGPIPEs the printf (141) and
  pipefail reports that as the pipeline status, flipping a negated test. Fixed
  with here-strings across the probe. This trap is worth a memory entry.

## security → 4 findings (all REAL sinks, not noise)
Excluded two false positives: `<style dangerouslySetInnerHTML>` (CSS, not an HTML
body sink) and a doc COMMENT saying "NO dangerouslySetInnerHTML". The remaining 4
are genuine sinks the interpreting agent must confirm are handled:
`CmsPageContent` (merchant HTML), `layout.tsx` inline theme-bootstrap script,
admin content page, blog. Correct evidence — the probe surfaces, the agent grades.

## auth → 1 finding (REAL, needs confirmation)
`apps/api/src/index.ts:426` calls `requireRole(['super_admin'])` on a route while
FWB also uses `authorize()` elsewhere. Two role-check idioms coexist in prod
routing — the same "surface the reference's real inconsistency" outcome as rls.
The probe distinguishes a route-level call from the rbac/middleware primitive
(that would downgrade to medium); here it is a real route call → critical, for
the agent + Ahmad to confirm the two guards enforce identically.

## Net
deps + money score clean; rls/security/auth surface a small set of REAL findings
about the reference repo — exactly the calibration goal. No lens floods FWB.

---

# Final verdicts after ground-truth verification (2026-08-13)

Every non-zero finding was checked against the actual code/policy, not asserted:

- **rls → 0**: 4 findings were false positives (hybrid NULL-allow policy). Struck.
- **deps → 0**, **money → 0**: clean.
- **security → 0 bugs**: the 4 sinks are safe by design — `CmsPageContent`
  renders HTML the API pre-renders server-side from a structured block array
  (not raw user HTML); `layout.tsx` is a static theme-bootstrap script. The probe
  correctly SURFACES them as evidence; the interpretation agent grades them solid.
- **auth → 1 REAL partial (grade 1, not a bug)**: `authorize()` (auth.ts) and
  `requireRole()` (rbac.ts) are two SEPARATE implementations, not a wrapper. The
  standard mandates one role-check idiom. This is a genuine consistency finding —
  a route could be guarded by either — but not a crash. Worth a cleanup, not a P0.

**Net: FWB has zero bugs the audit could confirm.** As expected of the reference.
The value delivered was three real probe fixes (ENABLE-vs-FORCE, policy-predicate,
the pipefail SIGPIPE trap) and one legitimate consistency nit surfaced. This is
the calibration working: the reference stays green, the probes get sharper.

---

# Batch 3 — testing / cicd / observability / dr (2026-08-13)

| lens | FWB | verdict |
|---|---|---|
| observability | 0 | clean (Sentry + pino wired) |
| dr | 0 | clean (rollback.sh + additive migrations) |
| testing | 0 | clean after 2 fixes: matched a `deleteMany:` vi.mock PROPERTY not a DB call (3 FPs), and honors global vitest `setupFiles` teardown so per-file afterAll isn't required |
| cicd | 4 | **REAL** — cloud-rescue / lighthouse-nightly / load-test-nightly / neon-snapshot define jobs with ZERO timeout-minutes. A hung nightly job burns runner budget (the exact failure that exhausted the org Actions quota earlier this session). Main CI is solid; these auxiliary workflows are a genuine grade-1 gap. Not tuned away. |

9 lenses now calibrated. FWB confirmable bugs: still zero. Real findings surfaced:
auth (dual role-check idiom) + cicd (4 timeout-less nightly workflows) — both
grade-1 consistency/hardening nits, neither a P0. The reference stays green.

---

# Batch 4 — scaling / migration-safety / error-surface / edge-protection / event-log (2026-08-13)

| lens | FWB | verdict |
|---|---|---|
| migration-safety | 0 | clean — newest migration adds/drops nothing dangerous, no NOT-NULL-no-default |
| edge-protection | 0 | clean on the one code-detectable criterion; the probe also emits an explicit `skipped` note that WAF/origin-lockdown/DDoS-playbook are infra and need interpreter review against the Cloudflare config |
| event-log | 0 | clean after excluding seed/scripts — `seed-demo-store.ts` does `paymentEvent.deleteMany` to RE-SEED demo data, not a prod append-only violation |
| scaling | 0 | **6 → 0, all verified false positives** (see below) |
| error-surface | 1 | **REAL grade-1** — `finance.routes.ts:1402` returns `{ error: err.message }` for a hand-thrown 409/400. Not a stack/driver leak (that check stayed clean), but a route hand-rolling its own error body instead of the shared middleware (22.1). Minor, honest, kept. |

**scaling — the calibration loop earned its keep.** The first pass flagged all 6
module-level `setInterval`s in `apps/api`. Reading the mechanism of each proved
every one a false positive, and drove three probe sharpenings:

1. `index.ts:119` + `loyalty-automation.service.ts` — the real call sites are
   wrapped in **`withLeaderLock(...)`**; my exempt regex only had `withLock`,
   which does not match `withLeaderLock`. (loyalty's line-9 hit was also just a
   JSDoc comment.) → added `withLeaderLock|LeaderLock`, skip comment lines.
2. `security.ts:25` + `view-ingest.service.ts:54` — clean a **per-process
   in-memory `BoundedMap`** (CSRF tokens / a debounce map). Leader-election would
   be WRONG: every replica must clean its own memory. My shared-effect regex
   matched a bare `.delete(` — i.e. `Map.delete(key)`. → scoped DB writes to
   `prisma.`-prefixed calls only.
3. `email-queue.service.ts:65` + `sms-queue.service.ts:81` — the timer calls
   `this.processQueue()`, and one level down that is an **atomic `redis.rpop`**,
   which `standard/scaling.md` EXPLICITLY exempts (each replica pops a different
   item — no double-send). → dropped indirection markers
   (`processQueue`/`dispatch`/`enqueue`) from the shared-effect set; the probe now
   flags only an unmistakable INLINE write/send and favors precision over recall.

Final: FWB has ZERO scaling leader-election gaps — every timer is leader-gated,
per-process-memory, or an atomic-RPOP worker. Exactly what the mature reference
should show, and it took reading each mechanism (not the exit code) to confirm it.

**14 lenses now calibrated. FWB confirmable bugs across all 14: still zero.**
Real grade-1 nits surfaced to date: auth (dual role idiom), cicd (4 timeout-less
nightlies), error-surface (one hand-rolled 409/400 error body). None a P0.

---

# Batch 5 — cache-ratelimit / feature-flags / environments / deploy-verify / ai-transparency (2026-08-13)

| lens | FWB | verdict |
|---|---|---|
| feature-flags | 0 | clean — FWB has requireFeature/PLAN_BASELINE and no scattered plan-string checks outside it |
| deploy-verify | 0 | clean — engines.node declared + a real .husky/pre-push mirror |
| cache-ratelimit | 2 (medium) | **REAL grade-1** — `store-resolver.ts:185` + `analytics.service.ts:10` are module-level `new Map()` TTL caches with no size bound; FWB has a `BoundedMap` util and just didn't use it here. The critical in-process-limiter check is CLEAN (FWB rate-limits via Redis). |
| environments | 1 (high) | **REAL grade-1** — local `.env` DATABASE_URL connects as the `neondb_owner` role, so ENABLE-only RLS is bypassed in local dev (FORCE tables still apply post-cutover). Probe emits NO secret value — only the boolean + a `grep -c`. |
| ai-transparency | 0 | clean after a fix (see below) |

**Two probe fixes the calibration forced:**

1. **ai-transparency false positive → fixed by content, not name.** First pass
   flagged "no generation-log table". FWB HAS one — `model AiUsage` — with
   `inputTokens`/`outputTokens`/`model`/`subjectType` and a comment literally
   citing "the generation log (EU AI Act transparency)". My name regex
   (`*Generation*`) missed `AiUsage`. Fix: detect a gen-log by CONTENT (token-
   accounting fields `inputTokens|outputTokens|promptTokens|completionTokens`),
   not just a name list — robust to whatever the table is called.

2. **cache-ratelimit scoped to server code.** First pass flagged 4 Map caches,
   2 of them client-side (`SearchAutocomplete.tsx`, `useCurrentStore.ts` hook) —
   a browser-tab Map is not the long-running-process leak criterion 6 is about.
   Excluded `.tsx` / `*/hooks/*` / `*/components/*`; the 2 genuine server caches
   remain.

**19 lenses now calibrated. FWB confirmable bugs across all 19: still zero.**
Real grade-1 nits to date: auth (dual role idiom), cicd (4 timeout-less
nightlies), error-surface (one hand-rolled 409/400 body), cache-ratelimit (2
unbounded server Map caches), environments (owner-role local DB). None a P0 —
exactly the profile of a mature reference.

---

# Batch 6 — architecture / docs-parity / data-ui-coverage / frontend-quality / mobile / unit-economics (2026-08-13)

| lens | FWB | verdict |
|---|---|---|
| architecture | 0 | clean — money stored as Int, $transaction wrapped (withMoneyTx/maxWait present) |
| docs-parity | 0 | clean — README + DEPLOYMENT + ROLLBACK present, no stale-stack tokens |
| frontend-quality | 0 | clean — no AR mojibake, axe wired, sitemap+robots present |
| mobile | 0 (N/A) | correctly skipped — FWB ships no apps/mobile |
| unit-economics | 0 | clean — AiUsage carries storeId + input/outputTokens + costMicros, so per-tenant spend is derivable |
| data-ui-coverage | 1 (medium) | **REAL grade-1** — see below |

**data-ui-coverage — a genuinely subtle two-layer CSV defect.**
`packages/shared/src/utils/csv.ts:168` splits records with `content.split(/\r?\n/)`
— a naive record splitter. The FIELD splitter `splitCsvLine` (line 292) *is*
quote-aware, but its own comment admits "Does not handle multi-line quoted
fields," and the function docstring OVERCLAIMS by listing "Quoted fields with
embedded commas/**newlines**" as handled. This is exactly the record-splitter-vs-
field-parser gap criterion 9 describes: a quoted field with an embedded newline
would corrupt every downstream row. Bounded (inventory CSVs rarely embed
newlines) and acknowledged in-code → grade-1, not a P0, but a real inaccuracy
worth the flag. The probe surfaced it precisely.

**Portability fix this batch:** frontend-quality's mojibake check used
`grep -P '\x{FFFD}'` (a unicode-codepoint match) which flipped inside a
subprocess depending on ambient locale. Switched to a raw-byte match under
`LC_ALL=C` (`EF BF BD`) — deterministic regardless of locale.

═══════════════════════════════════════════════════════════════════════════
# ALL 25 LENSES CALIBRATED — FINAL TALLY (2026-08-13)
═══════════════════════════════════════════════════════════════════════════

FWB **confirmable bugs (critical): ZERO** across all 25 lenses.

Real **grade-1** findings surfaced (all bounded, none a P0 — the profile of a
mature reference, not a clean bill of nothing):
- **auth** — authorize() + requireRole() are two role-check idioms, not one wrapper
- **cicd** — 4 nightly workflows define jobs with no timeout-minutes
- **error-surface** — one route hand-rolls a 409/400 { error: err.message } body
- **cache-ratelimit** — 2 server-side module Map caches with no size bound
- **environments** — local .env DATABASE_URL connects as the DB owner role
- **data-ui-coverage** — naive CSV record split + a docstring that overclaims

The calibration loop's real value was **probe hardening**, not bug-finding:
6 probe fixes it forced (ENABLE-vs-FORCE RLS, hybrid policy predicate, pipefail
SIGPIPE, withLeaderLock/atomic-RPOP scaling exemptions, AiUsage content-detection,
locale-safe byte matching) + 3 fixture traps (a fixture literally containing the
trigger word: gitleaks / requireFeature). The reference stayed green throughout —
which is the whole point of calibrating on the known-good project first.

═══════════════════════════════════════════════════════════════════════════
# DISCRIMINATION RUN — da-gusto-menu vs FWB (2026-08-13)
═══════════════════════════════════════════════════════════════════════════

A rubric that scores every repo the same is useless. Ran the full 25-lens sweep
against `_clients/da-gusto-menu` (a single-restaurant menu app) and compared to
FWB. The engine discriminates — not on raw count (FWB 14, da-gusto 17, close) but
on WHERE the findings land:

- **FWB** fails only HARDENING criteria — all grade-1: 4 timeout-less nightlies,
  4 safe-by-design XSS sinks, 2 unbounded caches, one dual-auth idiom, etc. Zero
  foundation failures.
- **da-gusto** fails FOUNDATION criteria FWB nails: **money 3** (`price` typed
  Float in the schema — a CRITICAL that caps the money/architecture layer at 0),
  **observability 2** (no Sentry, no structured logger), **frontend-quality 2**
  (no axe, no sitemap/robots), **rls 1** (no RLS defined), **architecture/deps/
  docs-parity 1** each.

The severity + cap rule is what makes the two profiles read differently: FWB's
nits are grade-1; da-gusto's Float-money and no-observability are grade-0 caps.
A human would grade these two projects exactly this far apart — which is the
whole point of calibrating discrimination, not just the reference.

**The discrimination run also caught a real probe bug** — the highest-value kind
of finding. rls first reported **7 criticals** on da-gusto ("write to RLS-scoped
model X"). But da-gusto has a Prisma schema with NO row-level security at all.
The `model_is_rls_scoped` fallback (`RLS_MODELS empty -> flag everything`) was
meant for the no-migrations fixture; it misfired on a real repo that HAS
migrations but defines no FORCE-RLS. Fixed: only flag-all when there are NO
migrations (fixture/greenfield); when migrations exist but define no RLS, emit
ONE finding ("no FORCE RLS in any migration") plus a `skipped` note handing the
tenancy judgment to the interpreter (single-tenant menu = N/A; multi-tenant = a
critical gap). da-gusto rls: 7 false criticals -> 1 real finding + 1 note. FWB
stays 0; dead-gate still fires. Verify-before-assert, one more time.

═══════════════════════════════════════════════════════════════════════════
# FWB calibration — lenses 26–29 (2026-09-02)
═══════════════════════════════════════════════════════════════════════════

`standard/` has documented 29 lenses since 2026-09-02; `lenses/` stopped at 25.
Four lenses were readable rubric that `/force-audit` never scored — which is,
with some irony, exactly what lens 27 is about. This entry calibrates the four
new probes against the reference. Same discipline as the first 25: **a finding
on FWB is either a REAL FWB gap or a probe false positive — both are recorded,
neither is tuned away silently.**

These four grade *process and proof*, not a missing config key, so each probe
covers a deliberate SUBSET of its lens and hands the rest to the interpreter via
a `skipped` note (the `unit-economics` precedent). What is mechanised and what
is not is stated per lens below, with the reason.

## Net result

| lens | FWB findings | verdict |
|---|---|---|
| skill-hygiene | 2 (1 medium, 1 high) | both **REAL**, both already true of the reference |
| gate-integrity | 0 | clean, after one probe narrowing (below) |
| mutation-proof | 1 (high) | **REAL**, with a stated probe blind spot |
| enumeration-integrity | 0 | clean — FWB's 16 shell scripts carry none of the four patterns |

No lens floods FWB. Total 3 findings across four lenses on a repo of this size.

## Iteration log

| run | lens | findings | change |
|---|---|---|---|
| 1 | gate-integrity | 1 critical | `?? []` anywhere in a gate file flagged `.github/scripts/audit-gate.mjs:53` |
| 2 | gate-integrity | 0 | **narrowed** — see the audit-gate correction below |
| 1 | mutation-proof | 1 high (37 files) | bare `export` in the mandatory-set path match |
| 2 | mutation-proof | 1 high (35 files) | narrowed `export` → `data-export\|gdpr\|eras(e\|ure)` (see da-gusto note) |
| 1 | skill-hygiene | 2 | unchanged — no tuning needed |
| 1 | enumeration-integrity | 0 | unchanged — no tuning needed |

## gate-integrity → 0 (one FALSE POSITIVE, narrowed and logged)

Run 1 flagged `.github/scripts/audit-gate.mjs:53` critical:
`for (const via of v.via ?? [])`. Read before asserting — it is **not** the
documented fail-open:

- the top-level report read is correct: `if (!raw) { … process.exit(1) }`, so an
  empty tool output FAILS rather than passing;
- `JSON.parse(raw)` is **unguarded**, so a parse error throws — which is what
  §2 demands ("parser fallbacks fail the gate, they do not empty it");
- `v.via ?? []` is a per-entry field default *inside* a loop that has already
  read and parsed the artifact. It is a shape-drift default, not a route to
  "pass" that never read the report.

Probe narrowed: a `?? []` / `|| echo '[]'` now fires only when it appears **on
the same line as the report read** (`JSON.parse`, `readFile*`, `cat `, `.json`),
or as the verbatim `catch { return [] }` the standard names. Fixture still fires;
FWB goes to 0.

**Residual, recorded not silenced:** the same file's line 51 reads
`Object.entries(report.vulnerabilities ?? {})`. If npm's JSON ever drops or
renames that key the gate reports clean. The narrowed probe deliberately no
longer flags it (`?? {}` is the normal way to iterate an optional map, and
flagging it floods every TS repo). It is named here so the interpreter can weigh
it under `negative-control`, which is interpreter-graded anyway.

## skill-hygiene → 2, both REAL

**1. `.claude/skills` — 14 of 14 installs are unreadable (medium).** Every entry
is a symlink to `../../.agents/skills/<name>`, and `.agents/` exists neither at
the repo root nor at its parent. Verified: `readlink .claude/skills/gpt-taste` →
`../../.agents/skills/gpt-taste`; `ls -L` on it → *No such file or directory*.
So the repo declares 14 skills, loads none, and none can be re-read or disposed.
This is L2's accumulation failure in its purest form — "skill count is a cost,
not a capability score" — and it is a genuine finding about the reference, not
a probe artifact.

**2. Same-vendor AI review (high).** `ai-review.yml` and `scoped-audit.yml` are
the only AI-invoking review/audit workflows and both call Anthropic. This is the
finding the standard itself is sourced from (PR #1099, authored by Claude and
passed by a Claude reviewer). **FWB has already partly addressed it**, and the
workflow says so in a long comment: the review runs on Fable 5 while the author
runs on Opus 5, and the reviewer receives only the prompt contract plus the
unified diff, never the PR body. The comment is explicit that this does *not*
fully decorrelate — same vendor means shared training lineage.

The probe does not read that comment, and should not: **a comment is not a
vendor.** It surfaces the fact; the interpreter grades it — on this evidence a
reasoned **1**, not a 0. Same shape as the `auth` verdict in the first pass:
a genuine consistency finding against the standard, deliberately accepted, not
a bug.

## mutation-proof → 1 REAL, with a stated blind spot

FWB has **35** test files covering defences where the §4 record is mandatory
(authn/session, tenant/RLS, money/payment/refund, consent, erasure) and **no
mutation record anywhere in the tree**: no mutation, no named test that went red,
no restore checksum.

**Probe blind spot, stated in the finding itself:** §4 specifies the table rides
in the **PR body**, which is not in the repo. The probe can only see an in-repo
record, so the interpreter must check the PRs that shipped these defences before
grading this 0. Recorded as REAL because a repo-visible record is what a later
auditor can actually re-read — but it is a claim about the tree, not about FWB's
history, and the finding says so.

## enumeration-integrity → 0 (clean)

FWB has 16 shell scripts and no JS census code. Measured, all four probed
patterns are absent: no `for x in $(find …)`, no `find | while` without
`-print0`, no `-e …/.git` or `existsSync(…/.git)`, no basename-as-id. A clean
result on a lens whose fixture fires five ways — the dead-gate test is what makes
that zero trustworthy.

## What each probe mechanises, and what it refuses to

Written down because "a criterion you cannot detect belongs in the JSON marked
for the interpreter, not in a probe that guesses."

| lens | mechanised | left to the interpreter, and why |
|---|---|---|
| 26 skill-hygiene | unreadable/undated installs; a pinned dated model id; one-vendor AI review | review **cadence** and role **rotation** — "when was this last read" and "would you install it again today" leave no trace in the tree |
| 27 gate-integrity | report → `/dev/stdout`; `\|\| true` / `continue-on-error` on a scanner; a fallback on the report read; `gitleaks detect` unpinned; truthy entitlement seam | the negative control, the receipt with a unit count, the empty-input FAIL — their **absence** emits no token to match on |
| 28 mutation-proof | substring assertions on cookie/header/auth values; mandatory-set tests with no in-repo record | baseline **regeneration** (a `.gitleaksignore` looks identical whether or not its fingerprints were diffed) and belt-and-braces **layer isolation** (indistinguishable from correct redundancy) |
| 29 enumeration-integrity | word-splitting iteration; `find\|while` without `-print0`; `.git` existence not directory-tested; basename-as-id | **reconciliation** (a missing assertion produces no error and a plausible total) and **score-not-first-match** classification (a control-flow shape, not a token) |

## Dead-gate + mutation discipline (both directions, per criterion)

`tests/probe-fires.sh`: **29/29 ok, exit 0**, each new fixture pinning its
specific findings via `expected.grep`. Then the half that is usually skipped —
each defect was removed from a fixture copy **one at a time**, and exactly the
matching finding disappeared with no collateral change:

| lens | defect removed | finding that went quiet |
|---|---|---|
| 26 | un-pinned the model id | "pins a specific model id" |
| 26 | gave the orphan a SKILL.md | "have no readable SKILL.md" |
| 26 | added a second-vendor reviewer workflow | "calls the SAME vendor" |
| 27 | `--report-path report.json` | "report is written to /dev/stdout" |
| 27 | dropped `\|\| true` | "neutered with '\|\| true'" |
| 27 | dropped the parser fallback | "report parse falls back to an empty result" |
| 27 | dropped `continue-on-error: true` | "runs a security scanner AND sets continue-on-error" |
| 27 | pinned `GITLEAKS_VERSION` | "deprecated 'gitleaks detect' … no version pin" |
| 27 | `=== true` at both seams | both "branched on for truthiness" |
| 28 | `toBe` / anchored regex | both substring findings |
| 28 | added an in-repo §4 record | "carries no record anywhere" |
| 29 | NUL-safe `while read -r -d ''` | "word-splitting a find/ls substitution" |
| 29 | `test -d` instead of `-e` | "-e …/.git … also true for a WORKTREE" |
| 29 | relative-path id (sh) | "basename is assigned as a unit id" |
| 29 | `isDirectory()` + path id (mjs) | both mjs findings |

A probe that fires on everything is as useless as one that fires on nothing, and
only the second column distinguishes them.

## Discrimination — da-gusto-menu

Same second target as the 25-lens run. `skill-hygiene` returns **N/A with a
reason** (no skills dir, no AI-invoking review workflow — reported, never
dropped); `gate-integrity` and `enumeration-integrity` clean; `mutation-proof`
initially fired on `tests/feedback-export.test.ts`. That was the path heuristic
over-reaching: §5 means GDPR erasure/**export endpoints**, not any CSV writer.
Narrowed `export` → `data-export|gdpr|eras(e|ure)`; da-gusto → 0, FWB 37 → 35.

## Two traps this round, worth carrying forward

1. **`[=` inside a bracket expression opens a POSIX equivalence class.**
   `[=[:space:]]+` silently never matched, so the `--report-path /dev/stdout`
   check — the single most concrete thing lens 27 documents — was dead on
   arrival and the fixture caught it. Write the class first: `[[:space:]=]+`.
2. **A pattern starting with `--` is eaten as an option by BSD grep** (the macOS
   default these probes run under). `grep -rnE -e "$P_SINK"`, never a bare
   pattern. Related: a comment that QUOTES the bad pattern is not the bad
   pattern — all three regex-driven probes now drop `//`, `#`, `*` lines, after
   the mutation-proof fixture flagged its own explanatory comment.

## Self-audit — the foundation repo, run against itself

Lens 27 is about gates that cannot fail, so the first thing to do with it is
point it at the repo that owns the gates. Two probe FALSE POSITIVES fell out,
both fixed by a principled narrowing rather than an exclusion list, and three
findings survived:

**FP A — `ops/dream-scan.sh:135`** flagged
`npm audit --json --omit=dev … > "$raw_file" || true` as a neutered scanner. It
is the opposite: the exit code is deliberately discarded **because the verdict is
bound to the artifact**, which is §2's own prescription (npm audit exits non-zero
whenever vulns exist and still writes the JSON). Narrowed: a scanner line that
captures `--json`/`--format` output to a real file is excluded. A bare
`npm audit --audit-level=high || true` still fires, and the fixture — whose
report goes to `/dev/stdout` — still fires.

**FP B — `.github/workflows/reusable-ci.yml:322`** flagged a `continue-on-error`
that sits on an **upload-artifact** step, 99 lines from the nearest scanner. The
check was file-scoped ("this file has a scanner somewhere and a
continue-on-error somewhere"), which FWB survived only because it keeps its
scanners in dedicated workflow files. Narrowed to require the two within 10 lines
— the same step. Both fixture checks still fire and still go quiet in isolation.

Surviving findings on the foundation repo (recorded, not acted on here):

| location | verdict |
|---|---|
| `.github/workflows/reusable-ci.yml:223` | **REAL but deliberate** — `npm audit --audit-level=high \|\| true` on the DEV-deps gate, waived in a comment for unfixable transitives in `@lhci/cli` + `@stryker-mutator/core`; the prod-deps gate above it is not waived. A grade-1 nit, same shape as FWB's reviewer rotation: a documented deviation, not a bug |
| `ops/wbs-ci-local.sh:21` | **REAL (medium)** — `gitleaks detect` with no version pin, in the local CI mirror |
| `skills/force-audit/probes/gate-integrity.sh` | **SELF-MATCH artifact** — the probe's own `P_FALLBACK` regex literal contains the string it looks for. Same class as the three fixture traps already logged (a file containing the trigger word). Only ever appears when auditing this repo; left as-is, because suppressing a probe's own directory is a special case that reads as tuning |

Lens 29 on the same repo: `ops/fleet-dep-audit.sh:36` `slug=$(basename "$d")` over
a fleet of repo directories — **REAL (medium)**, the documented collision shape.
`ops/sessions-live.sh:21` `sid=$(basename "$f" .jsonl)` — **FALSE POSITIVE**:
session filenames are uuids in one flat directory, so the basename IS the unit's
identity. Recorded rather than narrowed away — the pattern that distinguishes
them ("are these units at different paths?") is not visible to a grep, and the
criterion is `medium` precisely because it needs a reader.

## Probe status: CALIBRATED

Four lenses that were documented-but-ungraded are now scored. The reference
stays green where it should (gate-integrity 0, enumeration-integrity 0) and
surfaces three real, bounded gaps where it should (14 dangling skill installs,
one same-vendor review, no in-repo mutation record). They ship.
