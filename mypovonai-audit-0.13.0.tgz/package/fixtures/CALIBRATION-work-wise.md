# Calibration — work-wise-audit/src

Ground truth: `~/Desktop/projects/_clients/work-wise-audit/reports/{security,backend}.md`.
Append-only: each lens author adds their own section below and never edits another's.

> **2026-09-23 — six sections were LOST and rebuilt.** This file was written
> concurrently by five agents; one used a whole-file write instead of an append
> and wiped php-secrets, php-authz, php-sqli, php-blade-xss, php-config,
> php-deps and php-hygiene. The rebuilt sections below were re-measured from
> the probes directly, not restored from the agents' prose. "Append-only" is a
> convention a tool cannot enforce — the next pack to be written in parallel
> should give each lens its own file.

## Fleet-level measurement (measured, not quoted)

| | probes | lenses that ran | lenses skipped | findings |
|---|---|---|---|---|
| before (merge-base `6884eca`) | 37 | 8 | 29 | 3 |
| after (this branch) | 48 | 19 | 29 | 75 |

Skips did **not** fall. The brief expected "well under 28"; that assumed PHP
lenses would displace skipping TS lenses, and they cannot — those 29 are
TypeScript lenses that correctly cannot apply to a Laravel repo. The number
that moved is lenses that RAN: 8 → 19.

Severity split after: 9 critical, 66 high, 0 medium, 0 low.
The admin password appears **0 times** in the full fleet output (checked with
`grep -cF` against the real literal read from `routes/web.php:106`).

## No TypeScript regression

Same fleet against `force-website-builder` (TS), before vs after:
findings **35 → 35**, unchanged. All 11 PHP lenses skip it with a reason.

That run found a real bug in this pack's own stack detector: `is_php` excluded
`vendor/` but not `node_modules/`, and ONE stray `.php` file inside a single npm
dependency — the only `.php` in that entire repo — made a Next.js project answer
"yes, this is PHP", so `php-hygiene` ran over a TypeScript codebase. Fixed by
aligning `is_php`'s exclusions with `php_files()`.

## php-idor

Run: `bash probes/php-idor.sh ~/Desktop/projects/_clients/work-wise-audit/src` → 49 findings
(41 method-level `no-ownership-scope` + 8 route-level `public-route-to-unscoped-method`).

**Required by the contract — confirmed firing:**
- `app/Http/Controllers/CompanyController.php:26` (`offers`) — REAL. SEC-004. Single
  self-referential `where('company_id', $company_id)`, no second column, no auth at all on the
  route (`routes/web.php:404`, top-level, no middleware group).
- `app/Http/Controllers/CompanyController.php:41` (`commission`) — REAL. SEC-004, same shape
  (`routes/web.php:403`).
- `routes/web.php:403` and `routes/web.php:404` — REAL. The route-level criterion firing on
  exactly the two lines the ground truth cites, because both forward to the two flagged methods
  above and neither is wrapped in a middleware group.

**Other REAL findings** (same underlying gap the report already names broadly — "no per-role
separation inside `/admin`", "no company session exists anywhere" — but each is its own concrete
code site with zero ownership scope):
- `AdminController.php:208` `showApplications($id)`, `:223` `editApplication($id)`, `:249`
  `updateApplication($id)` — `applications` by raw `application_id`, admin-gated only.
- `AdminController.php:375` `newsEdit`, `:384` `newsUpdate`, `:418` `newsDestroy` — `blogs` by
  raw `blog_id`, admin-gated only.
- `AdminController.php:517` `publishNewsComment`, `:525` `destroyNewsComment` — `news_comments`
  by raw `comment_id`, admin-gated only.
- `AdminController.php:927` `groupsUpdate`, `:940` `groupsSetLeader`, `:950` `groupsDestroy` —
  `groups` by raw `id`, admin-gated only.
- `AdminController.php:1553` `showCompanyForm`, `:1625` `submitCompanyFieldsForm` — same
  self-referential `company_id` trap as CompanyController, on `company_fields`/`company_responses`
  (list queries, not single-record `->first()`, but the same "any company_id is accepted" gap).
- `AdminController.php:1722` `showpublicCompanyForm($company_id)` — REAL and notable: requires
  login (`Auth::check()`) but any authenticated user can submit against **any** `company_id`,
  same shape as SEC-008's neighbourhood. Route `routes/web.php:394` — top-level, no group, no
  `->middleware()` (the `Auth::check()` redirect is inside the method, invisible to the route
  cross-reference, so criterion 2 correctly still fires here too).
- `AdminController.php:1892` `showCompanyJobs($id)`, `:1957` `storeCompanyJob` — matches the
  report's SEC-004 note verbatim: *"Also public with no auth: ... showCompanyJobs($id)
  (/company/{id}/jobs)"*. Route `routes/web.php:400`.
- `AdminController.php:2206` `dictionaryLanguages($company)` — public route
  (`routes/web.php:398`, top-level), offers list filtered only by the client-supplied `company`.
- `AdminController.php:2346` `publishComment`, `:2355` `disableComment`, `:2364`
  `destroyComment` — `user_comments` by raw `comment_id`, admin-gated only.
- `AdminController.php:2414` `markContactMessageRead`, `:2423` `destroyContactMessage` —
  `contact_messages` by raw `message_id`, admin-gated only.
- `AdminController.php:2481` `markCompanyRequestRead`, `:2490` `destroyCompanyRequest` —
  `company_service_requests` by raw `request_id`, admin-gated only.
- `AdminController.php:2541` `languagesEdit`, `:2549` `languagesUpdate`, `:2580`
  `languagesDestroy` — `languages` by raw `id`, admin-gated only.
- `AdminController.php:2613` `employeeEmailsEdit`, `:2619` `employeeEmailsUpdate`, `:2627`
  `employeeEmailsDestroy` — `EmployeeEmail::findOrFail($id)`, admin-gated only.
- `HomeController.php:356` `offersUpdate`, `:388` `offersDelete` — `offers` by raw `id`,
  admin-gated only (`/admin/offers/update|delete/{id}`).

All of the "admin-gated only" findings above are REAL under this lens's literal definition (the
method genuinely has no ownership scope), but their real-world blast radius today is bounded by
the SAME already-reported weak shared password (SEC-001) rather than being a distinct new
vulnerability — flagged here as code-shape findings, not as 15 new Criticals on top of SEC-001.

**FALSE POSITIVES** (10 findings, all traced to a specific cause):
- `AdminController.php:309` `allApplications(Request $request)` — the `where('company_id',
  $request->company_id)` is an **optional** admin list filter (`->get()`, not `->first()`); with
  no `company_id` given the endpoint already returns every application. There is no boundary
  being crossed by supplying one. Lens limitation: criterion 1 doesn't distinguish a mandatory
  single-record fetch from an optional collection filter.
- `AdminController.php:532` `storeNewsComment($id)` — loads a public blog post to check it
  exists before accepting a comment; the route is behind the `auth` middleware group already, and
  a blog post has no per-user ownership boundary to violate (anyone logged in may comment on any
  public post). Lens limitation: cannot distinguish "public content, existence check only" from
  "private record, missing scope."
- `AdminController.php:567` `storeNewsCommentReply($commentId)` — has a real authorization check
  (`if (!$user || $user->team !== 'our_team') abort(403, ...)`), just not expressed as
  `->authorize(`/`Gate::`/`->can(`. Lens limitation: the policy-check pattern only recognizes the
  three canonical Laravel idioms, not an equivalent hand-rolled role guard.
- `AdminController.php:1332` `editResource(Request $request, $id)` — the flagged
  `where('company_id', $id)` is a **secondary** query building the company-edit sidebar; the
  actual record fetch delegates to `getResourceById($config, $id)`, whose lookup column
  (`$config['pk']`) is a variable, not a string literal, so it is invisible to this probe (see
  rubric's "known limitations"). No real gap was found in this method by other means either — the
  generic CRUD engine is gated by `admin.gate` for every resource type.
- `HomeController.php:154` `offerDetails($id)` — `routes/web.php:399` (`/offers/{id}`). The
  security report explicitly lists this as *"Public, no auth required (by design, confirmed
  intentional for a job board)"*. A job listing has no owner to protect.
- `HomeController.php:170` `newsDetails($id)` — `routes/web.php:92` (`news/{id}`). Same
  reasoning: a public news article, intentionally open.
- `PagesController.php:83` `teamDetails($id)` — `routes/web.php:53` (`/team/{id}`). A public
  team-member bio page; the second `where('team', 'our_team')` uses a string literal so this
  probe correctly doesn't count it as a second column, but the underlying resource is public
  content regardless, same class as the two above.
- `routes/web.php:53`, `:92`, `:399` — the route-level criterion firing on the three
  intentionally-public routes above, inherited directly from their (false-positive) method
  findings.

**Known false negative** (documented, not chased further): `AdminController::showCompany($id)`
(`AdminController.php:2239`, `/company/{id}`) is explicitly named in the report's SEC-004
("Also public with no auth: ... showCompany($id)") and has the exact same self-referential
`where('company_id', $id)->first()` bug as `showCompanyJobs` right next to it — but the method
body ALSO contains an unrelated, later, properly-double-scoped `company_jobs` lookup
(`where('id', $jobId)->where('company_id', $id)`) for an optional `?job=` query param. Because
criterion 1 aggregates distinct where() columns over the WHOLE method body rather than per
query-chain, that later compound scope is (wrongly) credited to the earlier, unrelated, unscoped
company lookup. Fixing this needs per-statement-chain grouping, not just per-method aggregation —
noted as a follow-up rather than implemented, to avoid the exact kind of over-fit special-casing
this pack's contract warns against.

## php-mass-assignment

Run: `bash probes/php-mass-assignment.sh ~/Desktop/projects/_clients/work-wise-audit/src` →
**0 findings.** Confirmed silent, correctly:
- `grep -rn '\$guarded\|\$fillable' app/Models/` → only `User.php` (`$fillable`, an explicit
  allowlist) and `EmployeeEmail.php` (`$fillable = ['email']`). No model anywhere declares
  `$guarded = []`.
- `grep -rn 'request()->all()\|\$request->all()' app/` and `grep -rn '->except(' app/` → zero
  hits reaching `create(`/`update(`/`->fill(`/`->forceFill(`. Every `Model::create([...])` call
  site in the repo (`AdminController.php:121`, `:2734`, `:2609`) builds its array from named
  `$request->field` literals, not the whole request body.
- The repo's one real mass-assignment-*adjacent* finding — SEC-008,
  `AdminController::storeCompanyForm()` iterating `$request->except([...])` into
  `DB::table('applicant_field_values')->insert([...])` — is a raw query-builder `insert()`, not
  `create()`/`update()`/`fill()`/`forceFill()` on an Eloquent model, and is explicitly out of
  scope for this lens per the contract's definition. It is a real bug, just a different lens's
  bug (closer to "unvalidated dynamic-key write" than "mass assignment").

No false positives to report because there were no findings to review; both criteria are proven
live only by `fixtures/php-mass-assignment/` (see `tests/probe-fires.sh` /
`tests/site-coverage.sh`).

## php-uploads

Ran: `bash probes/php-uploads.sh ~/Desktop/projects/_clients/work-wise-audit/src` → 4 findings.

- `app/Http/Controllers/HomeController.php:327` (`offersStore`, `$request->image->store('uploads',
  'public')` with no `validate()`/`Validator::make()` anywhere in the method) — **REAL**. This is the
  required site: matches security.md SEC-003 exactly ("Neither function calls `$request->validate()`
  on anything, including `image` — this is the *only* upload path in the whole codebase with zero
  mime/extension/size validation"). Falls inside the required 322–350 line range (`offersStore` spans
  322–353).
- `app/Http/Controllers/HomeController.php:373` (`offersUpdate`, same pattern) — **REAL**. SEC-003's
  own fix note names both functions: "Add `$request->validate(...)` to both `offersStore` and
  `offersUpdate`."
- `app/Http/Controllers/HomeController.php:276` (`handleGallery`, `$file->store('offers_gallery',
  'public')`, a private helper with no validate call of its own) — **REAL, but minor**: the same
  class of gap backend.md §5 calls out for company-job galleries ("gallery items only checked via
  `$file->isValid()`, not per-file mime-revalidated... minor gap, not flagged separately as it
  mirrors the same trusted-admin context"). `offersStore`/`offersUpdate` call this helper without
  validating `image` either, so their gallery uploads are unvalidated too — genuinely true, just not
  broken out as its own SEC- item upstream.
- `app/Http/Controllers/AdminController.php:486` (`handleNewsGallery`, `$file->store('blogs_gallery',
  'public')`, an explicit copy of `handleGallery` — "نسخة من handleGallery" — with the same no-validate
  shape) — **REAL, same minor class as above**. Note the lens stays SILENT on the third copy of this
  pattern, `companies_gallery` in `AdminController::storeResource`/`updateResource` (line ~1412):
  that write sits in a method that DOES call `$this->validateCrudRequest(...)`, so the "no validation
  in this method" rule correctly does not fire there even though the gallery items themselves are
  equally unchecked — the probe cannot see inside a config-driven helper, and guessing would be the
  noise this pack exists to avoid.

No false positives: every AdminController upload with an inline literal rule
(`register`/`updateProfile`/`newsStore`/`newsUpdate`/`storeCompany`/`updateSetting`/`languagesStore`)
validates `image`/`mimes:...`/`max:...` (or, for `languagesStore`'s `flag` field, `image|max:2048` —
the bare `image` rule already restricts to image MIME types, so the probe correctly does not demand
`mimes:` on top of it; security.md's own upload table marks this row ✓ too).

## php-throttle

Ran: `bash probes/php-throttle.sh ~/Desktop/projects/_clients/work-wise-audit/src` → 12 findings
(1 Kernel-level + 11 route-level).

- `app/Http/Kernel.php:26-29` (`'web'` group has no `throttle:` entry (lines 17-25), sibling `'api'`
  group does have `'throttle:api'`) — **REAL, required site**. Matches security.md SEC-005 exactly,
  down to the line range: "**Location:** `app/Http/Kernel.php:26-29` — the `'web'` group has no
  `throttle` entry; `'api'` does (`'throttle:api'`, line 28), but nothing in `routes/web.php` runs
  through the `api` group."
- `routes/web.php:16` (`comments.store`, in the `auth` group, no throttle) — **REAL**. SEC-005's
  affected-endpoints list names `POST /comments` explicitly.
- `routes/web.php:17` (`news.comments.store`) — **REAL**. SEC-005 names `POST /news/{id}/comments`.
- `routes/web.php:19` (`news.comments.reply`, matched via "comment") — **REAL, same class**: not
  individually named in SEC-005's list but the same `auth`-group, no-throttle comment-submission
  pattern as the two lines above it.
- `routes/web.php:23` (`contact.message.store`) — **REAL**. SEC-005 names `POST /contact-message`.
- `routes/web.php:105` (`admin.gate.submit`, the admin password gate itself) — **REAL**. SEC-005
  names `POST /admin-login` first in its list; SEC-001's own exploit line cites this same gap
  ("(see SEC-005) no rate limiting, so this password is brute-forceable in seconds").
- `routes/web.php:121` (`login`) — **REAL**. SEC-005 names `POST /login` ("Credential-stuffing
  against `/login`").
- `routes/web.php:376` (`register.custom`) — **REAL**. SEC-005 names `POST /admin/register`.
- `routes/web.php:385` (`team.verify.email`, matched via "register" in the `/register/...` URI) —
  **REAL**. SEC-005 names `POST /register/verify-team-email`.
- `routes/web.php:387` (`team.otp.verify`) — **REAL, and the sharpest instance**: SEC-005 itself
  flags this one hardest ("brute-forcing the team OTP within its 10-minute window (automatable)"; a
  6-digit code, 1,000,000 possibilities, zero attempt limit per SEC-010).
- `routes/web.php:389` (`team.register.complete`) — **REAL**, same `/register/team-complete` family
  as the two above.
- `routes/web.php:392` (`contact.store` → `AdminController::storeContact`, top-level, NOT wrapped in
  `admin.gate`) — **FALSE POSITIVE for practical risk, though the pattern match is technically
  correct**: `routes/web.php:310` registers the SAME `POST /contact/store` path (same name,
  `contact.store`) earlier, *inside* the `admin.gate` group. Laravel's router matches a URI+method
  against routes in REGISTRATION ORDER, so the line-310 (admin-gated) definition always wins and
  line-392 can never actually be reached — it is dead/shadowed routing, not a live gap. The lens
  cannot see route-shadowing (it would need to simulate Laravel's router, not just scan text), so it
  flags the literal, unreachable duplicate. Left un-suppressed rather than special-cased, per the
  contract's "surgical changes" guidance — this is a one-off duplicate-route artifact in this repo,
  not a pattern worth adding router-order logic for.

**Known false negatives (documented, not fixed)**: `POST /company-services` (`company.services.store`,
a public lead-gen form per its own code comment "visitors — no auth required") and
`POST /company/{company_id}/form` (`admin.storeCompanyForm`, the actual job-APPLICATION submission —
both explicitly named in SEC-005's affected-endpoints list) are missed. Neither the route name nor the
URI contains any of `login|register|password|reset|contact|comment|subscribe|apply|application` — this
is a text-pattern lens, and these two names give it nothing to match. Widening the keyword list to
generic terms like "form" or "company" would very likely reproduce the "110 false positives" failure
mode this pack exists to avoid (nearly every admin CRUD route in this codebase touches a "form").

## php-secrets

**Measured: 1 finding(s)** (1 critical). 1 finding, REAL.

- `routes/web.php:106` **critical** — ground truth SEC-001, the shared admin password compared with `===` to a request value. The literal is absent from both the message and the `evidence` command; verified with `grep -cF` against the real value → 0.
- 28 raw candidates were narrowed to 1 by value-scoped filters: Blade template echoes (`{{ csrf_token() }}`), error messages (`'password' => 'Incorrect password.'`), query-string fragments (`'_token='`), and Laravel validation rules (`'password' => 'required|min:8'`). Each exclusion reads the VALUE, never the line — filtering the line matched the quoted KEY and dropped a real credential as a placeholder.

## php-authz

**Measured: 0 finding(s)** (none). 0 findings, and the 0 is a measurement.

- Every privileged route sits inside a group declaring `admin.gate`. That `admin.gate` is itself a weak session-flag gate is SEC-001, which `php-secrets` reports — a missing-middleware lens double-reporting it would be noise.
- **Proof it is not a dead probe:** forcing `has_mw()` to return 0 makes it flag **128** privileged routes on this repo and 6 on its own clean twin. That mutation also reproduces the original 110-false-positive failure mode, which is exactly what the group-inheritance logic suppresses.
- Login/logout/register boundary routes are excluded from the privileged-keyword match by design, even when the URI contains `admin`.

## php-sqli

**Measured: 0 finding(s)** (none). 0 findings — required silent, and silent for the right reason.

- Excluded 26 raw-SQL call sites and 39 `orderBy()` calls: 12 literal `DB::statement` migrations, 8 `whereRaw` calls all using `?` placeholders with bindings arrays, 6 literal aggregate `DB::raw`/`selectRaw` expressions, and 39 `orderBy()` on fixed string columns.
- Known limitation: detection is line-based, so a raw call whose SQL string begins on the NEXT line is invisible. No such call exists in this repo (checked); documented in the probe.

## php-blade-xss

**Measured: 0 finding(s)** (none). 0 findings — required silent.

- Excluded 20 `{!! !!}` occurrences: 18 identical `isset($css) ? $css : ""` view-local constants, and 2 `nl2br(e($model->field))` — model-shaped but escaped.
- Breaking the `e()` exclusion makes the clean twin emit 3 findings, so the discriminator is live rather than the whole probe being quiet.

## php-config

**Measured: 1 finding(s)** (1 high). 1 finding, REAL.

- `config/session.php:172` — `'secure' => env('SESSION_SECURE_COOKIE'),` with no second argument resolves to `null` (falsy) whenever the variable is unset. Matches SEC-011; the report cited "line ~130", the probe's 172 is the exact line.
- Correctly silent elsewhere: no committed `.env` in this snapshot, `config/app.php` uses the safe `env('APP_DEBUG', false)` scaffold, and `VerifyCsrfToken.php` does not exist in the tree — the probe skips that check rather than inventing a finding.

## php-deps

**Measured: 0 finding(s)** (none). 0 findings — correctly silent.

- PHP `^8.2` (≥ 8.1), `laravel/framework` locked at 11.44.1 (≥ 9), `composer.lock` present, `minimum-stability: stable` with `prefer-stable: true`. Matches both reports' own conclusion that no CVE could be confidently confirmed.
- Only four STRUCTURAL advisories are pinned — missing lockfile, PHP floor < 8.1, Laravel major < 9, `minimum-stability: dev` without `prefer-stable`. No CVE database was consulted and none is guessed; the finding message names the basis and which source (lock vs. range) it read.

## php-hygiene

**Measured: 5 finding(s)** (5 high). 5 findings, all REAL.

- One aggregate: **276** backup/archive files (~10 MB) in deployable paths, 57 inside `app/Http/Controllers/`, 15 of them `routes/web.php` backups carrying the same hard-coded admin password as the live file (named, never printed).
- Independently reconciled: `*.bak*` = 269, `*_bak_*` = 6, `*.orig` = 1 → union 276. The ground-truth report's 269–275 counted only the `.bak*` shape.
- Plus 4 misplaced-file findings: 2 migrations and 1 Blade template inside `app/Http/Controllers/`, and a stale `AdminController.php` copy inside `resources/views/pages/`. Matches SEC-014 and backend.md §3.3/§3.4.
- **Trap:** a literal `*.bak` glob matches ZERO files here — every backup is named `AdminController.php.bak_20260725_applylock`, with the suffix AFTER `.bak`. A lens written from the obvious pattern would have called this repo clean over 276 files.

## php-runtime-ddl

**Measured: 1 finding** (1 critical). REAL.

- `app/Http/Controllers/AdminController.php:610` **critical** — `ensureNewsSchema()` calls the
  schema builder at request time. Ground truth SEC-013. 23 schema-builder call sites in that file,
  reported as ONE finding against the method that owns them.
- **A documented disagreement with the hand audit.** SEC-013 calls this an *"HTTP-reachable admin
  endpoint"*. In this snapshot it is not: `newsSetup()` is one of only **3 of 98** public methods in
  that controller with no route referencing it, and `routes/web.php` names every method explicitly —
  no dynamic dispatch could reach it. Criterion 3 is therefore silent here on purpose. The DDL
  finding stands; the reachability claim does not, in this snapshot.
- The two migration-shaped files inside `app/Http/Controllers/` are deliberately NOT counted: they
  are classes nobody calls, and `php-hygiene` already reports them as misplaced. Accusing the same
  files twice under two headings is how an audit loses a reader.

## php-unvalidated-write

**Measured: 10 findings** (9 critical, 1 high). All REAL.

- 9 routed methods that write request data with no validation, including **`storeCompanyForm()` at
  `AdminController.php:1757`** — backend #4 cites 1757-1841, so the line matches exactly. Also
  `offersStore`/`offersUpdate` in `HomeController` (the same methods `php-uploads` reports, for a
  different defect — no validation at all vs. no mime/size rule; both are real and neither is a
  duplicate of the other).
- 1 high: no FormRequest classes anywhere (backend #10).
- Kept defensible against 98 public methods / 30 validate call-sites by restricting to methods that
  WRITE and that a ROUTE can reach, plus a cap of 20 reported individually.
- **The cap was 5 and hid the headline.** At 5, `storeCompanyForm()` — the finding the hand audit
  led with — fell into the collapsed tail. Raised to 20. A cap that hides the headline is worse than
  no cap at all.

## php-schema-integrity

**Measured: 2 findings** (1 critical, 1 high). Both REAL.

- **critical** — 9 tables the code reads or writes have no migration anywhere: `about_us`,
  `applicant_field_values`, `applications`, `companies`, `company_fields`, `contactus`, `offers`,
  `settings`, `testimonials`. Backend #1 says "9 of the app's core tables" — the probe reached the
  same number independently.
- **high** — zero `->foreign(`/`->constrained()` across 55 migration files, while 14 declare a
  relational `*_id` column. Backend #6.
- Laravel's own framework tables are excluded, so the count blames the application and not the
  framework's furniture.

## php-deps (criterion 5, added 0.10.0)

**Measured: 3 findings** (2 high, 1 medium). All REAL, one verified against the live source.

CORRECTION: an earlier note here said 1 finding. That was measured against the advisory table
BEFORE the cursor-pagination fix and the anchor fetch, which added rows. The published 0.10.0
reports the same 3, so nothing regressed — the earlier number was simply taken from a smaller
table and should not have been written down as the result.

- `guzzlehttp/guzzle` 7.9.2, `guzzlehttp/psr7` 2.7.0, and `league/commonmark` 2.6.1 — the last
  inside `>= 1.5.0, < 2.10.0` of GHSA-8rr7-cvq3-gmfh.
  Confirmed by fetching the advisory from GitHub directly rather than trusting the shipped table.
- This is the whole point of the advisory feed: the lens went from four structural facts and zero
  findings here, to naming a real vulnerable dependency.
- The table is recency-capped, so **absence is not a clean bill of health** — the finding text says
  so. `tools/audit/build-advisory-table.mjs` fetches an ANCHOR package by name on every regeneration
  so the fixture proving this criterion cannot go dead when the advisory ages out.


### 0.10.1 — the flat-range caveat

49% of composer rows name no lower bound, which by semver ordering swallows every earlier major
line and flags a backported fix as vulnerable ([[advisory-flat-range-false-positive]]). All three
findings above survive it: guzzle, psr7 and commonmark all match BOUNDED ranges. A flat-range match
is now reported, capped at medium, and carries the `gh api /advisories/<GHSA> --jq .published_at`
check that settles it.
