// KNOWN-BAD (state-transition-integrity 1, check-then-act): the real pre-#205
// kyc/review.ts shape. The current status IS read and branched on, but the write
// is unconditional and an audit row follows - two concurrent reviews both pass the
// check and both log. Medium, not high: a guard exists, it is just not atomic.
export async function reviewProfile(tx: any, profileId: string, actorId: string) {
  const profile = await tx.verificationProfile.findUnique({ where: { id: profileId } })
  if (!['in_review', 'pending'].includes(profile.status)) {
    throw new Error('KYC_INVALID_TRANSITION')
  }
  const updated = await tx.verificationProfile.update({
    where: { id: profileId },
    data: { status: 'approved', reviewedById: actorId },
  })
  await tx.kycAuditLog.create({ data: { profileId, action: 'approve', actorId } })
  return updated
}
