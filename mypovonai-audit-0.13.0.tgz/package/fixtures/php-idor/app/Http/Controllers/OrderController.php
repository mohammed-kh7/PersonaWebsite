<?php
// KNOWN-BAD. Mirrors the finding that made this lens necessary: a lookup by a
// client-supplied id whose ONLY where() column happens to be named after the
// table's own key (`order_id`) -- it reads like an ownership check but it is
// comparing the id to itself, so it scopes nothing.
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function show($order_id)
    {
        // KNOWN-BAD: single self-referential where(), no second column, no
        // policy check, no relationship traversal.
        $order = DB::table('orders')->where('order_id', $order_id)->first();
        if (!$order) {
            abort(404, 'Order not found');
        }
        return view('orders.show', compact('order'));
    }

    public function invoice($id)
    {
        // KNOWN-BAD: a bare Eloquent find() by a client-supplied id, no scope
        // anywhere in the method.
        $invoice = \App\Models\Invoice::find($id);
        return view('orders.invoice', compact('invoice'));
    }
}
