<?php
// KNOWN-BAD: both routes sit at the TOP LEVEL -- no Route::middleware()/group()
// wraps them, and neither carries its own ->middleware() -- so a route
// forwarding to a method the probe already flagged must also fire here.
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrderController;

Route::get('/orders/{order_id}', [OrderController::class, 'show'])->name('orders.show');
Route::get('/orders/{id}/invoice', [OrderController::class, 'invoice'])->name('orders.invoice');
