<?php
// CLEAN TWIN of fixtures/php-secrets: the same shape, done correctly. The gate
// verifies a hash held in configuration, so nothing in this file is a credential
// and the probe must stay silent.
Route::post('/admin-login', function (\Illuminate\Http\Request $request) {
    if (\Illuminate\Support\Facades\Hash::check($request->input('password'), config('admin.password_hash'))) {
        $request->session()->put('admin_ok', true);
        return redirect('/admin');
    }
    return back();
});
