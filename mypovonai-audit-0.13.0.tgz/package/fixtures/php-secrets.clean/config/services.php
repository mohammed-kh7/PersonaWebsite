<?php
// CLEAN TWIN: every value comes from the environment, and the only defaults are
// honest non-credentials (a URL and a driver name), which the probe must not flag.
return [
    'mailer' => [
        'api_key'  => env('MAILER_API_KEY'),
        'token'    => env('MAILER_API_TOKEN'),
        'endpoint' => env('MAILER_ENDPOINT', 'https://api.example.com'),
        'driver'   => env('MAIL_MAILER', 'smtp'),
    ],
];
