<?php
// CLEAN TWIN. The validation rule stays; the credential comes from the
// environment. This file must produce ZERO findings.
namespace App\Http\Controllers;

class AdminController extends Controller
{
    public function login(Request $request)
    {
        \Validator::make($request->all(), [
            'password' => 'required|min:8',
        ]);
        $payload = [
            'password' => config('services.mailer.password'),
        ];
        return $payload;
    }
}
