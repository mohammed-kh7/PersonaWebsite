export function start(prisma) { return setInterval(() => withLeaderLock('orders', () => prisma.order.updateMany({where:{expired:true},data:{status:'expired'}})),10000); }
