import {Server} from 'socket.io';
import {createAdapter} from '@socket.io/redis-adapter';
export function realtime(server,pub,sub) {const io = new Server(server);io.adapter(createAdapter(pub,sub));return io;}
