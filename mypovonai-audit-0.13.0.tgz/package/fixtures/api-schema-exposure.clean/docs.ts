import swaggerUi from 'swagger-ui-express';
export function docs(app, spec) { if (process.env.NODE_ENV !== 'production') app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(spec)); }
