<?php
// KNOWN-BAD. Violates php-secrets grade 0: the whole admin area is gated by one
// literal compared against a value taken straight from the request, so everyone
// who has ever seen this file can sign in, and changing it needs a deploy.
Route::post('/admin-login', function (\Illuminate\Http\Request $request) {
    if ($request->input('password') === 'FAKE-Sup3rSharedGate2026') {
        $request->session()->put('admin_ok', true);
        return redirect('/admin');
    }
    return back();
});
