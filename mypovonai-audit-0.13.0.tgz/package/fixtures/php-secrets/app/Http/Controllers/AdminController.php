<?php
// KNOWN-BAD. Two lines under the SAME key, one real and one not: the probe must
// tell them apart by the VALUE. An earlier filter read the whole line, matched
// the quoted key, and suppressed the credential below.
namespace App\Http\Controllers;

class AdminController extends Controller
{
    public function login(Request $request)
    {
        // CLEAN: a Laravel validation rule, not a credential.
        \Validator::make($request->all(), [
            'password' => 'required|min:8',
        ]);
        // KNOWN-BAD: a credential in source under a credential-shaped key.
        $payload = [
            'password' => 'Wk9r-Tp42-Lm70-Qz18', // FAKE fixture value
        ];
        return $payload;
    }
}
