<?php
// KNOWN-BAD. Violates php-secrets grade 0 (a credential in source) and the
// env-default clause: the fallback ships whenever the variable is absent.
return [
    'mailer' => [
        'api_key' => 'key-9f2c4b7e1a3d5f6081b2c3d4e5f60718', // FAKE fixture value
        'token'   => env('MAILER_API_TOKEN', 'tok_live_4f9a2b7c1d8e3f60'), // FAKE fixture value
    ],
];
