export async function resolveTenant(id) { return await db.tenant.findUnique({where:{id}}) ?? await db.tenant.findFirst(); }
