<?php
// KNOWN-BAD: declaring nothing as guarded means every column, including a
// future is_admin/role column, becomes mass assignable the moment any write
// call reaches this model with raw input.
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $guarded = [];
}
