<?php
// KNOWN-BAD. Two shapes of the same bug: the whole request body reaching a
// mass-assignment write with no field allowlist at the call site.
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    public function store(Request $request)
    {
        // KNOWN-BAD, direct: $request->all() IS the create() argument.
        $user = User::create($request->all());
        return redirect()->route('users.index');
    }

    public function update(Request $request, $id)
    {
        // KNOWN-BAD, indirect: captured under a name, then reaches update()
        // two lines later in the same method.
        $data = $request->except(['_token']);
        $user = User::findOrFail($id);
        $user->update($data);
        return redirect()->route('users.index');
    }
}
