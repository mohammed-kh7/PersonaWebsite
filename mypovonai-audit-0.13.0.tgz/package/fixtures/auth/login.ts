// known-bad: the credential endpoint has no throttle anywhere in the project,
// so guessing passwords costs an attacker nothing but time.
export const POST = (req: Request) => fetch("/auth/login", { method: "POST" });
