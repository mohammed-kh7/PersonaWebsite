// known-bad: the post-login destination comes straight from a query param with
// no allowlist/same-origin check before the redirect.
// Violates auth.md criterion 11 (open redirect).
export function POST(req: Request, res: Response) {
  const returnTo = req.query.returnTo;
  authenticateUser(req);
  res.redirect(returnTo);
}
