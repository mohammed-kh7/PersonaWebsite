export async function findUser(id) { return db.$queryRawUnsafe(`SELECT * FROM users WHERE id = ${id}`); }
