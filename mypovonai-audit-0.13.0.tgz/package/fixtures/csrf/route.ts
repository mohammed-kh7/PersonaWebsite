export async function POST(request) { const session = await getServerSession(); return db.user.update({where:{id:session.id},data:{name:"ok"}}); }
