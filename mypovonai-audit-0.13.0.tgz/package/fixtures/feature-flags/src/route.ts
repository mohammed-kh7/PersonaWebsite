export function handler(store: { plan: string }) {
  // gated by UI hiding only; no server-side entitlement check on this route
  if (store.plan === "pro") return { ok: true };
  return { ok: false };
}
