// known-bad: a Redis connection string with no credentials — a default/open
// connection. The cache holds sessions and tokens.
// Violates cache-ratelimit.md criterion 10.
import Redis from "ioredis";

export const redis = new Redis("redis://cache.internal:6379");
