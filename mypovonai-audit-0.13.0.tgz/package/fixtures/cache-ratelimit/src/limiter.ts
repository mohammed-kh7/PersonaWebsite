import rateLimit from "express-rate-limit";
// in-process MemoryStore — meaningless across replicas
export const limiter = rateLimit({ windowMs: 60000, max: 100 });
