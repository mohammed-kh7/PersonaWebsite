# Agent rules
Never silently skip a rule: each of the 15 quality rules ends as done (evidence) or skip: <reason>.
Do not run through the checklist silently.
