# Rules
Never silently skip a rule.
