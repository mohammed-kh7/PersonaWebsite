import { spawnSync } from "node:child_process";
export const defaults = { cwd: ".", env: process.env };

export function runOnce(cmd: string) {
  return spawnSync(cmd, [], {
    env: process.env,
  });
}
