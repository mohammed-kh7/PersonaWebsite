import { spawn } from "node:child_process";
export function runTool(cmd: string, args: string[]) {
  return spawn(cmd, args, { env: process.env });
}
