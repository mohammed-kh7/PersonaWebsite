import { spawn } from "node:child_process";
// A constant named like a secret elsewhere in the file is not a scrub of THIS spawn.
const API_KEY_HEADER = "x-api-key";
export function runTool(cmd: string, args: string[]) {
  return spawn(cmd, args, {
    env: process.env,
  });
}
