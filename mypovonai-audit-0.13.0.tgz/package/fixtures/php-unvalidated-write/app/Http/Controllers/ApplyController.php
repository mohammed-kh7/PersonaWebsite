<?php
// KNOWN-BAD. The public apply endpoint: reachable from a route, writes what the
// client sent, validates none of it. Every key reaches persistence with neither
// a type, a length, nor a permitted-value check.
namespace App\Http\Controllers;

class ApplyController extends Controller
{
    public function storeApplication(Request $request)
    {
        $data = $request->all();
        Application::create($data);
        return back();
    }

    // A READ using request data is not this lens's business — it must stay quiet
    // here, or the lens would flag half of every controller ever written.
    public function search(Request $request)
    {
        return Application::where('title', $request->input('q'))->get();
    }
}
