import { prisma } from "./db";
export async function refund(transactionId?: string) {
  const payment = await prisma.payment.findFirst({ where: { transactionId } });
  return payment;
}
export async function cancel(input: { code: string }) {
  let orderId: string | undefined;
  if (input.code) orderId = input.code.trim();
  return prisma.order.deleteMany({ where: { id: orderId } });
}

export async function lookupByRef(orderRef?: string) {
  return prisma.order.findFirst({
    where: {
      orderRef,
      status: "open",
    },
  });
}

export async function lookupOnCall(sku?: string) {
  const rows = await prisma.item.deleteMany({ where: {
    sku: sku,
  } });
  return rows;
}

export async function afterCallback(tag?: string) {
  const upper = ["a"].map((s) => s.toUpperCase());
  return prisma.order.findFirst({ where: { tag } });
}
