<?php
// The SAME shape as the known-bad twin, written correctly: validated, named
// fields only -- never the whole request body -- reach create()/update().
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'  => 'required|string|max:100',
            'email' => 'required|email',
        ]);
        $user = User::create([
            'name'  => $validated['name'],
            'email' => $validated['email'],
        ]);
        return redirect()->route('users.index');
    }

    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:100',
        ]);
        $user = User::findOrFail($id);
        $user->update([
            'name' => $validated['name'],
        ]);
        return redirect()->route('users.index');
    }
}
