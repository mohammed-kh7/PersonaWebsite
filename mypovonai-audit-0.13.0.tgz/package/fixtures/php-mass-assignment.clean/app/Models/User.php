<?php
// SAFE: an explicit allowlist -- only these columns can ever be mass-assigned,
// no matter what a controller passes in.
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    protected $fillable = ['name', 'email'];
}
