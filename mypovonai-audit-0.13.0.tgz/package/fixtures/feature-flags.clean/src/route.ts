export async function route(store) { await requireFeature(store.id,'exports'); return exportRows(store.id); }
