const PLAN_BASELINE = {free:[],pro:['exports']};
export async function requireFeature(storeId,feature) { const subscription=await loadSubscription(storeId); if(!PLAN_BASELINE[subscription.plan].includes(feature)) throw Error('forbidden'); }
