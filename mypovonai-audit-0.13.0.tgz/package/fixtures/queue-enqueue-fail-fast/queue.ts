export async function queueJob(id) { await db.job.update({where:{id},data:{status:"queued"}}); await queue.send({id}); }
