<?php
Route::post('/apply', [App\Http\Controllers\ApplyController::class, 'storeApplication']);
Route::get('/search', [App\Http\Controllers\ApplyController::class, 'search']);
