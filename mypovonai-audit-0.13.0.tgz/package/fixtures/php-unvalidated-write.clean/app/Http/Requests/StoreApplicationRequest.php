<?php
namespace App\Http\Requests;

class StoreApplicationRequest extends FormRequest
{
    public function rules(): array
    {
        return ['name' => 'required|string|max:120', 'email' => 'required|email'];
    }
}
