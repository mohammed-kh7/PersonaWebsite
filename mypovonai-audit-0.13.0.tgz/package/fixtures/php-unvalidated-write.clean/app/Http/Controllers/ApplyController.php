<?php
// CLEAN TWIN: the same endpoint, validated, and the rules live in a FormRequest
// where they can be reviewed in one place, reused, and covered by one test.
namespace App\Http\Controllers;

use App\Http\Requests\StoreApplicationRequest;

class ApplyController extends Controller
{
    public function storeApplication(StoreApplicationRequest $request)
    {
        Application::create($request->validated());
        return back();
    }

    public function search(Request $request)
    {
        return Application::where('title', $request->input('q'))->get();
    }
}
