<?php
// KNOWN-BAD. Four methods, one per php-uploads criterion, so each of the
// probe's four finding call sites is proven alive by tests/site-coverage.sh.
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UploadController extends Controller
{
    // (1) validated, but the rule has no mimes:/mimetypes:/image and no max:
    public function avatarStore(Request $request)
    {
        $request->validate([
            'avatar' => 'required|file',
        ]);

        if ($request->hasFile('avatar')) {
            $path = $request->file('avatar')->store('avatars', 'public');
        }

        return back();
    }

    // (2) no validation call anywhere in the handler
    public function bannerStore(Request $request)
    {
        if ($request->hasFile('banner')) {
            $path = $request->file('banner')->store('banners', 'public');
        }

        return back();
    }

    // (3) write destination bypasses the disk abstraction: 'public' is the
    // PATH, not the disk -- lands under storage/app/public just the same.
    public function legacyStore(Request $request)
    {
        $path = $request->file('legacy')->store('public');

        return back();
    }

    // (4) stored filename derived from the client-supplied original name
    public function resumeStore(Request $request)
    {
        $name = $request->file('resume')->getClientOriginalName();
        $request->file('resume')->move(storage_path('app/resumes'), $name);

        return back();
    }
}
