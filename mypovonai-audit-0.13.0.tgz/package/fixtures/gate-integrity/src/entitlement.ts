// KNOWN-BAD FIXTURE for standard/gate-integrity.md §3.
// `checkEntitlement` is INJECTED and typed `() => Promise<boolean>`. TypeScript
// erases at runtime, so the type is a comment: {}, 1, "yes" and the string
// "false" are all truthy, and each of them grants access to a paid product.
type Deps = { isEntitled: (u: string) => Promise<boolean>; checkEntitlement: (u: string) => Promise<boolean> };

export async function openPaidFeature(deps: Deps, userId: string) {
  // Violation (§3): a bare truthiness branch at a trust boundary.
  if (await deps.isEntitled(userId)) {
    return { allow: true };
  }
  return { allow: false };
}

export async function renderUpsell(deps: Deps, userId: string) {
  // Violation (§3), the second seam in the same module — the one that survives
  // a fix applied only to the seam you were shown.
  return (await deps.checkEntitlement(userId)) ? "premium" : "upsell";
}
