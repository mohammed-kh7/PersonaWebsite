#!/usr/bin/env bash
# KNOWN-BAD FIXTURE for standard/gate-integrity.md. Four routes to "pass", none
# of which reads the artifact. This gate has reported 0 findings on every input
# it has ever been given, and would report 0 on a tree full of live keys.
set -uo pipefail
CORPUS="${1:-.}"

# Violation 1 (§2, report-sink): the report sink and the log sink are different
# streams. /dev/stdout receives nothing; the file below is never written.
# Violation 2 (§2, scanner-fail-open): `|| true` means the step cannot go red.
# Violation 3 (§2, gate-tool-pinning): `detect` is deprecated and there is no
# version pin anywhere in this file, so a tool bump silences the gate.
gitleaks detect --no-git --source "$CORPUS" --report-path /dev/stdout > report.json || true

# Violation 4 (§2, scanner-fail-open): the parser fallback converts a BROKEN
# gate into a passing one. On a parse error the gate must throw, not empty itself.
FINDINGS=$(cat report.json 2>/dev/null || echo '[]')
COUNT=$(printf '%s' "$FINDINGS" | grep -c 'RuleID' || echo 0)

echo "secret gate: $COUNT finding(s)"
[ "$COUNT" -eq 0 ] && echo PASS
