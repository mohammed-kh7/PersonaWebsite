# Rules
Run through all 15 rules silently; never silently skip a rule.
