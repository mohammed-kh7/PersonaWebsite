export async function POST(request) { const body = await request.json(); return db.user.update({where:{id:1},data:{...body}}); }
