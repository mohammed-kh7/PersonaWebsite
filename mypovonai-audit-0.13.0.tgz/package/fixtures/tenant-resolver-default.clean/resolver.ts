export async function resolveTenant(id) { const row = await db.tenant.findUnique({where:{id}}); if (!row) throw new Error("not found"); return row; }
