export async function POST(request) { const body = await request.json(); return db.payment.create({data:{amount:body.amount}}); }
