import { log } from "@/lib/log";
export async function GET() { log.error("[x] failed", { error: new Error("boom") }); return new Response("no", { status: 500 }); }
