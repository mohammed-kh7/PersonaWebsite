type Level = "error" | "warn" | "info";
function emit(level: Level, event: string, fields: Record<string, unknown> = {}) {
  console[level](JSON.stringify({ level, event, ...fields }));
}
export const log = {
  error: (e: string, f?: Record<string, unknown>) => emit("error", e, f),
  info: (e: string, f?: Record<string, unknown>) => emit("info", e, f),
};
