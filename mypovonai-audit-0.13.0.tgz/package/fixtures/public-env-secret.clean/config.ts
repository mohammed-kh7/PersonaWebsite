export const API_SECRET = process.env.API_SECRET;
export const NEXT_PUBLIC_API_URL = "https://example.test";
export const NEXT_PUBLIC_API_KEY = process.env.NEXT_PUBLIC_API_KEY;
