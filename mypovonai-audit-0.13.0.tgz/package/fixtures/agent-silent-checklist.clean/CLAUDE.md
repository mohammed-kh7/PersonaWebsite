# Agent rules
Never silently skip a rule: each of the 15 rules ends as done (evidence) or skip: <reason>.
