export async function POST(request) { const body = await request.json(); return db.user.update({where:{id:body.id},data:{role:body.role}}); }
