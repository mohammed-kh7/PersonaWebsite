export const NEXT_PUBLIC_API_SECRET = "sk_live_fixture_private_123456789";
