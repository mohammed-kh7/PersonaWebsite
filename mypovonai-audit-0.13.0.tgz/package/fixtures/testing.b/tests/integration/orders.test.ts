// known-bad: wipes real rows and never restores them, so the next suite
// inherits whatever this one left behind.
import { test } from "vitest";
test("orders", async () => {
  await prisma.order.deleteMany({});
  await prisma.orderItem.deleteMany({});
});
