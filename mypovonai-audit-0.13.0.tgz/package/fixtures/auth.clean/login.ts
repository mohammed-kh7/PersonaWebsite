export function login(router,authLimiter,handler) { router.post('/auth/login',authLimiter,handler); }
