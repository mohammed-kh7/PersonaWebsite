// known-bad: two different role-check idioms in one codebase.
// Violates auth.md criterion 2 (uniform middleware chain, ONE helper name).
import { authorize, requireRole } from './mw';
router.get('/a', authenticate, authorize('admin'), handlerA);
router.get('/b', authenticate, authorize('admin'), handlerB);
