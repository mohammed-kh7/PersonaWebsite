export async function GET(request) { return db.order.findUnique({where:{id:params.id}}); }
