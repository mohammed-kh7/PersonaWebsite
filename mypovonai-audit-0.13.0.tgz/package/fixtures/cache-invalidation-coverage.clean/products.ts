export async function readProduct(id) { const cached = await cache.get(id); return cached ?? await db.product.findUnique({where:{id},select:{price:true}}); }
export async function changePrice(id,price) { const result = await db.product.update({where:{id},data:{price}}); await invalidateProduct(id); return result; }
