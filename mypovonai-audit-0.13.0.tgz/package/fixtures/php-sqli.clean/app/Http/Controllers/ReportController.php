<?php
// CLEAN TWIN of fixtures/php-sqli: the same shapes, done correctly. Every raw
// SQL string is a fixed literal or uses `?` placeholders with a bindings
// array; every orderBy() takes a fixed column. This file must produce ZERO
// findings.
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function byEmail(Request $request)
    {
        // Parameter-bound: the placeholder is `?`, the value travels in the
        // bindings array, never inside the SQL string itself.
        $safe = DB::table('users')->whereRaw('email = ?', [$request->input('email')])->get();
        $rows = DB::select('SELECT * FROM users WHERE email = ?', [$request->input('email')]);

        return $rows;
    }

    public function byName(Request $request)
    {
        // Same bound form, named placeholder.
        $q = DB::table('users')
            ->whereRaw('name = :name', ['name' => $request->input('name')])
            ->get();

        return $q;
    }

    public function summary()
    {
        // A literal aggregate expression — no variable anywhere in it.
        $totals = DB::table('offers')
            ->select('company_id', DB::raw('COALESCE(offers.company_name, companies.name) as company_name'))
            ->get();

        return $totals;
    }

    public function list(Request $request)
    {
        // The column is a fixed, allow-listed value chosen in code, never the
        // raw request string.
        $allowed = ['name', 'created_at', 'id'];
        $sort = in_array($request->input('sort'), $allowed, true) ? $request->input('sort') : 'id';
        return DB::table('offers')->orderBy($sort)->get();
    }

    public function listByDirection(Request $request)
    {
        $direction = $request->input('direction') === 'desc' ? 'desc' : 'asc';
        $safe = DB::table('offers')->orderBy('created_at')->get();
        return DB::table('offers')->orderBy('created_at', $direction)->get();
    }
}
