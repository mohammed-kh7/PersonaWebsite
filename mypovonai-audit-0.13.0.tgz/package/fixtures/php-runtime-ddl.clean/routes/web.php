<?php
Route::get('/admin/news-setup', [App\Http\Controllers\SetupController::class, 'setup']);
