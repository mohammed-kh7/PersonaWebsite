<?php
// CLEAN TWIN: the same feature, with the schema change where it belongs.
// The controller reads; it does not reshape the database.
namespace App\Http\Controllers;

class SetupController extends Controller
{
    public function setup()
    {
        $ready = \Schema::hasColumn('blogs', 'subtitle'); // asking is not changing
        return response()->json(['ready' => $ready]);
    }
}
