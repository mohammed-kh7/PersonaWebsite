<?php
// CLEAN TWIN: the schema change lives in a migration — reviewed, ordered,
// reversible, and run by a deploy step rather than by traffic.
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('blogs', function (Blueprint $table) {
            $table->string('subtitle')->nullable();
        });
        Schema::create('news_comments', function (Blueprint $table) {
            $table->id();
        });
    }
};
