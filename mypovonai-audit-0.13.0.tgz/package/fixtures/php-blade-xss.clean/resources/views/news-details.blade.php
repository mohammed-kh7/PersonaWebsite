{{-- CLEAN TWIN of fixtures/php-blade-xss: the same shapes, done correctly.
     Every raw echo is either escaped before printing or a genuinely safe,
     non-attacker-controlled source. This file must produce ZERO findings. --}}
<article>
    {!! nl2br(e($news->description)) !!}

    {{-- The same model field as the bad twin, escaped through e() first. --}}
    {!! e($news->body_html) !!}

    {{-- The same request value, escaped before the raw echo. --}}
    <div class="banner">{!! e(request('promo_message')) !!}</div>

    <p>{!! __('news.disclaimer') !!}</p>

    @foreach ($items as $item)
        <span>{!! $loop->iteration !!}</span>
    @endforeach
</article>
