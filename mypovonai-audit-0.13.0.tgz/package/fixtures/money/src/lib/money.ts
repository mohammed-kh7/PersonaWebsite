// known-bad: the one place money math lives, and nothing tests it.
export const applyDiscount = (minor: number, pct: number) =>
  Math.round(minor - (minor * pct) / 100);
