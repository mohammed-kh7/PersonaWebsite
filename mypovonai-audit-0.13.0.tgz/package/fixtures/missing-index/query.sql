CREATE TABLE invoices (id UUID PRIMARY KEY, customer_id UUID);
SELECT id FROM invoices WHERE customer_id = $1;
