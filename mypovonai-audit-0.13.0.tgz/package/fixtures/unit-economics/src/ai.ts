import OpenAI from "openai";
const c = new OpenAI();
export const gen = (p: string) => c.chat.completions.create({ model: "gpt-4", messages: [{ role: "user", content: p }] });
