<?php
// CLEAN: only the live controller lives here — no backups, no misplaced
// migrations or views.
namespace App\Http\Controllers;

class AdminController extends Controller
{
    public function index()
    {
        return view('admin.index');
    }
}
