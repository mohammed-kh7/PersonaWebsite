{{-- CLEAN: the view lives where views belong. --}}
<div>{{ $company->name }}</div>
