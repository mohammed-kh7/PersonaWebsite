export async function POST(request) { const body = await request.json(); await claimEvent(body.idempotencyKey); return db.payment.create({data:{amount:body.amount}}); }
