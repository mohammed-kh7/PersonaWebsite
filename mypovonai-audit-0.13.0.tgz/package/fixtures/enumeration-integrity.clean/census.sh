#!/usr/bin/env bash
find . -type d -name .git -print0 | while IFS= read -r -d '' gitdir; do repo=${gitdir%/.git}; [ -d "$repo/.git" ] || continue; printf '%s\n' "$repo"; done
