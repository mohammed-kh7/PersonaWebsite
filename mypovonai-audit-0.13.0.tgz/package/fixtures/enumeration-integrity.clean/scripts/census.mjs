import {statSync} from 'node:fs';
export function identity(repo) { if (!statSync(`${repo}/.git`).isDirectory()) throw Error('not a repo'); return repo; }
export function unique(repos) { const ids=repos.map(identity); if(new Set(ids).size!==ids.length) throw Error('duplicate identity'); return ids; }
