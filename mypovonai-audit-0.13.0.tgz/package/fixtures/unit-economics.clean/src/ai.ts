import OpenAI from 'openai';
export async function generate(prisma,tenantId,input) {const response=await new OpenAI().responses.create({model:process.env.MODEL_ID,input});await prisma.usage.create({data:{tenantId,inputTokens:response.usage.input_tokens,outputTokens:response.usage.output_tokens,costMicros:priceUsage(response.usage)}});return response.output_text;}
