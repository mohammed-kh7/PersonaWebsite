# Probe fixtures — known-bad inputs

Every probe in `../probes/` MUST have a directory here named after it,
containing a minimal repo-shaped input that the probe is guaranteed to flag.

`../tests/probe-fires.sh` runs each probe against its fixture and **fails the
suite if any probe stays silent** — a probe that cannot fire is a dead gate: it
would score a broken repo as clean, which is worse than having no probe at all.

Rules:

- One directory per probe: `fixtures/<probe-id>/`.
- Keep fixtures minimal — the smallest file set that makes the probe fire.
- A fixture is **known-bad by construction**; comment inside each file WHICH
  standard clause it violates and why.
- Calibration verdicts against real repos live in `CALIBRATION-<repo>.md`
  files here, one line per finding: REAL or FALSE POSITIVE, with a reason.

## Variants

Some finding sites are alternative branches of one `if/else` and **no single
fixture can reach both** — `cicd` line 9 fires only when there is NO
`.github/workflows`, which the primary fixture must have to reach every check
below it. A lens may therefore carry additional known-bad shapes:

    fixtures/<lens>/      the primary (what probe-fires.sh runs)
    fixtures/<lens>.b/    another shape
    fixtures/<lens>.c/    another

`../tests/site-coverage.sh` unions every variant and requires the result to
reach **every** `finding` call site the probe declares. `probe-fires.sh` proves
a PROBE is alive; site-coverage proves every CRITERION inside it is.

## Do not name the forbidden token in a fixture's own comment

Three fixtures failed on their first run because the comment explaining what was
wrong contained the exact string the probe greps for — `maxWait`,
`redis-adapter`, `-print0`. The comment suppressed the finding it was
describing. Describe the defect in prose; never write the token that proves the
defect is absent.

## Fixtures are not tests

`fleet/fixtures/**` is excluded from vitest collection. A fixture demonstrating
"a test truncates real rows with no teardown" is, by construction, a `.test.ts`
file; collecting it makes the real suite red for the exact defect the fixture
exists to contain.
