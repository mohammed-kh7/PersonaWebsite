export async function POST(request) { const body = await request.json(); assertPublicUrl(body.url); return fetch(body.url); }
