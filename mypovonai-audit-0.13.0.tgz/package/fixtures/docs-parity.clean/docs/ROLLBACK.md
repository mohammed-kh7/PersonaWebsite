Select the previous known-good Worker deployment in the dashboard. Verify health and error monitoring before reopening traffic. Keep schema migrations additive.
