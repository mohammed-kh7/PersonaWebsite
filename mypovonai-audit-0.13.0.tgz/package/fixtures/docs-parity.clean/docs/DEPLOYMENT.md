Run npm ci, npm test and npm run build. Deploy the tested commit through the Worker workflow; verify its deployment receipt and health response.
