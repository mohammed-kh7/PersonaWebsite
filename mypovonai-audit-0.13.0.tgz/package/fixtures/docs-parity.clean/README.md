Example Next.js app. Deploy to Cloudflare Workers using the checked-in CI. See docs/DEPLOYMENT.md and docs/ROLLBACK.md.
