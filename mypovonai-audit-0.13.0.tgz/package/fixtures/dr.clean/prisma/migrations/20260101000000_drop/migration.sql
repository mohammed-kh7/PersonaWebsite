ALTER TABLE "orders" ADD COLUMN "legacy_total";
