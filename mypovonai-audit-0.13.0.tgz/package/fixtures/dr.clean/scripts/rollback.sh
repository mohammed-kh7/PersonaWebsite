#!/usr/bin/env bash
set -euo pipefail
# Roll back application code only; additive DB migrations remain compatible.
: "${PREVIOUS_DEPLOYMENT:?set the verified previous deployment id}"
wrangler rollback "$PREVIOUS_DEPLOYMENT"
