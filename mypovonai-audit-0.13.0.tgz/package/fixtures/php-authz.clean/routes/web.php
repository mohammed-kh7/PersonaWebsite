<?php
// CLEAN twin of fixtures/php-authz -- same route shapes, each one actually
// gated. Every canonical Laravel middleware syntax gets its own example so
// the probe is proven to recognize all of them, not just the one it happens
// to be tuned on.

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\PagesController;
use App\Http\Controllers\SecureAdminController;

// 1. Array-form group middleware: fixes fixture #1 and #2 from the bad twin
//    at once -- both routes now sit inside a group that declares middleware.
Route::group(['prefix' => 'admin', 'middleware' => ['auth', 'admin']], function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');
    Route::get('/users', [AdminController::class, 'users'])->name('admin.users');
});

// 2. Fluent group middleware (Route::middleware([...])->group(...)).
Route::middleware(['auth'])->group(function () {
    Route::get('/admin/settings', [AdminController::class, 'settings'])->name('admin.settings');
});

// 3. Per-route ->middleware(), no group at all.
Route::get('/admin/export', [AdminController::class, 'export'])
    ->middleware('auth')
    ->name('admin.export');

// 4. Chained prefix()->middleware()->group() form.
Route::prefix('admin')->middleware('auth')->group(function () {
    Route::delete('/reports/{id}', [AdminController::class, 'destroyReport'])->name('admin.reports.destroy');
});

// 5. Route::resource with middleware chained on -- fixes fixture #3.
Route::resource('admin/photos', PhotoController::class)->middleware('auth');

// 6. Controller-level coverage: no group, no per-route middleware, but
//    SecureAdminController gates every action in its own __construct().
Route::get('/manage/widgets', [SecureAdminController::class, 'index'])->name('manage.widgets');

// 7. The admin login/logout/register boundary -- bare, no middleware, URI
//    contains "admin", and still correctly silent: these ARE the gate, not
//    something behind it. Fixes fixture #4's near-miss the same way.
Route::get('/admin-login', function () {
    return view('admin.login');
})->name('admin.gate.form');
Route::post('/admin-login', function (\Illuminate\Http\Request $request) {
    return back();
})->name('admin.gate.submit');
Route::get('/admin/register', function () {
    return view('admin.register');
})->name('register');

// 8. Public, non-privileged route -- never a candidate.
Route::get('/about', [PagesController::class, 'about'])->name('about');
