<?php

namespace App\Http\Controllers;

// Controller-level coverage: gates every one of its own actions from the
// constructor, independent of whatever routes/web.php declares. Laravel 11
// still supports this form alongside the newer static ::middleware() method;
// the probe recognizes this one specifically because it is what the
// calibration repo's own sibling controllers would use if they gated this way.
class SecureAdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        return view('admin.widgets.index');
    }
}
