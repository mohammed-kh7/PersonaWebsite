<?php

namespace App\Http\Controllers;

class AdminController extends Controller
{
    public function dashboard()
    {
        return view('admin.dashboard');
    }

    public function users()
    {
        return view('admin.users');
    }

    public function settings()
    {
        return view('admin.settings');
    }

    public function export()
    {
        return response()->streamDownload(fn () => print(''), 'export.csv');
    }

    public function destroyReport(string $id)
    {
        return back();
    }
}
