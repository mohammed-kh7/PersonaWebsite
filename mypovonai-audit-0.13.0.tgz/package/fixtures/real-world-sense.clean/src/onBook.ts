// CLEAN TWIN: sign-in first, then verification.
export function onBook(kycApproved: boolean, token: string | null, push: (p: string) => void) {
  if (!token) {
    push('/auth')
    return
  }
  if (!kycApproved) {
    push('/account/kyc')
    return
  }
  push('/book')
}
