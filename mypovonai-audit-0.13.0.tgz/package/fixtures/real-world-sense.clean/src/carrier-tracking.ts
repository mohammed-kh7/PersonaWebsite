// REGRESSION TWIN (force-website-builder shipping-carrier.service.ts runTrackingCron,
// 2026-10-08): a background poll living in a *carrier* service file. Not a directory.
export async function runTrackingCron(db: { shipment: { findMany(a: unknown): Promise<unknown[]> } }) {
  // Find all shipments that are not in a terminal state
  return db.shipment.findMany({
    where: { status: { notIn: ['delivered', 'cancelled'] }, trackingNumber: { not: null } },
    select: { id: true },
    take: 200,
  })
}
