// CLEAN TWIN: a ranged request is answered with 206 + Content-Range.
export async function getVideo(key: string, rangeHeader: string | null, bucket: { get(k: string, o?: unknown): Promise<{ body: ReadableStream; size: number } | null> }) {
  const m = rangeHeader ? /bytes=(\d+)-(\d*)/.exec(rangeHeader) : null
  const obj = await bucket.get(key, m ? { range: { offset: Number(m[1]) } } : undefined)
  if (!obj) return new Response('not found', { status: 404 })
  const headers = { 'content-type': 'video/mp4', 'accept-ranges': 'bytes' }
  return m ? new Response(obj.body, { status: 206, headers }) : new Response(obj.body, { headers })
}
