// REGRESSION TWIN (force-website-builder payment.factory.ts / shipping-carrier.service.ts,
// 2026-10-08): a TENANT-scoped config read in a path that merely contains
// "provider". One store's own configuration is not a directory users browse.
export async function loadStoreProviders(storeId: string, db: { paymentConfig: { findMany(a: unknown): Promise<unknown[]> } }) {
  return db.paymentConfig.findMany({
    where: { storeId, isEnabled: true },
    orderBy: { provider: 'asc' },
  })
}
