// REGRESSION TWIN (gcc-horse-market providers/service.ts:145): the country filter
// is composed into `where` well above the findMany, as an explicit optional filter.
export async function listProviderListings(
  query: { kind: string; country?: string },
  db: { providerListing: { findMany(a: unknown): Promise<unknown[]> } },
) {
  const where = {
    status: 'active',
    kind: query.kind,
    ...(query.country ? { country: query.country } : {}),
  }
  // ...pin arithmetic, index notes and the select shape live here...
  // ...
  // ...
  // ...
  const take = 50
  return db.providerListing.findMany({ where, orderBy: { createdAt: 'desc' }, take })
}
