// known-bad: the raw error message is echoed straight into the HTTP response.
export function handler(res: any, err: any) {
  return res.status(500).json({ error: err.message });
}
