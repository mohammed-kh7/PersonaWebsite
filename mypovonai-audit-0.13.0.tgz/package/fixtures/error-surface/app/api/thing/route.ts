import { NextResponse } from "next/server";
export async function POST(req: Request) {
  try { return NextResponse.json({ ok: true }); }
  catch (err: any) { return NextResponse.json({ error: err.stack }, { status: 500 }); }
}
