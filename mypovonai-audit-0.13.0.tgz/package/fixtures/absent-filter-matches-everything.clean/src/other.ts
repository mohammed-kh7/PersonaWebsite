import { prisma } from "./db";
interface Draft { id?: string; userId?: string }
export async function load(order: { id: string }, userId: string) {
  const a = await prisma.order.findFirst({ where: { id: order.id } });
  const b = await prisma.order.findFirst({ where: { userId: userId } });
  return [a, b];
}

export async function multi(order: { id: string }, userId: string, ids: string[]) {
  const rows = ids.map((i) => i.trim());
  return prisma.order.findFirst({
    where: {
      id: order.id,
      userId,
      AND: [{ code: rows[0] }],
    },
  });
}

export async function scoped(draftId?: string) {
  const labels = [1, 2].map((n) => String(n));
  if (!draftId) return labels;
  return prisma.order.findFirst({ where: { id: draftId } });
}
