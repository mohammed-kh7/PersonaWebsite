import { prisma } from "./db";
export async function refund(transactionId?: string) {
  if (!transactionId) throw new Error("PAYMENT_NOT_REFUNDABLE");
  return prisma.payment.findFirst({ where: { transactionId } });
}

export async function lookupByRef(orderRef?: string) {
  if (!orderRef) throw new Error("ORDER_NOT_FOUND");
  return prisma.order.findFirst({
    where: {
      orderRef,
      status: "open",
    },
  });
}
