// known-bad: a money transaction that sets no tx options and uses no wrapper.
export async function checkout(prisma: any, id: string) {
  return prisma.$transaction(async (tx: any) => {
    await tx.order.update({ where: { id }, data: { status: "paid" } });
  });
}
