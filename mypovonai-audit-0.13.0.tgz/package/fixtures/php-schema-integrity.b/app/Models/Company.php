<?php
// KNOWN-BAD variant (criterion 3): the app has models and no migrations/ at all,
// so NONE of the schema is reproducible from this repository.
namespace App\Models;

class Company extends Model
{
    protected $table = 'companies';
}
