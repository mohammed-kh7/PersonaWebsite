// known-bad: Swagger UI registered with no production gate anywhere nearby —
// the schema/documentation endpoint ships live.
// Violates api-schema-exposure criterion 4.
import swaggerUi from "swagger-ui-express";

export function registerDocs(app: Express) {
  app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(openapiSpec));
}
