// known-bad: an Apollo Server with introspection left at its default (on).
// One request returns the complete schema in production.
// Violates api-schema-exposure criterion 1.
import { ApolloServer } from "@apollo/server";

export const server = new ApolloServer({
  typeDefs,
  resolvers,
});
