import {default as AxeBuilder} from '@axe-core/playwright';
export async function accessibility(page) { await page.goto('/'); const result=await new AxeBuilder({page}).analyze(); if(result.violations.length) throw Error('accessibility violations'); }
