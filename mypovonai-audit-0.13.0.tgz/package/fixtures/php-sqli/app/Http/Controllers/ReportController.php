<?php
// KNOWN-BAD. Every method here pairs an unsafe line with the safe form of the
// SAME construct directly above or below it, so the probe has to tell them
// apart by what is inside the SQL text, not by which method it sits in.
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function byEmail(Request $request)
    {
        // CLEAN: parameter-bound — the placeholder is `?`, the value travels
        // in the bindings array, never inside the SQL string itself.
        $safe = DB::table('users')->whereRaw('email = ?', [$request->input('email')])->get();

        // KNOWN-BAD: the request value is interpolated straight into a
        // double-quoted SQL string via `{$...}`.
        $rows = DB::select("SELECT * FROM users WHERE email = '{$request->email}'");

        return $rows;
    }

    public function byName(Request $request)
    {
        // KNOWN-BAD: the SQL string is single-quoted (so PHP does not
        // interpolate it), but it is concatenated with a request value before
        // reaching the driver — same hole, different syntax.
        $q = DB::table('users')
            ->whereRaw("name = '" . $request->input('name') . "'")
            ->get();

        return $q;
    }

    public function summary()
    {
        // CLEAN: a literal aggregate expression, no variable anywhere in it.
        $totals = DB::table('offers')
            ->select('company_id', DB::raw('COALESCE(offers.company_name, companies.name) as company_name'))
            ->get();

        return $totals;
    }

    public function list(Request $request)
    {
        // KNOWN-BAD: the column/direction come straight from the request —
        // orderBy() cannot parameter-bind an identifier, so a caller can name
        // any column (or worse) here.
        return DB::table('offers')->orderBy($request->input('sort'))->get();
    }

    public function listByDirection(Request $request)
    {
        $direction = $request->input('direction', 'asc');
        // CLEAN: the column is a fixed literal — direction is unrelated here.
        $safe = DB::table('offers')->orderBy('created_at')->get();
        // KNOWN-BAD: $direction was assigned straight from the request just
        // above, and is handed to orderBy() unchecked.
        return DB::table('offers')->orderBy($direction)->get();
    }
}
