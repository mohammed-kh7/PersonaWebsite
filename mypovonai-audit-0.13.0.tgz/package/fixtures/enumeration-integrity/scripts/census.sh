#!/usr/bin/env bash
# KNOWN-BAD FIXTURE for standard/enumeration-integrity.md. Every count this
# script produces is plausible, has no error path, and is wrong.
set -uo pipefail
ROOT="${1:-.}"

# Violation 1 (§2, nul-safe-iteration): word-splits on spaces. A directory whose
# name contains spaces becomes two units; measured, this reports 4 repos where
# the NUL-safe census reports 2, and the lost repo raises nothing.
for gitent in $(find "$ROOT" -maxdepth 3 -name .git); do
  repo=$(dirname "$gitent")

  # Violation 2 (§2, worktree-vs-repo): -e is true for a WORKTREE's .git, which
  # is a FILE, as well as a canonical repo's, which is a DIRECTORY. Counting
  # both duplicated a third of the corpus.
  if [ -e "$repo/.git" ]; then
    # Violation 3 (§2, path-not-basename-id): a basename is not unique. Two
    # paths sharing a basename silently collapse onto one id, and nothing here
    # asserts |unique ids| == |units|.
    id=$(basename "$repo")
    echo "$id"
  fi
done
