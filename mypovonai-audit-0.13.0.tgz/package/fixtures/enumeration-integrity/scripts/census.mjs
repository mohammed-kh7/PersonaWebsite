// KNOWN-BAD FIXTURE for standard/enumeration-integrity.md.
// Violation (§2, worktree-vs-repo): existsSync answers "has a .git entry",
// which is a different question from "is a canonical repo" — a worktree's .git
// is a file. The measured run reported 41 repos for a 34-repo corpus.
// Violation (§2, path-not-basename-id): basename as the unit id collided across
// 24 project directories, and no uniqueness assertion follows.
import { existsSync, readdirSync } from "node:fs";
import { join, basename } from "node:path";

export function census(root) {
  const out = [];
  for (const dir of readdirSync(root)) {
    if (existsSync(join(root, dir, ".git"))) {
      const id = basename(dir);
      out.push(id);
    }
  }
  return out;
}
