#!/usr/bin/env bash
# known-bad: a path loop that word-splits on IFS instead of reading NUL-delimited
# records, so any path containing a newline silently becomes two units.
find . -type d -name .git | while read -r p; do
  echo "$p"
done
