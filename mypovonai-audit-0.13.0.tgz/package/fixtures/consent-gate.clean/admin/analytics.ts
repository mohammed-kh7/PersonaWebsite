export function recordView(user) { if (!hasConsent(user)) return; analytics.track("page",{userId:user.id}); }
