# Agent rules
Run through all 15 quality rules silently before every commit.
