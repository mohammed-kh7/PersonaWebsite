export async function GET(request) { return consumeMagicLink(params.token); }
