<?php
// CLEAN TWIN. Same four handlers, each fixed: a full mimes+max rule, a
// validate() call before every write, the 'public' DISK (second argument,
// not the path) and a framework-generated filename. Must emit ZERO findings.
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UploadController extends Controller
{
    public function avatarStore(Request $request)
    {
        $request->validate([
            'avatar' => 'required|image|mimes:png,jpg,jpeg,webp|max:5120',
        ]);

        if ($request->hasFile('avatar')) {
            $path = $request->file('avatar')->store('avatars', 'public');
        }

        return back();
    }

    public function bannerStore(Request $request)
    {
        $request->validate([
            'banner' => 'required|image|mimes:png,jpg,jpeg,webp|max:5120',
        ]);

        if ($request->hasFile('banner')) {
            $path = $request->file('banner')->store('banners', 'public');
        }

        return back();
    }

    public function legacyStore(Request $request)
    {
        $request->validate([
            'legacy' => 'required|image|mimes:png,jpg,jpeg,webp|max:5120',
        ]);

        $path = $request->file('legacy')->store('legacy', 'public');

        return back();
    }

    public function resumeStore(Request $request)
    {
        $request->validate([
            'resume' => 'required|mimes:pdf,doc,docx|max:10240',
        ]);

        $path = $request->file('resume')->store('resumes', 'public');

        return back();
    }
}
