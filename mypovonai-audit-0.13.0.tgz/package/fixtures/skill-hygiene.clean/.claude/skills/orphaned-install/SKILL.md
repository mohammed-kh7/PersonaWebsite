---
name: orphaned-install
installed: 2026-10-09
reviewed: 2026-10-09
---
Use the configured model to review source. Installed to support source review. Reassess usefulness monthly; remove when no longer used.
