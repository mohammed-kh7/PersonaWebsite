export function recordView(user) { analytics.track("page",{userId:user.id}); }
