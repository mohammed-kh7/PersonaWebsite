#!/usr/bin/env bash
# claude-hook: PreToolUse
exit 0
