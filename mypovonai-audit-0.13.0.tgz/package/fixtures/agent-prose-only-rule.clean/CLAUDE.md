# Rules
NEVER push to main.
NEVER skip tests.
NEVER commit secrets.
ALWAYS run the linter.
ALWAYS verify in production.
