<?php
// CLEAN: every cookie flag has a safe default or is explicitly hardened.
return [
    'secure' => env('SESSION_SECURE_COOKIE', true),
    'same_site' => env('SESSION_SAME_SITE', 'lax'),
    'http_only' => env('SESSION_HTTP_ONLY', true),
];
