<?php
// CLEAN: the framework's own safe default — read from the environment, false
// unless explicitly enabled.
return [
    'name' => 'Example',
    'debug' => (bool) env('APP_DEBUG', false),
];
