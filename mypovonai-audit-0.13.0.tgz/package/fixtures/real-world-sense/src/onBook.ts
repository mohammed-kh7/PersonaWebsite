// KNOWN-BAD (real-world-sense 2): gcc-horse-market, vet/transport booking. A signed-out
// guest tapped "book" and was told to verify their identity — they had never
// been asked to sign in. Gate order is guest -> signed-in -> verified -> owner.
export function onBook(kycApproved: boolean, token: string | null, push: (p: string) => void) {
  if (!kycApproved) {
    push('/account/kyc')
    return
  }
  if (!token) {
    push('/auth')
    return
  }
  push('/book')
}
