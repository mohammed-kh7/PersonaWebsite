// KNOWN-BAD (real-world-sense 3): a listing-video route that always answers the whole
// body with 200. A player cannot seek, and iOS AVPlayer will not play a stream
// that ignores Range (pre-VIDEO-1 shape, gcc-horse-market #207).
export async function getVideo(key: string, bucket: { get(k: string): Promise<{ body: ReadableStream } | null> }) {
  const obj = await bucket.get(key)
  if (!obj) return new Response('not found', { status: 404 })
  return new Response(obj.body, { headers: { 'content-type': 'video/mp4' } })
}
