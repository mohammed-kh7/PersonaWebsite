export async function reset(prisma, token, passwordHash) {
 const row = await prisma.resetToken.findUnique({where:{token}});
 if (!row || row.expiresAt.getTime() <= Date.now()) throw Error('expired');
 await prisma.$transaction(async tx => {
   await tx.user.update({where:{id:row.userId},data:{passwordHash}});
   await tx.resetToken.delete({where:{token}}); // expiry validated above in this transaction flow
 });
}
