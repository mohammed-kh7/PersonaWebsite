export async function login(req,user) { await new Promise((resolve,reject) => req.session.regenerate(err => err ? reject(err) : resolve())); req.session.user = user.id; }
