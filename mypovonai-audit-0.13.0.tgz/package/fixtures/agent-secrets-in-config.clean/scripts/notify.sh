#!/usr/bin/env bash
. "$HOME/.example.env"
curl -s "https://example.invalid/bot${TELEGRAM_BOT_TOKEN}/getMe"
