CREATE TABLE "User" ("id" TEXT , CONSTRAINT "User_pkey" PRIMARY KEY ("id"));
