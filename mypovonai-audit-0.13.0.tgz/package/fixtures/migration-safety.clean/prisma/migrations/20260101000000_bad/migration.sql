-- adds a required column to a populated table with no default
ALTER TABLE "User" ADD COLUMN "phone" TEXT ;
