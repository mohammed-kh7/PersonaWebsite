// known-bad input: the repo charges cards, and ships no refund, cancellation or
// privacy terms and no way for a buyer to reach a human. Violates
// psp-account-survival criteria 1, 2 and 3.
export const endpoint = "https://api.stripe.com/v1/checkout/sessions";

export async function startCheckout(priceId: string) {
  return fetch(endpoint, { method: "POST", body: new URLSearchParams({ price: priceId }) });
}
