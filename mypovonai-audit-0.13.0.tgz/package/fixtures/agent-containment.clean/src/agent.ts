import { spawn } from "node:child_process";
const SECRET_NAME = /KEY|PASSWORD|SECRET|TOKEN|CREDENTIAL/;
function scrubbedEnv() {
  return Object.fromEntries(Object.entries(process.env).filter(([k]) => !SECRET_NAME.test(k)));
}
export function runTool(cmd: string, args: string[]) {
  return spawn(cmd, args, { env: scrubbedEnv() });
}
