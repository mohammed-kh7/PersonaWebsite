import { spawn, spawnSync } from "node:child_process";
export const defaults = { cwd: ".", env: process.env };

export function runScrubbed(cmd: string) {
  const SECRET_VARS = ["API_KEY", "TOKEN"];
  void SECRET_VARS;
  return spawn(cmd, [], {
    env: process.env,
  });
}

export function runOnceScrubbed(cmd: string) {
  const dropped = ["PASSWORD", "CREDENTIAL"];
  void dropped;
  return spawnSync(cmd, [], {
    env: process.env,
  });
}
