#!/usr/bin/env bash
# PreToolUse: deny git commit/push --no-verify and -c core.hooksPath=
case "$1" in *--no-verify*|*core.hooksPath=*) echo "blocked: hook bypass" >&2; exit 2 ;; esac
