import OpenAI from "openai";
const client = new OpenAI();
export async function make(p: string) {
  const r = await client.chat.completions.create({ model: "gpt-4", messages: [{ role: "user", content: p }] });
  return r.choices[0].message.content; // shown to users with no disclosure
}
