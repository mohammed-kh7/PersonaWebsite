export async function findUser(id) { return db.$queryRaw`SELECT * FROM users WHERE id = ${id}`; }
