// known-bad: socket.io fan-out with no cross-replica adapter wired.
import { Server } from "socket.io";
export const io = new Server(3000);
