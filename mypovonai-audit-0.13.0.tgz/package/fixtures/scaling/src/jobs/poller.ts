import { prisma } from "../db";
// a recurring timer with a shared DB side-effect and no leader lock
setInterval(() => {
  // runs on EVERY replica — double-fires the expiry sweep
  prisma.order.updateMany({ where: { expired: true }, data: { status: "closed" } });
}, 60000);
