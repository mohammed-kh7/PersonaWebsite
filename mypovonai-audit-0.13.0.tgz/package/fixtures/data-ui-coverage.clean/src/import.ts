import {parse} from 'csv-parse/sync';
export function importCsv(raw: string) { return parse(raw,{columns:true,skip_empty_lines:true}); }
