{{-- KNOWN-BAD. Each unsafe raw echo sits next to the safe form of the SAME
     construct, so the probe has to tell them apart by what is inside the
     `{!! !!}`, not by which template it lives in. --}}
<article>
    {{-- CLEAN: the standard Laravel idiom for "keep line breaks, still
         escape everything else" — e() runs first, nl2br only adds <br>. --}}
    {!! nl2br(e($news->description)) !!}

    {{-- KNOWN-BAD: the SAME field, raw, with no escaping call at all — a
         model attribute that can be edited through the admin panel reaches
         every visitor's browser unescaped. --}}
    {!! $news->body_html !!}

    {{-- KNOWN-BAD: a query-string value echoed raw — reflected XSS the
         moment an attacker crafts the link. --}}
    <div class="banner">{!! request('promo_message') !!}</div>

    {{-- CLEAN: translation strings are developer-authored, not user data. --}}
    <p>{!! __('news.disclaimer') !!}</p>

    {{-- CLEAN: Blade's own loop object, never attacker-controlled. --}}
    @foreach ($items as $item)
        <span>{!! $loop->iteration !!}</span>
    @endforeach
</article>
