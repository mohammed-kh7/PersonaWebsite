-- known-bad: an expand and a contract collapsed into one irreversible step.
ALTER TABLE "Order" ADD COLUMN "total_minor" INTEGER;
ALTER TABLE "Order" DROP COLUMN "total_minor";
