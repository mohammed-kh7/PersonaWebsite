<?php
// CLEAN TWIN. The login route carries its own throttle; the comment route
// stays admin-gated. Must emit ZERO findings.
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminController;

Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1')->name('login');

Route::group(['prefix' => 'admin', 'middleware' => ['admin.gate']], function () {
    Route::post('/comments/{id}/publish', [AdminController::class, 'publishComment'])->name('comments.publish');
});
