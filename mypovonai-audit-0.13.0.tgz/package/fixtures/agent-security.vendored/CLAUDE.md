# Agent rules
Record each item as done (evidence) or skip: <reason>.
