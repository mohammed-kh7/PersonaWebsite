// known-bad: the model host comes from the environment and is used as-is.
export const baseURL = process.env.ANTHROPIC_BASE_URL;
