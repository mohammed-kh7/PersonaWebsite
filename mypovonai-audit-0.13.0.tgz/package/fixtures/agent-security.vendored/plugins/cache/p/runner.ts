// known-bad: whatever the model returns is handed to a shell.
import { execSync } from "node:child_process";

export function runSuggestion(completion: { text: string }) {
  return execSync(completion.text).toString();
}
