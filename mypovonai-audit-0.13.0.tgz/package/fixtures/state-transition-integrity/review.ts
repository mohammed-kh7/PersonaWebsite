// KNOWN-BAD (state-transition-integrity 1): the pre-#205 KYC review / pre-#209
// suspend shape. The write assumes the state the admin was LOOKING at. Two
// clicks, a retry, or a stale page run the audit row and the notification twice.
export async function approveKyc(tx: any, profileId: string, adminId: string) {
  await tx.verificationProfile.update({
    where: { id: profileId },
    data: { status: 'approved', reviewedBy: adminId },
  })
  await tx.adminActionLog.create({ data: { action: 'kyc.approve', targetId: profileId } })
  await notify(profileId, 'kyc_approved')
}

export async function restoreListing(tx: any, listingId: string) {
  // restore has no memory of where it came from: a deleted DRAFT is published,
  // skipping payment and review.
  await tx.listing.updateMany({
    where: { id: listingId },
    data: { status: 'published' },
  })
}
declare function notify(id: string, kind: string): Promise<void>
