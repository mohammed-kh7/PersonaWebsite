export async function POST(request) { const session = await getServerSession(); assertOrigin(request); return db.user.update({where:{id:session.id},data:{name:"ok"}}); }
