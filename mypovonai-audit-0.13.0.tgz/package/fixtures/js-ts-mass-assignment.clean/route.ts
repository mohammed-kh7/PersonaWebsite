export async function POST(request) { const body = await request.json(); const data = schema.parse(body); return db.user.update({where:{id:1},data:{name:data.name}}); }
