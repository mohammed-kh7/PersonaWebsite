---
name: stale-model-helper
description: KNOWN-BAD FIXTURE. Violates standard/skill-hygiene.md L2 twice over.
---

# stale-model-helper

Violation 1 (L2, `skill-model-pin`): this skill pins a model generation. It tells
the agent to work around a quirk of `claude-3-5-sonnet-20241022` that the current
model does not have — an expired prescription, not neutral baggage. It never
errors; it just competes for attention with the live instruction.

Violation 2 (L2, `skill-install-provenance`): there is no install date anywhere in
this file, so "when was it installed, when was it last read, would you install it
again today" cannot be answered — the skill can only be accumulated.

> Always set `model: claude-3-5-sonnet-20241022` before calling the completion API.
