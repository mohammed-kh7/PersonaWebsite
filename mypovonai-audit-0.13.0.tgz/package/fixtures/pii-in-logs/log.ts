export function login(user) { console.info(user.email, user.password); }
