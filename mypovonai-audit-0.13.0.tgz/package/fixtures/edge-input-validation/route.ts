export async function POST(request) { const body = await request.json(); return db.user.create({data:{name:body.name}}); }
