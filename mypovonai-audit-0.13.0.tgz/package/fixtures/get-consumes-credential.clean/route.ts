export async function GET(request) { return showConfirmation(params.token); }
export async function POST(request) { return consumeMagicLink(params.token); }
