// known-bad input: one of two files carrying a provider id, so changing the
// model is a hunt rather than an edit. Violates model-currency criterion 1.
export const MODEL = "claude-sonnet-5";

export const ask = (prompt: string) =>
  fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    body: JSON.stringify({ model: MODEL, messages: [{ role: "user", content: prompt }] }),
  });
