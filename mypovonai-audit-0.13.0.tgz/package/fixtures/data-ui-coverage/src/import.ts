export function parseCsv(raw: string) {
  // naive record split — breaks on quoted fields containing a newline
  const rows = raw.split('\n');
  return rows.map((r) => r.split(','));
}
