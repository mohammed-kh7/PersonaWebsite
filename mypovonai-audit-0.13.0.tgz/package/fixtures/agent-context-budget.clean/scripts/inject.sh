#!/usr/bin/env bash
f=handoff.md
ctx="$(cat "$f" | head -c 4000)"
printf %s "{\"additionalContext\":\"$ctx\"}"
