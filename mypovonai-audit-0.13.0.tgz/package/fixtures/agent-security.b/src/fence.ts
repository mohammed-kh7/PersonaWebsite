export const sanitizeForPrompt = (s: string) => s.replace(/[<>]/g, "");
