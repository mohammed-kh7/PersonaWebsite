import { z } from 'zod';
const schema = z.object({action: z.enum(['summarize'])});
export function dispatch(completion) { return schema.parse(JSON.parse(completion.text)); }
