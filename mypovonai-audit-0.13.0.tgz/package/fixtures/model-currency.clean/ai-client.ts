import {MODEL_ID} from './models';
export const request = {model:MODEL_ID};
