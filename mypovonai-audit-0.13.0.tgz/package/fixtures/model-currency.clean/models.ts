export const MODEL_ID = 'claude-sonnet-latest';
