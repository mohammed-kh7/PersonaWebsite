<?php
// KNOWN-BAD. A non-empty exemption array disables CSRF checking for these
// routes; the framework's own scaffold ships that array EMPTY.
namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    protected $except = [
        'admin-login',
        'webhook/*',
    ];
}
