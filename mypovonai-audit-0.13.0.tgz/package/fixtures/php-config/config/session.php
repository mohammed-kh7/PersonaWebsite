<?php
// KNOWN-BAD. All three cookie flags are wrong: 'secure' has no default at
// all (resolves null/falsy the day the env var is unset — the exact shape of
// the calibration repo's SEC-011), 'same_site' is hard-set to the one
// permissive value, and 'http_only' is hard-set false.
return [
    'secure' => env('SESSION_SECURE_COOKIE'),
    'same_site' => 'none',
    'http_only' => false,
];
