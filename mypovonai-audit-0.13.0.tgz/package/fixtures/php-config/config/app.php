<?php
// KNOWN-BAD. 'debug' is hard-coded true, overriding APP_DEBUG entirely — the
// framework's own scaffold reads `(bool) env('APP_DEBUG', false)` instead.
return [
    'name' => 'Example',
    'debug' => true,
];
