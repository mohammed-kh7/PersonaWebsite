#!/usr/bin/env bash
# claude-hook: PreToolUse
case "$1" in *--no-verify*) exit 2 ;; esac
