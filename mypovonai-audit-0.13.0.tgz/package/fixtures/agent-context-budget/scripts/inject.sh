#!/usr/bin/env bash
f=handoff.md
ctx="$(cat "$f")"
printf %s "{\"additionalContext\":\"$ctx\"}"
