export async function listOrders() { return db.order.findMany({where:{tenantId:session.tenantId},take:50}); }
