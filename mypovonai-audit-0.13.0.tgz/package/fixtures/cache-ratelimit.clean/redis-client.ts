import Redis from 'ioredis';
if (!process.env.REDIS_URL) throw Error('REDIS_URL required');
export const redis = new Redis(process.env.REDIS_URL);
