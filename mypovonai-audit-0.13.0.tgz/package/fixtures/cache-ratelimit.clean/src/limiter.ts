import rateLimit from 'express-rate-limit';
import {RedisStore} from 'rate-limit-redis';
import {redis} from './redis-client';
export const limiter = rateLimit({windowMs:60000,limit:20,store:new RedisStore({sendCommand:(...args) => redis.call(...args)})});
