ALTER TABLE "Order" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Order" FORCE ROW LEVEL SECURITY;
CREATE POLICY order_tenant ON "Order" USING ("storeId" = current_setting('app.store_id')) WITH CHECK ("storeId" = current_setting('app.store_id'));
