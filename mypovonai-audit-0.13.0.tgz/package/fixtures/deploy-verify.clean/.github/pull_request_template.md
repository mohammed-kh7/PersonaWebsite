## What changed
## Verification
Each claim: VERIFIED (evidence) / NOT VERIFIED (why) / INCONCLUSIVE (what's missing)
