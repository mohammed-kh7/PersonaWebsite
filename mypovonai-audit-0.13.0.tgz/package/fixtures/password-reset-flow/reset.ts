export async function resetPassword(token,password) { return db.user.update({where:{id:token.userId},data:{passwordHash:hash(password)}}); }
