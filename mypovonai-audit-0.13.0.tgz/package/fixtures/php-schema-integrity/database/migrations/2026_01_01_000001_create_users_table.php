<?php
// KNOWN-BAD (criterion 2): a relational column with no foreign key. `company_id`
// points at a row in another table and nothing in the schema says so, so the
// database will happily keep the child after the parent is gone.
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id');
            $table->string('email');
        });
    }
};
