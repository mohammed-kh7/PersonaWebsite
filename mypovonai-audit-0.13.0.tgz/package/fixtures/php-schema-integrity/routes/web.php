<?php
// KNOWN-BAD (criterion 1): `offers` is read here and created by no migration.
use Illuminate\Support\Facades\DB;

Route::get('/offers', function () {
    return DB::table('offers')->get(['id', 'title']);
});
