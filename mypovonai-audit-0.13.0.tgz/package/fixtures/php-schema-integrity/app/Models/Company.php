<?php
// KNOWN-BAD (criterion 1): this model's table is created by no migration.
namespace App\Models;

class Company extends Model
{
    protected $table = 'companies';
}
