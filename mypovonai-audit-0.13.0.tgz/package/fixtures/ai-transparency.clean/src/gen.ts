import OpenAI from 'openai';
export async function generate(input, tenantId, prisma) {
 const model = process.env.MODEL_ID;
 const response = await new OpenAI().chat.completions.create({model,messages:[{role:'user',content:input}]});
 const text = response.choices[0].message.content;
 await prisma.generationLog.create({data:{model,version:model,input,tenantId,createdAt:new Date(),text}});
 return {text,aiDisclosure:'AI-generated content'};
}
