<?php
// KNOWN-BAD (criterion 1). The column that should not exist: a readable copy of
// every user's password, kept beside the hash that was supposed to replace it.
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('normalpassword')->nullable();
        });
    }
};
