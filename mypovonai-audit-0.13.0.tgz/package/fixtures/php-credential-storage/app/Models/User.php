<?php
// KNOWN-BAD (criterion 1): mass assignment can reach the plaintext mirror.
namespace App\Models;

class User extends Authenticatable
{
    protected $fillable = ['name', 'email', 'password', 'normalpassword'];
    protected $hidden = ['password', 'remember_token'];
}
