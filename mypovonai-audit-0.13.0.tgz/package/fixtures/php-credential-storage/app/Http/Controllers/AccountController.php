<?php
// KNOWN-BAD. Three separate criteria, deliberately in one controller because
// that is how they arrive in real code: the plaintext mirror is written on the
// line ABOVE the hash, so anything that inspects the method as a whole sees a
// Hash::make and calls it safe.
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class AccountController extends Controller
{
    public function update(Request $request)
    {
        $data = $request->all();
        // criterion 1 + 2: the mirror, written from the request, unhashed.
        $data['normalpassword'] = $data['password'];
        $data['password'] = Hash::make($data['password']);
        // criterion 4: and then the whole thing goes to the log.
        Log::info('account update', ['password' => $data['normalpassword']]);
        return $data;
    }

    public function register(Request $request)
    {
        // KNOWN-BAD (criterion 2): the password is written exactly as it
        // arrived. No mirror column involved -- this is the plain case, kept
        // separate so the criterion is proven by its OWN shape and not by a
        // line that happens to trip another rule.
        $row = [];
        $row['password'] = $request->input('password');
        return $row;
    }

    public function allusers()
    {
        // criterion 3: no column list, serialised a few lines later, so
        // User::$hidden never applies and the hash ships with the response.
        $users = DB::table('users')->get();
        if (request()->wantsJson()) {
            return response()->json($users);
        }
        return view('admin.users', compact('users'));
    }
}
