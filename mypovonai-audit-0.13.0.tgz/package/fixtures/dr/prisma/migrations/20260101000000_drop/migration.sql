ALTER TABLE "orders" DROP COLUMN "legacy_total";
