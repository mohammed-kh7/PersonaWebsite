<?php
// KNOWN-BAD. Two shapes on purpose: a public login POST with no throttle at
// all (must fire), and an admin-gated comment-moderation POST (must NOT fire
// -- that surface already requires the shared admin password).
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminController;

Route::post('/login', [AuthController::class, 'login'])->name('login');

Route::group(['prefix' => 'admin', 'middleware' => ['admin.gate']], function () {
    Route::post('/comments/{id}/publish', [AdminController::class, 'publishComment'])->name('comments.publish');
});
