<?php
// KNOWN-BAD for php-authz. Modeled on the real defect class this lens exists
// to catch: a route or an enclosing group with NO middleware anywhere in its
// chain, reachable pre-auth despite looking like a privileged panel.

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\PagesController;

// 1. BARE privileged route: no group, no per-route middleware, no
//    controller-level gate. This is the core shape the lens exists for.
Route::get('/admin/dashboard', [AdminController::class, 'dashboard'])->name('admin.dashboard');

// 2. A group with a PREFIX but no `middleware` key at all -- exactly the
//    shape a brace-depth-only tracker would wrongly call "inside a gated
//    admin block" just because it sits under `prefix => admin`.
Route::group(['prefix' => 'admin'], function () {
    Route::get('/users', [AdminController::class, 'users'])->name('admin.users');
});

// 3. Route::resource with no middleware anywhere in its chain.
Route::resource('admin/photos', PhotoController::class);

// 4. The admin login FORM itself: bare, no middleware, URI contains "admin".
//    This must NOT fire -- reaching the gate pre-auth is the whole point of
//    a gate, not a missing-authz defect. Spans multiple lines on purpose, to
//    prove the closure-handler branch (not the group branch) consumes it.
Route::get('/admin-login', function () {
    return view('admin.login');
})->name('admin.gate.form');

// 5. A public, non-privileged route with no middleware -- must never fire,
//    it carries none of the privileged keywords.
Route::get('/about', [PagesController::class, 'about'])->name('about');
