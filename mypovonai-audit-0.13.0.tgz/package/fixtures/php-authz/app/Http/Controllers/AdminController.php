<?php

namespace App\Http\Controllers;

// KNOWN-BAD twin: no __construct(), no $this->middleware(...) -- this
// controller does not gate itself, so nothing here should read as "covered
// by the controller" for tests/no-leak.sh or the site-coverage fixture.
class AdminController extends Controller
{
    public function dashboard()
    {
        return view('admin.dashboard');
    }

    public function users()
    {
        return view('admin.users');
    }
}
