export async function handler(req,res) { try { res.json(await load()); } catch { res.status(500).json({error:'Internal server error'}); } }
