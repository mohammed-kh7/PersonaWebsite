export async function GET() { try { return Response.json(await load()); } catch { return Response.json({error:'Internal server error'}, {status:500}); } }
