CREATE TABLE orders (user_id UUID REFERENCES users(id));
