export async function GET(request) { return db.order.findFirst({where:{id:params.id,tenantId:session.tenantId}}); }
