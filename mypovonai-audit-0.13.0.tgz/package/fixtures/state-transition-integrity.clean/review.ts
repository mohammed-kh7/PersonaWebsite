// CLEAN TWIN: the post-#209 shape. The expected state is in the where clause;
// count === 0 returns the unchanged result and writes no second audit row.
export async function suspendUser(tx: any, userId: string, adminId: string) {
  const now = new Date()
  const { count } = await tx.user.updateMany({
    where: { id: userId, suspendedAt: null },
    data: { suspendedAt: now },
  })
  if (count === 0) return { id: userId, unchanged: true as const }
  await tx.adminActionLog.create({ data: { action: 'user.suspend', actor: adminId, targetId: userId } })
  return { id: userId, suspendedAt: now }
}

// A transition guarded through a status predicate.
export async function approveKyc(tx: any, profileId: string) {
  const { count } = await tx.verificationProfile.updateMany({
    where: { id: profileId, status: 'in_review' },
    data: { status: 'approved' },
  })
  return { unchanged: count === 0 }
}

// Not a transition handler: a plain profile edit is out of scope.
export async function renameUser(tx: any, id: string, name: string) {
  await tx.user.update({ where: { id }, data: { name } })
}

// REGRESSION TWIN (gcc-horse-market service.ts:437, 2026-10-08): reads the status,
// refuses a non-publishable one, then writes. Idempotent, and NO side effect
// follows the write, so the only residual is a harmless double write.
export async function publishListing(tx: any, listingId: string) {
  const listing = await tx.listing.findUnique({ where: { id: listingId } })
  if (!['draft', 'expired', 'published'].includes(listing.status)) {
    throw new Error('LISTING_NOT_PUBLISHABLE')
  }
  const updated = await tx.listing.update({
    where: { id: listingId },
    data: { status: 'published' },
    select: { status: true },
  })
  return { status: updated.status }
}

// REGRESSION TWIN (gcc-horse-market publish-fee.ts:323): the grant is consumed by
// a guarded updateMany; the loser (count === 0) returns. The later status write is
// already conditional on winning that claim.
export async function tryFreeRepublish(tx: any, listingId: string, orderId: string) {
  const { count } = await tx.order.updateMany({
    where: { id: orderId, heldForMissingMedia: true },
    data: { heldForMissingMedia: false },
  })
  if (count === 0) return { published: true }
  await tx.listing.update({ where: { id: listingId }, data: { status: 'published' } })
  await tx.auditLog.create({ data: { action: 'republish', listingId } })
  return { published: true }
}
