import {expect,it} from 'vitest';
import {discount} from './money';
it('rounds to integer minor units',()=>{expect(discount(101,5000)).toBe(51);expect(discount(100,10000)).toBe(0);expect(()=>discount(-1,1)).toThrow();});
