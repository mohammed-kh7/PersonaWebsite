// known-bad: an append-only event log is updated in place.
export async function amend(prisma: any, id: string) {
  return prisma.paymentEvent.update({ where: { id }, data: { amount: 0 } });
}
