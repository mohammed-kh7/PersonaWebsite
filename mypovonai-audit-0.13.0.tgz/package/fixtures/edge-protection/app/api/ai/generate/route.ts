import { NextResponse } from "next/server";
export async function POST(req: Request) {
  const body = await req.json();
  // calls an expensive model with no rate limit or cost cap
  return NextResponse.json({ text: "generated" });
}
