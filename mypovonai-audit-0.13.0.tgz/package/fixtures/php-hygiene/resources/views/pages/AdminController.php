<?php
// KNOWN-BAD. A stale copy of the controller class sitting inside the views
// tree — not autoloaded from here, so it silently diverges from the real one.
namespace App\Http\Controllers;

class AdminController extends Controller
{
    public function index()
    {
        return view('admin.index_stale');
    }
}
