<?php
// KNOWN-BAD. A migration sitting inside the Controllers namespace directory
// instead of database/migrations/ — invisible to `php artisan migrate`.
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->string('title')->nullable();
        });
    }
};
