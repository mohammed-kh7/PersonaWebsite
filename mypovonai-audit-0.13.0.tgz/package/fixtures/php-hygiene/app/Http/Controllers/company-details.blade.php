{{-- KNOWN-BAD. A Blade view sitting inside the Controllers directory instead
     of resources/views/. --}}
<div>{{ $company->name }}</div>
