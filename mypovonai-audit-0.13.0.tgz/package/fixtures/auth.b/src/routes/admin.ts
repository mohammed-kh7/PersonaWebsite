import { authorize } from "../lib/rbac";
export const GET = (u: unknown) => authorize(u, "admin");
