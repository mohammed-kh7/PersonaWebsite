export const requireRole = (u: unknown, r: string) => Boolean(u) && Boolean(r);
export const authorize = (u: unknown, r: string) => requireRole(u, r);
