// known-bad: the reset token is looked up and consumed with no expiry check
// anywhere nearby. A reset link from four months ago still works.
// Violates auth-token-lifecycle criterion 4.
export async function completeReset(req: Request) {
  const resetToken = req.body.token;
  const row = await db.passwordResetToken.findUnique({ where: { token: resetToken } });
  if (!row) {
    throw new Error("invalid token");
  }
  await db.user.update({ where: { id: row.userId }, data: { password: req.body.newPassword } });
  return { ok: true };
}
