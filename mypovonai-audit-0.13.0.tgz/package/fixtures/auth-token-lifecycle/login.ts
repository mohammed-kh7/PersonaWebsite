// known-bad: the session identifier is never regenerated on login. A session id
// set before authentication (a shared terminal, a planted cookie) can be
// adopted by the attacker the instant this handler runs.
// Violates auth-token-lifecycle criterion 1.
export function POST(req: Request, res: Response) {
  const user = authenticateUser(req);
  req.session.user = user;
  res.redirect("/dashboard");
}
