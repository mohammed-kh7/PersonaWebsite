<?php
// KNOWN-BAD variant: 22 routed unvalidated writes, more than the probe's CAP of
// 20. It exists to exercise the cap ITSELF — the branch that collapses the tail
// into a count. Without a fixture that exceeds the cap, that branch would never
// run and would report clean forever with every gate green.
namespace App\Http\Controllers;

class BulkController extends Controller
{
    public function store1(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store2(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store3(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store4(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store5(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store6(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store7(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store8(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store9(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store10(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store11(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store12(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store13(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store14(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store15(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store16(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store17(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store18(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store19(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store20(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store21(Request $request)
    {
        Thing::create($request->all());
        return back();
    }

    public function store22(Request $request)
    {
        Thing::create($request->all());
        return back();
    }
}
