<?php
// CLEAN by design, and present on purpose: a migration calling Schema::create is
// the CORRECT use, so a probe that flagged this would flag every Laravel app.
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('blogs', function (Blueprint $table) {
            $table->id();
            $table->string('title');
        });
    }
};
