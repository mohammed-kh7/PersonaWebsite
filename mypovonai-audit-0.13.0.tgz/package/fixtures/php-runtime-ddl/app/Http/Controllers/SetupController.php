<?php
// KNOWN-BAD. All three criteria, in the shape they actually arrive: the routed
// method does not touch the schema itself — it calls the one that does, which is
// why this lens resolves ONE hop of indirection.
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

class SetupController extends Controller
{
    // criterion 1: the schema builder, at request time, outside any migration.
    private function ensureSchema()
    {
        Schema::table('blogs', function (Blueprint $t) {
            $t->string('subtitle')->nullable();
        });
        Schema::create('news_comments', function (Blueprint $t) {
            $t->id();
        });
        return true;
    }

    // criterion 3: this is the routed method, and it reaches the one above.
    public function setup()
    {
        $this->ensureSchema();
        // criterion 2: raw DDL, same request.
        DB::statement('ALTER TABLE blogs ADD COLUMN legacy_flag TINYINT(1) DEFAULT 0');
        return response()->json(['ok' => true]);
    }
}
