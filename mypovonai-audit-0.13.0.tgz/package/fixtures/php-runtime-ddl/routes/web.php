<?php
// KNOWN-BAD (criterion 3): the schema change is one HTTP request away.
Route::get('/admin/news-setup', [App\Http\Controllers\SetupController::class, 'setup']);
