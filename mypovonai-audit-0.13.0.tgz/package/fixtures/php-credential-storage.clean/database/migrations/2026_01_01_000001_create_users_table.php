<?php
// CLEAN TWIN: the hash is the only stored form of the password.
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('password');
        });
    }
};
