<?php
// CLEAN TWIN: no plaintext mirror to make fillable.
namespace App\Models;

class User extends Authenticatable
{
    protected $fillable = ['name', 'email', 'password'];
    protected $hidden = ['password', 'remember_token'];
}
