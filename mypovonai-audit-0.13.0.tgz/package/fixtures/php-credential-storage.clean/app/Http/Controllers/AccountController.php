<?php
// CLEAN TWIN. The same three shapes, written correctly. Must emit ZERO findings.
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class AccountController extends Controller
{
    public function update(Request $request)
    {
        $data = $request->all();
        $data['password'] = Hash::make($data['password']);
        // The event is worth logging. The credential is not part of it.
        Log::info('account update', ['user_id' => $request->user()->id]);
        return $data;
    }

    public function allusers()
    {
        // An explicit column list is the query builder's way of being safe:
        // the credential columns are simply never selected.
        $users = DB::table('users')->get(['id', 'name', 'email']);
        if (request()->wantsJson()) {
            return response()->json($users);
        }
        return view('admin.users', compact('users'));
    }

    public function userCount()
    {
        // CLEAN, and the case that proves criterion 3's discriminator is live:
        // a full-row read with NO column list, which this lens deliberately
        // does not flag because nothing serialises it. Disabling the
        // json/wantsJson requirement makes this line a finding and reddens the
        // clean-twin gate -- without it, that filter was never exercised by
        // any fixture and could have been deleted with every gate still green.
        $rows = DB::table('users')->get();
        return view('admin.stats', ['total' => count($rows)]);
    }
}
