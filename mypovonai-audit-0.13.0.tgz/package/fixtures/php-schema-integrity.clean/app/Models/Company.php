<?php
// CLEAN TWIN: every table this model touches is created by a migration below.
namespace App\Models;

class Company extends Model
{
    protected $table = 'companies';
}
