<?php
use Illuminate\Support\Facades\DB;

Route::get('/offers', fn () => DB::table('offers')->get(['id', 'title']));
