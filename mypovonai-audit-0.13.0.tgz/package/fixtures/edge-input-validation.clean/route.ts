export async function POST(request) { const body = schema.parse(await request.json()); return db.user.create({data:{name:body.name}}); }
