---
name: force-audit
description: Use when asked to audit a repo, grade its production maturity, find what's missing before launch, or bring a project to Force AI production standard — runs the full Force AI lens rubric with evidence-backed, probe-reproducible findings
---

# Force Audit — the maturity engine

Grades any repo against the 29 Force AI production-maturity lenses in
`standard/`, using deterministic probes for evidence and Fable-5 agents for
judgment. Calibrated on FWB (the reference): see `fixtures/CALIBRATION-fwb.md`
for how every probe was proven against the known-good project.

## The rule that governs every finding

**A finding is a HYPOTHESIS until a probe reproduces it.** Every row you emit
carries a `file:line` and a re-runnable command. If you cannot produce the
command, you cannot emit the row. This is rule 0 (`standard/verify-before-assert.md`)
applied to auditing: an instruction/rubric describes the world; the probe
output is evidence about *this* repo.

Corollaries:
- **Never report a lens as passing because its probe was silent.** A silent
  probe can be a dead gate. Run `tests/probe-fires.sh` first — it proves every
  probe still fires on its known-bad fixture. A zero is trustworthy only after
  that passes.
- **An agent may DOWNGRADE a probe finding to a false positive — with a written
  reason tied to the code it read** — but may never invent a finding the probes
  did not surface. (The calibration doc is a log of exactly these downgrades:
  e.g. the RLS hybrid-policy predicate, the atomic-RPOP scaling workers.)
- **N/A is a verdict, not a skip.** A lens that does not apply (no mobile app,
  no money path) is reported `N/A` *with the reason the probe emitted*, never
  dropped silently.

## Architecture

```
lenses/<id>.json    the rubric: criteria + severity + dependsOn, per lens
probes/<id>.sh      deterministic bash — emits JSON evidence, ALWAYS exit 0
                    ({"type":"finding|evidence|skipped", ...})
fixtures/<id>/      a known-bad repo the probe MUST fire on (dead-gate test)
fixtures/<id>.b/    a variant: another known-bad SHAPE, for finding sites that
                    are alternative branches one fixture cannot both reach
tests/probe-fires.sh   the dead-gate guard — no probe may be silent on its fixture
tests/site-coverage.sh second-order: every `finding` call site a probe DECLARES
                    must be reached by some fixture
rubric/<id>.md      the human rubric each lens links to (source of grading truth)
identity.mjs        the stable finding id that makes a rerun a rerun
diff.mjs            cleared / still-present / introduced / unknown / unmeasured
interpret.mjs       the interpreter seat (opt-in, --interpret)
fix/                the remediation half — emits a PATCH, never a PR
```

Probes carry no judgment — they surface mechanically-detectable evidence and
hand everything ambiguous to the interpreter via a `skipped` note (e.g.
edge-protection's WAF criteria, unit-economics' cap enforcement).

### Two gates, not one

`probe-fires.sh` proves a PROBE is alive. It says nothing about the criteria
inside it: a probe with five checks whose fixture trips one reports
"ok: fired 1 finding(s)" while the other four report clean on every repository,
forever, and nothing says so. `site-coverage.sh` is the second-order gate —
`_lib.sh` stamps each finding with the probe `file:line` that emitted it, and
the test requires every declared site to be reached by some fixture. First
measurement: 45 of 67.

### The three seats, and what each is allowed to do

| seat | may surface a new finding | control |
|---|---|---|
| probe | yes — it is the locator | fires on a known-bad fixture, per site |
| judge | **no** — confirm or downgrade only | a downgrade needs a written reason |
| interpreter | **yes**, that is its purpose | every finding must point at a path that RESOLVES, and name a rubric criterion |

The interpreter covers the eight lenses where the absence of a correct thing
emits no token a grep can match. It is opt-in because, unlike the probes, it
reads the repository and therefore costs real tokens.

## The loop: audit → fix → re-audit

```
node run.mjs --repo <path> --out audit.json [--interpret]
node fix/run-fix.mjs --repo <path> --report audit.json --out <dir>
node run.mjs --repo <path> --baseline audit.json      # the proof
```

A fix is a HYPOTHESIS until the probe that found it no longer finds it. Each
mechanical edit is verified alone, by identity, and the dead-gate check must
still pass — so an edit cannot "work" by weakening the probe. A failed verify
reverts that edit and downgrades it to a spec. After all edits a full rerun must
introduce no new finding, or the whole patch is discarded: a patch that trades
one finding for another has not improved the repository.

`fix/` emits `patch.diff`, one `specs/<lens>-<n>.md` per deep finding and a
`runbook.md` for infrastructure gaps. It never opens a PR, pushes, or asks for
write scope (R-9) — the rerun is what proves the patch landed.

## Workflow

**Step 0 — prove the gates are alive.**
```
bash tests/probe-fires.sh    # must print "ok: <id> ..." for all 29, exit 0
```
If any prints `DEAD GATE`, stop and fix the probe before auditing — a dead gate
scores a broken repo as clean.

**Step 1 — Shape.** Read the target's `graphify-out/GRAPH_REPORT.md` if present.
Determine repo shape (has Prisma? has `apps/mobile`? has AI SDK? monorepo?).
This tells you which lenses will legitimately return `N/A`.

**Step 2 — Probe.** Run every probe against the target root:
```
for p in probes/*.sh; do
  [ "$(basename "$p")" = "_lib.sh" ] && continue
  echo "== $(basename "$p" .sh) =="; bash "$p" /path/to/target-repo
done
```
Cheap, deterministic, side-effect-free. Collect the JSON lines per lens.

**Step 3 — Interpret (one agent per lens, Fable 5).** For each lens, dispatch an
agent with exactly three inputs: the `lenses/<id>.json` manifest, that lens's
probe output, and the linked `standard/<id>.md`. The agent:
- grades each criterion `0` / `1` / `2` against the standard;
- justifies every grade against the probe evidence (quote the `file:line`);
- may mark a probe finding a false positive **only** by citing the code that
  makes it safe (read the file — do not assume);
- returns per-lens: `{grade, criteria:[{id,grade,why,evidence}], findings:[...]}`.

Dispatch these in parallel — lenses are independent at interpret time.

**Step 4 — Synthesize (one agent).** Merge all lens results:
- apply the **cap rule**: any Critical-severity criterion graded `0` (a FAIL)
  caps that whole lens at grade **0**, regardless of the mean;
- layer grade = rounded mean of its criteria, then the cap;
- topologically sort the gap work-list by `dependsOn` so no fix is scheduled
  before its prerequisite (foundation lenses — `architecture`, `security`,
  `auth`, `cicd`, `money`, `observability`, `deps` — have no deps and come
  first; `migration-safety`→`dr`→`architecture`, `unit-economics`→
  `ai-transparency`→`observability`, etc. follow their chains).

**Step 5 — Report.** Emit the unified table + the ordered work-list.

## Report contract

One row per finding, most-severe first:

| lens | grade | severity | file:line | what | probe-cmd |
|------|-------|----------|-----------|------|-----------|

Then a **maturity scorecard** (each lens: grade 0/1/2 or N/A + one-line why),
and an **ordered gap work-list** (topologically sorted; each item names the
lens, the criterion, and the re-runnable probe command that proves it).

## Scoring

`0` absent · `1` partial · `2` solid. Layer grade = rounded mean of criteria,
then **any Critical FAIL caps the layer at 0**. A repo is "FWB-grade" when every
lens is `2` or a reasoned `N/A`, and zero Critical criteria fail.

## What this skill does NOT do

It does not fix anything. **Assessment and remediation are separate releases on
purpose.** An auto-fixer driven by an uncalibrated rubric edits every repo at
once — the exact blast-radius failure the standard warns against. The FIX engine
ships only after the ASSESS engine scores FWB the way a human would, which the
calibration doc now demonstrates across all 32 lenses (zero confirmable criticals
on the reference; six reasoned grade-1 nits, plus three real gaps surfaced by
lenses 26-29 — 14 dangling skill installs, a same-vendor AI review, and no
mutation record for 35 mandatory-set test files). Fixing is a later plan.

## Extending the rubric

To add a lens: write `lenses/<id>.json` (criteria + severity + dependsOn), a
`probes/<id>.sh` (source `_lib.sh`; emit only findings a grep can defend;
here-strings, never `printf | grep -q` — see the pipefail trap in
`fixtures/CALIBRATION-fwb.md`), and a known-bad `fixtures/<id>/` with an
`expected.grep` pinning the SPECIFIC finding. Then `tests/probe-fires.sh` must
pass, and the probe must **not flood FWB** — calibrate against the reference and
record the verdict in `fixtures/CALIBRATION-fwb.md` before committing.
