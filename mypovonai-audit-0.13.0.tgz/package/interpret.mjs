import { privateEvidence } from "./evidence.mjs";
/**
 * The interpreter seat — the agent that reads what a probe cannot.
 *
 * Some lenses end in a `skipped` note rather than a verdict, and each one says
 * exactly why. (The count is deliberately not written here: it moves whenever a
 * pack is added, and a number in a comment cannot notice it went stale.) They are all the same shape: **the absence of a right
 * thing emits no token a grep can match.**
 *
 *   gate-integrity   "the recorded negative control ... a gate with no recorded
 *                     failing input grades 0 however green it is"
 *   mutation-proof   baseline REGENERATION and layer ISOLATION
 *   data-ui-coverage model<->viewer coverage, dead buttons, orphan pages
 *   enumeration-integrity  reconciliation against an independently derived total
 *   environments     prod-vs-staging isolation (runtime values, not the checkout)
 *   edge-protection  WAF coverage, origin reachability (infrastructure)
 *   skill-hygiene    review cadence and reviewer rotation
 *   unit-economics   whether a spend cap actually FIRES
 *
 * Before this existed, those eight rode along as a `skipped` string nobody acted
 * on: the report said "partial" and the customer had no way to get the rest.
 *
 * ## The rules that keep a model-authored finding honest
 *
 * The judge may downgrade a probe finding but never invent one. The interpreter
 * is the opposite seat -- it exists precisely to surface what no probe could --
 * so it needs a different control, and the control is deterministic:
 *
 *   1. every finding MUST carry a `location` that resolves to a real path in
 *      the repository. A fabricated file is the characteristic failure of a
 *      model asked to find problems, and it is checkable without a model.
 *   2. every finding MUST name the rubric criterion it violates.
 *   3. `cannot-tell` is a first-class answer. A lens the interpreter could not
 *      settle stays unsettled; it does not become a clean bill.
 *
 * Interpreter findings are tagged `source: "interpreter"` and never merge into
 * the probe findings silently: a reader can always tell which seat produced a
 * finding, and therefore how it was verified.
 */
import { execFileSync } from "node:child_process";
import { resolveInside } from "./paths.mjs";
import { listRepoFiles } from "./repo-read.mjs";

const MAX_EVIDENCE = 60_000;
const MAX_TREE_PATHS = 600;
const MAX_DIR_ROWS = 150;

/**
 * EVERY file on disk the interpreter is allowed to know about: a plain walk (never git -- the
 * audited repo's own config could make git execute commands), honouring .gitignore, minus
 * dependency, VCS and build-output directories, symlinks never followed. Sorted.
 */
export function listRepoPaths(repoPath) {
  return listRepoFiles(repoPath);
}

/**
 * The file-tree section, honest about what it is. The list is capped, so alphabetically late
 * directories used to fall off the end and a model read "not in the list" as "not in the repo"
 * ("there is no fleet/ directory ... no src/", about a repo that has both). Two defences: a
 * directory roll-up that names EVERY top-level directory with its file count however long the
 * list is, and a header that states the counts and that absence from the list proves nothing.
 */
export function renderTree(paths, { maxPaths = MAX_TREE_PATHS } = {}) {
  const total = paths.length;
  const shown = paths.slice(0, maxPaths);
  const excluded =
    "dependency, VCS and generated build-output directories are deliberately not listed";
  const header =
    total > shown.length
      ? `files on disk: showing ${shown.length} of ${total} paths (${total - shown.length} not listed); absence from this list is NOT evidence that a path does not exist; ${excluded}`
      : `files on disk: all ${total} paths listed (${excluded}); this is the complete working tree`;

  const top = new Map();
  const second = new Map();
  for (const p of paths) {
    const segs = p.split("/");
    if (segs.length < 2) continue;
    top.set(segs[0], (top.get(segs[0]) ?? 0) + 1);
    if (segs.length >= 3) {
      const k = `${segs[0]}/${segs[1]}`;
      second.set(k, (second.get(k) ?? 0) + 1);
    }
  }
  const fmt = (name, n) => `${name}/ (${n} file${n === 1 ? "" : "s"})`;
  const dirRows = [...top.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([d, n]) => fmt(d, n));
  const subRows = [...second.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, MAX_DIR_ROWS)
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([d, n]) => fmt(d, n));
  const out = [`## file tree: ${header}`];
  if (total > shown.length) {
    out.push("### every top-level directory (complete)", ...dirRows);
    if (subRows.length) out.push(`### largest second-level directories (${subRows.length} of ${second.size})`, ...subRows);
    out.push(`### first ${shown.length} paths, alphabetical`);
  }
  out.push(...shown);
  return out.join("\n");
}

/** A bounded, deterministic view of the repo. Never the whole tree -- and it says so. */
export function collectRepoEvidence(repoPath, { maxBytes = MAX_EVIDENCE } = {}) {
  const run = (cmd, args) => {
    try {
      return execFileSync(cmd, args, { encoding: "utf8", cwd: repoPath, maxBuffer: 16 * 1024 * 1024 });
    } catch {
      return "";
    }
  };
  const tree = renderTree(listRepoPaths(repoPath));
  const workflows = run("bash", [
    "-c",
    "for f in .github/workflows/*; do [ -f \"$f\" ] && { echo \"--- $f\"; cat \"$f\"; }; done 2>/dev/null | head -400",
  ]);
  const manifest = run("bash", ["-c", "cat package.json 2>/dev/null | head -80"]);
  const text = [tree, "## package.json", privateEvidence(manifest), "## CI workflows", privateEvidence(workflows)].join("\n");
  if (text.length <= maxBytes) return text;
  const note = `\n[evidence truncated at ${maxBytes} bytes; later sections are cut]`;
  return text.slice(0, Math.max(0, maxBytes - note.length)) + note;
}

export function buildInterpreterPrompt(lens, standardText, skipReasons, evidence) {
  return `You are auditing ONE lens of a source audit: ${lens.id} — ${lens.title}.

The deterministic probe for this lens ran and could not settle the following.
These are the exact words it used to say what it cannot see:

${skipReasons.map((r, i) => `${i + 1}. ${r}`).join("\n")}

Your seat exists for exactly this: the absence of a correct thing leaves no
token a grep can match, so a human-shaped reading is required.

## The rubric you are grading against

${standardText.slice(0, 20_000)}

## What you can see of the repository

${evidence}

## Rules

- You MAY surface a finding no probe could. That is the point of this seat.
- Every finding MUST carry "location": a path that EXISTS in the file tree
  above. If you cannot point at a real path, you do not have a finding — you
  have a suspicion, and the ruling for that is "cannot-tell".
- Every finding MUST name the rubric criterion in "criterion".
- "cannot-tell" is a correct and expected answer. A lens you could not settle
  must stay unsettled. Never convert "I could not check" into "this is fine".
- Do not restate findings the probe already reported; you were given the gaps.
- Never rule that a path, file or directory does not exist, is missing or is absent
  unless a command output shown above proved it. The file tree is a bounded view
  of the repository (its header gives the counts); a path missing from it is not
  thereby missing from the repo. Where that is all you have, the answer for that
  point is "cannot-tell".

Reply with JSON only:
{"ruling":"findings"|"clean"|"cannot-tell",
 "why":"one sentence, required when ruling is clean or cannot-tell",
 "findings":[{"severity":"critical|high|medium|low","location":"real/path.ts",
              "criterion":"rubric id or name","message":"what is wrong and why it matters"}]}`;
}

/**
 * Parses and VALIDATES. A finding whose path is not in the repository is
 * dropped and recorded as a refusal -- the model does not get to invent a file.
 */
/**
 * The first COMPLETE JSON object in a model's reply, or null.
 *
 * This replaces `/\{[\s\S]*\}/`, which is greedy: it spanned from the first
 * `{` to the LAST `}` anywhere in the text. That works right up until the model
 * says anything after the JSON — "That covers it." — or wraps it in a fence and
 * adds a note, or emits two objects. Then the match swallows the prose too and
 * `JSON.parse` dies on "Unexpected non-whitespace character after JSON".
 *
 * It cost two lenses on a real customer run (`environments`, `mutation-proof`)
 * — the two with the most nuanced output, which is exactly where a model is
 * most likely to add a closing remark. The lens stayed unsettled and the
 * customer was charged in full.
 *
 * Braces inside string literals do not count, and `\"` inside a string does not
 * end it — a message like "saw ${VAR} in config" is ordinary interpreter
 * output, and a depth counter that ignored strings would end the object early.
 */
export function firstJsonObject(text) {
  const s = String(text ?? "");
  const start = s.indexOf("{");
  if (start === -1) return null;

  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < s.length; i += 1) {
    const ch = s[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') inString = true;
    else if (ch === "{") depth += 1;
    else if (ch === "}") {
      depth -= 1;
      if (depth === 0) return s.slice(start, i + 1);
    }
  }
  // Unbalanced — a truncated reply. Better to fail loudly than to guess where
  // the object was meant to end.
  return null;
}

export function parseInterpreterResult(text, repoPath) {
  const candidate = firstJsonObject(text);
  if (!candidate) throw new Error("interpreter returned no JSON object");
  let parsed;
  try {
    parsed = JSON.parse(candidate);
  } catch (error) {
    throw new Error(`interpreter returned unparseable JSON: ${String(error?.message ?? error).slice(0, 120)}`);
  }
  const ruling = parsed.ruling;
  if (!["findings", "clean", "cannot-tell"].includes(ruling)) {
    throw new Error(`interpreter returned an unknown ruling: ${JSON.stringify(ruling).slice(0, 80)}`);
  }
  // A clean or cannot-tell verdict with no reason is how a lens quietly stops
  // being audited -- the same rule the judge is held to for a downgrade.
  if (ruling !== "findings" && !String(parsed.why ?? "").trim()) {
    throw new Error(`interpreter ruled "${ruling}" with no reason`);
  }

  const findings = [];
  const refused = [];
  for (const row of Array.isArray(parsed.findings) ? parsed.findings : []) {
    const location = String(row?.location ?? "").trim();
    const bare = location.replace(/^\.\//, "").replace(/:\d+(?:-\d+)?$/, "");
    // The location is model-written. Absolute paths, `..` segments and symlinks
    // that leave the repo are refused, not just "does not exist".
    if (!bare || !resolveInside(repoPath, bare)) {
      refused.push({ ...row, refusedBecause: "location does not exist inside the repository" });
      continue;
    }
    if (!String(row?.criterion ?? "").trim()) {
      refused.push({ ...row, refusedBecause: "no rubric criterion named" });
      continue;
    }
    findings.push({
      severity: ["critical", "high", "medium", "low"].includes(row.severity) ? row.severity : "medium",
      location,
      message: `${String(row.message ?? "").trim()} (${String(row.criterion).trim()})`,
      source: "interpreter",
    });
  }
  return { ruling: findings.length === 0 && ruling === "findings" ? "cannot-tell" : ruling, why: parsed.why ?? null, findings, refused };
}
